package a;

import com.syncleoiot.transport.core.models.DeviceToken;
import com.syncleoiot.core.infrastructure.history.HistoryRepositoryImpl;
import kotlin.coroutines.jvm.internal.d;

public final class a extends d
{
    public long A;
    public Object B;
    public final HistoryRepositoryImpl C;
    public int H;
    public HistoryRepositoryImpl y;
    public DeviceToken z;
    
    public a(final HistoryRepositoryImpl c, final P8.d d) {
        this.C = c;
        super(d);
    }
    
    public final Object invokeSuspend(final Object b) {
        this.B = b;
        this.H |= Integer.MIN_VALUE;
        return HistoryRepositoryImpl.access$deleteData(this.C, (DeviceToken)null, 0L, (P8.d)this);
    }
}
