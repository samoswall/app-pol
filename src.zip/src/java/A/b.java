package a;

import r9.a;
import com.syncleoiot.core.infrastructure.history.HistoryRepositoryImpl;
import K8.u;
import java.io.Serializable;
import kotlin.coroutines.jvm.internal.d;

public final class b extends d
{
    public Serializable A;
    public Object B;
    public u C;
    public long H;
    public Object L;
    public final HistoryRepositoryImpl M;
    public int Q;
    public Object y;
    public a z;
    
    public b(final HistoryRepositoryImpl m, final P8.d d) {
        this.M = m;
        super(d);
    }
    
    public final Object invokeSuspend(final Object l) {
        this.L = l;
        this.Q |= Integer.MIN_VALUE;
        return this.M.deleteHistory(0L, (P8.d)this);
    }
}
