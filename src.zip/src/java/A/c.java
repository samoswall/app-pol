package a;

import java.util.List;
import com.syncleoiot.core.infrastructure.history.HistoryRepositoryImpl;
import r9.a;
import kotlin.coroutines.jvm.internal.d;

public final class c extends d
{
    public a A;
    public Object B;
    public final HistoryRepositoryImpl C;
    public int H;
    public Object y;
    public List z;
    
    public c(final HistoryRepositoryImpl c, final P8.d d) {
        this.C = c;
        super(d);
    }
    
    public final Object invokeSuspend(final Object b) {
        this.B = b;
        this.H |= Integer.MIN_VALUE;
        return this.C.deleteLocalHistory((List)null, (P8.d)this);
    }
}
