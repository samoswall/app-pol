package a;

import com.syncleoiot.core.infrastructure.history.HistoryRepositoryImpl;
import com.syncleoiot.transport.core.models.DeviceToken;

public final class d extends kotlin.coroutines.jvm.internal.d
{
    public DeviceToken A;
    public Long B;
    public Object C;
    public final HistoryRepositoryImpl H;
    public int L;
    public Object y;
    public String z;
    
    public d(final HistoryRepositoryImpl h, final P8.d d) {
        this.H = h;
        super(d);
    }
    
    public final Object invokeSuspend(final Object c) {
        this.C = c;
        this.L |= Integer.MIN_VALUE;
        return HistoryRepositoryImpl.access$loadData(this.H, (String)null, (DeviceToken)null, (Long)null, (P8.d)this);
    }
}
