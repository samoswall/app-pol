package a;

import com.syncleoiot.core.infrastructure.history.HistoryRepositoryImpl;
import com.syncleoiot.core.domain.core.failures.CommonFailure;
import com.syncleoiot.core.data.model.DeviceHistory;
import com.syncleoiot.transport.core.models.DeviceToken;
import kotlin.coroutines.jvm.internal.d;

public final class e extends d
{
    public Object A;
    public DeviceToken B;
    public Long C;
    public Long H;
    public DeviceHistory L;
    public CommonFailure M;
    public Long Q;
    public Object W;
    public final HistoryRepositoryImpl X;
    public int Y;
    public Object y;
    public Object z;
    
    public e(final HistoryRepositoryImpl x, final P8.d d) {
        this.X = x;
        super(d);
    }
    
    public final Object invokeSuspend(final Object w) {
        this.W = w;
        this.Y |= Integer.MIN_VALUE;
        return this.X.loadHistory((Long)null, (P8.d)this);
    }
}
