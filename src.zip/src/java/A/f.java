package a;

import com.syncleoiot.core.infrastructure.history.HistoryRepositoryImpl;
import kotlin.coroutines.jvm.internal.d;

public final class f extends d
{
    public Object A;
    public String B;
    public long C;
    public Object H;
    public final HistoryRepositoryImpl L;
    public int M;
    public Object y;
    public Object z;
    
    public f(final HistoryRepositoryImpl l, final P8.d d) {
        this.L = l;
        super(d);
    }
    
    public final Object invokeSuspend(final Object h) {
        this.H = h;
        this.M |= Integer.MIN_VALUE;
        return this.L.loadNextPage((P8.d)this);
    }
}
