package a0;

import W.e;
import V.q;
import L8.t;
import java.util.Collection;
import b0.L;
import androidx.compose.foundation.lazy.layout.d$b;
import x0.b;

final class a implements A
{
    private final int a;
    private int b;
    private final b c;
    private boolean d;
    
    public a(final int a) {
        this.a = a;
        this.b = -1;
        this.c = new b((Object[])new d$b[16], 0);
    }
    
    @Override
    public void a(final L l, final int n) {
        for (int a = this.a, i = 0; i < a; ++i) {
            l.a(n + i);
        }
    }
    
    @Override
    public void c(final z z, final float n, final s s) {
        if (!((Collection)s.k()).isEmpty()) {
            final int n2 = 0;
            final int n3 = 0;
            final boolean d = n < 0.0f;
            int b;
            int n4;
            if (d) {
                final k k = (k)t.v0(s.k());
                if (s.f() == q.Vertical) {
                    b = k.a();
                }
                else {
                    b = k.m();
                }
                ++b;
                n4 = ((k)t.v0(s.k())).getIndex() + 1;
            }
            else {
                final k i = (k)t.k0(s.k());
                if (s.f() == q.Vertical) {
                    b = i.a();
                }
                else {
                    b = i.m();
                }
                --b;
                n4 = ((k)t.k0(s.k())).getIndex() - 1;
            }
            if (n4 >= 0 && n4 < s.i()) {
                if (b != this.b) {
                    if (this.d != d) {
                        final b c = this.c;
                        final int q = c.q();
                        if (q > 0) {
                            final Object[] p3 = c.p();
                            int n5 = 0;
                            do {
                                ((d$b)p3[n5]).cancel();
                            } while (++n5 < q);
                        }
                    }
                    this.d = d;
                    this.b = b;
                    this.c.k();
                    final b c2 = this.c;
                    c2.f(c2.q(), z.a(b));
                }
                if (d) {
                    final k j = (k)t.v0(s.k());
                    if (e.a(j, s.f()) + e.b(j, s.f()) + s.j() - s.e() < -n) {
                        final b c3 = this.c;
                        final int q2 = c3.q();
                        if (q2 > 0) {
                            final Object[] p4 = c3.p();
                            int n6 = n3;
                            do {
                                ((d$b)p4[n6]).b();
                            } while (++n6 < q2);
                        }
                    }
                }
                else if (s.h() - e.a((k)t.k0(s.k()), s.f()) < n) {
                    final b c4 = this.c;
                    final int q3 = c4.q();
                    if (q3 > 0) {
                        final Object[] p5 = c4.p();
                        int n7 = n2;
                        do {
                            ((d$b)p5[n7]).b();
                        } while (++n7 < q3);
                    }
                }
            }
        }
    }
    
    @Override
    public void d(final z z, final s s) {
        if (this.b != -1 && !((Collection)s.k()).isEmpty()) {
            int n;
            if (this.d) {
                final k k = (k)t.v0(s.k());
                if (s.f() == q.Vertical) {
                    n = k.a();
                }
                else {
                    n = k.m();
                }
                ++n;
            }
            else {
                final k i = (k)t.k0(s.k());
                if (s.f() == q.Vertical) {
                    n = i.a();
                }
                else {
                    n = i.m();
                }
                --n;
            }
            if (this.b != n) {
                this.b = -1;
                final b c = this.c;
                final int q = c.q();
                if (q > 0) {
                    final Object[] p2 = c.p();
                    int n2 = 0;
                    do {
                        ((d$b)p2[n2]).cancel();
                    } while (++n2 < q);
                }
                this.c.k();
            }
        }
    }
}
