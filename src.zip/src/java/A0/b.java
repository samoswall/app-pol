package a0;

import kotlin.jvm.internal.m;
import A1.h;
import java.util.List;
import A1.d;

public interface b
{
    List a(final d p0, final int p1, final int p2);
    
    public static final class a implements b
    {
        private final float a;
        
        private a(final float a) {
            this.a = a;
            if (h.h(a, h.i((float)0)) > 0) {
                return;
            }
            final StringBuilder sb = new StringBuilder();
            sb.append("Provided min size ");
            sb.append((Object)h.m(a));
            sb.append(" should be larger than zero.");
            throw new IllegalArgumentException(sb.toString().toString());
        }
        
        @Override
        public List a(final d d, final int n, final int n2) {
            return a0.h.b(n, Math.max((n + n2) / (d.p1(this.a) + n2), 1), n2);
        }
        
        @Override
        public boolean equals(final Object o) {
            return o instanceof a && h.k(this.a, ((a)o).a);
        }
        
        @Override
        public int hashCode() {
            return h.l(this.a);
        }
    }
    
    public static final class b implements a0.b
    {
        private final int a;
        
        public b(final int a) {
            this.a = a;
            if (a > 0) {
                return;
            }
            final StringBuilder sb = new StringBuilder();
            sb.append("Provided count ");
            sb.append(a);
            sb.append(" should be larger than zero");
            throw new IllegalArgumentException(sb.toString().toString());
        }
        
        @Override
        public List a(final d d, final int n, final int n2) {
            return a0.h.b(n, this.a, n2);
        }
        
        @Override
        public boolean equals(final Object o) {
            return o instanceof b && this.a == ((b)o).a;
        }
        
        @Override
        public int hashCode() {
            return -this.a;
        }
    }
}
