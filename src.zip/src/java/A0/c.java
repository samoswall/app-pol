package a0;

public final class c
{
    private final long a = a;
    
    public static long b(final long n) {
        return n;
    }
    
    public static boolean c(final long n, final Object o) {
        return o instanceof c && n == ((c)o).g();
    }
    
    public static final int d(final long n) {
        return (int)n;
    }
    
    public static int e(final long n) {
        return Long.hashCode(n);
    }
    
    public static String f(final long n) {
        final StringBuilder sb = new StringBuilder();
        sb.append("GridItemSpan(packedValue=");
        sb.append(n);
        sb.append(')');
        return sb.toString();
    }
    
    @Override
    public boolean equals(final Object o) {
        return c(this.a, o);
    }
    
    public final /* synthetic */ long g() {
        return this.a;
    }
    
    @Override
    public int hashCode() {
        return e(this.a);
    }
    
    @Override
    public String toString() {
        return f(this.a);
    }
}
