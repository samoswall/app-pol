package a0;

import kotlin.jvm.internal.v;
import A1.b;
import A1.c;
import X8.p;

final class d implements F
{
    private final p a;
    private long b;
    private float c;
    private E d;
    
    public d(final p a) {
        this.a = a;
        this.b = A1.c.b(0, 0, 0, 0, 15, (Object)null);
    }
    
    @Override
    public E a(final A1.d d, final long b) {
        if (this.d != null && b.f(this.b, b) && this.c == d.getDensity()) {
            final E d2 = this.d;
            v.g((Object)d2);
            return d2;
        }
        this.b = b;
        this.c = d.getDensity();
        return this.d = (E)this.a.invoke((Object)d, (Object)b.a(b));
    }
}
