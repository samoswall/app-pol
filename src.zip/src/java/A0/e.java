package a0;

import A1.n;
import V.v;
import L8.t;
import K8.M;
import Q8.b;
import T.G;
import V.y;
import P8.d;
import X8.p;
import A1.r;
import java.util.List;
import kotlin.jvm.internal.w;
import X8.l;
import V.q;
import b0.h;

public final class e implements h
{
    private final I a;
    
    public e(final I a) {
        this.a = a;
    }
    
    private final int h(final s s) {
        final boolean b = s.f() == q.Vertical;
        final List k = s.k();
        final l l = (l)new l(b, k) {
            final boolean H;
            final List L;
            
            public final Integer a(int n) {
                final boolean h = this.H;
                final k k = (k)this.L.get(n);
                if (h) {
                    n = k.a();
                }
                else {
                    n = k.m();
                }
                return n;
            }
        };
        int i = 0;
        int n2;
        int n = n2 = 0;
        while (i < k.size()) {
            final int intValue = ((Number)((l)l).invoke((Object)i)).intValue();
            if (intValue == -1) {
                ++i;
            }
            else {
                int max = 0;
                while (i < k.size() && ((Number)((l)l).invoke((Object)i)).intValue() == intValue) {
                    int n3;
                    if (b) {
                        n3 = r.f(((k)k.get(i)).b());
                    }
                    else {
                        n3 = r.g(((k)k.get(i)).b());
                    }
                    max = Math.max(max, n3);
                    ++i;
                }
                n += max;
                ++n2;
            }
        }
        return n / n2 + s.j();
    }
    
    @Override
    public int a() {
        return this.a.s().i();
    }
    
    @Override
    public Object b(final p p2, final d d) {
        final Object a = y.a(this.a, null, p2, d, 1, null);
        if (a == b.f()) {
            return a;
        }
        return M.a;
    }
    
    @Override
    public int c() {
        final k k = (k)t.w0(this.a.s().k());
        int index;
        if (k != null) {
            index = k.getIndex();
        }
        else {
            index = 0;
        }
        return index;
    }
    
    @Override
    public int d() {
        return this.a.p();
    }
    
    @Override
    public void e(final v v, final int n, final int n2) {
        this.a.I(n, n2, true);
    }
    
    @Override
    public float f(int n) {
        final s s = this.a.s();
        if (s.k().isEmpty()) {
            return 0.0f;
        }
        final List k = s.k();
        final int size = k.size();
        final int n2 = 0;
        while (true) {
            for (int i = 0; i < size; ++i) {
                final Object value = k.get(i);
                if (((k)value).getIndex() == n) {
                    final k j = (k)value;
                    float n6;
                    if (j == null) {
                        final int b = this.a.B();
                        final int h = this.h(s);
                        final int g = this.g();
                        final int n3 = 1;
                        int n4 = n2;
                        if (n < g) {
                            n4 = 1;
                        }
                        final int g2 = this.g();
                        int n5 = n3;
                        if (n4 != 0) {
                            n5 = -1;
                        }
                        n6 = h * ((n - g2 + (b - 1) * n5) / b) - (float)this.d();
                    }
                    else {
                        if (s.f() == q.Vertical) {
                            n = n.k(j.l());
                        }
                        else {
                            n = n.j(j.l());
                        }
                        n6 = (float)n;
                    }
                    return n6;
                }
            }
            final Object value = null;
            continue;
        }
    }
    
    @Override
    public int g() {
        return this.a.o();
    }
}
