package a0;

import v0.p;
import v0.m;

public abstract class f
{
    public static final b0.m a(final I i, final m m, int n) {
        if (p.J()) {
            p.S(2004349821, n, -1, "androidx.compose.foundation.lazy.grid.rememberLazyGridBeyondBoundsState (LazyGridBeyondBoundsModifier.kt:23)");
        }
        if ((((n & 0xE) ^ 0x6) > 4 && m.Y((Object)i)) || (n & 0x6) == 0x4) {
            n = 1;
        }
        else {
            n = 0;
        }
        final Object g = m.g();
        g g2;
        if (n != 0 || (g2 = (g)g) == m.a.a()) {
            g2 = new g(i);
            m.P((Object)g2);
        }
        final g g3 = g2;
        if (p.J()) {
            p.R();
        }
        return g3;
    }
}
