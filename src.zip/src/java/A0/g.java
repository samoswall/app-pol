package a0;

import java.util.Collection;
import e1.W;
import L8.t;
import b0.m;

public final class g implements m
{
    private final I a;
    
    public g(final I a) {
        this.a = a;
    }
    
    @Override
    public int a() {
        return this.a.s().i();
    }
    
    @Override
    public int b() {
        return ((k)t.v0(this.a.s().k())).getIndex();
    }
    
    @Override
    public void c() {
        final W y = this.a.y();
        if (y != null) {
            y.k();
        }
    }
    
    @Override
    public boolean d() {
        return ((Collection)this.a.s().k()).isEmpty() ^ true;
    }
    
    @Override
    public int e() {
        return this.a.o();
    }
}
