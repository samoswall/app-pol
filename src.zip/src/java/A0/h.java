package a0;

import java.util.Collection;
import A1.t;
import A1.d;
import java.util.ArrayList;
import java.util.List;
import v0.b1;
import K8.M;
import v0.P0;
import kotlin.jvm.internal.w;
import V.x;
import androidx.compose.foundation.layout.p;
import v0.m;
import X8.l;
import V.n;
import Y.A;
import androidx.compose.ui.e;

public abstract class h
{
    public static final void a(final b b, e a, I b2, A a2, boolean b3, Y.b.m m, Y.b.e g, n a3, boolean b4, final l l, final m i, final int n, final int n2) {
        final m v = i.v(1485410512);
        int n3;
        if ((n2 & 0x1) != 0x0) {
            n3 = (n | 0x6);
        }
        else if ((n & 0x6) == 0x0) {
            int n4;
            if (v.Y((Object)b)) {
                n4 = 4;
            }
            else {
                n4 = 2;
            }
            n3 = (n4 | n);
        }
        else {
            n3 = n;
        }
        final int n5 = n2 & 0x2;
        int n8 = 0;
        Label_0136: {
            int n6;
            if (n5 != 0) {
                n6 = (n3 | 0x30);
            }
            else {
                n6 = n3;
                if ((n & 0x30) == 0x0) {
                    int n7;
                    if (v.Y((Object)a)) {
                        n7 = 32;
                    }
                    else {
                        n7 = 16;
                    }
                    n8 = (n3 | n7);
                    break Label_0136;
                }
            }
            n8 = n6;
        }
        if ((n & 0x180) == 0x0) {
            int n9;
            if ((n2 & 0x4) == 0x0 && v.Y((Object)b2)) {
                n9 = 256;
            }
            else {
                n9 = 128;
            }
            n8 |= n9;
        }
        final int n10 = n2 & 0x8;
        int n13 = 0;
        Label_0257: {
            int n11;
            if (n10 != 0) {
                n11 = (n8 | 0xC00);
            }
            else {
                n11 = n8;
                if ((n & 0xC00) == 0x0) {
                    int n12;
                    if (v.Y((Object)a2)) {
                        n12 = 2048;
                    }
                    else {
                        n12 = 1024;
                    }
                    n13 = (n8 | n12);
                    break Label_0257;
                }
            }
            n13 = n11;
        }
        final int n14 = n2 & 0x10;
        int n15;
        if (n14 != 0) {
            n15 = (n13 | 0x6000);
        }
        else {
            n15 = n13;
            if ((n & 0x6000) == 0x0) {
                int n16;
                if (v.d(b3)) {
                    n16 = 16384;
                }
                else {
                    n16 = 8192;
                }
                n15 = (n13 | n16);
            }
        }
        if ((n & 0x30000) == 0x0) {
            int n17;
            if ((n2 & 0x20) == 0x0 && v.Y((Object)m)) {
                n17 = 131072;
            }
            else {
                n17 = 65536;
            }
            n15 |= n17;
        }
        final int n18 = n2 & 0x40;
        int n19;
        if (n18 != 0) {
            n19 = (n15 | 0x180000);
        }
        else {
            n19 = n15;
            if ((n & 0x180000) == 0x0) {
                int n20;
                if (v.Y((Object)g)) {
                    n20 = 1048576;
                }
                else {
                    n20 = 524288;
                }
                n19 = (n15 | n20);
            }
        }
        int n22;
        if ((n & 0xC00000) == 0x0) {
            int n21;
            if ((n2 & 0x80) == 0x0 && v.Y((Object)a3)) {
                n21 = 8388608;
            }
            else {
                n21 = 4194304;
            }
            n22 = (n19 | n21);
        }
        else {
            n22 = n19;
        }
        final int n23 = n2 & 0x100;
        int n24;
        if (n23 != 0) {
            n24 = (n22 | 0x6000000);
        }
        else {
            n24 = n22;
            if ((n & 0x6000000) == 0x0) {
                int n25;
                if (v.d(b4)) {
                    n25 = 67108864;
                }
                else {
                    n25 = 33554432;
                }
                n24 = (n22 | n25);
            }
        }
        int n28 = 0;
        Label_0622: {
            int n26;
            if ((n2 & 0x200) != 0x0) {
                n26 = (n24 | 0x30000000);
            }
            else {
                n26 = n24;
                if ((n & 0x30000000) == 0x0) {
                    int n27;
                    if (v.m((Object)l)) {
                        n27 = 536870912;
                    }
                    else {
                        n27 = 268435456;
                    }
                    n28 = (n24 | n27);
                    break Label_0622;
                }
            }
            n28 = n26;
        }
        n n29;
        Y.b.m k;
        if ((n28 & 0x12492493) == 0x12492492 && v.y()) {
            v.G();
            final Y.b.m j = m;
            n29 = a3;
            k = j;
        }
        else {
            v.u();
            boolean b5;
            boolean b6;
            if ((n & 0x1) != 0x0 && !v.M()) {
                v.G();
                int n30 = n28;
                if ((n2 & 0x4) != 0x0) {
                    n30 = (n28 & 0xFFFFFC7F);
                }
                int n31 = n30;
                if ((n2 & 0x20) != 0x0) {
                    n31 = (n30 & 0xFFF8FFFF);
                }
                int n32 = n31;
                if ((n2 & 0x80) != 0x0) {
                    n32 = (n31 & 0xFE3FFFFF);
                }
                b5 = b3;
                b6 = b4;
                n28 = n32;
            }
            else {
                if (n5 != 0) {
                    a = (e)e.a;
                }
                b5 = false;
                if ((n2 & 0x4) != 0x0) {
                    b2 = J.b(0, 0, v, 0, 3);
                    n28 &= 0xFFFFFC7F;
                }
                if (n10 != 0) {
                    a2 = p.a(A1.h.i((float)0));
                }
                if (n14 == 0) {
                    b5 = b3;
                }
                if ((n2 & 0x20) != 0x0) {
                    final Y.b a4 = Y.b.a;
                    if (!b5) {
                        m = a4.h();
                    }
                    else {
                        m = a4.a();
                    }
                    n28 &= 0xFFF8FFFF;
                }
                if (n18 != 0) {
                    g = Y.b.a.g();
                }
                if ((n2 & 0x80) != 0x0) {
                    a3 = x.a.a(v, 6);
                    n28 &= 0xFE3FFFFF;
                }
                if (n23 != 0) {
                    b6 = true;
                }
                else {
                    b6 = b4;
                }
            }
            v.W();
            if (v0.p.J()) {
                v0.p.S(1485410512, n28, -1, "androidx.compose.foundation.lazy.grid.LazyVerticalGrid (LazyGridDsl.kt:73)");
            }
            final int n33 = n28 >> 3;
            final F d = d(b, g, a2, v, (n28 & 0xE) | (n28 >> 15 & 0x70) | (n33 & 0x380));
            final int n34 = n28 << 9;
            r.a(a, b2, d, a2, b5, true, a3, b6, m, g, l, v, (n28 & 0x1C00) | ((n33 & 0xE) | 0x30000 | (n33 & 0x70)) | (0xE000 & n28) | (0x380000 & n33) | (0x1C00000 & n33) | (0xE000000 & n34) | (n34 & 0x70000000), n28 >> 27 & 0xE, 0);
            if (v0.p.J()) {
                v0.p.R();
            }
            final Y.b.m m2 = m;
            n29 = a3;
            b4 = b6;
            k = m2;
            b3 = b5;
        }
        final b1 c = v.C();
        if (c != null) {
            c.a((X8.p)new X8.p(b, a, b2, a2, b3, k, g, n29, b4, l, n, n2) {
                final b H;
                final e L;
                final I M;
                final A Q;
                final boolean W;
                final Y.b.m X;
                final Y.b.e Y;
                final n Z;
                final boolean a0;
                final l b0;
                final int c0;
                final int d0;
                
                public final void a(final m m, final int n) {
                    h.a(this.H, this.L, this.M, this.Q, this.W, this.X, this.Y, this.Z, this.a0, this.b0, m, P0.a(this.c0 | 0x1), this.d0);
                }
            });
        }
    }
    
    private static final List c(int i, final int n, int n2) {
        final int n3 = i - n2 * (n - 1);
        final int n4 = n3 / n;
        final ArrayList list = new ArrayList(n);
        for (i = 0; i < n; ++i) {
            if (i < n3 % n) {
                n2 = 1;
            }
            else {
                n2 = 0;
            }
            list.add((Object)(n2 + n4));
        }
        return (List)list;
    }
    
    private static final F d(final b b, final Y.b.e e, final A a, final m m, final int n) {
        if (v0.p.J()) {
            v0.p.S(1632454918, n, -1, "androidx.compose.foundation.lazy.grid.rememberColumnWidthSums (LazyGridDsl.kt:148)");
        }
        boolean b2 = false;
        final boolean b3 = (((n & 0xE) ^ 0x6) > 4 && m.Y((Object)b)) || (n & 0x6) == 0x4;
        final boolean b4 = (((n & 0x70) ^ 0x30) > 32 && m.Y((Object)e)) || (n & 0x30) == 0x20;
        if ((((n & 0x380) ^ 0x180) > 256 && m.Y((Object)a)) || (n & 0x180) == 0x100) {
            b2 = true;
        }
        final Object g = m.g();
        F f;
        if ((b3 | b4 | b2) || (f = (F)g) == m.a.a()) {
            f = new a0.d((X8.p)new X8.p(a, b, e) {
                final A H;
                final b L;
                final Y.b.e M;
                
                public final E a(final d d, final long n) {
                    if (A1.b.l(n) != Integer.MAX_VALUE) {
                        final A h = this.H;
                        final t ltr = t.Ltr;
                        final int n2 = A1.b.l(n) - d.p1(A1.h.i(p.g(h, ltr) + p.f(this.H, ltr)));
                        final b l = this.L;
                        final Y.b.e m = this.M;
                        final int[] t0 = L8.t.T0((Collection)l.a(d, n2, d.p1(m.a())));
                        final int[] array = new int[t0.length];
                        m.c(d, n2, t0, ltr, array);
                        return new E(t0, array);
                    }
                    throw new IllegalArgumentException("LazyVerticalGrid's width should be bound by parent.");
                }
            });
            m.P((Object)f);
        }
        final F f2 = f;
        if (v0.p.J()) {
            v0.p.R();
        }
        return f2;
    }
}
