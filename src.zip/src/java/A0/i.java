package a0;

import X8.r;
import X8.p;
import X8.l;
import b0.o;

public final class i implements a
{
    private final l a;
    private final p b;
    private final l c;
    private final r d;
    
    public i(final l a, final p b, final l c, final r d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public final r a() {
        return this.d;
    }
    
    public final p b() {
        return this.b;
    }
    
    @Override
    public l getKey() {
        return this.a;
    }
    
    @Override
    public l getType() {
        return this.c;
    }
}
