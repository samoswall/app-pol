package a0;

import b0.d;
import K8.M;
import X8.r;
import kotlin.jvm.internal.w;
import X8.q;
import X8.l;
import kotlin.jvm.internal.m;
import b0.J;
import X8.p;
import b0.o;

public final class j extends o implements C
{
    private static final b d;
    public static final int e;
    private static final p f;
    private final H a;
    private final J b;
    private boolean c;
    
    static {
        d = new b(null);
        e = 8;
        f = (p)j$a.H;
    }
    
    public j(final l l) {
        this.a = new H(this);
        this.b = new J();
        l.invoke((Object)this);
    }
    
    @Override
    public void c(final Object o, final l l, final Object o2, final q q) {
        final J n = this.n();
        Object o3;
        if (o != null) {
            o3 = new l(o) {
                final Object H;
                
                public final Object invoke(final int n) {
                    return this.H;
                }
            };
        }
        else {
            o3 = null;
        }
        Object f;
        if (l != null) {
            f = new p(l) {
                final l H;
                
                public final long invoke-_-orMbw(final a0.q q, final int n) {
                    return ((c)this.H.invoke((Object)q)).g();
                }
            };
        }
        else {
            f = j.f;
        }
        n.c(1, (Object)new i((l)o3, (p)f, (l)new l(o2) {
            final Object H;
            
            public final Object invoke(final int n) {
                return this.H;
            }
        }, (r)D0.c.c(-34608120, true, (Object)new r(q) {
            final q H;
            
            public final void invoke(final a0.o o, int n, final v0.m m, final int n2) {
                n = n2;
                if ((n2 & 0x6) == 0x0) {
                    if (m.Y((Object)o)) {
                        n = 4;
                    }
                    else {
                        n = 2;
                    }
                    n |= n2;
                }
                if ((n & 0x83) == 0x82 && m.y()) {
                    m.G();
                }
                else {
                    if (v0.p.J()) {
                        v0.p.S(-34608120, n, -1, "androidx.compose.foundation.lazy.grid.LazyGridIntervalContent.item.<anonymous> (LazyGridIntervalContent.kt:49)");
                    }
                    this.H.invoke((Object)o, (Object)m, (Object)(n & 0xE));
                    if (v0.p.J()) {
                        v0.p.R();
                    }
                }
            }
        })));
        if (l != null) {
            this.c = true;
        }
    }
    
    @Override
    public void h(final int n, final l l, final p p5, final l i, final r r) {
        final J n2 = this.n();
        p f;
        if (p5 == null) {
            f = j.f;
        }
        else {
            f = p5;
        }
        n2.c(n, (Object)new i(l, f, i, r));
        if (p5 != null) {
            this.c = true;
        }
    }
    
    public final boolean m() {
        return this.c;
    }
    
    public J n() {
        return this.b;
    }
    
    public final H o() {
        return this.a;
    }
    
    private static final class b
    {
    }
}
