package a0;

public interface k
{
    int a();
    
    long b();
    
    int getIndex();
    
    long l();
    
    int m();
}
