package a0;

import androidx.compose.foundation.lazy.layout.c;
import b0.t;

public interface l extends t
{
    c c();
    
    H i();
}
