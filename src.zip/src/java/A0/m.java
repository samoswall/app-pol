package a0;

import v0.b1;
import v0.P0;
import b0.D;
import K8.M;
import b0.d$a;
import kotlin.jvm.internal.w;
import v0.p;
import kotlin.jvm.internal.v;
import androidx.compose.foundation.lazy.layout.c;

final class m implements l
{
    private final I a;
    private final j b;
    private final c c;
    
    public m(final I a, final j b, final c c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public static final /* synthetic */ j j(final m m) {
        return m.b;
    }
    
    @Override
    public int a() {
        return this.b.k();
    }
    
    @Override
    public Object b(final int n) {
        Object o;
        if ((o = this.c().b(n)) == null) {
            o = this.b.l(n);
        }
        return o;
    }
    
    @Override
    public c c() {
        return this.c;
    }
    
    @Override
    public int d(final Object o) {
        return this.c().d(o);
    }
    
    @Override
    public Object e(final int n) {
        return this.b.i(n);
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o instanceof m && v.e((Object)this.b, (Object)((m)o).b));
    }
    
    @Override
    public void h(final int n, final Object o, v0.m v, final int n2) {
        v = v.v(1493551140);
        int n4;
        if ((n2 & 0x6) == 0x0) {
            int n3;
            if (v.j(n)) {
                n3 = 4;
            }
            else {
                n3 = 2;
            }
            n4 = (n3 | n2);
        }
        else {
            n4 = n2;
        }
        int n5 = n4;
        if ((n2 & 0x30) == 0x0) {
            int n6;
            if (v.m(o)) {
                n6 = 32;
            }
            else {
                n6 = 16;
            }
            n5 = (n4 | n6);
        }
        int n7 = n5;
        if ((n2 & 0x180) == 0x0) {
            int n8;
            if (v.Y((Object)this)) {
                n8 = 256;
            }
            else {
                n8 = 128;
            }
            n7 = (n5 | n8);
        }
        if ((n7 & 0x93) == 0x92 && v.y()) {
            v.G();
        }
        else {
            if (p.J()) {
                p.S(1493551140, n7, -1, "androidx.compose.foundation.lazy.grid.LazyGridItemProviderImpl.Item (LazyGridItemProvider.kt:74)");
            }
            D.a(o, n, this.a.v(), (X8.p)D0.c.e(726189336, true, (Object)new X8.p(this, n) {
                final m H;
                final int L;
                
                public final void a(final v0.m m, int b) {
                    if ((b & 0x3) == 0x2 && m.y()) {
                        m.G();
                    }
                    else {
                        if (p.J()) {
                            p.S(726189336, b, -1, "androidx.compose.foundation.lazy.grid.LazyGridItemProviderImpl.Item.<anonymous> (LazyGridItemProvider.kt:76)");
                        }
                        final j j = m.j(this.H);
                        final int l = this.L;
                        final d$a value = j.j().get(l);
                        b = value.b();
                        ((i)value.c()).a().invoke((Object)a0.p.a, (Object)(l - b), (Object)m, (Object)6);
                        if (p.J()) {
                            p.R();
                        }
                    }
                }
            }, v, 54), v, (n7 >> 3 & 0xE) | 0xC00 | (n7 << 3 & 0x70));
            if (p.J()) {
                p.R();
            }
        }
        final b1 c = v.C();
        if (c != null) {
            c.a((X8.p)new X8.p(this, n, o, n2) {
                final m H;
                final int L;
                final Object M;
                final int Q;
                
                public final void a(final v0.m m, final int n) {
                    this.H.h(this.L, this.M, m, P0.a(this.Q | 0x1));
                }
            });
        }
    }
    
    @Override
    public int hashCode() {
        return this.b.hashCode();
    }
    
    @Override
    public H i() {
        return this.b.o();
    }
}
