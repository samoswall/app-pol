package a0;

import kotlin.jvm.internal.h;
import e9.k;
import kotlin.jvm.internal.G;
import androidx.compose.foundation.lazy.layout.c;
import b0.o;
import b0.K;
import v0.G1;
import kotlin.jvm.internal.w;
import v0.v1;
import v0.p;
import X8.a;
import v0.m;
import X8.l;

public abstract class n
{
    public static final a a(final I i, final l l, final m m, int n) {
        if (p.J()) {
            p.S(-1898306282, n, -1, "androidx.compose.foundation.lazy.grid.rememberLazyGridItemProviderLambda (LazyGridItemProvider.kt:40)");
        }
        final G1 n2 = v1.n((Object)l, m, n >> 3 & 0xE);
        if ((((n & 0xE) ^ 0x6) > 4 && m.Y((Object)i)) || (n & 0x6) == 0x4) {
            n = 1;
        }
        else {
            n = 0;
        }
        final Object g = m.g();
        Object o;
        if (n != 0 || (o = g) == m.a.a()) {
            o = new G(v1.e(v1.m(), (a)new a(v1.e(v1.m(), (a)new a(n2) {
                final G1 H;
                
                public final j a() {
                    return new j((l)this.H.getValue());
                }
            }), i) {
                final G1 H;
                final I L;
                
                public final a0.m a() {
                    final j j = (j)this.H.getValue();
                    return new a0.m(this.L, j, (c)new K(this.L.u(), (o)j));
                }
            }));
            m.P(o);
        }
        final k k = (k)o;
        if (p.J()) {
            p.R();
        }
        return (a)k;
    }
}
