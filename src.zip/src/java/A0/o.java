package a0;

import S.j;
import S.J0;
import A1.n;
import S.G;
import androidx.compose.ui.e;

public interface o
{
    e a(final e p0, final G p1, final G p2, final G p3);
    
    default e b(final e e, final G g) {
        return this.a(e, null, g, null);
    }
}
