package a0;

import androidx.compose.foundation.lazy.layout.LazyLayoutAnimateItemElement;
import S.G;
import androidx.compose.ui.e;

public final class p implements o
{
    public static final p a;
    
    static {
        a = new p();
    }
    
    private p() {
    }
    
    public e a(e f, final G g, final G g2, final G g3) {
        if (g != null || g2 != null || g3 != null) {
            f = f.f((e)new LazyLayoutAnimateItemElement(g, g2, g3));
        }
        return f;
    }
}
