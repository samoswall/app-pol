package a0;

public interface q
{
}
