package a0;

import G0.k$a;
import L8.P;
import e1.G;
import G0.k;
import java.util.ArrayList;
import java.util.List;
import A1.o;
import A1.c;
import T.j;
import v0.b1;
import X8.a;
import K8.M;
import v0.P0;
import b0.w;
import V.d;
import V.y;
import x0.b;
import A1.t;
import androidx.compose.foundation.lazy.layout.f;
import V.q;
import v0.v;
import androidx.compose.ui.platform.f0;
import P0.V;
import v0.B;
import P8.g;
import v0.Q;
import V.x;
import androidx.compose.foundation.layout.p;
import A1.h;
import v0.m;
import X8.l;
import Y.b$e;
import Y.b$m;
import V.n;
import Y.A;
import androidx.compose.ui.e;

public abstract class r
{
    public static final void a(e a, final I i, final F f, A a2, boolean b, final boolean b2, n a3, final boolean b3, final b$m b$m, final b$e b$e, final l l, final m m, final int n, final int n2, final int n3) {
        final m v = m.v(-649686062);
        final int n4 = n3 & 0x1;
        int n5;
        if (n4 != 0) {
            n5 = (n | 0x6);
        }
        else if ((n & 0x6) == 0x0) {
            int n6;
            if (v.Y((Object)a)) {
                n6 = 4;
            }
            else {
                n6 = 2;
            }
            n5 = (n6 | n);
        }
        else {
            n5 = n;
        }
        int n7;
        if ((n3 & 0x2) != 0x0) {
            n7 = (n5 | 0x30);
        }
        else {
            n7 = n5;
            if ((n & 0x30) == 0x0) {
                int n8;
                if (v.Y((Object)i)) {
                    n8 = 32;
                }
                else {
                    n8 = 16;
                }
                n7 = (n5 | n8);
            }
        }
        int n9;
        if ((n3 & 0x4) != 0x0) {
            n9 = (n7 | 0x180);
        }
        else {
            n9 = n7;
            if ((n & 0x180) == 0x0) {
                boolean b4;
                if ((n & 0x200) == 0x0) {
                    b4 = v.Y((Object)f);
                }
                else {
                    b4 = v.m((Object)f);
                }
                int n10;
                if (b4) {
                    n10 = 256;
                }
                else {
                    n10 = 128;
                }
                n9 = (n7 | n10);
            }
        }
        final int n11 = n3 & 0x8;
        int n14 = 0;
        Label_0291: {
            int n12;
            if (n11 != 0) {
                n12 = (n9 | 0xC00);
            }
            else {
                n12 = n9;
                if ((n & 0xC00) == 0x0) {
                    int n13;
                    if (v.Y((Object)a2)) {
                        n13 = 2048;
                    }
                    else {
                        n13 = 1024;
                    }
                    n14 = (n9 | n13);
                    break Label_0291;
                }
            }
            n14 = n12;
        }
        final int n15 = n3 & 0x10;
        int n16;
        if (n15 != 0) {
            n16 = (n14 | 0x6000);
        }
        else {
            n16 = n14;
            if ((n & 0x6000) == 0x0) {
                int n17;
                if (v.d(b)) {
                    n17 = 16384;
                }
                else {
                    n17 = 8192;
                }
                n16 = (n14 | n17);
            }
        }
        int n18;
        if ((n3 & 0x20) != 0x0) {
            n18 = (n16 | 0x30000);
        }
        else {
            n18 = n16;
            if ((n & 0x30000) == 0x0) {
                int n19;
                if (v.d(b2)) {
                    n19 = 131072;
                }
                else {
                    n19 = 65536;
                }
                n18 = (n16 | n19);
            }
        }
        if ((n & 0x180000) == 0x0) {
            int n20;
            if ((n3 & 0x40) == 0x0 && v.Y((Object)a3)) {
                n20 = 1048576;
            }
            else {
                n20 = 524288;
            }
            n18 |= n20;
        }
        int n23 = 0;
        Label_0533: {
            int n21;
            if ((n3 & 0x80) != 0x0) {
                n21 = (n18 | 0xC00000);
            }
            else {
                n21 = n18;
                if ((n & 0xC00000) == 0x0) {
                    int n22;
                    if (v.d(b3)) {
                        n22 = 8388608;
                    }
                    else {
                        n22 = 4194304;
                    }
                    n23 = (n18 | n22);
                    break Label_0533;
                }
            }
            n23 = n21;
        }
        int n26 = 0;
        Label_0598: {
            int n24;
            if ((n3 & 0x100) != 0x0) {
                n24 = (n23 | 0x6000000);
            }
            else {
                n24 = n23;
                if ((n & 0x6000000) == 0x0) {
                    int n25;
                    if (v.Y((Object)b$m)) {
                        n25 = 67108864;
                    }
                    else {
                        n25 = 33554432;
                    }
                    n26 = (n23 | n25);
                    break Label_0598;
                }
            }
            n26 = n24;
        }
        int n29 = 0;
        Label_0663: {
            int n27;
            if ((n3 & 0x200) != 0x0) {
                n27 = (n26 | 0x30000000);
            }
            else {
                n27 = n26;
                if ((n & 0x30000000) == 0x0) {
                    int n28;
                    if (v.Y((Object)b$e)) {
                        n28 = 536870912;
                    }
                    else {
                        n28 = 268435456;
                    }
                    n29 = (n26 | n28);
                    break Label_0663;
                }
            }
            n29 = n27;
        }
        int n30;
        if ((n3 & 0x400) != 0x0) {
            n30 = (n2 | 0x6);
        }
        else if ((n2 & 0x6) == 0x0) {
            int n31;
            if (v.m((Object)l)) {
                n31 = 4;
            }
            else {
                n31 = 2;
            }
            n30 = (n2 | n31);
        }
        else {
            n30 = n2;
        }
        A a4;
        n n33;
        if ((n29 & 0x12492493) == 0x12492492 && (n30 & 0x3) == 0x2 && v.y()) {
            v.G();
            final n n32 = a3;
            a4 = a2;
            n33 = n32;
        }
        else {
            v.u();
            if ((n & 0x1) != 0x0 && !v.M()) {
                v.G();
                int n34 = n29;
                if ((n3 & 0x40) != 0x0) {
                    n34 = (n29 & 0xFFC7FFFF);
                }
                n29 = n34;
            }
            else {
                if (n4 != 0) {
                    a = (e)e.a;
                }
                if (n11 != 0) {
                    a2 = p.a(h.i((float)0));
                }
                if (n15 != 0) {
                    b = false;
                }
                if ((n3 & 0x40) != 0x0) {
                    a3 = x.a.a(v, 6);
                    n29 &= 0xFFC7FFFF;
                }
            }
            v.W();
            if (v0.p.J()) {
                v0.p.S(-649686062, n29, n30, "androidx.compose.foundation.lazy.grid.LazyGrid (LazyGrid.kt:77)");
            }
            final int n35 = n29 >> 3;
            final int n36 = n35 & 0xE;
            final a a5 = n.a(i, l, v, (n30 << 3 & 0x70) | n36);
            final int n37 = n29 >> 9;
            final b0.F a6 = K.a(i, b, v, (n37 & 0x70) | n36);
            Object g;
            if ((g = v.g()) == m.a.a()) {
                g = new B(Q.k((g)P8.h.a, v));
                v.P(g);
            }
            final X8.p b5 = b(a5, i, f, a2, b, b2, b$e, b$m, ((B)g).a(), (V)v.p((v)f0.h()), v, (0x7FFF0 & n29) | (n37 & 0x380000) | (0x1C00000 & n35));
            q q;
            if (b2) {
                q = V.q.Vertical;
            }
            else {
                q = V.q.Horizontal;
            }
            w.a(a5, T.V.a(b0.l.b(f.c(a.f((e)i.z()).f((e)i.m()), a5, a6, q, b3, b, v, (n37 & 0xE000) | (n29 << 3 & 0x70000)), f.a(i, v, n36), i.n(), b, (t)v.p((v)f0.k()), q, b3, v, b.d << 6 | (n35 & 0x1C00) | (0x380000 & n35)).f(i.r().j()), (y)i, q, b3, b, a3, i.q(), (d)null, v, (n29 & 0x70) | (n29 >> 12 & 0x1C00) | (n29 & 0xE000) | (0x70000 & n35), 64), i.x(), b5, v, 0, 0);
            if (v0.p.J()) {
                v0.p.R();
            }
            final A a7 = a2;
            n33 = a3;
            a4 = a7;
        }
        final b1 c = v.C();
        if (c != null) {
            c.a((X8.p)new X8.p(a, i, f, a4, b, b2, n33, b3, b$m, b$e, l, n, n2, n3) {
                final e H;
                final I L;
                final F M;
                final A Q;
                final boolean W;
                final boolean X;
                final n Y;
                final boolean Z;
                final b$m a0;
                final b$e b0;
                final l c0;
                final int d0;
                final int e0;
                final int f0;
                
                public final void a(final m m, final int n) {
                    r.a(this.H, this.L, this.M, this.Q, this.W, this.X, this.Y, this.Z, this.a0, this.b0, this.c0, m, P0.a(this.d0 | 0x1), P0.a(this.e0), this.f0);
                }
            });
        }
    }
    
    private static final X8.p b(final a a, final I i, final F f, final A a2, final boolean b, final boolean b2, final b$e b$e, final b$m b$m, final i9.M m, final V v, final m j, final int n) {
        if (v0.p.J()) {
            v0.p.S(-1585069765, n, -1, "androidx.compose.foundation.lazy.grid.rememberLazyGridMeasurePolicy (LazyGrid.kt:161)");
        }
        boolean b3 = false;
        final boolean b4 = (((n & 0x70) ^ 0x30) > 32 && j.Y((Object)i)) || (n & 0x30) == 0x20;
        final boolean b5 = (((n & 0x380) ^ 0x180) > 256 && j.Y((Object)f)) || (n & 0x180) == 0x100;
        final boolean b6 = (((n & 0x1C00) ^ 0xC00) > 2048 && j.Y((Object)a2)) || (n & 0xC00) == 0x800;
        final boolean b7 = (((0xE000 & n) ^ 0x6000) > 16384 && j.d(b)) || (n & 0x6000) == 0x4000;
        final boolean b8 = (((0x70000 & n) ^ 0x30000) > 131072 && j.d(b2)) || (n & 0x30000) == 0x20000;
        final boolean b9 = (((0x380000 & n) ^ 0x180000) > 1048576 && j.Y((Object)b$e)) || (n & 0x180000) == 0x100000;
        if ((((0x1C00000 & n) ^ 0xC00000) > 8388608 && j.Y((Object)b$m)) || (n & 0xC00000) == 0x800000) {
            b3 = true;
        }
        final boolean y = j.Y((Object)v);
        final Object g = j.g();
        Object o;
        if ((b4 | b5 | b6 | b7 | b8 | b9 | b3 | y) || (o = g) == m.a.a()) {
            o = new X8.p(i, b2, a2, b, a, f, b$m, b$e, m, v) {
                final I H;
                final boolean L;
                final A M;
                final boolean Q;
                final a W;
                final F X;
                final b$m Y;
                final b$e Z;
                final i9.M a0;
                final V b0;
                
                public final u a(final b0.x x, final long n) {
                    b0.M.a(this.H.t());
                    q q;
                    if (this.L) {
                        q = V.q.Vertical;
                    }
                    else {
                        q = V.q.Horizontal;
                    }
                    j.a(n, q);
                    int n2;
                    if (this.L) {
                        n2 = ((A1.d)x).p1(this.M.c(x.getLayoutDirection()));
                    }
                    else {
                        n2 = ((A1.d)x).p1(p.g(this.M, x.getLayoutDirection()));
                    }
                    int n3;
                    if (this.L) {
                        n3 = ((A1.d)x).p1(this.M.b(x.getLayoutDirection()));
                    }
                    else {
                        n3 = ((A1.d)x).p1(p.f(this.M, x.getLayoutDirection()));
                    }
                    int n4 = ((A1.d)x).p1(this.M.d());
                    final int p2 = ((A1.d)x).p1(this.M.a());
                    final int n5 = n4 + p2;
                    final int n6 = n2 + n3;
                    final boolean l = this.L;
                    int n7;
                    if (l) {
                        n7 = n5;
                    }
                    else {
                        n7 = n6;
                    }
                    if (l && !this.Q) {
                        n3 = n4;
                    }
                    else if (l && this.Q) {
                        n3 = p2;
                    }
                    else if (!l && !this.Q) {
                        n3 = n2;
                    }
                    final int n8 = n7 - n3;
                    final long o = c.o(n, -n6, -n5);
                    final a0.l i = (a0.l)this.W.invoke();
                    final H j = i.i();
                    final E a = this.X.a((A1.d)x, n);
                    final int length = a.b().length;
                    j.h(length);
                    float n9;
                    if (this.L) {
                        final b$m y = this.Y;
                        if (y == null) {
                            throw new IllegalArgumentException("null verticalArrangement when isVertical == true");
                        }
                        n9 = y.a();
                    }
                    else {
                        final b$e z = this.Z;
                        if (z == null) {
                            throw new IllegalArgumentException("null horizontalArrangement when isVertical == false");
                        }
                        n9 = z.a();
                    }
                    final int p3 = ((A1.d)x).p1(n9);
                    final int a2 = ((b0.t)i).a();
                    int n10;
                    if (this.L) {
                        n10 = A1.b.k(n) - n5;
                    }
                    else {
                        n10 = A1.b.l(n) - n6;
                    }
                    long n12;
                    if (this.Q && n10 <= 0) {
                        final boolean k = this.L;
                        if (!k) {
                            n2 += n10;
                        }
                        int n11 = n4;
                        if (k) {
                            n11 = n4 + n10;
                        }
                        n12 = A1.o.a(n2, n11);
                    }
                    else {
                        n12 = A1.o.a(n2, n4);
                    }
                    final a0.w w = new a0.w(i, x, p3, this.H, this.L, this.Q, n3, n8, n12) {
                        final b0.x d;
                        final I e;
                        final boolean f;
                        final boolean g;
                        final int h;
                        final int i;
                        final long j;
                        
                        @Override
                        public a0.v b(final int n, final Object o, final Object o2, final int n2, final int n3, final List list, final long n4, final int n5, final int n6) {
                            return new a0.v(n, o, this.f, n2, n3, this.g, this.d.getLayoutDirection(), this.h, this.i, list, this.j, o2, this.e.r(), n4, n5, n6, null);
                        }
                    };
                    final a0.y y2 = new a0.y(this.L, a, a2, p3, w, j) {
                        final boolean g;
                        final E h;
                        
                        @Override
                        public a0.x b(final int n, final a0.v[] array, final List list, final int n2) {
                            return new a0.x(n, array, this.h, list, this.g, n2);
                        }
                    };
                    final l m = (l)new l(j, y2) {
                        final H H;
                        final r$b$c L;
                        
                        public final ArrayList a(int i) {
                            final H$c c = this.H.c(i);
                            int a = c.a();
                            final ArrayList list = new ArrayList(c.b().size());
                            final List b = c.b();
                            final a0.y l = this.L;
                            final int size = b.size();
                            i = 0;
                            int n = 0;
                            while (i < size) {
                                final int d = a0.c.d(((a0.c)b.get(i)).g());
                                list.add((Object)K8.B.a((Object)a, (Object)A1.b.a(l.a(n, d))));
                                ++a;
                                n += d;
                                ++i;
                            }
                            return list;
                        }
                    };
                    final k$a e = k.e;
                    final I h = this.H;
                    final k d = e.d();
                    l h2;
                    if (d != null) {
                        h2 = d.h();
                    }
                    else {
                        h2 = null;
                    }
                    final k f = e.f(d);
                    Label_0857: {
                        Label_0706: {
                            try {
                                n2 = h.J(i, h.o());
                                if (n2 >= a2) {
                                    if (a2 > 0) {
                                        n2 = j.d(a2 - 1);
                                        n4 = 0;
                                        break Label_0706;
                                    }
                                }
                            }
                            finally {
                                break Label_0857;
                            }
                            n2 = j.d(n2);
                            n4 = h.p();
                        }
                        final M a3 = K8.M.a;
                        e.m(d, f, h2);
                        final b0.x x2;
                        final u d2 = a0.t.d(a2, y2, w, n10, n3, n8, p3, n2, n4, this.H.A(), o, this.L, this.Y, this.Z, this.Q, (A1.d)x2, this.H.r(), length, b0.n.a((b0.t)i, this.H.v(), this.H.n()), this.a0, this.H.w(), this.b0, (l)m, (X8.q)new X8.q(x2, n, n6, n5) {
                            final b0.x H;
                            final long L;
                            final int M;
                            final int Q;
                            
                            public final G a(final int n, final int n2, final l l) {
                                return this.H.c1(c.i(this.L, n + this.M), c.h(this.L, n2 + this.Q), P.j(), l);
                            }
                        });
                        I.l(this.H, d2, false, 2, (Object)null);
                        return d2;
                    }
                    e.m(d, f, h2);
                }
            };
            j.P(o);
        }
        final X8.p p12 = (X8.p)o;
        if (v0.p.J()) {
            v0.p.R();
        }
        return p12;
    }
}
