package a0;

import java.util.List;
import V.q;

public interface s
{
    long a();
    
    int d();
    
    int e();
    
    q f();
    
    int g();
    
    int h();
    
    int i();
    
    int j();
    
    List k();
}
