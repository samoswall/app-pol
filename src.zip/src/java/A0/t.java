package a0;

import java.util.Collection;
import L8.f;
import e1.U$a;
import L8.k;
import e1.G;
import A1.c;
import A1.r;
import b0.A;
import A1.b;
import X8.q;
import P0.V;
import v0.t0;
import i9.M;
import androidx.compose.foundation.lazy.layout.LazyLayoutItemAnimator;
import d9.j;
import d9.h;
import d9.n;
import L8.l;
import java.util.ArrayList;
import A1.d;
import Y.b$e;
import Y.b$m;
import java.util.List;

public abstract class t
{
    private static final void a(final List list, final Object[] array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            list.add(array[i]);
        }
    }
    
    private static final List b(final List list, final List list2, final List list3, final int n, final int n2, int i, int j, int n3, final boolean b, final b$m b$m, final b$e b$e, final boolean b2, final d d) {
        int n4;
        if (b) {
            n4 = n2;
        }
        else {
            n4 = n;
        }
        if (i < Math.min(n4, j)) {
            i = 1;
        }
        else {
            i = 0;
        }
        if (i != 0 && n3 != 0) {
            throw new IllegalStateException("non-zero firstLineScrollOffset");
        }
        final int size = list.size();
        j = 0;
        int n5 = 0;
        while (j < size) {
            n5 += ((x)list.get(j)).b().length;
            ++j;
        }
        final ArrayList list4 = new ArrayList(n5);
        if (i != 0) {
            if (!list2.isEmpty() || !list3.isEmpty()) {
                throw new IllegalArgumentException("no items");
            }
            final int size2 = list.size();
            final int[] array = new int[size2];
            for (i = 0; i < size2; ++i) {
                array[i] = ((x)list.get(c(i, b2, size2))).c();
            }
            final int[] array2 = new int[size2];
            for (i = 0; i < size2; ++i) {
                array2[i] = 0;
            }
            if (b) {
                if (b$m == null) {
                    throw new IllegalArgumentException("null verticalArrangement");
                }
                b$m.b(d, n4, array, array2);
            }
            else {
                if (b$e == null) {
                    throw new IllegalArgumentException("null horizontalArrangement");
                }
                b$e.c(d, n4, array, A1.t.Ltr, array2);
            }
            Object o;
            final j k = (j)(o = l.g0(array2));
            if (b2) {
                o = n.u((h)k);
            }
            j = ((h)o).q();
            final int s = ((h)o).s();
            final int u = ((h)o).u();
            if (u <= 0 || (i = j) > s) {
                if (u >= 0 || s > j) {
                    return (List)list4;
                }
                i = j;
            }
            while (true) {
                n3 = array2[i];
                final x x = (x)list.get(c(i, b2, size2));
                j = n3;
                if (b2) {
                    j = n4 - n3 - x.c();
                }
                a((List)list4, x.f(j, n, n2));
                if (i == s) {
                    break;
                }
                i += u;
            }
        }
        else {
            j = list2.size() - 1;
            if (j >= 0) {
                i = n3;
                while (true) {
                    final int n6 = j - 1;
                    final v v = (v)list2.get(j);
                    i -= v.f();
                    v.n(i, 0, n, n2);
                    list4.add((Object)v);
                    if (n6 < 0) {
                        break;
                    }
                    j = n6;
                }
            }
            final int size3 = list.size();
            i = n3;
            x x2;
            for (j = 0; j < size3; ++j) {
                x2 = (x)list.get(j);
                a((List)list4, x2.f(i, n, n2));
                i += x2.d();
            }
            final int size4 = list3.size();
            n3 = 0;
            j = i;
            v v2;
            for (i = n3; i < size4; ++i) {
                v2 = (v)list3.get(i);
                v2.n(j, 0, n, n2);
                list4.add((Object)v2);
                j += v2.f();
            }
        }
        return (List)list4;
    }
    
    private static final int c(int n, final boolean b, final int n2) {
        if (b) {
            n = n2 - n - 1;
        }
        return n;
    }
    
    public static final u d(int n, final y y, final w w, int i, int n2, final int n3, final int n4, int j, int n5, float n6, final long n7, final boolean b, final b$m b$m, final b$e b$e, final boolean b2, final d d, final LazyLayoutItemAnimator lazyLayoutItemAnimator, final int n8, List n9, final M m, final t0 t0, final V v, final X8.l l, final q q) {
        if (n2 < 0) {
            throw new IllegalArgumentException("negative beforeContentPadding");
        }
        if (n3 < 0) {
            throw new IllegalArgumentException("negative afterContentPadding");
        }
        if (n <= 0) {
            j = b.n(n7);
            n = b.m(n7);
            lazyLayoutItemAnimator.m(0, j, n, (List)new ArrayList(), w.e(), (A)w, b, false, n8, false, 0, 0, m, v);
            final long k = lazyLayoutItemAnimator.i();
            if (!r.e(k, r.b.a())) {
                j = c.i(n7, r.g(k));
                n = c.h(n7, r.f(k));
            }
            final G g = (G)q.invoke((Object)j, (Object)n, (Object)t$a.H);
            final List n10 = L8.t.n();
            n = -n2;
            V.q q2;
            if (b) {
                q2 = V.q.Vertical;
            }
            else {
                q2 = V.q.Horizontal;
            }
            return new u(null, 0, false, 0.0f, g, false, m, d, n8, l, n10, n, i + n3, 0, b2, q2, n3, n4);
        }
        final int round = Math.round(n6);
        final int n11 = n5 - round;
        n5 = round;
        int n12 = n11;
        if (j == 0) {
            n5 = round;
            if ((n12 = n11) < 0) {
                n5 = round + n11;
                n12 = 0;
            }
        }
        final k k2 = new k();
        final int n13 = -n2;
        int n14;
        if (n4 < 0) {
            n14 = n4;
        }
        else {
            n14 = 0;
        }
        final int n15 = n14 + n13;
        int n16;
        x c;
        for (n16 = n12 + n15; n16 < 0 && j > 0; n16 += c.d()) {
            --j;
            c = y.c(j);
            k2.add(0, (Object)c);
        }
        int n17 = n5;
        int n18;
        if ((n18 = n16) < n15) {
            n17 = n5 + n16;
            n18 = n15;
        }
        final int n19 = n18 - n15;
        final int n20 = i + n3;
        final int f = n.f(n20, 0);
        int n21 = -n19;
        n5 = j;
        int n22 = 0;
        boolean b3 = false;
        while (n22 < ((f)k2).size()) {
            if (n21 >= f) {
                ((f)k2).remove(n22);
                b3 = true;
            }
            else {
                ++n5;
                n21 += ((x)k2.get(n22)).d();
                ++n22;
            }
        }
        final int n23 = n5;
        n5 = n19;
        for (int n24 = n23, n25 = f; n24 < n && (n21 < n25 || n21 <= 0 || k2.isEmpty()); ++n24) {
            final x c2 = y.c(n24);
            if (c2.e()) {
                break;
            }
            n21 += c2.d();
            if (n21 <= n15 && ((v)l.P0((Object[])c2.b())).getIndex() != n - 1) {
                n5 -= c2.d();
                j = n24 + 1;
                b3 = true;
            }
            else {
                k2.add((Object)c2);
            }
        }
        if (n21 < i) {
            final int n26 = i - n21;
            final int n27 = n21 + n26;
            final int n28 = n5 - n26;
            x c3;
            for (n5 = j, j = n28; j < n2 && n5 > 0; j += c3.d()) {
                --n5;
                c3 = y.c(n5);
                k2.add(0, (Object)c3);
            }
            n17 += n26;
            if (j < 0) {
                n17 += j;
                n5 = n27 + j;
                j = 0;
            }
            else {
                n5 = n27;
            }
        }
        else {
            j = n5;
            n5 = n21;
        }
        if (Z8.b.a(Math.round(n6)) == Z8.b.a(n17) && Math.abs(Math.round(n6)) >= Math.abs(n17)) {
            n6 = (float)n17;
        }
        if (j >= 0) {
            final int n29 = -j;
            final x x = (x)k2.first();
            final v v2 = (v)l.f0((Object[])x.b());
            int index;
            if (v2 != null) {
                index = v2.getIndex();
            }
            else {
                index = 0;
            }
            final x x2 = (x)k2.w();
            int index2 = 0;
            Label_0858: {
                if (x2 != null) {
                    final v[] b4 = x2.b();
                    if (b4 != null) {
                        final v v3 = (v)l.S0((Object[])b4);
                        if (v3 != null) {
                            index2 = v3.getIndex();
                            break Label_0858;
                        }
                    }
                }
                index2 = 0;
            }
            final int size = n9.size();
            final List list = null;
            List list2 = null;
            for (int n30 = 0; n30 < size; ++n30) {
                final int intValue = ((Number)n9.get(n30)).intValue();
                if (intValue >= 0 && intValue < index) {
                    final int d2 = y.d(intValue);
                    final v c4 = w.c(intValue, 0, d2, y.a(0, d2));
                    Object o;
                    if ((o = list2) == null) {
                        o = new ArrayList();
                    }
                    ((List)o).add((Object)c4);
                    list2 = (List)o;
                }
            }
            List n31;
            if ((n31 = list2) == null) {
                n31 = L8.t.n();
            }
            final int size2 = n9.size();
            int n32 = 0;
            List list3 = list;
            while (n32 < size2) {
                final int intValue2 = ((Number)n9.get(n32)).intValue();
                if (index2 + 1 <= intValue2 && intValue2 < n) {
                    final int d3 = y.d(intValue2);
                    final v c5 = w.c(intValue2, 0, d3, y.a(0, d3));
                    Object o2;
                    if ((o2 = list3) == null) {
                        o2 = new ArrayList();
                    }
                    ((List)o2).add((Object)c5);
                    list3 = (List)o2;
                }
                ++n32;
            }
            if ((n9 = list3) == null) {
                n9 = L8.t.n();
            }
            x x3;
            int n33;
            if (n2 <= 0 && n4 >= 0) {
                x3 = x;
                n33 = j;
            }
            else {
                final int size3 = ((f)k2).size();
                x3 = x;
                final int n34 = 0;
                n2 = j;
                int d4;
                for (j = n34; j < size3; ++j, x3 = (x)k2.get(j)) {
                    d4 = ((x)k2.get(j)).d();
                    if (n2 == 0 || d4 > n2 || j == L8.t.p((List)k2)) {
                        break;
                    }
                    n2 -= d4;
                }
                n33 = n2;
            }
            if (b) {
                n2 = b.l(n7);
            }
            else {
                n2 = A1.c.i(n7, n5);
            }
            if (b) {
                j = A1.c.h(n7, n5);
            }
            else {
                j = b.k(n7);
            }
            final List b5 = b((List)k2, n31, n9, n2, j, n5, i, n29, b, b$m, b$e, b2, d);
            lazyLayoutItemAnimator.m((int)n6, n2, j, b5, w.e(), (A)w, b, false, n8, false, n33, n5, m, v);
            final long i2 = lazyLayoutItemAnimator.i();
            int i3;
            if (!r.e(i2, r.b.a())) {
                int n35;
                if (b) {
                    n35 = j;
                }
                else {
                    n35 = n2;
                }
                i3 = A1.c.i(n7, Math.max(n2, r.g(i2)));
                n2 = A1.c.h(n7, Math.max(j, r.f(i2)));
                if (b) {
                    j = n2;
                }
                else {
                    j = i3;
                }
                if (j != n35) {
                    for (int size4 = b5.size(), n36 = 0; n36 < size4; ++n36) {
                        ((v)b5.get(n36)).v(j);
                    }
                }
            }
            else {
                i3 = n2;
                n2 = j;
            }
            final boolean b6 = index2 != n - 1 || n5 > i;
            final G g2 = (G)q.invoke((Object)i3, (Object)n2, (Object)new X8.l(b5, t0) {
                final List H;
                final t0 L;
                
                public final void a(final U$a u$a) {
                    final List h = this.H;
                    for (int size = h.size(), i = 0; i < size; ++i) {
                        ((v)h.get(i)).t(u$a);
                    }
                    b0.M.a(this.L);
                }
            });
            Object o3;
            if (n31.isEmpty() && n9.isEmpty()) {
                o3 = b5;
            }
            else {
                o3 = new ArrayList(b5.size());
                Object value;
                for (n2 = b5.size(), i = 0; i < n2; ++i) {
                    value = b5.get(i);
                    j = ((v)value).getIndex();
                    if (index <= j && j <= index2) {
                        ((Collection)o3).add(value);
                    }
                }
            }
            V.q q3;
            if (b) {
                q3 = V.q.Vertical;
            }
            else {
                q3 = V.q.Horizontal;
            }
            return new u(x3, n33, b6, n6, g2, b3, m, d, n8, l, (List)o3, n13, n20, n, b2, q3, n3, n4);
        }
        throw new IllegalArgumentException("negative initial offset");
    }
}
