package a0;

import W.e;
import L8.t;
import java.util.Map;
import V.q;
import java.util.List;
import X8.l;
import A1.d;
import i9.M;
import e1.G;

public final class u implements s, G
{
    private final x a;
    private int b;
    private boolean c;
    private float d;
    private final boolean e;
    private final M f;
    private final d g;
    private final int h;
    private final l i;
    private final List j;
    private final int k;
    private final int l;
    private final int m;
    private final boolean n;
    private final q o;
    private final int p;
    private final int q;
    private final G r;
    
    public u(final x a, final int b, final boolean c, final float d, final G r, final boolean e, final M f, final d g, final int h, final l i, final List j, final int k, final int l, final int m, final boolean n, final q o, final int p18, final int q) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = i;
        this.j = j;
        this.k = k;
        this.l = l;
        this.m = m;
        this.n = n;
        this.o = o;
        this.p = p18;
        this.q = q;
        this.r = r;
    }
    
    @Override
    public long a() {
        return A1.s.a(this.c(), this.b());
    }
    
    public int b() {
        return this.r.b();
    }
    
    public int c() {
        return this.r.c();
    }
    
    @Override
    public int d() {
        return this.p;
    }
    
    @Override
    public int e() {
        return this.l;
    }
    
    @Override
    public q f() {
        return this.o;
    }
    
    @Override
    public int g() {
        return -this.h();
    }
    
    @Override
    public int h() {
        return this.k;
    }
    
    @Override
    public int i() {
        return this.m;
    }
    
    @Override
    public int j() {
        return this.q;
    }
    
    @Override
    public List k() {
        return this.j;
    }
    
    public final boolean l() {
        final x a = this.a;
        boolean b = false;
        int a2;
        if (a != null) {
            a2 = a.a();
        }
        else {
            a2 = 0;
        }
        if (a2 != 0 || this.b != 0) {
            b = true;
        }
        return b;
    }
    
    public final boolean m() {
        return this.c;
    }
    
    public final float n() {
        return this.d;
    }
    
    public final x o() {
        return this.a;
    }
    
    public final int p() {
        return this.b;
    }
    
    public Map q() {
        return this.r.q();
    }
    
    public void r() {
        this.r.r();
    }
    
    public l s() {
        return this.r.s();
    }
    
    public final l t() {
        return this.i;
    }
    
    public final int u() {
        return this.h;
    }
    
    public final boolean v(final int n) {
        final boolean e = this.e;
        final boolean b = false;
        int i = 0;
        boolean b2 = b;
        if (!e) {
            b2 = b;
            if (!this.k().isEmpty()) {
                final x a = this.a;
                b2 = b;
                if (a != null) {
                    final int d = a.d();
                    final int n2 = this.b - n;
                    b2 = b;
                    if (n2 >= 0) {
                        b2 = b;
                        if (n2 < d) {
                            final v v = (v)t.k0(this.k());
                            final v v2 = (v)t.v0(this.k());
                            b2 = b;
                            if (!v.s()) {
                                if (v2.s()) {
                                    b2 = b;
                                }
                                else {
                                    if (n < 0) {
                                        b2 = b;
                                        if (Math.min(W.e.a((k)v, this.f()) + v.f() - this.h(), W.e.a((k)v2, this.f()) + v2.f() - this.e()) <= -n) {
                                            return b2;
                                        }
                                    }
                                    else {
                                        b2 = b;
                                        if (Math.min(this.h() - W.e.a((k)v, this.f()), this.e() - W.e.a((k)v2, this.f())) <= n) {
                                            return b2;
                                        }
                                    }
                                    this.b -= n;
                                    for (List k = this.k(); i < k.size(); ++i) {
                                        ((v)k.get(i)).o(n);
                                    }
                                    this.d = (float)n;
                                    final boolean c = this.c;
                                    final boolean b3 = b2 = true;
                                    if (!c) {
                                        b2 = b3;
                                        if (n > 0) {
                                            this.c = true;
                                            b2 = b3;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return b2;
    }
}
