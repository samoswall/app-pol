package a0;

import e1.I;
import S0.c;
import X8.l;
import e1.U$a;
import androidx.compose.foundation.lazy.layout.b;
import A1.o;
import kotlin.jvm.internal.m;
import A1.s;
import d9.n;
import e1.U;
import androidx.compose.foundation.lazy.layout.LazyLayoutItemAnimator;
import java.util.List;
import A1.t;
import b0.z;

public final class v implements k, z
{
    private final int a;
    private final Object b;
    private final boolean c;
    private final int d;
    private final boolean e;
    private final t f;
    private final int g;
    private final int h;
    private final List i;
    private final long j;
    private final Object k;
    private final LazyLayoutItemAnimator l;
    private final long m;
    private final int n;
    private final int o;
    private final int p;
    private final int q;
    private int r;
    private int s;
    private int t;
    private final long u;
    private long v;
    private int w;
    private int x;
    private boolean y;
    
    private v(int max, final Object b, final boolean c, int i, final int n, final boolean e, final t f, int g, int size, final List j, long n2, final Object k, final LazyLayoutItemAnimator l, final long m, final int n3, final int o) {
        this.a = max;
        this.b = b;
        this.c = c;
        this.d = i;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = size;
        this.i = j;
        this.j = n2;
        this.k = k;
        this.l = l;
        this.m = m;
        this.n = n3;
        this.o = o;
        this.r = Integer.MIN_VALUE;
        size = j.size();
        i = 0;
        max = 0;
        while (i < size) {
            final U u = (U)j.get(i);
            if (this.i()) {
                g = u.J0();
            }
            else {
                g = u.S0();
            }
            max = Math.max(max, g);
            ++i;
        }
        this.p = max;
        this.q = d9.n.f(max + n, 0);
        if (this.i()) {
            n2 = A1.s.a(this.d, max);
        }
        else {
            n2 = A1.s.a(max, this.d);
        }
        this.u = n2;
        this.v = A1.n.b.a();
        this.w = -1;
        this.x = -1;
    }
    
    private final int p(final long n) {
        int n2;
        if (this.i()) {
            n2 = A1.n.k(n);
        }
        else {
            n2 = A1.n.j(n);
        }
        return n2;
    }
    
    private final int r(final U u) {
        int n;
        if (this.i()) {
            n = u.J0();
        }
        else {
            n = u.S0();
        }
        return n;
    }
    
    public int a() {
        return this.w;
    }
    
    public long b() {
        return this.u;
    }
    
    public int c() {
        return this.i.size();
    }
    
    public long d() {
        return this.m;
    }
    
    public void e(final boolean y) {
        this.y = y;
    }
    
    public int f() {
        return this.q;
    }
    
    public int g() {
        return this.o;
    }
    
    public int getIndex() {
        return this.a;
    }
    
    public Object getKey() {
        return this.b;
    }
    
    public Object h(final int n) {
        return ((I)this.i.get(n)).c();
    }
    
    public boolean i() {
        return this.c;
    }
    
    public long j(final int n) {
        return this.l();
    }
    
    public int k() {
        return this.n;
    }
    
    public long l() {
        return this.v;
    }
    
    public int m() {
        return this.x;
    }
    
    public void n(final int n, final int n2, final int n3, final int n4) {
        this.u(n, n2, n3, n4, -1, -1);
    }
    
    public final void o(final int n) {
        if (this.s()) {
            return;
        }
        final long l = this.l();
        int j;
        if (this.i()) {
            j = A1.n.j(l);
        }
        else {
            j = A1.n.j(l) + n;
        }
        final boolean i = this.i();
        int k = A1.n.k(l);
        if (i) {
            k += n;
        }
        this.v = A1.o.a(j, k);
        for (int c = this.c(), n2 = 0; n2 < c; ++n2) {
            final b e = this.l.e(this.getKey(), n2);
            if (e != null) {
                final long s = e.s();
                int n3;
                if (this.i()) {
                    n3 = A1.n.j(s);
                }
                else {
                    n3 = ((Number)Integer.valueOf(A1.n.j(s) + n)).intValue();
                }
                final boolean m = this.i();
                int k2 = A1.n.k(s);
                if (m) {
                    k2 += n;
                }
                e.J(A1.o.a(n3, k2));
            }
        }
    }
    
    public final int q() {
        return this.p;
    }
    
    public boolean s() {
        return this.y;
    }
    
    public final void t(final U$a u$a) {
        if (this.r != Integer.MIN_VALUE) {
            for (int c = this.c(), i = 0; i < c; ++i) {
                final U u = (U)this.i.get(i);
                final int n = this.s - this.r(u);
                final int t = this.t;
                long l = this.l();
                final b e = this.l.e(this.getKey(), i);
                c p;
                if (e != null) {
                    final long n2 = A1.n.n(l, e.r());
                    if ((this.p(l) <= n && this.p(n2) <= n) || (this.p(l) >= t && this.p(n2) >= t)) {
                        e.n();
                    }
                    p = e.p();
                    l = n2;
                }
                else {
                    p = null;
                }
                long a = l;
                if (this.e) {
                    int j;
                    if (this.i()) {
                        j = A1.n.j(l);
                    }
                    else {
                        j = this.r - A1.n.j(l) - this.r(u);
                    }
                    int k;
                    if (this.i()) {
                        k = this.r - A1.n.k(l) - this.r(u);
                    }
                    else {
                        k = A1.n.k(l);
                    }
                    a = A1.o.a(j, k);
                }
                final long n3 = A1.n.n(a, this.j);
                if (e != null) {
                    e.E(n3);
                }
                if (this.i()) {
                    if (p != null) {
                        U$a.z(u$a, u, n3, p, 0.0f, 4, (Object)null);
                    }
                    else {
                        U$a.y(u$a, u, n3, 0.0f, (l)null, 6, (Object)null);
                    }
                }
                else if (p != null) {
                    U$a.t(u$a, u, n3, p, 0.0f, 4, (Object)null);
                }
                else {
                    U$a.s(u$a, u, n3, 0.0f, (l)null, 6, (Object)null);
                }
            }
            return;
        }
        throw new IllegalArgumentException("position() should be called first");
    }
    
    public final void u(final int n, final int n2, int n3, int n4, final int w, final int x) {
        int r;
        if (this.i()) {
            r = n4;
        }
        else {
            r = n3;
        }
        this.r = r;
        if (!this.i()) {
            n3 = n4;
        }
        n4 = n2;
        if (this.i()) {
            n4 = n2;
            if (this.f == A1.t.Rtl) {
                n4 = n3 - n2 - this.d;
            }
        }
        long v;
        if (this.i()) {
            v = A1.o.a(n4, n);
        }
        else {
            v = A1.o.a(n, n4);
        }
        this.v = v;
        this.w = w;
        this.x = x;
        this.s = -this.g;
        this.t = this.r + this.h;
    }
    
    public final void v(final int r) {
        this.r = r;
        this.t = r + this.h;
    }
}
