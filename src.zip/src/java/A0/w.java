package a0;

import b0.t;
import androidx.compose.foundation.lazy.layout.c;
import A1.b;
import java.util.List;
import b0.z;
import b0.x;
import b0.A;

public abstract class w implements A
{
    private final l a;
    private final x b;
    private final int c;
    
    public w(final l a, final x b, final int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public abstract v b(final int p0, final Object p1, final Object p2, final int p3, final int p4, final List p5, final long p6, final int p7, final int p8);
    
    public v c(final int n, final int n2, final int n3, final long n4) {
        return this.d(n, n4, n2, n3, this.c);
    }
    
    public final v d(final int n, final long n2, final int n3, final int n4, final int n5) {
        final Object b = ((t)this.a).b(n);
        final Object e = ((t)this.a).e(n);
        final List e2 = this.b.E0(n, n2);
        int n6;
        if (A1.b.j(n2)) {
            n6 = A1.b.n(n2);
        }
        else {
            if (!A1.b.i(n2)) {
                throw new IllegalArgumentException("does not have fixed height");
            }
            n6 = A1.b.m(n2);
        }
        return this.b(n, b, e, n6, n5, e2, n2, n3, n4);
    }
    
    public final c e() {
        return this.a.c();
    }
}
