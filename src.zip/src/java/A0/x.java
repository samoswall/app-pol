package a0;

import K8.M;
import d9.n;
import java.util.List;

public final class x
{
    private final int a;
    private final v[] b;
    private final E c;
    private final List d;
    private final boolean e;
    private final int f;
    private final int g;
    private final int h;
    
    public x(int max, final v[] b, final E c, final List d, final boolean e, int i) {
        this.a = max;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = i;
        final int length = b.length;
        i = 0;
        max = 0;
        while (i < length) {
            max = Math.max(max, b[i].q());
            ++i;
        }
        this.g = max;
        this.h = n.f(max + this.f, 0);
    }
    
    public final int a() {
        return this.a;
    }
    
    public final v[] b() {
        return this.b;
    }
    
    public final int c() {
        return this.g;
    }
    
    public final int d() {
        return this.h;
    }
    
    public final boolean e() {
        return this.b.length == 0;
    }
    
    public final v[] f(final int n, final int n2, final int n3) {
        final v[] b = this.b;
        final int length = b.length;
        int i = 0;
        int n4 = 0;
        int n5 = 0;
        while (i < length) {
            final v v = b[i];
            final int d = a0.c.d(((c)this.d.get(n4)).g());
            final int n6 = this.c.a()[n5];
            final boolean e = this.e;
            int a;
            if (e) {
                a = this.a;
            }
            else {
                a = n5;
            }
            int a2;
            if (e) {
                a2 = n5;
            }
            else {
                a2 = this.a;
            }
            v.u(n, n6, n2, n3, a, a2);
            final M a3 = M.a;
            n5 += d;
            ++i;
            ++n4;
        }
        return this.b;
    }
}
