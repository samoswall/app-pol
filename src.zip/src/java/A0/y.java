package a0;

import K8.M;
import java.util.List;
import A1.b;
import d9.n;

public abstract class y
{
    private final boolean a;
    private final E b;
    private final int c;
    private final int d;
    private final w e;
    private final H f;
    
    public y(final boolean a, final E b, final int c, final int d, final w e, final H f) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    
    public final long a(int f, int n) {
        if (n == 1) {
            f = this.b.b()[f];
        }
        else {
            n = n + f - 1;
            f = this.b.a()[n] + this.b.b()[n] - this.b.a()[f];
        }
        f = n.f(f, 0);
        long n2;
        if (this.a) {
            n2 = A1.b.b.e(f);
        }
        else {
            n2 = A1.b.b.d(f);
        }
        return n2;
    }
    
    public abstract x b(final int p0, final v[] p1, final List p2, final int p3);
    
    public final x c(final int n) {
        final H$c c = this.f.c(n);
        final int size = c.b().size();
        int i = 0;
        int d;
        if (size != 0 && c.a() + size != this.c) {
            d = this.d;
        }
        else {
            d = 0;
        }
        final v[] array = new v[size];
        int n2 = 0;
        while (i < size) {
            final int d2 = a0.c.d(((c)c.b().get(i)).g());
            final v d3 = this.e.d(c.a() + i, this.a(n2, d2), n2, d2, d);
            n2 += d2;
            final M a = M.a;
            array[i] = d3;
            ++i;
        }
        return this.b(n, array, c.b(), d);
    }
    
    public final int d(final int n) {
        final H f = this.f;
        return f.i(n, f.e());
    }
}
