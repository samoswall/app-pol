package a0;

import java.util.List;

public interface z
{
    List a(final int p0);
}
