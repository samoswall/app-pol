package a1;

import kotlin.jvm.internal.v;

public final class a implements t
{
    private final int b;
    
    public a(final int b) {
        this.b = b;
    }
    
    public final int a() {
        return this.b;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        Class<?> class1;
        if (o != null) {
            class1 = o.getClass();
        }
        else {
            class1 = null;
        }
        if (!v.e((Object)a.class, (Object)class1)) {
            return false;
        }
        v.h(o, "null cannot be cast to non-null type androidx.compose.ui.input.pointer.AndroidPointerIconType");
        return this.b == ((a)o).b;
    }
    
    @Override
    public int hashCode() {
        return this.b;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("AndroidPointerIcon(type=");
        sb.append(this.b);
        sb.append(')');
        return sb.toString();
    }
}
