package a1;

import androidx.compose.ui.platform.b1;
import X8.p;
import A1.d;

public interface b extends d
{
    Object K1(final o p0, final P8.d p1);
    
    m Q();
    
    long b();
    
    Object c0(final long p0, final p p1, final P8.d p2);
    
    long e1();
    
    b1 getViewConfiguration();
    
    Object j1(final long p0, final p p1, final P8.d p2);
}
