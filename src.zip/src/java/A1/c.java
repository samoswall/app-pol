package a1;

import java.util.concurrent.CancellationException;

public final class c extends CancellationException
{
    public static final c a;
    
    static {
        a = new c();
    }
    
    private c() {
    }
    
    public Throwable fillInStackTrace() {
        ((Throwable)this).setStackTrace(S.a());
        return (Throwable)this;
    }
}
