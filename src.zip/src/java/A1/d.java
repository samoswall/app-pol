package a1;

public final class d
{
    private boolean a;
    private boolean b;
    
    public d(final boolean a, final boolean b) {
        this.a = a;
        this.b = b;
    }
    
    public final boolean a() {
        return this.b;
    }
    
    public final boolean b() {
        return this.a;
    }
    
    public final void c(final boolean b) {
        this.b = b;
    }
    
    public final void d(final boolean a) {
        this.a = a;
    }
}
