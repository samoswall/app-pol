package a1;

import kotlin.jvm.internal.m;
import O0.g;

public final class e
{
    private final long a;
    private final long b;
    private long c;
    
    private e(final long a, final long b) {
        this.a = a;
        this.b = b;
        this.c = g.b.c();
    }
    
    private e(final long n, final long n2, final long c) {
        this(n, n2, null);
        this.c = c;
    }
    
    public final long a() {
        return this.c;
    }
    
    public final long b() {
        return this.b;
    }
    
    public final long c() {
        return this.a;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("HistoricalChange(uptimeMillis=");
        sb.append(this.a);
        sb.append(", position=");
        sb.append((Object)g.t(this.b));
        sb.append(')');
        return sb.toString();
    }
}
