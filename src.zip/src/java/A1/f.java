package a1;

import androidx.collection.p;
import x0.b;
import kotlin.jvm.internal.m;
import kotlin.jvm.internal.v;
import androidx.compose.ui.e$c;
import java.util.List;
import androidx.collection.E;
import androidx.collection.A;
import e1.s;

public final class f
{
    private final s a;
    private final k b;
    private final A c;
    
    public f(final s a) {
        this.a = a;
        this.b = new k();
        this.c = new A(10);
    }
    
    private final void f(final long n, final E e) {
        this.b.i(n, e);
    }
    
    public final void a(long n, final List list, final boolean b) {
        k b2 = this.b;
        this.c.g();
        final int size = list.size();
        int i = 0;
        int n2 = 1;
        while (i < size) {
            final e$c e$c = (e$c)list.get(i);
            Label_0315: {
                int n3;
                if ((n3 = n2) != 0) {
                    final b g = b2.g();
                    final int q = g.q();
                    Object o = null;
                    Label_0131: {
                        if (q > 0) {
                            final Object[] p3 = g.p();
                            int n4 = 0;
                            do {
                                o = p3[n4];
                                if (v.e((Object)((j)o).k(), (Object)e$c)) {
                                    break Label_0131;
                                }
                            } while (++n4 < q);
                        }
                        o = null;
                    }
                    final j j = (j)o;
                    if (j != null) {
                        j.n();
                        j.l().b(n);
                        final A c = this.c;
                        Object b3;
                        if ((b3 = ((p)c).b(n)) == null) {
                            b3 = new E(0, 1, (m)null);
                            c.o(n, b3);
                        }
                        ((E)b3).g((Object)j);
                        b2 = j;
                        break Label_0315;
                    }
                    n3 = 0;
                }
                final j k = new j(e$c);
                k.l().b(n);
                final A c2 = this.c;
                Object b4 = ((p)c2).b(n);
                if (b4 == null) {
                    b4 = new E(0, 1, (m)null);
                    c2.o(n, b4);
                }
                ((E)b4).g((Object)k);
                b2.g().b((Object)k);
                b2 = k;
                n2 = n3;
            }
            ++i;
        }
        if (b) {
            final A c3 = this.c;
            final long[] b5 = ((p)c3).b;
            final Object[] c4 = ((p)c3).c;
            final long[] a = ((p)c3).a;
            final int n5 = a.length - 2;
            if (n5 >= 0) {
                int n6 = 0;
                while (true) {
                    n = a[n6];
                    if ((~n << 7 & n & 0x8080808080808080L) != 0x8080808080808080L) {
                        final int n7 = 8 - (~(n6 - n5) >>> 31);
                        for (int l = 0; l < n7; ++l) {
                            if ((0xFFL & n) < 128L) {
                                final int n8 = (n6 << 3) + l;
                                this.f(b5[n8], (E)c4[n8]);
                            }
                            n >>= 8;
                        }
                        if (n7 != 8) {
                            break;
                        }
                    }
                    if (n6 == n5) {
                        break;
                    }
                    ++n6;
                }
            }
        }
    }
    
    public final void b() {
        this.b.c();
    }
    
    public final boolean c(final g g, final boolean b) {
        final boolean a = this.b.a(g.b(), this.a, g, b);
        final boolean b2 = false;
        if (!a) {
            return false;
        }
        final boolean f = this.b.f(g.b(), this.a, g, b);
        if (!this.b.e(g)) {
            final boolean b3 = b2;
            if (!f) {
                return b3;
            }
        }
        return true;
    }
    
    public final void d() {
        this.b.d();
        this.b();
    }
    
    public final void e() {
        this.b.h();
    }
}
