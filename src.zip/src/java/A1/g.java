package a1;

import android.view.MotionEvent;
import java.util.List;
import androidx.collection.s;

public final class g
{
    private final s a;
    private final A b;
    private boolean c;
    
    public g(final s a, final A b) {
        this.a = a;
        this.b = b;
    }
    
    public final boolean a(final long n) {
        final List b = this.b.b();
        final int size = b.size();
        boolean a = false;
        while (true) {
            for (int i = 0; i < size; ++i) {
                final Object value = b.get(i);
                if (x.d(((B)value).d(), n)) {
                    final B b2 = (B)value;
                    if (b2 != null) {
                        a = b2.a();
                    }
                    return a;
                }
            }
            final Object value = null;
            continue;
        }
    }
    
    public final s b() {
        return this.a;
    }
    
    public final MotionEvent c() {
        return this.b.a();
    }
    
    public final boolean d() {
        return this.c;
    }
    
    public final void e(final boolean c) {
        this.c = c;
    }
}
