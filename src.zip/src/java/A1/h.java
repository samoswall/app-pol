package a1;

import kotlin.jvm.internal.m;
import O0.g;
import android.view.MotionEvent;
import java.util.ArrayList;
import java.util.List;
import android.util.SparseBooleanArray;
import android.util.SparseLongArray;

public final class h
{
    private long a;
    private final SparseLongArray b;
    private final SparseBooleanArray c;
    private final List d;
    private int e;
    private int f;
    
    public h() {
        this.b = new SparseLongArray();
        this.c = new SparseBooleanArray();
        this.d = (List)new ArrayList();
        this.e = -1;
        this.f = -1;
    }
    
    private final void a(final MotionEvent motionEvent) {
        final int actionMasked = motionEvent.getActionMasked();
        if (actionMasked != 0 && actionMasked != 5) {
            if (actionMasked == 9) {
                final int pointerId = motionEvent.getPointerId(0);
                if (this.b.indexOfKey(pointerId) < 0) {
                    final SparseLongArray b = this.b;
                    final long a = this.a;
                    this.a = 1L + a;
                    b.put(pointerId, a);
                }
            }
        }
        else {
            final int actionIndex = motionEvent.getActionIndex();
            final int pointerId2 = motionEvent.getPointerId(actionIndex);
            if (this.b.indexOfKey(pointerId2) < 0) {
                final SparseLongArray b2 = this.b;
                final long a2 = this.a;
                this.a = 1L + a2;
                b2.put(pointerId2, a2);
                if (motionEvent.getToolType(actionIndex) == 3) {
                    this.c.put(pointerId2, true);
                }
            }
        }
    }
    
    private final void b(final MotionEvent motionEvent) {
        if (motionEvent.getPointerCount() != 1) {
            return;
        }
        final int toolType = motionEvent.getToolType(0);
        final int source = motionEvent.getSource();
        if (toolType != this.e || source != this.f) {
            this.e = toolType;
            this.f = source;
            this.c.clear();
            this.b.clear();
        }
    }
    
    private final B d(final N n, final MotionEvent motionEvent, final int n2, final boolean b) {
        final long f = this.f(motionEvent.getPointerId(n2));
        final float pressure = motionEvent.getPressure(n2);
        final long g = O0.g.g(O0.h.a(motionEvent.getX(n2), motionEvent.getY(n2)), 0.0f, 0.0f, 3, (Object)null);
        long n3;
        long n4;
        if (n2 == 0) {
            n3 = O0.h.a(motionEvent.getRawX(), motionEvent.getRawY());
            n4 = n.r(n3);
        }
        else {
            n3 = i.a.a(motionEvent, n2);
            n4 = n.r(n3);
        }
        final int toolType = motionEvent.getToolType(n2);
        int n5;
        if (toolType != 0) {
            if (toolType != 1) {
                if (toolType != 2) {
                    if (toolType != 3) {
                        if (toolType != 4) {
                            n5 = M.a.e();
                        }
                        else {
                            n5 = M.a.a();
                        }
                    }
                    else {
                        n5 = M.a.b();
                    }
                }
                else {
                    n5 = M.a.c();
                }
            }
            else {
                n5 = M.a.d();
            }
        }
        else {
            n5 = M.a.e();
        }
        final ArrayList list = new ArrayList(motionEvent.getHistorySize());
        for (int historySize = motionEvent.getHistorySize(), i = 0; i < historySize; ++i) {
            final float historicalX = motionEvent.getHistoricalX(n2, i);
            final float historicalY = motionEvent.getHistoricalY(n2, i);
            if (!Float.isInfinite(historicalX) && !Float.isNaN(historicalX) && !Float.isInfinite(historicalY) && !Float.isNaN(historicalY)) {
                final long a = O0.h.a(historicalX, historicalY);
                list.add((Object)new e(motionEvent.getHistoricalEventTime(i), a, a, null));
            }
        }
        long n6;
        if (motionEvent.getActionMasked() == 8) {
            n6 = O0.h.a(motionEvent.getAxisValue(10), -motionEvent.getAxisValue(9) + 0.0f);
        }
        else {
            n6 = O0.g.b.c();
        }
        return new B(f, motionEvent.getEventTime(), n3, n4, b, pressure, n5, this.c.get(motionEvent.getPointerId(n2), false), (List)list, n6, g, null);
    }
    
    private final long f(final int n) {
        final int indexOfKey = this.b.indexOfKey(n);
        long n2;
        if (indexOfKey >= 0) {
            n2 = this.b.valueAt(indexOfKey);
        }
        else {
            n2 = this.a;
            this.a = 1L + n2;
            this.b.put(n, n2);
        }
        return x.b(n2);
    }
    
    private final boolean g(final MotionEvent motionEvent, final int n) {
        for (int pointerCount = motionEvent.getPointerCount(), i = 0; i < pointerCount; ++i) {
            if (motionEvent.getPointerId(i) == n) {
                return true;
            }
        }
        return false;
    }
    
    private final void h(final MotionEvent motionEvent) {
        final int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 1 || actionMasked == 6) {
            final int pointerId = motionEvent.getPointerId(motionEvent.getActionIndex());
            if (!this.c.get(pointerId, false)) {
                this.b.delete(pointerId);
                this.c.delete(pointerId);
            }
        }
        if (this.b.size() > motionEvent.getPointerCount()) {
            for (int n = this.b.size() - 1; -1 < n; --n) {
                final int key = this.b.keyAt(n);
                if (!this.g(motionEvent, key)) {
                    this.b.removeAt(n);
                    this.c.delete(key);
                }
            }
        }
    }
    
    public final A c(final MotionEvent motionEvent, final N n) {
        final int actionMasked = motionEvent.getActionMasked();
        if (actionMasked != 3 && actionMasked != 4) {
            this.b(motionEvent);
            this.a(motionEvent);
            final boolean b = actionMasked == 9 || actionMasked == 7 || actionMasked == 10;
            final boolean b2 = actionMasked == 8;
            if (b) {
                this.c.put(motionEvent.getPointerId(motionEvent.getActionIndex()), true);
            }
            int actionIndex;
            if (actionMasked != 1) {
                if (actionMasked != 6) {
                    actionIndex = -1;
                }
                else {
                    actionIndex = motionEvent.getActionIndex();
                }
            }
            else {
                actionIndex = 0;
            }
            this.d.clear();
            for (int pointerCount = motionEvent.getPointerCount(), i = 0; i < pointerCount; ++i) {
                this.d.add((Object)this.d(n, motionEvent, i, !b && i != actionIndex && (!b2 || motionEvent.getButtonState() != 0)));
            }
            this.h(motionEvent);
            return new A(motionEvent.getEventTime(), this.d, motionEvent);
        }
        this.b.clear();
        this.c.clear();
        return null;
    }
    
    public final void e(final int n) {
        this.c.delete(n);
        this.b.delete(n);
    }
}
