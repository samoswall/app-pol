package a1;

import O0.h;
import android.view.MotionEvent;

final class i
{
    public static final i a;
    
    static {
        a = new i();
    }
    
    private i() {
    }
    
    public final long a(final MotionEvent motionEvent, final int n) {
        return h.a(motionEvent.getRawX(n), motionEvent.getRawY(n));
    }
}
