package a1;

import androidx.collection.L;
import androidx.collection.E;
import java.util.List;
import kotlin.jvm.internal.v;
import java.util.ArrayList;
import g1.t0;
import g1.s0;
import g1.e0;
import O0.g;
import androidx.collection.s;
import b1.b;
import androidx.compose.ui.e$c;

public final class j extends k
{
    private final e$c c;
    private final b d;
    private final s e;
    private e1.s f;
    private m g;
    private boolean h;
    private boolean i;
    private boolean j;
    
    public j(final e$c c) {
        this.c = c;
        this.d = new b();
        this.e = new s(2);
        this.i = true;
        this.j = true;
    }
    
    private final void j() {
        this.e.a();
        this.f = null;
    }
    
    private final boolean m(final m m, final m i) {
        if (m != null && m.c().size() == i.c().size()) {
            for (int size = i.c().size(), j = 0; j < size; ++j) {
                if (!O0.g.j(((y)m.c().get(j)).h(), ((y)i.c().get(j)).h())) {
                    return true;
                }
            }
            return false;
        }
        return true;
    }
    
    @Override
    public boolean a(final s s, final e1.s s2, final a1.g g, final boolean b) {
        final boolean a = super.a(s, s2, g, b);
        if (!this.c.X1()) {
            return true;
        }
        e$c e$c = this.c;
        final int a2 = e0.a(16);
        x0.b b2 = null;
        while (e$c != null) {
            x0.b b3;
            if (e$c instanceof s0) {
                this.f = t0.a((s0)e$c);
                b3 = b2;
            }
            else {
                b3 = b2;
                if ((e$c.S1() & a2) != 0x0) {
                    b3 = b2;
                    if (e$c instanceof g1.m) {
                        e$c e$c2 = ((g1.m)e$c).r2();
                        int n = 0;
                        while (e$c2 != null) {
                            e$c e$c3 = e$c;
                            x0.b b4 = b2;
                            int n2 = n;
                            if ((e$c2.S1() & a2) != 0x0) {
                                n2 = n + 1;
                                if (n2 == 1) {
                                    e$c3 = e$c2;
                                    b4 = b2;
                                }
                                else {
                                    x0.b b5;
                                    if ((b5 = b2) == null) {
                                        b5 = new x0.b((Object[])new e$c[16], 0);
                                    }
                                    e$c e$c4;
                                    if ((e$c4 = e$c) != null) {
                                        b5.b((Object)e$c);
                                        e$c4 = null;
                                    }
                                    b5.b((Object)e$c2);
                                    b4 = b5;
                                    e$c3 = e$c4;
                                }
                            }
                            e$c2 = e$c2.O1();
                            e$c = e$c3;
                            b2 = b4;
                            n = n2;
                        }
                        b3 = b2;
                        if (n == 1) {
                            continue;
                        }
                    }
                }
            }
            e$c = g1.k.b(b3);
            b2 = b3;
        }
        for (int m = s.m(), i = 0; i < m; ++i) {
            final long h = s.h(i);
            final y y = (y)s.n(i);
            if (this.d.d(h)) {
                final long k = y.k();
                final long h2 = y.h();
                if (g.p(k) && g.p(h2)) {
                    final ArrayList list = new ArrayList(y.e().size());
                    final List e = y.e();
                    for (int size = e.size(), j = 0; j < size; ++j) {
                        final e e2 = (e)e.get(j);
                        final long b6 = e2.b();
                        if (g.p(b6)) {
                            final long c = e2.c();
                            final e1.s f = this.f;
                            v.g((Object)f);
                            list.add((Object)new e(c, f.H(s2, b6), e2.a(), null));
                        }
                    }
                    final s e3 = this.e;
                    final e1.s f2 = this.f;
                    v.g((Object)f2);
                    final long h3 = f2.H(s2, k);
                    final e1.s f3 = this.f;
                    v.g((Object)f3);
                    e3.i(h, (Object)a1.y.c(y, 0L, 0L, f3.H(s2, h2), false, 0L, h3, false, 0, (List)list, 0L, 731, null));
                }
            }
        }
        if (this.e.f()) {
            this.d.c();
            this.g().k();
            return true;
        }
        for (int n3 = this.d.f() - 1; -1 < n3; --n3) {
            if (!s.c(this.d.e(n3))) {
                this.d.j(n3);
            }
        }
        final ArrayList list2 = new ArrayList(this.e.m());
        for (int l = this.e.m(), n4 = 0; n4 < l; ++n4) {
            list2.add(this.e.n(n4));
        }
        final m g2 = new m((List)list2, g);
        final List c2 = g2.c();
        while (true) {
            for (int size2 = c2.size(), n5 = 0; n5 < size2; ++n5) {
                final Object value = c2.get(n5);
                if (g.a(((y)value).f())) {
                    final y y2 = (y)value;
                    Label_1014: {
                        if (y2 != null) {
                            if (!b) {
                                this.i = false;
                            }
                            else if (!this.i && (y2.i() || y2.l())) {
                                final e1.s f4 = this.f;
                                v.g((Object)f4);
                                this.i = (n.e(y2, f4.b()) ^ true);
                            }
                            if (this.i != this.h) {
                                final int f5 = g2.f();
                                final q.a a3 = q.a;
                                if (q.i(f5, a3.c()) || q.i(g2.f(), a3.a()) || q.i(g2.f(), a3.b())) {
                                    int n6;
                                    if (this.i) {
                                        n6 = a3.a();
                                    }
                                    else {
                                        n6 = a3.b();
                                    }
                                    g2.g(n6);
                                    break Label_1014;
                                }
                            }
                            final int f6 = g2.f();
                            final q.a a4 = q.a;
                            if (q.i(f6, a4.a()) && this.h && !this.j) {
                                g2.g(a4.c());
                            }
                            else if (q.i(g2.f(), a4.b()) && this.i && y2.i()) {
                                g2.g(a4.c());
                            }
                        }
                    }
                    final boolean b7 = a || !q.i(g2.f(), q.a.c()) || this.m(this.g, g2);
                    this.g = g2;
                    return b7;
                }
            }
            final Object value = null;
            continue;
        }
    }
    
    @Override
    public void b(final a1.g g) {
        super.b(g);
        final m g2 = this.g;
        if (g2 == null) {
            return;
        }
        this.h = this.i;
        final List c = g2.c();
        for (int size = c.size(), i = 0; i < size; ++i) {
            final y y = (y)c.get(i);
            final boolean j = y.i();
            final boolean a = g.a(y.f());
            final boolean k = this.i;
            if ((!j && !a) || (!j && !k)) {
                this.d.i(y.f());
            }
        }
        this.i = false;
        this.j = q.i(g2.f(), q.a.b());
    }
    
    @Override
    public void d() {
        final x0.b g = this.g();
        final int q = g.q();
        if (q > 0) {
            final Object[] p = g.p();
            int n = 0;
            do {
                ((j)p[n]).d();
            } while (++n < q);
        }
        e$c e$c = this.c;
        final int a = e0.a(16);
        x0.b b = null;
        while (e$c != null) {
            x0.b b2;
            if (e$c instanceof s0) {
                ((s0)e$c).s0();
                b2 = b;
            }
            else {
                b2 = b;
                if ((e$c.S1() & a) != 0x0) {
                    b2 = b;
                    if (e$c instanceof g1.m) {
                        e$c e$c2 = ((g1.m)e$c).r2();
                        int n2 = 0;
                        while (e$c2 != null) {
                            x0.b b3 = b;
                            int n3 = n2;
                            e$c e$c3 = e$c;
                            if ((e$c2.S1() & a) != 0x0) {
                                n3 = n2 + 1;
                                if (n3 == 1) {
                                    e$c3 = e$c2;
                                    b3 = b;
                                }
                                else {
                                    if ((b3 = b) == null) {
                                        b3 = new x0.b((Object[])new e$c[16], 0);
                                    }
                                    if ((e$c3 = e$c) != null) {
                                        b3.b((Object)e$c);
                                        e$c3 = null;
                                    }
                                    b3.b((Object)e$c2);
                                }
                            }
                            e$c2 = e$c2.O1();
                            b = b3;
                            n2 = n3;
                            e$c = e$c3;
                        }
                        b2 = b;
                        if (n2 == 1) {
                            continue;
                        }
                    }
                }
            }
            e$c = g1.k.b(b2);
            b = b2;
        }
    }
    
    @Override
    public boolean e(final a1.g g) {
        final boolean f = this.e.f();
        boolean b = false;
        final int n = 0;
        if (!f) {
            if (this.c.X1()) {
                final m g2 = this.g;
                v.g((Object)g2);
                final e1.s f2 = this.f;
                v.g((Object)f2);
                final long b2 = f2.b();
                e$c e$c = this.c;
                final int a = e0.a(16);
                x0.b b3 = null;
                while (e$c != null) {
                    x0.b b4;
                    if (e$c instanceof s0) {
                        ((s0)e$c).C0(g2, o.Final, b2);
                        b4 = b3;
                    }
                    else {
                        b4 = b3;
                        if ((e$c.S1() & a) != 0x0) {
                            b4 = b3;
                            if (e$c instanceof g1.m) {
                                e$c e$c2 = ((g1.m)e$c).r2();
                                int n2 = 0;
                                while (e$c2 != null) {
                                    e$c e$c3 = e$c;
                                    x0.b b5 = b3;
                                    int n3 = n2;
                                    if ((e$c2.S1() & a) != 0x0) {
                                        n3 = n2 + 1;
                                        if (n3 == 1) {
                                            e$c3 = e$c2;
                                            b5 = b3;
                                        }
                                        else {
                                            x0.b b6;
                                            if ((b6 = b3) == null) {
                                                b6 = new x0.b((Object[])new e$c[16], 0);
                                            }
                                            e$c e$c4;
                                            if ((e$c4 = e$c) != null) {
                                                b6.b((Object)e$c);
                                                e$c4 = null;
                                            }
                                            b6.b((Object)e$c2);
                                            b5 = b6;
                                            e$c3 = e$c4;
                                        }
                                    }
                                    e$c2 = e$c2.O1();
                                    e$c = e$c3;
                                    b3 = b5;
                                    n2 = n3;
                                }
                                b4 = b3;
                                if (n2 == 1) {
                                    continue;
                                }
                            }
                        }
                    }
                    e$c = g1.k.b(b4);
                    b3 = b4;
                }
                if (this.c.X1()) {
                    final x0.b g3 = this.g();
                    final int q = g3.q();
                    if (q > 0) {
                        final Object[] p = g3.p();
                        int n4 = n;
                        do {
                            ((j)p[n4]).e(g);
                        } while (++n4 < q);
                    }
                }
                b = true;
            }
        }
        this.b(g);
        this.j();
        return b;
    }
    
    @Override
    public boolean f(s e, final e1.s s, final a1.g g, final boolean b) {
        final boolean f = this.e.f();
        final boolean b2 = false;
        boolean b3;
        if (f) {
            b3 = b2;
        }
        else if (!this.c.X1()) {
            b3 = b2;
        }
        else {
            final m g2 = this.g;
            v.g((Object)g2);
            final e1.s f2 = this.f;
            v.g((Object)f2);
            final long b4 = f2.b();
            e$c e$c = this.c;
            final int a = e0.a(16);
            x0.b b5 = null;
            while (e$c != null) {
                x0.b b6;
                if (e$c instanceof s0) {
                    ((s0)e$c).C0(g2, o.Initial, b4);
                    b6 = b5;
                }
                else {
                    b6 = b5;
                    if ((e$c.S1() & a) != 0x0) {
                        b6 = b5;
                        if (e$c instanceof g1.m) {
                            e$c e$c2 = ((g1.m)e$c).r2();
                            int n = 0;
                            while (e$c2 != null) {
                                e$c e$c3 = e$c;
                                x0.b b7 = b5;
                                int n2 = n;
                                if ((e$c2.S1() & a) != 0x0) {
                                    n2 = n + 1;
                                    if (n2 == 1) {
                                        e$c3 = e$c2;
                                        b7 = b5;
                                    }
                                    else {
                                        x0.b b8;
                                        if ((b8 = b5) == null) {
                                            b8 = new x0.b((Object[])new e$c[16], 0);
                                        }
                                        e$c e$c4;
                                        if ((e$c4 = e$c) != null) {
                                            b8.b((Object)e$c);
                                            e$c4 = null;
                                        }
                                        b8.b((Object)e$c2);
                                        b7 = b8;
                                        e$c3 = e$c4;
                                    }
                                }
                                e$c2 = e$c2.O1();
                                e$c = e$c3;
                                b5 = b7;
                                n = n2;
                            }
                            b6 = b5;
                            if (n == 1) {
                                continue;
                            }
                        }
                    }
                }
                e$c = g1.k.b(b6);
                b5 = b6;
            }
            if (this.c.X1()) {
                final x0.b g3 = this.g();
                final int q = g3.q();
                if (q > 0) {
                    final Object[] p4 = g3.p();
                    int n3 = 0;
                    do {
                        final j j = (j)p4[n3];
                        e = this.e;
                        final e1.s f3 = this.f;
                        v.g((Object)f3);
                        j.f(e, f3, g, b);
                    } while (++n3 < q);
                }
            }
            if (this.c.X1()) {
                e$c e$c5 = this.c;
                final int a2 = e0.a(16);
                x0.b b9 = null;
                while (e$c5 != null) {
                    x0.b b10;
                    if (e$c5 instanceof s0) {
                        ((s0)e$c5).C0(g2, o.Main, b4);
                        b10 = b9;
                    }
                    else {
                        b10 = b9;
                        if ((e$c5.S1() & a2) != 0x0) {
                            b10 = b9;
                            if (e$c5 instanceof g1.m) {
                                e$c e$c6 = ((g1.m)e$c5).r2();
                                int n4 = 0;
                                while (e$c6 != null) {
                                    int n5 = n4;
                                    e$c e$c7 = e$c5;
                                    x0.b b11 = b9;
                                    if ((e$c6.S1() & a2) != 0x0) {
                                        n5 = n4 + 1;
                                        if (n5 == 1) {
                                            e$c7 = e$c6;
                                            b11 = b9;
                                        }
                                        else {
                                            x0.b b12;
                                            if ((b12 = b9) == null) {
                                                b12 = new x0.b((Object[])new e$c[16], 0);
                                            }
                                            e$c e$c8;
                                            if ((e$c8 = e$c5) != null) {
                                                b12.b((Object)e$c5);
                                                e$c8 = null;
                                            }
                                            b12.b((Object)e$c6);
                                            b11 = b12;
                                            e$c7 = e$c8;
                                        }
                                    }
                                    e$c6 = e$c6.O1();
                                    n4 = n5;
                                    e$c5 = e$c7;
                                    b9 = b11;
                                }
                                b10 = b9;
                                if (n4 == 1) {
                                    continue;
                                }
                            }
                        }
                    }
                    e$c5 = g1.k.b(b10);
                    b9 = b10;
                }
            }
            b3 = true;
        }
        return b3;
    }
    
    @Override
    public void i(final long n, final E e) {
        if (this.d.d(n) && !((L)e).a((Object)this)) {
            this.d.h(n);
            this.e.k(n);
        }
        final x0.b g = this.g();
        final int q = g.q();
        if (q > 0) {
            final Object[] p2 = g.p();
            int n2 = 0;
            do {
                ((j)p2[n2]).i(n, e);
            } while (++n2 < q);
        }
    }
    
    public final e$c k() {
        return this.c;
    }
    
    public final b l() {
        return this.d;
    }
    
    public final void n() {
        this.i = true;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("Node(pointerInputFilter=");
        sb.append((Object)this.c);
        sb.append(", children=");
        sb.append((Object)this.g());
        sb.append(", pointerIds=");
        sb.append((Object)this.d);
        sb.append(')');
        return sb.toString();
    }
}
