package a1;

import androidx.collection.E;
import androidx.collection.s;
import x0.b;

public class k
{
    public static final int b;
    private final b a;
    
    static {
        b = x0.b.d;
    }
    
    public k() {
        this.a = new b((Object[])new j[16], 0);
    }
    
    public boolean a(final s s, final e1.s s2, final g g, final boolean b) {
        final b a = this.a;
        final int q = a.q();
        boolean b2 = false;
        if (q > 0) {
            final Object[] p4 = a.p();
            int n = 0;
            int n2 = 0;
            int i;
            do {
                b2 = (((j)p4[n]).a(s, s2, g, b) || n2 != 0);
                i = ++n;
                n2 = (b2 ? 1 : 0);
            } while (i < q);
        }
        return b2;
    }
    
    public void b(final g g) {
        for (int n = this.a.q() - 1; -1 < n; --n) {
            if (((j)this.a.p()[n]).l().g()) {
                this.a.y(n);
            }
        }
    }
    
    public final void c() {
        this.a.k();
    }
    
    public void d() {
        final b a = this.a;
        final int q = a.q();
        if (q > 0) {
            final Object[] p = a.p();
            int n = 0;
            do {
                ((j)p[n]).d();
            } while (++n < q);
        }
    }
    
    public boolean e(final g g) {
        final b a = this.a;
        final int q = a.q();
        boolean b = false;
        if (q > 0) {
            final Object[] p = a.p();
            int n = 0;
            int n2 = 0;
            int i;
            do {
                b = (((j)p[n]).e(g) || n2 != 0);
                i = ++n;
                n2 = (b ? 1 : 0);
            } while (i < q);
        }
        this.b(g);
        return b;
    }
    
    public boolean f(final s s, final e1.s s2, final g g, final boolean b) {
        final b a = this.a;
        final int q = a.q();
        boolean b2 = false;
        if (q > 0) {
            final Object[] p4 = a.p();
            int n = 0;
            int n2 = 0;
            int i;
            do {
                b2 = (((j)p4[n]).f(s, s2, g, b) || n2 != 0);
                i = ++n;
                n2 = (b2 ? 1 : 0);
            } while (i < q);
        }
        return b2;
    }
    
    public final b g() {
        return this.a;
    }
    
    public final void h() {
        int i = 0;
        while (i < this.a.q()) {
            final j j = (j)this.a.p()[i];
            if (!j.k().X1()) {
                j.d();
                this.a.y(i);
            }
            else {
                ++i;
                j.h();
            }
        }
    }
    
    public void i(final long n, final E e) {
        final b a = this.a;
        final int q = a.q();
        if (q > 0) {
            final Object[] p2 = a.p();
            int n2 = 0;
            do {
                ((j)p2[n2]).i(n, e);
            } while (++n2 < q);
        }
    }
}
