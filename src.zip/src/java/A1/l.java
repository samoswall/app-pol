package a1;

public abstract class l
{
    public static int a(final int n) {
        return n;
    }
}
