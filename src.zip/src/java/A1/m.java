package a1;

import android.view.MotionEvent;
import java.util.List;

public final class m
{
    private final List a;
    private final g b;
    private final int c;
    private final int d;
    private int e;
    
    public m(final List list) {
        this(list, null);
    }
    
    public m(final List a, final g b) {
        this.a = a;
        this.b = b;
        final MotionEvent e = this.e();
        final int n = 0;
        int buttonState;
        if (e != null) {
            buttonState = e.getButtonState();
        }
        else {
            buttonState = 0;
        }
        this.c = l.a(buttonState);
        final MotionEvent e2 = this.e();
        int metaState = n;
        if (e2 != null) {
            metaState = e2.getMetaState();
        }
        this.d = L.b(metaState);
        this.e = this.a();
    }
    
    private final int a() {
        final MotionEvent e = this.e();
        if (e != null) {
            final int actionMasked = e.getActionMasked();
            if (actionMasked != 0) {
                if (actionMasked != 1) {
                    if (actionMasked != 2) {
                        switch (actionMasked) {
                            default: {
                                return q.a.g();
                            }
                            case 10: {
                                return q.a.b();
                            }
                            case 9: {
                                return q.a.a();
                            }
                            case 8: {
                                return q.a.f();
                            }
                            case 7: {
                                break;
                            }
                            case 6: {
                                return q.a.e();
                            }
                            case 5: {
                                return q.a.d();
                            }
                        }
                    }
                    return q.a.c();
                }
                return q.a.e();
            }
            return q.a.d();
        }
        final List a = this.a;
        for (int size = a.size(), i = 0; i < size; ++i) {
            final y y = (y)a.get(i);
            if (n.d(y)) {
                return q.a.e();
            }
            if (n.b(y)) {
                return q.a.d();
            }
        }
        return q.a.c();
    }
    
    public final int b() {
        return this.c;
    }
    
    public final List c() {
        return this.a;
    }
    
    public final g d() {
        return this.b;
    }
    
    public final MotionEvent e() {
        final g b = this.b;
        MotionEvent c;
        if (b != null) {
            c = b.c();
        }
        else {
            c = null;
        }
        return c;
    }
    
    public final int f() {
        return this.e;
    }
    
    public final void g(final int e) {
        this.e = e;
    }
}
