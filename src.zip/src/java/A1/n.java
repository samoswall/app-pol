package a1;

import O0.m;
import A1.r;
import O0.g;

public abstract class n
{
    public static final boolean a(final y y) {
        return !y.p() && !y.l() && y.i();
    }
    
    public static final boolean b(final y y) {
        return !y.l() && y.i();
    }
    
    public static final boolean c(final y y) {
        return !y.p() && y.l() && !y.i();
    }
    
    public static final boolean d(final y y) {
        return y.l() && !y.i();
    }
    
    public static final boolean e(final y y, final long n) {
        final long h = y.h();
        final float m = g.m(h);
        final float n2 = g.n(h);
        final int g = r.g(n);
        final int f = r.f(n);
        return m < 0.0f || m > g || n2 < 0.0f || n2 > f;
    }
    
    public static final boolean f(final y y, final long n, final long n2) {
        if (!M.g(y.n(), M.a.d())) {
            return e(y, n);
        }
        final long h = y.h();
        final float m = g.m(h);
        final float n3 = g.n(h);
        final float n4 = -O0.m.i(n2);
        final float n5 = (float)r.g(n);
        final float i = O0.m.i(n2);
        final float n6 = -O0.m.g(n2);
        final float n7 = (float)r.f(n);
        final float g = O0.m.g(n2);
        return m < n4 || m > n5 + i || n3 < n6 || n3 > n7 + g;
    }
    
    public static final long g(final y y) {
        return i(y, false);
    }
    
    public static final long h(final y y) {
        return i(y, true);
    }
    
    private static final long i(final y y, final boolean b) {
        long n = g.q(y.h(), y.k());
        if (!b) {
            n = n;
            if (y.p()) {
                n = g.b.c();
            }
        }
        return n;
    }
    
    public static final boolean j(final y y) {
        return g.j(i(y, false), g.b.c()) ^ true;
    }
    
    public static final boolean k(final y y) {
        return g.j(i(y, true), g.b.c()) ^ true;
    }
}
