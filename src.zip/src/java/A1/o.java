package a1;

public enum o
{
    private static final o[] $VALUES;
    
    Final, 
    Initial, 
    Main;
    
    private static final /* synthetic */ o[] $values() {
        return new o[] { o.Initial, o.Main, o.Final };
    }
    
    static {
        $VALUES = $values();
    }
}
