package a1;

import java.util.concurrent.CancellationException;

public final class p extends CancellationException
{
    public p(final long n) {
        final StringBuilder sb = new StringBuilder();
        sb.append("Timed out waiting for ");
        sb.append(n);
        sb.append(" ms");
        super(sb.toString());
    }
    
    public Throwable fillInStackTrace() {
        ((Throwable)this).setStackTrace(S.a());
        return (Throwable)this;
    }
}
