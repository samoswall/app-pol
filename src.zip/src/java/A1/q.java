package a1;

import kotlin.jvm.internal.m;

public abstract class q
{
    public static final a a;
    private static final int b;
    private static final int c;
    private static final int d;
    private static final int e;
    private static final int f;
    private static final int g;
    private static final int h;
    
    static {
        a = new a(null);
        b = h(0);
        c = h(1);
        d = h(2);
        e = h(3);
        f = h(4);
        g = h(5);
        h = h(6);
    }
    
    public static final /* synthetic */ int a() {
        return q.f;
    }
    
    public static final /* synthetic */ int b() {
        return q.g;
    }
    
    public static final /* synthetic */ int c() {
        return q.e;
    }
    
    public static final /* synthetic */ int d() {
        return q.c;
    }
    
    public static final /* synthetic */ int e() {
        return q.d;
    }
    
    public static final /* synthetic */ int f() {
        return q.h;
    }
    
    public static final /* synthetic */ int g() {
        return q.b;
    }
    
    private static int h(final int n) {
        return n;
    }
    
    public static final boolean i(final int n, final int n2) {
        return n == n2;
    }
    
    public static final class a
    {
        private a() {
        }
        
        public final int a() {
            return q.a();
        }
        
        public final int b() {
            return q.b();
        }
        
        public final int c() {
            return q.c();
        }
        
        public final int d() {
            return q.d();
        }
        
        public final int e() {
            return q.e();
        }
        
        public final int f() {
            return q.f();
        }
        
        public final int g() {
            return q.g();
        }
    }
}
