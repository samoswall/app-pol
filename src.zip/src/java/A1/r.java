package a1;

public abstract class r
{
    public static final int a() {
        return L.b(0);
    }
    
    public static final boolean b(final int n) {
        return (n & 0x21) != 0x0;
    }
    
    public static final boolean c(final int n) {
        return (n & 0x42) != 0x0;
    }
}
