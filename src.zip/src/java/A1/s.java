package a1;

import g1.i;
import androidx.compose.ui.platform.f0;
import g1.z0;
import K8.M;
import g1.B0;
import kotlin.jvm.internal.w;
import X8.l;
import kotlin.jvm.internal.S;
import g1.h;
import g1.s0;
import g1.A0;
import androidx.compose.ui.e$c;

public final class s extends e$c implements A0, s0, h
{
    private final String n;
    private t o;
    private boolean p;
    private boolean q;
    
    public s(final t o, final boolean p2) {
        this.n = "androidx.compose.ui.input.pointer.PointerHoverIcon";
        this.o = o;
        this.p = p2;
    }
    
    private final void B2() {
        this.q = true;
        this.v2();
    }
    
    private final void C2() {
        if (this.q) {
            this.q = false;
            if (this.X1()) {
                this.t2();
            }
        }
    }
    
    public static final /* synthetic */ boolean q2(final s s) {
        return s.q;
    }
    
    private final void r2() {
        final v z2 = this.z2();
        if (z2 != null) {
            z2.a(null);
        }
    }
    
    private final void s2() {
        final s x2 = this.x2();
        t t;
        if (x2 == null || (t = x2.o) == null) {
            t = this.o;
        }
        final v z2 = this.z2();
        if (z2 != null) {
            z2.a(t);
        }
    }
    
    private final void t2() {
        final S s = new S();
        B0.d((A0)this, (l)new l(s) {
            final S H;
            
            public final Boolean a(final s s) {
                if (this.H.a == null && s.q2(s)) {
                    this.H.a = s;
                }
                else if (this.H.a != null && s.y2() && s.q2(s)) {
                    this.H.a = s;
                }
                return Boolean.TRUE;
            }
        });
        final s s2 = (s)s.a;
        M a;
        if (s2 != null) {
            s2.s2();
            a = M.a;
        }
        else {
            a = null;
        }
        if (a == null) {
            this.r2();
        }
    }
    
    private final void u2() {
        if (!this.q) {
            return;
        }
        s s = this;
        if (!this.p) {
            final s w2 = this.w2();
            s = this;
            if (w2 != null) {
                s = w2;
            }
        }
        s.s2();
    }
    
    private final void v2() {
        final kotlin.jvm.internal.M m = new kotlin.jvm.internal.M();
        m.a = true;
        if (!this.p) {
            B0.f((A0)this, (l)new l(m) {
                final kotlin.jvm.internal.M H;
                
                public final z0 a(final s s) {
                    z0 z0;
                    if (s.q2(s)) {
                        this.H.a = false;
                        z0 = g1.z0.CancelTraversal;
                    }
                    else {
                        z0 = g1.z0.ContinueTraversal;
                    }
                    return z0;
                }
            });
        }
        if (m.a) {
            this.s2();
        }
    }
    
    private final s w2() {
        final S s = new S();
        B0.f((A0)this, (l)new l(s) {
            final S H;
            
            public final z0 a(final s a) {
                z0 z0 = g1.z0.ContinueTraversal;
                if (s.q2(a)) {
                    this.H.a = a;
                    z0 = z0;
                    if (a.y2()) {
                        z0 = g1.z0.SkipSubtreeAndContinueTraversal;
                    }
                }
                return z0;
            }
        });
        return (s)s.a;
    }
    
    private final s x2() {
        final S s = new S();
        B0.d((A0)this, (l)new l(s) {
            final S H;
            
            public final Boolean a(final s a) {
                if (a.y2() && s.q2(a)) {
                    this.H.a = a;
                }
                return Boolean.TRUE;
            }
        });
        return (s)s.a;
    }
    
    private final v z2() {
        return (v)i.a((h)this, (v0.v)f0.l());
    }
    
    public String A2() {
        return this.n;
    }
    
    public void C0(final m m, final o o, final long n) {
        if (o == o.Main) {
            final int f = m.f();
            final q.a a = a1.q.a;
            if (a1.q.i(f, a.a())) {
                this.B2();
            }
            else if (a1.q.i(m.f(), a.b())) {
                this.C2();
            }
        }
    }
    
    public final void D2(final t o) {
        if (!kotlin.jvm.internal.v.e((Object)this.o, (Object)o)) {
            this.o = o;
            if (this.q) {
                this.v2();
            }
        }
    }
    
    public final void E2(final boolean p) {
        if (this.p != p) {
            this.p = p;
            if (p) {
                if (this.q) {
                    this.s2();
                }
            }
            else if (this.q) {
                this.u2();
            }
        }
    }
    
    public void b2() {
        this.C2();
        super.b2();
    }
    
    public void s0() {
        this.C2();
    }
    
    public final boolean y2() {
        return this.p;
    }
}
