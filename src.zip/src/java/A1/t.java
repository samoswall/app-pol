package a1;

public interface t
{
    public static final a a = t.a.a;
    
    public static final class a
    {
        static final a a;
        private static final t b;
        private static final t c;
        private static final t d;
        private static final t e;
        
        static {
            a = new a();
            b = w.c();
            c = w.b();
            d = w.e();
            e = w.d();
        }
        
        private a() {
        }
        
        public final t a() {
            return t.a.b;
        }
        
        public final t b() {
            return t.a.e;
        }
    }
}
