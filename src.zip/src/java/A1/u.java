package a1;

import androidx.compose.ui.input.pointer.PointerHoverIconModifierElement;
import androidx.compose.ui.e;

public abstract class u
{
    public static final e a(final e e, final t t, final boolean b) {
        return e.f((e)new PointerHoverIconModifierElement(t, b));
    }
}
