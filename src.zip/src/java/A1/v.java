package a1;

public interface v
{
    void a(final t p0);
}
