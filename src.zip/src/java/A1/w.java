package a1;

public abstract class w
{
    private static final t a;
    private static final t b;
    private static final t c;
    private static final t d;
    
    static {
        a = new a(1000);
        b = new a(1007);
        c = new a(1008);
        d = new a(1002);
    }
    
    public static final t a(final int n) {
        return new a(n);
    }
    
    public static final t b() {
        return w.b;
    }
    
    public static final t c() {
        return w.a;
    }
    
    public static final t d() {
        return w.d;
    }
    
    public static final t e() {
        return w.c;
    }
}
