package a1;

public final class x
{
    private final long a = a;
    
    public static long b(final long n) {
        return n;
    }
    
    public static boolean c(final long n, final Object o) {
        return o instanceof x && n == ((x)o).g();
    }
    
    public static final boolean d(final long n, final long n2) {
        return n == n2;
    }
    
    public static int e(final long n) {
        return Long.hashCode(n);
    }
    
    public static String f(final long n) {
        final StringBuilder sb = new StringBuilder();
        sb.append("PointerId(value=");
        sb.append(n);
        sb.append(')');
        return sb.toString();
    }
    
    @Override
    public boolean equals(final Object o) {
        return c(this.a, o);
    }
    
    public final /* synthetic */ long g() {
        return this.a;
    }
    
    @Override
    public int hashCode() {
        return e(this.a);
    }
    
    @Override
    public String toString() {
        return f(this.a);
    }
}
