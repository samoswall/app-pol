package a1;

import L8.t;
import kotlin.jvm.internal.m;
import O0.g;
import java.util.List;

public final class y
{
    private final long a;
    private final long b;
    private final long c;
    private final boolean d;
    private final float e;
    private final long f;
    private final long g;
    private final boolean h;
    private final int i;
    private final long j;
    private List k;
    private long l;
    private d m;
    
    private y(final long a, final long b, final long c, final boolean d, final float e, final long f, final long g, final boolean h, final boolean b2, final int i, final long j) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = i;
        this.j = j;
        this.l = O0.g.b.c();
        this.m = new d(b2, b2);
    }
    
    private y(final long n, final long n2, final long n3, final boolean b, final float n4, final long n5, final long n6, final boolean b2, final boolean b3, final int n7, final List k, final long n8, final long l) {
        this(n, n2, n3, b, n4, n5, n6, b2, b3, n7, n8, null);
        this.k = k;
        this.l = l;
    }
    
    public final void a() {
        this.m.c(true);
        this.m.d(true);
    }
    
    public final y b(final long n, final long n2, final long n3, final boolean b, final long n4, final long n5, final boolean b2, final int n6, final List list, final long n7) {
        return this.d(n, n2, n3, b, this.e, n4, n5, b2, n6, list, n7);
    }
    
    public final y d(final long n, final long n2, final long n3, final boolean b, final float n4, final long n5, final long n6, final boolean b2, final int n7, final List list, final long n8) {
        final y y = new y(n, n2, n3, b, n4, n5, n6, b2, false, n7, list, n8, this.l, null);
        y.m = this.m;
        return y;
    }
    
    public final List e() {
        List list;
        if ((list = this.k) == null) {
            list = t.n();
        }
        return list;
    }
    
    public final long f() {
        return this.a;
    }
    
    public final long g() {
        return this.l;
    }
    
    public final long h() {
        return this.c;
    }
    
    public final boolean i() {
        return this.d;
    }
    
    public final float j() {
        return this.e;
    }
    
    public final long k() {
        return this.g;
    }
    
    public final boolean l() {
        return this.h;
    }
    
    public final long m() {
        return this.j;
    }
    
    public final int n() {
        return this.i;
    }
    
    public final long o() {
        return this.b;
    }
    
    public final boolean p() {
        return this.m.a() || this.m.b();
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("PointerInputChange(id=");
        sb.append((Object)x.f(this.a));
        sb.append(", uptimeMillis=");
        sb.append(this.b);
        sb.append(", position=");
        sb.append((Object)O0.g.t(this.c));
        sb.append(", pressed=");
        sb.append(this.d);
        sb.append(", pressure=");
        sb.append(this.e);
        sb.append(", previousUptimeMillis=");
        sb.append(this.f);
        sb.append(", previousPosition=");
        sb.append((Object)O0.g.t(this.g));
        sb.append(", previousPressed=");
        sb.append(this.h);
        sb.append(", isConsumed=");
        sb.append(this.p());
        sb.append(", type=");
        sb.append((Object)M.i(this.i));
        sb.append(", historical=");
        sb.append((Object)this.e());
        sb.append(",scrollDelta=");
        sb.append((Object)O0.g.t(this.j));
        sb.append(')');
        return sb.toString();
    }
}
