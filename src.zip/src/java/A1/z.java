package a1;

import java.util.List;
import kotlin.jvm.internal.m;
import androidx.collection.s;

final class z
{
    private final s a;
    
    public z() {
        this.a = new s(0, 1, (m)null);
    }
    
    public final void a() {
        this.a.a();
    }
    
    public final g b(final A a, final N n) {
        final s s = new s(a.b().size());
        final List b = a.b();
        for (int size = b.size(), i = 0; i < size; ++i) {
            final B b2 = (B)b.get(i);
            final a a2 = (a)this.a.d(b2.d());
            long n2;
            long n3;
            boolean a3;
            if (a2 == null) {
                n2 = b2.k();
                n3 = b2.f();
                a3 = false;
            }
            else {
                n2 = a2.c();
                a3 = a2.a();
                n3 = n.r(a2.b());
            }
            s.i(b2.d(), (Object)new y(b2.d(), b2.k(), b2.f(), b2.b(), b2.h(), n2, n3, a3, false, b2.j(), b2.c(), b2.i(), b2.e(), null));
            if (b2.b()) {
                this.a.i(b2.d(), (Object)new a(b2.k(), b2.g(), b2.b(), b2.j(), null));
            }
            else {
                this.a.k(b2.d());
            }
        }
        return new g(s, a);
    }
    
    private static final class a
    {
        private final long a;
        private final long b;
        private final boolean c;
        private final int d;
        
        private a(final long a, final long b, final boolean c, final int d) {
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
        }
        
        public final boolean a() {
            return this.c;
        }
        
        public final long b() {
            return this.b;
        }
        
        public final long c() {
            return this.a;
        }
    }
}
