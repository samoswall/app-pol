package a2;

import kotlin.jvm.internal.v;
import java.io.File;
import android.content.Context;

public abstract class a
{
    public static final File a(final Context context, final String s) {
        v.j((Object)context, "<this>");
        v.j((Object)s, "fileName");
        final File filesDir = context.getApplicationContext().getFilesDir();
        final StringBuilder sb = new StringBuilder();
        sb.append("datastore/");
        sb.append(s);
        return new File(filesDir, sb.toString());
    }
}
