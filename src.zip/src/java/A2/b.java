package A2;

import android.content.Context;

final class b
{
    public static final b a;
    
    static {
        a = new b();
    }
    
    private b() {
    }
    
    public final int a(final Context context, final int n) {
        return context.getColor(n);
    }
}
