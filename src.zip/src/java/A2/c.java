package A2;

import kotlin.jvm.internal.m;

public abstract class c
{
    public static final a a(final int n) {
        return new f(n);
    }
    
    public static final a b(final long n) {
        return new e(n, null);
    }
}
