package A2;

import kotlin.jvm.internal.m;

public abstract class d
{
    private d() {
    }
    
    public static final class a extends d
    {
        private final float a;
        
        private a(final float a) {
            super(null);
            this.a = a;
        }
        
        public final float a() {
            return this.a;
        }
    }
    
    public static final class b extends d
    {
        public static final b a;
        
        static {
            a = new b();
        }
        
        private b() {
            super(null);
        }
    }
    
    public static final class c extends d
    {
        public static final c a;
        
        static {
            a = new c();
        }
        
        private c() {
            super(null);
        }
    }
    
    public static final class d extends A2.d
    {
        private final int a;
        
        public d(final int a) {
            super(null);
            this.a = a;
        }
        
        public final int a() {
            return this.a;
        }
    }
    
    public static final class e extends d
    {
        public static final e a;
        
        static {
            a = new e();
        }
        
        private e() {
            super(null);
        }
    }
}
