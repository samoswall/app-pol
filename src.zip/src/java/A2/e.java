package A2;

import P0.I;
import android.content.Context;
import kotlin.jvm.internal.m;

public final class e implements a
{
    private final long a;
    
    private e(final long a) {
        this.a = a;
    }
    
    @Override
    public long a(final Context context) {
        return this.a;
    }
    
    public final long b() {
        return this.a;
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o instanceof e && I.q(this.a, ((e)o).a));
    }
    
    @Override
    public int hashCode() {
        return I.w(this.a);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("FixedColorProvider(color=");
        sb.append((Object)I.x(this.a));
        sb.append(')');
        return sb.toString();
    }
}
