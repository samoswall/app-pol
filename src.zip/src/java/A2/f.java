package A2;

import P0.K;
import android.content.Context;

public final class f implements a
{
    private final int a;
    
    public f(final int a) {
        this.a = a;
    }
    
    @Override
    public long a(final Context context) {
        return K.b(b.a.a(context, this.a));
    }
    
    public final int b() {
        return this.a;
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o instanceof f && this.a == ((f)o).a);
    }
    
    @Override
    public int hashCode() {
        return Integer.hashCode(this.a);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("ResourceColorProvider(resId=");
        sb.append(this.a);
        sb.append(')');
        return sb.toString();
    }
}
