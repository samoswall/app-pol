package a3;

public abstract class a
{
    public static void a(final String s, final int n) {
        c.a(f(s), n);
    }
    
    public static void b(final String s) {
        b.a(f(s));
    }
    
    public static void c(final String s, final int n) {
        c.b(f(s), n);
    }
    
    public static void d() {
        b.b();
    }
    
    public static boolean e() {
        return c.c();
    }
    
    private static String f(final String s) {
        if (s.length() <= 127) {
            return s;
        }
        return s.substring(0, 127);
    }
}
