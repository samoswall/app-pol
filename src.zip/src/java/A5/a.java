package a5;

import java.util.Iterator;
import java.util.List;
import X4.c;
import android.os.Parcel;
import java.util.ArrayList;
import android.util.SparseArray;
import java.util.HashMap;
import android.os.Parcelable$Creator;
import com.google.android.gms.common.server.response.a$b;

public final class a extends X4.a implements a$b
{
    public static final Parcelable$Creator<a> CREATOR;
    final int a;
    private final HashMap b;
    private final SparseArray c;
    
    static {
        CREATOR = (Parcelable$Creator)new e();
    }
    
    a(int i, final ArrayList list) {
        this.a = i;
        this.b = new HashMap();
        this.c = new SparseArray();
        int size;
        d d;
        for (size = ((List)list).size(), i = 0; i < size; ++i) {
            d = (d)((List)list).get(i);
            this.M(d.b, d.c);
        }
    }
    
    public a M(final String s, final int n) {
        this.b.put((Object)s, (Object)n);
        this.c.put(n, (Object)s);
        return this;
    }
    
    public final void writeToParcel(final Parcel parcel, int a) {
        final int a2 = this.a;
        a = X4.c.a(parcel);
        X4.c.t(parcel, 1, a2);
        final ArrayList list = new ArrayList();
        for (final String s : this.b.keySet()) {
            list.add((Object)new d(s, (int)this.b.get((Object)s)));
        }
        X4.c.H(parcel, 2, (List)list, false);
        X4.c.b(parcel, a);
    }
}
