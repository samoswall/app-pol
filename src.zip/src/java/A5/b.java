package a5;

import android.os.Parcelable;
import android.os.Parcel;
import com.google.android.gms.common.server.response.a$b;
import android.os.Parcelable$Creator;
import X4.a;

public final class b extends a
{
    public static final Parcelable$Creator<b> CREATOR;
    final int a;
    private final a5.a b;
    
    static {
        CREATOR = (Parcelable$Creator)new c();
    }
    
    b(final int a, final a5.a b) {
        this.a = a;
        this.b = b;
    }
    
    private b(final a5.a b) {
        this.a = 1;
        this.b = b;
    }
    
    public static b M(final a$b a$b) {
        if (a$b instanceof a5.a) {
            return new b((a5.a)a$b);
        }
        throw new IllegalArgumentException("Unsupported safe parcelable field converter class.");
    }
    
    public final a$b O() {
        final a5.a b = this.b;
        if (b != null) {
            return (a$b)b;
        }
        throw new IllegalStateException("There was no converter wrapped in this ConverterWrapper.");
    }
    
    public final void writeToParcel(final Parcel parcel, final int n) {
        final int a = this.a;
        final int a2 = X4.c.a(parcel);
        X4.c.t(parcel, 1, a);
        X4.c.B(parcel, 2, (Parcelable)this.b, n, false);
        X4.c.b(parcel, a2);
    }
}
