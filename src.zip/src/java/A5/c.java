package a5;

import X4.b;
import android.os.Parcel;
import android.os.Parcelable$Creator;

public final class c implements Parcelable$Creator
{
}
