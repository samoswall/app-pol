package a5;

import X4.c;
import android.os.Parcel;
import android.os.Parcelable$Creator;
import X4.a;

public final class d extends a
{
    public static final Parcelable$Creator<d> CREATOR;
    final int a;
    final String b;
    final int c;
    
    static {
        CREATOR = (Parcelable$Creator)new f();
    }
    
    d(final int a, final String b, final int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    d(final String b, final int c) {
        this.a = 1;
        this.b = b;
        this.c = c;
    }
    
    public final void writeToParcel(final Parcel parcel, int a) {
        final int a2 = this.a;
        a = X4.c.a(parcel);
        X4.c.t(parcel, 1, a2);
        X4.c.D(parcel, 2, this.b, false);
        X4.c.t(parcel, 3, this.c);
        X4.c.b(parcel, a);
    }
}
