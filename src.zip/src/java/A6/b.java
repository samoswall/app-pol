package a6;

import java.security.GeneralSecurityException;
import Z5.a;
import Z5.g;

public final class b implements g
{
    private static final com.google.crypto.tink.config.internal.b.b b;
    private final a a;
    
    static {
        b = com.google.crypto.tink.config.internal.b.b.ALGORITHM_NOT_FIPS;
    }
    
    public b(final a a) {
        if (a6.b.b.isCompatible()) {
            this.a = a;
            return;
        }
        throw new GeneralSecurityException("Can not use AES-CMAC in FIPS-mode.");
    }
}
