package a6;

import java.security.GeneralSecurityException;
import Z5.i;
import com.google.crypto.tink.config.internal.b;
import Z5.g;

public final class c implements g
{
    private static final b.b b;
    private final i a;
    
    static {
        b = com.google.crypto.tink.config.internal.b.b.ALGORITHM_REQUIRES_BORINGCRYPTO;
    }
    
    public c(final i a) {
        if (c.b.isCompatible()) {
            this.a = a;
            return;
        }
        throw new GeneralSecurityException("Can not use HMAC in FIPS-mode, as BoringCrypto module is not available.");
    }
}
