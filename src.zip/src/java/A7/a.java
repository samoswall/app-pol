package a7;

import java.util.List;
import f7.b;
import h7.e;
import java.util.Arrays;
import Y6.h;
import h7.c;

public final class a
{
    private static final String[] b;
    private static final String[] c;
    private static final String[] d;
    private static final String[] e;
    private static final String[] f;
    private Z6.a a;
    
    static {
        b = new String[] { "CTRL_PS", " ", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "CTRL_LL", "CTRL_ML", "CTRL_DL", "CTRL_BS" };
        c = new String[] { "CTRL_PS", " ", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "CTRL_US", "CTRL_ML", "CTRL_DL", "CTRL_BS" };
        d = new String[] { "CTRL_PS", " ", "\u0001", "\u0002", "\u0003", "\u0004", "\u0005", "\u0006", "\u0007", "\b", "\t", "\n", "\u000b", "\f", "\r", "\u001b", "\u001c", "\u001d", "\u001e", "\u001f", "@", "\\", "^", "_", "`", "|", "~", "\u007f", "CTRL_LL", "CTRL_UL", "CTRL_PL", "CTRL_BS" };
        e = new String[] { "", "\r", "\r\n", ". ", ", ", ": ", "!", "\"", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", ":", ";", "<", "=", ">", "?", "[", "]", "{", "}", "CTRL_UL" };
        f = new String[] { "CTRL_PS", " ", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ",", ".", "CTRL_UL", "CTRL_US" };
    }
    
    static byte[] a(final boolean[] array) {
        final int n = (array.length + 7) / 8;
        final byte[] array2 = new byte[n];
        for (int i = 0; i < n; ++i) {
            array2[i] = h(array, i << 3);
        }
        return array2;
    }
    
    private boolean[] b(boolean[] array) {
        h7.a a;
        int n;
        if (this.a.d() <= 2) {
            a = h7.a.j;
            n = 6;
        }
        else {
            final int d = this.a.d();
            n = 8;
            if (d <= 8) {
                a = h7.a.n;
            }
            else if (this.a.d() <= 22) {
                a = h7.a.i;
                n = 10;
            }
            else {
                a = h7.a.h;
                n = 12;
            }
        }
        final int c = this.a.c();
        final int n2 = array.length / n;
        if (n2 >= c) {
            int n3 = array.length % n;
            final int[] array2 = new int[n2];
            for (int i = 0; i < n2; ++i, n3 += n) {
                array2[i] = i(array, n3, n);
            }
            try {
                new c(a).a(array2, n2 - c);
                final int n4 = 1 << n;
                int j = 0;
                int n5 = 0;
                while (j < c) {
                    final int n6 = array2[j];
                    if (n6 == 0 || n6 == n4 - 1) {
                        throw h.a();
                    }
                    int n7 = 0;
                    Label_0225: {
                        if (n6 != 1) {
                            n7 = n5;
                            if (n6 != n4 - 2) {
                                break Label_0225;
                            }
                        }
                        n7 = n5 + 1;
                    }
                    ++j;
                    n5 = n7;
                }
                array = new boolean[c * n - n5];
                int k = 0;
                int n8 = 0;
                while (k < c) {
                    final int n9 = array2[k];
                    if (n9 != 1 && n9 != n4 - 2) {
                        int n10 = n - 1;
                        int n11 = n8;
                        while (true) {
                            n8 = n11;
                            if (n10 < 0) {
                                break;
                            }
                            array[n11] = ((1 << n10 & n9) != 0x0);
                            --n10;
                            ++n11;
                        }
                    }
                    else {
                        Arrays.fill(array, n8, n8 + n - 1, n9 > 1);
                        n8 += n - 1;
                    }
                    ++k;
                }
                return array;
            }
            catch (final e e) {
                throw h.b((Throwable)e);
            }
        }
        throw h.a();
    }
    
    private boolean[] d(final f7.b b) {
        final boolean e = this.a.e();
        final int d = this.a.d();
        int n;
        if (e) {
            n = 11;
        }
        else {
            n = 14;
        }
        final int n2 = n + (d << 2);
        final int[] array = new int[n2];
        final boolean[] array2 = new boolean[j(d, e)];
        if (e) {
            for (int i = 0; i < n2; ++i) {
                array[i] = i;
            }
        }
        else {
            final int n3 = n2 / 2;
            final int n4 = (n2 + 1 + (n3 - 1) / 15 * 2) / 2;
            for (int j = 0; j < n3; ++j) {
                final int n5 = j / 15 + j;
                array[n3 - j - 1] = n4 - n5 - 1;
                array[n3 + j] = n5 + n4 + 1;
            }
        }
        int k = 0;
        int n6 = 0;
        for (int n7 = d; k < n7; ++k) {
            int n8;
            if (e) {
                n8 = 9;
            }
            else {
                n8 = 12;
            }
            final int n9 = (n7 - k << 2) + n8;
            final int n10 = k << 1;
            final int n11 = n2 - 1 - n10;
            for (int l = 0; l < n9; ++l) {
                final int n12 = l << 1;
                for (int n13 = 0; n13 < 2; ++n13) {
                    final int n14 = n10 + n13;
                    final int n15 = array[n14];
                    final int n16 = n10 + l;
                    array2[n6 + n12 + n13] = b.e(n15, array[n16]);
                    final int n17 = array[n16];
                    final int n18 = n11 - n13;
                    array2[n9 * 2 + n6 + n12 + n13] = b.e(n17, array[n18]);
                    final int n19 = array[n18];
                    final int n20 = n11 - l;
                    array2[n9 * 4 + n6 + n12 + n13] = b.e(n19, array[n20]);
                    array2[n9 * 6 + n6 + n12 + n13] = b.e(array[n20], array[n14]);
                }
            }
            n6 += n9 << 3;
        }
        return array2;
    }
    
    private static String e(final b b, final int n) {
        final int n2 = a$a.a[b.ordinal()];
        if (n2 == 1) {
            return a.b[n];
        }
        if (n2 == 2) {
            return a.c[n];
        }
        if (n2 == 3) {
            return a.d[n];
        }
        if (n2 == 4) {
            return a.e[n];
        }
        if (n2 == 5) {
            return a.f[n];
        }
        throw new IllegalStateException("Bad table");
    }
    
    private static String f(final boolean[] array) {
        final int length = array.length;
        b upper = a.b.UPPER;
        final StringBuilder sb = new StringBuilder(20);
        b b = upper;
        int i = 0;
        while (i < length) {
            Label_0146: {
                if (upper == a.b.BINARY) {
                    if (length - i < 5) {
                        break;
                    }
                    final int j = i(array, i, 5);
                    final int n = i + 5;
                    int n2 = j;
                    int n3 = n;
                    if (j == 0) {
                        if (length - n < 11) {
                            break;
                        }
                        n2 = i(array, n, 11) + 31;
                        n3 = i + 16;
                    }
                    for (int k = 0; k < n2; ++k) {
                        if (length - n3 < 8) {
                            i = length;
                            break Label_0146;
                        }
                        sb.append((char)i(array, n3, 8));
                        n3 += 8;
                    }
                    i = n3;
                }
                else {
                    int n4;
                    if (upper == a.b.DIGIT) {
                        n4 = 4;
                    }
                    else {
                        n4 = 5;
                    }
                    if (length - i < n4) {
                        break;
                    }
                    final int l = i(array, i, n4);
                    i += n4;
                    final String e = e(upper, l);
                    if (e.startsWith("CTRL_")) {
                        final b g = g(e.charAt(5));
                        if (e.charAt(6) != 'L') {
                            b = upper;
                            upper = g;
                            continue;
                        }
                        b = g;
                    }
                    else {
                        sb.append(e);
                    }
                }
            }
            upper = b;
        }
        return sb.toString();
    }
    
    private static b g(final char c) {
        if (c == 'B') {
            return a.b.BINARY;
        }
        if (c == 'D') {
            return a.b.DIGIT;
        }
        if (c == 'P') {
            return a.b.PUNCT;
        }
        if (c == 'L') {
            return a.b.LOWER;
        }
        if (c != 'M') {
            return a.b.UPPER;
        }
        return a.b.MIXED;
    }
    
    private static byte h(final boolean[] array, int i) {
        final int n = array.length - i;
        if (n >= 8) {
            i = i(array, i, 8);
        }
        else {
            i = i(array, i, n) << 8 - n;
        }
        return (byte)i;
    }
    
    private static int i(final boolean[] array, final int n, final int n2) {
        int n3 = 0;
        for (int i = n; i < n + n2; ++i) {
            final int n4 = n3 <<= 1;
            if (array[i]) {
                n3 = (n4 | 0x1);
            }
        }
        return n3;
    }
    
    private static int j(final int n, final boolean b) {
        int n2;
        if (b) {
            n2 = 88;
        }
        else {
            n2 = 112;
        }
        return (n2 + (n << 4)) * n;
    }
    
    public f7.e c(final Z6.a a) {
        this.a = a;
        final boolean[] b = this.b(this.d(a.a()));
        final f7.e e = new f7.e(a(b), f(b), (List)null, (String)null);
        e.l(b.length);
        return e;
    }
    
    private enum b
    {
        private static final b[] $VALUES;
        
        BINARY, 
        DIGIT, 
        LOWER, 
        MIXED, 
        PUNCT, 
        UPPER;
    }
}
