package A7;

import Y6.w;
import Y6.l;
import Y6.a;
import android.graphics.Bitmap$Config;
import android.graphics.Bitmap;

public class b
{
    public Bitmap a(final f7.b b) {
        final int l = b.l();
        final int i = b.i();
        final int[] array = new int[l * i];
        for (int j = 0; j < i; ++j) {
            for (int k = 0; k < l; ++k) {
                int n;
                if (b.e(k, j)) {
                    n = -16777216;
                }
                else {
                    n = -1;
                }
                array[j * l + k] = n;
            }
        }
        final Bitmap bitmap = Bitmap.createBitmap(l, i, Bitmap$Config.ARGB_8888);
        bitmap.setPixels(array, 0, l, 0, 0, l, i);
        return bitmap;
    }
    
    public f7.b b(final String s, final a a, final int n, final int n2) {
        try {
            return new l().b(s, a, n, n2);
        }
        catch (final Exception ex) {}
        catch (final w w) {
            throw w;
        }
        final Exception ex;
        throw new w((Throwable)ex);
    }
    
    public Bitmap c(final String s, final a a, final int n, final int n2) {
        return this.a(this.b(s, a, n, n2));
    }
}
