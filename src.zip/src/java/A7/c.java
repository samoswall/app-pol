package A7;

import java.util.Map;
import android.graphics.Rect;
import android.graphics.Bitmap;
import Y6.a;
import java.util.Iterator;
import Y6.t;
import java.util.ArrayList;
import java.util.List;
import Y6.r;

public class c
{
    protected r a;
    protected s b;
    private final int c;
    
    public c(final r a, final s b) {
        this.c = 2;
        this.a = a;
        this.b = b;
    }
    
    public static List f(final List list, final s s) {
        final ArrayList list2 = new ArrayList(list.size());
        final Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            ((List)list2).add((Object)s.f((t)iterator.next()));
        }
        return (List)list2;
    }
    
    public a a() {
        return this.a.b();
    }
    
    public Bitmap b() {
        return this.b.b(null, 2);
    }
    
    public byte[] c() {
        return this.a.c();
    }
    
    public Map d() {
        return this.a.d();
    }
    
    public String e() {
        return this.a.f();
    }
    
    @Override
    public String toString() {
        return this.a.f();
    }
}
