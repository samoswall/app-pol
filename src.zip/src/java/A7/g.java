package A7;

import android.content.Context;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;

public class g extends DecoratedBarcodeView
{
    public g(final Context context) {
        super(context);
    }
}
