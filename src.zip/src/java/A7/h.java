package A7;

import Y6.b;
import java.util.Collection;
import Y6.j;
import Y6.k;
import Y6.r;
import Y6.c;
import Y6.t;
import java.util.ArrayList;
import java.util.List;
import Y6.p;
import Y6.u;

public class h implements u
{
    private p a;
    private List b;
    
    public h(final p a) {
        this.b = (List)new ArrayList();
        this.a = a;
    }
    
    @Override
    public void a(final t t) {
        this.b.add((Object)t);
    }
    
    protected r b(final c c) {
        this.b.clear();
        try {
            final p a = this.a;
            if (a instanceof k) {
                final r e = ((k)a).e(c);
                this.a.a();
                return e;
            }
            goto Label_0045;
        }
        catch (final Exception ex) {
            this.a.a();
            return null;
        }
        finally {
            goto Label_0056;
        }
    }
    
    public r c(final j j) {
        return this.b(this.e(j));
    }
    
    public List d() {
        return (List)new ArrayList((Collection)this.b);
    }
    
    protected c e(final j j) {
        return new c((b)new f7.j(j));
    }
}
