package A7;

import java.util.Map;

public interface i
{
    h a(final Map p0);
}
