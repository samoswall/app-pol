package A7;

import Y6.t;
import Y6.u;

public class j implements u
{
    private h a;
    
    @Override
    public void a(final t t) {
        final h a = this.a;
        if (a != null) {
            a.a(t);
        }
    }
    
    public void b(final h a) {
        this.a = a;
    }
}
