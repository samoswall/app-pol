package A7;

import Y6.r;
import Y6.j;
import android.os.Bundle;
import android.util.Log;
import android.os.Message;
import B7.p;
import android.os.Handler$Callback;
import android.graphics.Rect;
import android.os.Handler;
import android.os.HandlerThread;
import B7.g;

public class k
{
    private static final String k = "k";
    private g a;
    private HandlerThread b;
    private Handler c;
    private h d;
    private Handler e;
    private Rect f;
    private boolean g;
    private final Object h;
    private final Handler$Callback i;
    private final p j;
    
    public k(final g a, final h d, final Handler e) {
        this.g = false;
        this.h = new Object();
        this.i = (Handler$Callback)new Handler$Callback() {
            final k a;
            
            public boolean handleMessage(final Message message) {
                final int what = message.what;
                if (what == d7.k.e) {
                    this.a.g((s)message.obj);
                }
                else if (what == d7.k.i) {
                    this.a.h();
                }
                return true;
            }
        };
        this.j = new p() {
            final k a;
            
            @Override
            public void a(final Exception ex) {
                final Object c;
                monitorenter(c = this.a.h);
                Label_0045: {
                    try {
                        if (this.a.g) {
                            this.a.c.obtainMessage(d7.k.i).sendToTarget();
                        }
                        break Label_0045;
                    }
                    finally {
                        monitorexit(c);
                        monitorexit(c);
                    }
                }
            }
            
            @Override
            public void b(final s s) {
                final Object c;
                monitorenter(c = this.a.h);
                Label_0046: {
                    try {
                        if (this.a.g) {
                            this.a.c.obtainMessage(d7.k.e, (Object)s).sendToTarget();
                        }
                        break Label_0046;
                    }
                    finally {
                        monitorexit(c);
                        monitorexit(c);
                    }
                }
            }
        };
        t.a();
        this.a = a;
        this.d = d;
        this.e = e;
    }
    
    private void g(final s s) {
        final long currentTimeMillis = System.currentTimeMillis();
        s.d(this.f);
        final j f = this.f(s);
        r c;
        if (f != null) {
            c = this.d.c(f);
        }
        else {
            c = null;
        }
        if (c != null) {
            final long currentTimeMillis2 = System.currentTimeMillis();
            final String k = A7.k.k;
            final StringBuilder sb = new StringBuilder();
            sb.append("Found barcode in ");
            sb.append(currentTimeMillis2 - currentTimeMillis);
            sb.append(" ms");
            Log.d(k, sb.toString());
            if (this.e != null) {
                final Message obtain = Message.obtain(this.e, d7.k.g, (Object)new c(c, s));
                obtain.setData(new Bundle());
                obtain.sendToTarget();
            }
        }
        else {
            final Handler e = this.e;
            if (e != null) {
                Message.obtain(e, d7.k.f).sendToTarget();
            }
        }
        if (this.e != null) {
            Message.obtain(this.e, d7.k.h, (Object)A7.c.f(this.d.d(), s)).sendToTarget();
        }
        this.h();
    }
    
    private void h() {
        this.a.v(this.j);
    }
    
    protected j f(final s s) {
        if (this.f == null) {
            return null;
        }
        return (j)s.a();
    }
    
    public void i(final Rect f) {
        this.f = f;
    }
    
    public void j(final h d) {
        this.d = d;
    }
    
    public void k() {
        t.a();
        ((Thread)(this.b = new HandlerThread(A7.k.k))).start();
        this.c = new Handler(this.b.getLooper(), this.i);
        this.g = true;
        this.h();
    }
    
    public void l() {
        t.a();
        final Object h = this.h;
        synchronized (h) {
            this.g = false;
            this.c.removeCallbacksAndMessages((Object)null);
            this.b.quit();
        }
    }
}
