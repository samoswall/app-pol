package A7;

import Y6.p;
import Y6.k;
import java.util.EnumMap;
import Y6.e;
import java.util.Map;
import java.util.Collection;

public class l implements i
{
    private Collection a;
    private Map b;
    private String c;
    private int d;
    
    public l() {
    }
    
    public l(final Collection a, final Map b, final String c, final int d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    @Override
    public h a(Map b) {
        final EnumMap enumMap = new EnumMap((Class)e.class);
        ((Map)enumMap).putAll(b);
        b = this.b;
        if (b != null) {
            ((Map)enumMap).putAll(b);
        }
        final Collection a = this.a;
        if (a != null) {
            ((Map)enumMap).put((Object)e.POSSIBLE_FORMATS, (Object)a);
        }
        final String c = this.c;
        if (c != null) {
            ((Map)enumMap).put((Object)e.CHARACTER_SET, (Object)c);
        }
        final k k = new k();
        k.f((Map)enumMap);
        final int d = this.d;
        if (d == 0) {
            return new h((p)k);
        }
        if (d == 1) {
            return new m((p)k);
        }
        if (d != 2) {
            return new h((p)k);
        }
        return new n((p)k);
    }
}
