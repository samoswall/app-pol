package A7;

import Y6.b;
import Y6.c;
import Y6.j;
import Y6.p;

public class m extends h
{
    public m(final p p) {
        super(p);
    }
    
    @Override
    protected c e(final j j) {
        return new c((b)new f7.j(j.e()));
    }
}
