package A7;

import Y6.b;
import Y6.c;
import Y6.j;
import Y6.p;

public class n extends h
{
    private boolean c;
    
    public n(final p p) {
        super(p);
        this.c = true;
    }
    
    @Override
    protected c e(final j j) {
        if (this.c) {
            this.c = false;
            return new c((b)new f7.j(j.e()));
        }
        this.c = true;
        return new c((b)new f7.j(j));
    }
}
