package A7;

import android.graphics.Rect;

public class o
{
    private byte[] a;
    private int b;
    private int c;
    
    public o(final byte[] a, final int b, final int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public static byte[] e(final byte[] array, int i, int n) {
        final int n2 = i * n;
        final byte[] array2 = new byte[n2];
        n = n2 - 1;
        for (i = 0; i < n2; ++i) {
            array2[n] = array[i];
            --n;
        }
        return array2;
    }
    
    public static byte[] f(final byte[] array, final int n, final int n2) {
        final int n3 = n * n2;
        final byte[] array2 = new byte[n3];
        int n4 = n3 - 1;
        for (int i = 0; i < n; ++i) {
            for (int j = n2 - 1; j >= 0; --j) {
                array2[n4] = array[j * n + i];
                --n4;
            }
        }
        return array2;
    }
    
    public static byte[] g(final byte[] array, final int n, final int n2) {
        final byte[] array2 = new byte[n * n2];
        int i = 0;
        int n3 = 0;
        while (i < n) {
            for (int j = n2 - 1; j >= 0; --j) {
                array2[n3] = array[j * n + i];
                ++n3;
            }
            ++i;
        }
        return array2;
    }
    
    public o a(final Rect rect, int i) {
        final int n = rect.width() / i;
        final int n2 = rect.height() / i;
        final int top = rect.top;
        final byte[] array = new byte[n * n2];
        final int n3 = 0;
        if (i == 1) {
            final int n4 = top * this.b + rect.left;
            i = n3;
            int n5 = n4;
            while (i < n2) {
                System.arraycopy((Object)this.a, n5, (Object)array, i * n, n);
                n5 += this.b;
                ++i;
            }
        }
        else {
            int n6 = top * this.b + rect.left;
            for (int j = 0; j < n2; ++j) {
                int n7 = j * n;
                int n8 = n6;
                for (int k = 0; k < n; ++k) {
                    array[n7] = this.a[n8];
                    n8 += i;
                    ++n7;
                }
                n6 += this.b * i;
            }
        }
        return new o(array, n, n2);
    }
    
    public byte[] b() {
        return this.a;
    }
    
    public int c() {
        return this.c;
    }
    
    public int d() {
        return this.b;
    }
    
    public o h(final int n) {
        if (n == 90) {
            return new o(g(this.a, this.b, this.c), this.c, this.b);
        }
        if (n == 180) {
            return new o(e(this.a, this.b, this.c), this.b, this.c);
        }
        if (n != 270) {
            return this;
        }
        return new o(f(this.a, this.b, this.c), this.c, this.b);
    }
}
