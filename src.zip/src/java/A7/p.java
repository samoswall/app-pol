package A7;

public interface p
{
    void a(final int p0);
}
