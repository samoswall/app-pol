package A7;

import android.content.Context;
import android.view.OrientationEventListener;
import android.view.WindowManager;

public class q
{
    private int a;
    private WindowManager b;
    private OrientationEventListener c;
    private p d;
    
    public void e(Context applicationContext, final p d) {
        this.f();
        applicationContext = applicationContext.getApplicationContext();
        this.d = d;
        this.b = (WindowManager)applicationContext.getSystemService("window");
        (this.c = new OrientationEventListener(this, applicationContext, 3) {
            final q a;
            
            public void onOrientationChanged(int rotation) {
                final WindowManager a = this.a.b;
                final p b = this.a.d;
                if (this.a.b != null && b != null) {
                    rotation = a.getDefaultDisplay().getRotation();
                    if (rotation != this.a.a) {
                        this.a.a = rotation;
                        b.a(rotation);
                    }
                }
            }
        }).enable();
        this.a = this.b.getDefaultDisplay().getRotation();
    }
    
    public void f() {
        final OrientationEventListener c = this.c;
        if (c != null) {
            c.disable();
        }
        this.c = null;
        this.b = null;
        this.d = null;
    }
}
