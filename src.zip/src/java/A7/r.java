package A7;

public class r implements Comparable
{
    public final int a;
    public final int b;
    
    public r(final int a, final int b) {
        this.a = a;
        this.b = b;
    }
    
    public int b(final r r) {
        final int n = this.b * this.a;
        final int n2 = r.b * r.a;
        if (n2 < n) {
            return 1;
        }
        if (n2 > n) {
            return -1;
        }
        return 0;
    }
    
    public r c() {
        return new r(this.b, this.a);
    }
    
    public r e(final r r) {
        final int a = this.a;
        final int b = r.b;
        final int a2 = r.a;
        final int b2 = this.b;
        if (a * b <= a2 * b2) {
            return new r(a2, b2 * a2 / a);
        }
        return new r(a * b / b2, b);
    }
    
    @Override
    public boolean equals(final Object o) {
        boolean b = true;
        if (this == o) {
            return true;
        }
        if (o != null && this.getClass() == o.getClass()) {
            final r r = (r)o;
            if (this.a != r.a || this.b != r.b) {
                b = false;
            }
            return b;
        }
        return false;
    }
    
    public r f(final r r) {
        final int a = this.a;
        final int b = r.b;
        final int a2 = r.a;
        final int b2 = this.b;
        if (a * b >= a2 * b2) {
            return new r(a2, b2 * a2 / a);
        }
        return new r(a * b / b2, b);
    }
    
    @Override
    public int hashCode() {
        return this.a * 31 + this.b;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(this.a);
        sb.append("x");
        sb.append(this.b);
        return sb.toString();
    }
}
