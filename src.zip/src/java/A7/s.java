package A7;

import Y6.t;
import android.graphics.Matrix;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory$Options;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import android.graphics.YuvImage;
import android.graphics.Bitmap;
import Y6.n;
import android.graphics.Rect;

public class s
{
    private o a;
    private int b;
    private int c;
    private Rect d;
    private int e;
    private boolean f;
    
    public s(final byte[] array, final int n, final int n2, final int b, final int c) {
        this.e = 1;
        this.a = new o(array, n, n2);
        this.c = c;
        this.b = b;
        if (n * n2 <= array.length) {
            return;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("Image data does not match the resolution. ");
        sb.append(n);
        sb.append("x");
        sb.append(n2);
        sb.append(" > ");
        sb.append(array.length);
        throw new IllegalArgumentException(sb.toString());
    }
    
    public n a() {
        final o a = this.a.h(this.c).a(this.d, this.e);
        return new n(a.b(), a.d(), a.c(), 0, 0, a.d(), a.c(), false);
    }
    
    public Bitmap b(final Rect rect, final int inSampleSize) {
        Rect rect2;
        if (rect == null) {
            rect2 = new Rect(0, 0, this.a.d(), this.a.c());
        }
        else {
            rect2 = rect;
            if (this.c()) {
                rect2 = new Rect(rect.top, rect.left, rect.bottom, rect.right);
            }
        }
        final YuvImage yuvImage = new YuvImage(this.a.b(), this.b, this.a.d(), this.a.c(), (int[])null);
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        yuvImage.compressToJpeg(rect2, 90, (OutputStream)byteArrayOutputStream);
        final byte[] byteArray = byteArrayOutputStream.toByteArray();
        final BitmapFactory$Options bitmapFactory$Options = new BitmapFactory$Options();
        bitmapFactory$Options.inSampleSize = inSampleSize;
        Bitmap bitmap2;
        final Bitmap bitmap = bitmap2 = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length, bitmapFactory$Options);
        if (this.c != 0) {
            final Matrix matrix = new Matrix();
            matrix.postRotate((float)this.c);
            bitmap2 = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, false);
        }
        return bitmap2;
    }
    
    public boolean c() {
        return this.c % 180 != 0;
    }
    
    public void d(final Rect d) {
        this.d = d;
    }
    
    public void e(final boolean f) {
        this.f = f;
    }
    
    public t f(final t t) {
        final float n = t.c() * this.e + this.d.left;
        final float d = t.d();
        final float n2 = (float)this.e;
        final float n3 = (float)this.d.top;
        float n4 = n;
        if (this.f) {
            n4 = this.a.d() - n;
        }
        return new t(n4, d * n2 + n3);
    }
}
