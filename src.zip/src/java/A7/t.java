package A7;

import android.os.Looper;

public abstract class t
{
    public static void a() {
        if (Looper.getMainLooper() == Looper.myLooper()) {
            return;
        }
        throw new IllegalStateException("Must be called from the main thread.");
    }
}
