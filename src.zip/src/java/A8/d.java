package A8;

import java.util.Collection;
import java.util.Set;
import java.util.Map;

public final class d implements Map
{
    private final Map a;
    
    private d(final Map a) {
        this.a = a;
    }
    
    public static Map b(final Map map) {
        return (Map)new d(map);
    }
    
    public void clear() {
        throw new UnsupportedOperationException("Dagger map bindings are immutable");
    }
    
    public boolean containsKey(final Object o) {
        if (o instanceof Class) {
            return this.a.containsKey((Object)((Class)o).getName());
        }
        throw new IllegalArgumentException("Key must be a class");
    }
    
    public boolean containsValue(final Object o) {
        return this.a.containsValue(o);
    }
    
    public Object d(final Class clazz, final Object o) {
        throw new UnsupportedOperationException("Dagger map bindings are immutable");
    }
    
    public Set entrySet() {
        throw new UnsupportedOperationException("Maps created with @LazyClassKey do not support usage of entrySet(). Consider @ClassKey instead.");
    }
    
    public Object get(final Object o) {
        if (o instanceof Class) {
            return this.a.get((Object)((Class)o).getName());
        }
        throw new IllegalArgumentException("Key must be a class");
    }
    
    public boolean isEmpty() {
        return this.a.isEmpty();
    }
    
    public Set keySet() {
        throw new UnsupportedOperationException("Maps created with @LazyClassKey do not support usage of keySet(). Consider @ClassKey instead.");
    }
    
    public void putAll(final Map map) {
        throw new UnsupportedOperationException("Dagger map bindings are immutable");
    }
    
    public Object remove(final Object o) {
        throw new UnsupportedOperationException("Dagger map bindings are immutable");
    }
    
    public int size() {
        return this.a.size();
    }
    
    public Collection values() {
        return this.a.values();
    }
}
