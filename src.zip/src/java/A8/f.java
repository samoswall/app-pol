package A8;

import I8.a;

public interface f extends a
{
}
