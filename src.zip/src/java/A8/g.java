package A8;

public final class g implements f
{
    private static final Object c;
    private volatile f a;
    private volatile Object b;
    
    static {
        c = new Object();
    }
    
    private g(final f a) {
        this.b = g.c;
        this.a = a;
    }
    
    public static f a(final f f) {
        if (!(f instanceof g) && !(f instanceof A8.a)) {
            return new g((f)e.b(f));
        }
        return f;
    }
    
    @Override
    public Object get() {
        Object b;
        if ((b = this.b) == g.c) {
            final f a = this.a;
            if (a == null) {
                b = this.b;
            }
            else {
                b = a.get();
                this.b = b;
                this.a = null;
            }
        }
        return b;
    }
}
