package a9;

import e9.j;

public interface a
{
    Object a(final Object p0, final j p1);
}
