package A9;

import java.util.concurrent.TimeUnit;
import D9.d;
import D9.s;
import D9.t;
import D9.r;
import D9.l;
import org.eclipse.paho.client.mqttv3.j;
import org.eclipse.paho.client.mqttv3.q;
import org.eclipse.paho.client.mqttv3.k;
import java.io.EOFException;
import org.eclipse.paho.client.mqttv3.m;
import java.util.Enumeration;
import D9.n;
import D9.u;
import org.eclipse.paho.client.mqttv3.h;
import java.util.Vector;
import org.eclipse.paho.client.mqttv3.logging.a;
import org.eclipse.paho.client.mqttv3.o;
import java.util.Hashtable;

public class b
{
    private static final String E = "A9.b";
    private Hashtable A;
    private Hashtable B;
    private Hashtable C;
    private o D;
    private a a;
    private int b;
    private Hashtable c;
    private volatile Vector d;
    private volatile Vector e;
    private f f;
    private A9.a g;
    private c h;
    private long i;
    private boolean j;
    private h k;
    private i l;
    private int m;
    private int n;
    private int o;
    private final Object p;
    private final Object q;
    private boolean r;
    private long s;
    private long t;
    private long u;
    private u v;
    private final Object w;
    private int x;
    private boolean y;
    private Hashtable z;
    
    protected b(final h k, final f f, final c h, final A9.a g, final o d, final i l) {
        final String e = A9.b.E;
        final a a = org.eclipse.paho.client.mqttv3.logging.b.a("org.eclipse.paho.client.mqttv3.internal.nls.logcat", e);
        this.a = a;
        this.b = 0;
        this.g = null;
        this.h = null;
        this.m = 0;
        this.n = 0;
        this.o = 0;
        this.p = new Object();
        this.q = new Object();
        this.r = false;
        this.s = 0L;
        this.t = 0L;
        this.u = 0L;
        this.w = new Object();
        this.x = 0;
        this.y = false;
        this.z = null;
        this.A = null;
        this.B = null;
        this.C = null;
        this.D = null;
        a.setResourceName(g.t().a0());
        this.a.finer(e, "<Init>", "");
        this.c = new Hashtable();
        this.e = new Vector();
        this.z = new Hashtable();
        this.A = new Hashtable();
        this.B = new Hashtable();
        this.C = new Hashtable();
        this.v = new D9.i();
        this.o = 0;
        this.n = 0;
        this.k = k;
        this.h = h;
        this.f = f;
        this.g = g;
        this.D = d;
        this.l = l;
        this.F();
    }
    
    private Vector A(final Vector vector) {
        final Vector vector2 = new Vector();
        if (vector.size() == 0) {
            return vector2;
        }
        final int n = 0;
        final int n2 = 0;
        int n3 = 0;
        int n5;
        int n4 = n5 = n3;
        int q;
        int n7;
        for (int i = n2; i < vector.size(); ++i, n3 = q, n5 = n7) {
            q = ((u)vector.elementAt(i)).q();
            final int n6 = q - n3;
            if (n6 > (n7 = n5)) {
                n4 = i;
                n7 = n6;
            }
        }
        if (65535 - n3 + ((u)vector.elementAt(0)).q() > n5) {
            n4 = 0;
        }
        int n8 = n4;
        int j;
        while (true) {
            j = n;
            if (n8 >= vector.size()) {
                break;
            }
            vector2.addElement(vector.elementAt(n8));
            ++n8;
        }
        while (j < n4) {
            vector2.addElement(vector.elementAt(j));
            ++j;
        }
        return vector2;
    }
    
    private void B(final int n) {
        synchronized (this) {
            this.c.remove((Object)n);
        }
    }
    
    private void D() {
        this.d = new Vector(this.m);
        this.e = new Vector();
        final Enumeration keys = this.z.keys();
        while (keys.hasMoreElements()) {
            final Object nextElement = keys.nextElement();
            final u u = (u)this.z.get(nextElement);
            if (u instanceof D9.o) {
                this.a.fine(A9.b.E, "restoreInflightMessages", "610", new Object[] { nextElement });
                u.y(true);
                this.q(this.d, u);
            }
            else {
                if (!(u instanceof n)) {
                    continue;
                }
                this.a.fine(A9.b.E, "restoreInflightMessages", "611", new Object[] { nextElement });
                this.q(this.e, u);
            }
        }
        final Enumeration keys2 = this.A.keys();
        while (keys2.hasMoreElements()) {
            final Object nextElement2 = keys2.nextElement();
            final D9.o o = (D9.o)this.A.get(nextElement2);
            o.y(true);
            this.a.fine(A9.b.E, "restoreInflightMessages", "612", new Object[] { nextElement2 });
            this.q(this.d, o);
        }
        final Enumeration keys3 = this.B.keys();
        while (keys3.hasMoreElements()) {
            final Object nextElement3 = keys3.nextElement();
            final D9.o o2 = (D9.o)this.B.get(nextElement3);
            this.a.fine(A9.b.E, "restoreInflightMessages", "512", new Object[] { nextElement3 });
            this.q(this.d, o2);
        }
        this.e = this.A(this.e);
        this.d = this.A(this.d);
    }
    
    private u E(final String s, final m m) {
        u h;
        try {
            h = D9.u.h(m);
        }
        catch (final k k) {
            this.a.fine(A9.b.E, "restoreMessage", "602", new Object[] { s }, (Throwable)k);
            if (!(k.getCause() instanceof EOFException)) {
                throw k;
            }
            if (s != null) {
                this.k.remove(s);
            }
            h = null;
        }
        this.a.fine(A9.b.E, "restoreMessage", "601", new Object[] { s, h });
        return h;
    }
    
    private void f() {
        final Object p;
        monitorenter(p = this.p);
        Label_0072: {
            try {
                final int n = this.n - 1;
                this.n = n;
                this.a.fine(A9.b.E, "decrementInFlight", "646", new Object[] { n });
                if (!this.b()) {
                    this.p.notifyAll();
                }
                break Label_0072;
            }
            finally {
                monitorexit(p);
                monitorexit(p);
            }
        }
    }
    
    private int l() {
        monitorenter(this);
        Label_0043: {
            try {
                final int b = this.b;
                final int n = 0;
                Label_0012: {
                    if (++this.b > 65535) {
                        this.b = 1;
                    }
                }
                break Label_0043;
            }
            finally {
                monitorexit(this);
                while (true) {
                    Block_7: {
                        while (true) {
                            int n;
                            while (true) {
                                final int n2;
                                n = n2;
                                final int b2;
                                iftrue(Label_0012:)(this.c.containsKey((Object)b2));
                                break Block_7;
                                continue;
                            }
                            final int n2 = n + 1;
                            iftrue(Label_0069:)(n2 == 2);
                            continue;
                        }
                        Label_0069: {
                            throw A9.h.a(32001);
                        }
                    }
                    final Integer value = this.b;
                    this.c.put((Object)value, (Object)value);
                    final int b3 = this.b;
                    monitorexit(this);
                    return b3;
                    final int b2 = this.b;
                    int n = 0;
                    final int n2 = n;
                    final int b;
                    iftrue(Label_0076:)(b2 != b);
                    continue;
                }
            }
        }
    }
    
    private String m(final u u) {
        final int q = u.q();
        final StringBuilder sb = new StringBuilder();
        sb.append("r-");
        sb.append(q);
        return sb.toString();
    }
    
    private String n(final u u) {
        final int q = u.q();
        final StringBuilder sb = new StringBuilder();
        sb.append("sb-");
        sb.append(q);
        return sb.toString();
    }
    
    private String o(final u u) {
        final int q = u.q();
        final StringBuilder sb = new StringBuilder();
        sb.append("sc-");
        sb.append(q);
        return sb.toString();
    }
    
    private String p(final u u) {
        final int q = u.q();
        final StringBuilder sb = new StringBuilder();
        sb.append("s-");
        sb.append(q);
        return sb.toString();
    }
    
    private void q(final Vector vector, final u u) {
        final int q = u.q();
        for (int i = 0; i < vector.size(); ++i) {
            if (((u)vector.elementAt(i)).q() > q) {
                vector.insertElementAt((Object)u, i);
                return;
            }
        }
        vector.addElement((Object)u);
    }
    
    public Vector C(final k k) {
        this.a.fine(A9.b.E, "resolveOldTokens", "632", new Object[] { k });
        k i = k;
        if (k == null) {
            i = new k(32102);
        }
        final Vector d = this.f.d();
        final Enumeration elements = d.elements();
    Label_0058:
        while (elements.hasMoreElements()) {
            final q q = (q)elements.nextElement();
            final q q2;
            monitorenter(q2 = q);
            Label_0121: {
                try {
                    if (!q.f() && !q.a.j() && q.e() == null) {
                        q.a.q(i);
                    }
                    break Label_0121;
                }
                finally {
                    monitorexit(q2);
                    monitorexit(q2);
                    iftrue(Label_0058:)(q instanceof j);
                    this.f.j(q.a.d());
                    continue;
                }
            }
            break;
        }
        return d;
    }
    
    protected void F() {
        final Enumeration n = this.k.N();
        int b = this.b;
        final Vector vector = new Vector();
        this.a.fine(A9.b.E, "restoreState", "600");
        while (n.hasMoreElements()) {
            final String s = (String)n.nextElement();
            final u e = this.E(s, this.k.f(s));
            if (e != null) {
                if (s.startsWith("r-")) {
                    this.a.fine(A9.b.E, "restoreState", "604", new Object[] { s, e });
                    this.C.put((Object)e.q(), (Object)e);
                }
                else if (s.startsWith("s-")) {
                    final D9.o o = (D9.o)e;
                    b = Math.max(o.q(), b);
                    if (this.k.o0(this.o(o))) {
                        final n n2 = (n)this.E(s, this.k.f(this.o(o)));
                        if (n2 != null) {
                            this.a.fine(A9.b.E, "restoreState", "605", new Object[] { s, e });
                            this.z.put((Object)n2.q(), (Object)n2);
                        }
                        else {
                            this.a.fine(A9.b.E, "restoreState", "606", new Object[] { s, e });
                        }
                    }
                    else {
                        o.y(true);
                        if (o.E().c() == 2) {
                            this.a.fine(A9.b.E, "restoreState", "607", new Object[] { s, e });
                            this.z.put((Object)o.q(), (Object)o);
                        }
                        else {
                            this.a.fine(A9.b.E, "restoreState", "608", new Object[] { s, e });
                            this.A.put((Object)o.q(), (Object)o);
                        }
                    }
                    ((q)this.f.k(o)).a.p(this.g.t());
                    this.c.put((Object)o.q(), (Object)o.q());
                }
                else if (s.startsWith("sb-")) {
                    final D9.o o2 = (D9.o)e;
                    b = Math.max(o2.q(), b);
                    if (o2.E().c() == 2) {
                        this.a.fine(A9.b.E, "restoreState", "607", new Object[] { s, e });
                        this.z.put((Object)o2.q(), (Object)o2);
                    }
                    else if (o2.E().c() == 1) {
                        this.a.fine(A9.b.E, "restoreState", "608", new Object[] { s, e });
                        this.A.put((Object)o2.q(), (Object)o2);
                    }
                    else {
                        this.a.fine(A9.b.E, "restoreState", "511", new Object[] { s, e });
                        this.B.put((Object)o2.q(), (Object)o2);
                        this.k.remove(s);
                    }
                    ((q)this.f.k(o2)).a.p(this.g.t());
                    this.c.put((Object)o2.q(), (Object)o2.q());
                }
                else {
                    if (!s.startsWith("sc-") || this.k.o0(this.p(e))) {
                        continue;
                    }
                    vector.addElement((Object)s);
                }
            }
        }
        final Enumeration elements = vector.elements();
        while (elements.hasMoreElements()) {
            final String s2 = (String)elements.nextElement();
            this.a.fine(A9.b.E, "restoreState", "609", new Object[] { s2 });
            this.k.remove(s2);
        }
        this.b = b;
    }
    
    public void G(u v, final q q) {
        if (v.w() && v.q() == 0) {
            if (v instanceof D9.o && ((D9.o)v).E().c() != 0) {
                v.z(this.l());
            }
            else if (v instanceof D9.k || v instanceof D9.m || v instanceof n || v instanceof l || v instanceof r || v instanceof D9.q || v instanceof t || v instanceof s) {
                v.z(this.l());
            }
        }
        while (true) {
            if (q == null) {
                break Label_0129;
            }
            v.A(q);
            try {
                q.a.t(v.q());
                if (v instanceof D9.o) {
                    final Object p2;
                    monitorenter(p2 = this.p);
                    Label_0350: {
                        while (true) {
                            Label_0329: {
                                try {
                                    final int n = this.n;
                                    if (n >= this.m) {
                                        break Label_0350;
                                    }
                                    final org.eclipse.paho.client.mqttv3.l e = ((D9.o)v).E();
                                    this.a.fine(A9.b.E, "send", "628", new Object[] { v.q(), e.c(), v });
                                    final int c = e.c();
                                    if (c == 1) {
                                        break EndFinally_0;
                                    }
                                    if (c != 2) {
                                        break Label_0329;
                                    }
                                    this.z.put((Object)v.q(), (Object)v);
                                    this.k.D(this.p(v), (m)v);
                                    this.f.l(q, v);
                                    break Label_0329;
                                }
                                finally {
                                    monitorexit(p2);
                                    this.A.put((Object)v.q(), (Object)v);
                                    this.k.D(this.p(v), (m)v);
                                    this.f.l(q, v);
                                    break Label_0329;
                                    final int n;
                                    this.a.fine(A9.b.E, "send", "613", new Object[] { n });
                                    v = (u)new k(32202);
                                    continue;
                                    this.d.addElement((Object)v);
                                    this.p.notifyAll();
                                    monitorexit(p2);
                                    return;
                                }
                            }
                            break;
                        }
                    }
                }
                this.a.fine(A9.b.E, "send", "615", new Object[] { v.q(), v });
                if (v instanceof d) {
                    final Object p3 = this.p;
                    synchronized (p3) {
                        this.f.l(q, v);
                        this.e.insertElementAt((Object)v, 0);
                        this.p.notifyAll();
                        return;
                    }
                }
                if (v instanceof D9.i) {
                    this.v = v;
                }
                else if (v instanceof n) {
                    this.z.put((Object)v.q(), (Object)v);
                    this.k.D(this.o(v), (m)v);
                }
                else if (v instanceof l) {
                    this.k.remove(this.m(v));
                }
                final Object p4;
                monitorenter(p4 = this.p);
                Label_0604: {
                    try {
                        if (!(v instanceof D9.b)) {
                            this.f.l(q, v);
                        }
                        break Label_0604;
                    }
                    finally {
                        monitorexit(p4);
                        this.e.addElement((Object)v);
                        this.p.notifyAll();
                        monitorexit(p4);
                    }
                }
            }
            catch (final Exception ex) {
                continue;
            }
            break;
        }
    }
    
    protected void H(final boolean j) {
        this.j = j;
    }
    
    protected void I(final long n) {
        this.i = TimeUnit.SECONDS.toNanos(n);
    }
    
    protected void J(final int m) {
        this.m = m;
        this.d = new Vector(this.m);
    }
    
    protected void K(final D9.o o) {
        final Object p;
        monitorenter(p = this.p);
        Label_0087: {
            try {
                this.a.fine(A9.b.E, "undo", "618", new Object[] { o.q(), o.E().c() });
                if (o.E().c() == 1) {
                    this.A.remove((Object)o.q());
                    break Label_0087;
                }
                break Label_0087;
            }
            finally {
                monitorexit(p);
                while (true) {
                    this.B(o.q());
                    o.z(0);
                    Label_0157: {
                        break Label_0157;
                        this.z.remove((Object)o.q());
                        break Label_0087;
                    }
                    this.b();
                    monitorexit(p);
                    return;
                    this.d.removeElement((Object)o);
                    this.k.remove(this.p(o));
                    this.f.i(o);
                    iftrue(Label_0157:)(o.E().c() <= 0);
                    continue;
                }
            }
        }
    }
    
    public q a(final org.eclipse.paho.client.mqttv3.a a) {
        final a a2 = this.a;
        final String e = A9.b.E;
        a2.fine(e, "checkForActivity", "616", new Object[0]);
        final Object q;
        monitorenter(q = this.q);
        Label_0065: {
            try {
                final boolean r = this.r;
                final q q2 = null;
                if (r) {
                    monitorexit(q);
                    return null;
                }
                break Label_0065;
            }
            finally {
                monitorexit(q);
                q q3 = null;
            Block_6:
                while (true) {
                    final q q2;
                    q3 = q2;
                    iftrue(Label_0513:)(this.i <= 0L);
                    break Block_6;
                    Label_0513: {
                        return q3;
                    }
                    monitorexit(q);
                    TimeUnit.NANOSECONDS.toMillis(this.i);
                    q3 = q2;
                    iftrue(Label_0513:)(!this.y);
                    continue;
                }
                final long b = this.l.b();
                final Object w;
                monitorenter(w = this.w);
                Label_0241: {
                    try {
                        final int x = this.x;
                        if (x <= 0) {
                            break Label_0241;
                        }
                        final long t = this.t;
                        final long i = this.i;
                        if (b - t < 100000 + i) {
                            break Label_0241;
                        }
                        this.a.severe(e, "checkForActivity", "619", new Object[] { i, this.s, this.t, b, this.u });
                        throw A9.h.a(32000);
                    }
                    finally {
                        monitorexit(w);
                        long j;
                        while (true) {
                            while (true) {
                                final long s = this.s;
                                j = this.i;
                                iftrue(Label_0274:)(b - s >= 2L * j);
                                this.a.fine(e, "checkForActivity", "620", new Object[] { this.i, this.s, this.t });
                                q3 = new q(this.g.t().a0());
                                iftrue(Label_0430:)(a == null);
                                q3.g(a);
                                Label_0430: {
                                    this.f.l(q3, this.v);
                                }
                                this.e.insertElementAt((Object)this.v, 0);
                                final long k = this.k();
                                this.s();
                                monitorexit(w);
                                this.a.fine(e, "checkForActivity", "624", new Object[] { k });
                                this.D.schedule(k);
                                return q3;
                                final int x;
                                iftrue(Label_0347:)(x != 0);
                                continue;
                            }
                            continue;
                        }
                        Label_0274: {
                            this.a.severe(e, "checkForActivity", "642", new Object[] { j, this.s, this.t, b, this.u });
                        }
                        throw A9.h.a(32002);
                    }
                }
                return q3;
            }
        }
    }
    
    protected boolean b() {
        final int b = this.f.b();
        if (this.r && b == 0 && this.e.size() == 0 && this.h.h()) {
            this.a.fine(A9.b.E, "checkQuiesceLock", "626", new Object[] { this.r, this.n, this.e.size(), this.o, this.h.h(), b });
            final Object q = this.q;
            synchronized (q) {
                this.q.notifyAll();
                return true;
            }
        }
        return false;
    }
    
    protected void c() {
        this.a.fine(A9.b.E, "clearState", ">");
        this.k.clear();
        this.c.clear();
        this.d.clear();
        this.e.clear();
        this.z.clear();
        this.A.clear();
        this.B.clear();
        this.C.clear();
        this.f.a();
    }
    
    protected void d() {
        this.c.clear();
        if (this.d != null) {
            this.d.clear();
        }
        this.e.clear();
        this.z.clear();
        this.A.clear();
        this.B.clear();
        this.C.clear();
        this.f.a();
        this.c = null;
        this.d = null;
        this.e = null;
        this.z = null;
        this.A = null;
        this.B = null;
        this.C = null;
        this.f = null;
        this.h = null;
        this.g = null;
        this.k = null;
        this.v = null;
        this.l = null;
    }
    
    public void e() {
        this.a.fine(A9.b.E, "connected", "631");
        this.y = true;
        this.D.start();
    }
    
    protected void g(final D9.o o) {
        this.a.fine(A9.b.E, "deliveryComplete", "641", new Object[] { o.q() });
        this.k.remove(this.m(o));
        this.C.remove((Object)o.q());
    }
    
    public void h(final k k) {
        this.a.fine(A9.b.E, "disconnected", "633", new Object[] { k });
        this.y = false;
        try {
            if (this.j) {
                this.c();
            }
            this.d.clear();
            this.e.clear();
            final Object w = this.w;
            synchronized (w) {
                this.x = 0;
            }
        }
        catch (final k k) {}
    }
    
    protected u i() {
        final Object p;
        monitorenter(p = this.p);
        Object o = null;
    Block_7_Outer:
        while (true) {
            Label_0371: {
                if (o != null) {
                    break Label_0371;
                }
                Label_0045: {
                    try {
                        if (this.d.isEmpty() && this.e.isEmpty()) {
                            break Label_0045;
                        }
                        break Label_0045;
                    }
                    finally {
                        while (true) {
                            Label_0376: {
                                break Label_0376;
                                try {
                                    final a a = this.a;
                                    final String e = A9.b.E;
                                    a.fine(e, "get", "644");
                                    this.p.wait();
                                    this.a.fine(e, "get", "647");
                                    Label_0348: {
                                        if (this.e != null) {
                                            if (!this.y) {
                                                if (this.e.isEmpty()) {
                                                    break Label_0348;
                                                }
                                                if (!(((u)this.e.elementAt(0)) instanceof d)) {
                                                    break Label_0348;
                                                }
                                            }
                                            if (!this.e.isEmpty()) {
                                                o = this.e.remove(0);
                                                if (o instanceof n) {
                                                    final int o2 = this.o + 1;
                                                    this.o = o2;
                                                    this.a.fine(A9.b.E, "get", "617", new Object[] { o2 });
                                                }
                                                this.b();
                                                continue Block_7_Outer;
                                            }
                                            if (this.d.isEmpty()) {
                                                continue Block_7_Outer;
                                            }
                                            if (this.n < this.m) {
                                                o = this.d.elementAt(0);
                                                this.d.removeElementAt(0);
                                                final int n = this.n + 1;
                                                this.n = n;
                                                this.a.fine(A9.b.E, "get", "623", new Object[] { n });
                                                continue Block_7_Outer;
                                            }
                                            this.a.fine(A9.b.E, "get", "622");
                                            continue Block_7_Outer;
                                        }
                                    }
                                    this.a.fine(A9.b.E, "get", "621");
                                    monitorexit(p);
                                    return null;
                                    monitorexit(p);
                                    return (u)o;
                                    monitorexit(p);
                                }
                                catch (final InterruptedException ex) {}
                            }
                            iftrue(Label_0120:)(!this.e.isEmpty() || this.n < this.m);
                            continue;
                        }
                    }
                }
            }
        }
    }
    
    protected boolean j() {
        return this.j;
    }
    
    protected long k() {
        return TimeUnit.NANOSECONDS.toMillis(this.i);
    }
    
    protected void r(final q q) {
        final u h = q.a.h();
        if (h != null && h instanceof D9.b) {
            final a a = this.a;
            final String e = A9.b.E;
            a.fine(e, "notifyComplete", "629", new Object[] { h.q(), q, h });
            final D9.b b = (D9.b)h;
            if (b instanceof D9.k) {
                this.k.remove(this.p(h));
                this.k.remove(this.n(h));
                this.A.remove((Object)b.q());
                this.f();
                this.B(h.q());
                this.f.i(h);
                this.a.fine(e, "notifyComplete", "650", new Object[] { b.q() });
            }
            else if (b instanceof l) {
                this.k.remove(this.p(h));
                this.k.remove(this.o(h));
                this.k.remove(this.n(h));
                this.z.remove((Object)b.q());
                --this.o;
                this.f();
                this.B(h.q());
                this.f.i(h);
                this.a.fine(e, "notifyComplete", "645", new Object[] { b.q(), this.o });
            }
            this.b();
        }
    }
    
    public void s() {
        final Object p = this.p;
        synchronized (p) {
            this.a.fine(A9.b.E, "notifyQueueLock", "638");
            this.p.notifyAll();
        }
    }
    
    protected void t(final D9.b b) {
        this.t = this.l.b();
        final a a = this.a;
        final String e = b.E;
        a.fine(e, "notifyReceivedAck", "627", new Object[] { b.q(), b });
        final q e2 = this.f.e(b);
        Label_0432: {
            if (e2 == null) {
                this.a.fine(e, "notifyReceivedAck", "662", new Object[] { b.q() });
            }
            else if (b instanceof D9.m) {
                this.G(new n((D9.m)b), e2);
            }
            else if (!(b instanceof D9.k) && !(b instanceof l)) {
                if (b instanceof D9.j) {
                    final Object w;
                    monitorenter(w = this.w);
                    Label_0208: {
                        try {
                            this.x = Math.max(0, this.x - 1);
                            this.w(b, e2, null);
                            if (this.x == 0) {
                                this.f.i(b);
                            }
                            break Label_0208;
                        }
                        finally {
                            monitorexit(w);
                            monitorexit(w);
                            this.a.fine(e, "notifyReceivedAck", "636", new Object[] { this.x });
                            break Label_0432;
                        }
                    }
                }
                if (b instanceof D9.c) {
                    final D9.c c = (D9.c)b;
                    final int d = c.D();
                    if (d == 0) {
                        final Object p;
                        monitorenter(p = this.p);
                        Label_0312: {
                            try {
                                if (this.j) {
                                    this.c();
                                    this.f.l(e2, b);
                                }
                                break Label_0312;
                            }
                            finally {
                                monitorexit(p);
                                this.o = 0;
                                this.n = 0;
                                this.D();
                                this.e();
                                monitorexit(p);
                                this.g.q(c, null);
                                this.w(b, e2, null);
                                this.f.i(b);
                                final Object p2 = this.p;
                                synchronized (p2) {
                                    this.p.notifyAll();
                                    break Label_0432;
                                }
                            }
                        }
                    }
                    throw A9.h.a(d);
                }
                this.w(b, e2, null);
                this.B(b.q());
                this.f.i(b);
            }
            else {
                this.w(b, e2, null);
            }
        }
        this.b();
    }
    
    public void u(final int n) {
        if (n > 0) {
            this.t = this.l.b();
        }
        this.a.fine(A9.b.E, "notifyReceivedBytes", "630", new Object[] { n });
    }
    
    protected void v(final u u) {
        this.t = this.l.b();
        this.a.fine(A9.b.E, "notifyReceivedMsg", "651", new Object[] { u.q(), u });
        if (!this.r) {
            if (u instanceof D9.o) {
                final D9.o o = (D9.o)u;
                final int c = o.E().c();
                if (c != 0 && c != 1) {
                    if (c == 2) {
                        this.k.D(this.m(u), o);
                        this.C.put((Object)o.q(), (Object)o);
                        this.G(new D9.m(o), null);
                    }
                }
                else {
                    final c h = this.h;
                    if (h != null) {
                        h.k(o);
                    }
                }
            }
            else if (u instanceof n) {
                final D9.o o2 = (D9.o)this.C.get((Object)u.q());
                if (o2 != null) {
                    final c h2 = this.h;
                    if (h2 != null) {
                        h2.k(o2);
                    }
                }
                else {
                    this.G(new l(u.q()), null);
                }
            }
        }
    }
    
    protected void w(final u u, final q q, final k k) {
        q.a.l(u, k);
        q.a.m();
        if (u != null && u instanceof D9.b && !(u instanceof D9.m)) {
            this.a.fine(A9.b.E, "notifyResult", "648", new Object[] { q.a.d(), u, k });
            this.h.a(q);
        }
        if (u == null) {
            this.a.fine(A9.b.E, "notifyResult", "649", new Object[] { q.a.d(), k });
            this.h.a(q);
        }
    }
    
    protected void x(final u u) {
        this.s = this.l.b();
        final a a = this.a;
        final String e = A9.b.E;
        a.fine(e, "notifySent", "625", new Object[] { u.p() });
        q q;
        if ((q = u.t()) == null && (q = this.f.e(u)) == null) {
            return;
        }
        q.a.n();
        if (u instanceof D9.i) {
            final Object w;
            final long b;
            final Object w2;
            synchronized (w = this.w) {
                b = this.l.b();
                monitorenter(w2 = this.w);
                final b b2 = this;
                final long n = b;
                b2.u = n;
                final b b3 = this;
                final int n2 = b3.x;
                final int n3 = 1;
                final int n4 = n2 + n3;
                final b b4 = this;
                final int n5 = n4;
                b4.x = n5;
                final Object o = w2;
                monitorexit(o);
                final b b5 = this;
                final a a2 = b5.a;
                final String s = e;
                final String s2 = "notifySent";
                final String s3 = "635";
                final int n6 = 1;
                final Object[] array = new Object[n6];
                final int n7 = 0;
                final int n8 = n4;
                final Integer n9 = n8;
                array[n7] = n9;
                a2.fine(s, s2, s3, array);
                return;
            }
            try {
                final b b2 = this;
                final long n = b;
                b2.u = n;
                final b b3 = this;
                final int n2 = b3.x;
                final int n3 = 1;
                final int n4 = n2 + n3;
                final b b4 = this;
                final int n5 = n4;
                b4.x = n5;
                final Object o = w2;
                monitorexit(o);
                final b b5 = this;
                final a a2 = b5.a;
                final String s = e;
                final String s2 = "notifySent";
                final String s3 = "635";
                final int n6 = 1;
                final Object[] array = new Object[n6];
                final int n7 = 0;
                final int n8 = n4;
                final Integer n9 = n8;
                array[n7] = n9;
                a2.fine(s, s2, s3, array);
                return;
            }
            finally {}
        }
        if (u instanceof D9.o && ((D9.o)u).E().c() == 0) {
            q.a.l(null, null);
            this.h.a(q);
            this.f();
            this.B(u.q());
            this.f.i(u);
            this.b();
        }
    }
    
    public void y(final int n) {
        if (n > 0) {
            this.s = this.l.b();
        }
        this.a.fine(A9.b.E, "notifySentBytes", "643", new Object[] { n });
    }
    
    public void z(final long p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: lconst_0       
        //     2: lcmp           
        //     3: ifle            280
        //     6: aload_0        
        //     7: getfield        A9/b.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //    10: astore          5
        //    12: getstatic       A9/b.E:Ljava/lang/String;
        //    15: astore          4
        //    17: aload           5
        //    19: aload           4
        //    21: ldc_w           "quiesce"
        //    24: ldc_w           "637"
        //    27: iconst_1       
        //    28: anewarray       Ljava/lang/Object;
        //    31: dup            
        //    32: iconst_0       
        //    33: lload_1        
        //    34: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //    37: aastore        
        //    38: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
        //    43: aload_0        
        //    44: getfield        A9/b.p:Ljava/lang/Object;
        //    47: astore          5
        //    49: aload           5
        //    51: dup            
        //    52: astore          6
        //    54: monitorenter   
        //    55: aload_0        
        //    56: iconst_1       
        //    57: putfield        A9/b.r:Z
        //    60: aload           6
        //    62: monitorexit    
        //    63: aload_0        
        //    64: getfield        A9/b.h:LA9/c;
        //    67: invokevirtual   A9/c.l:()V
        //    70: aload_0        
        //    71: invokevirtual   A9/b.s:()V
        //    74: aload_0        
        //    75: getfield        A9/b.q:Ljava/lang/Object;
        //    78: astore          5
        //    80: aload           5
        //    82: dup            
        //    83: astore          6
        //    85: monitorenter   
        //    86: aload_0        
        //    87: getfield        A9/b.f:LA9/f;
        //    90: invokevirtual   A9/f.b:()I
        //    93: istore_3       
        //    94: iload_3        
        //    95: ifgt            126
        //    98: aload_0        
        //    99: getfield        A9/b.e:Ljava/util/Vector;
        //   102: invokevirtual   java/util/Vector.size:()I
        //   105: ifgt            126
        //   108: aload_0        
        //   109: getfield        A9/b.h:LA9/c;
        //   112: invokevirtual   A9/c.h:()Z
        //   115: ifne            195
        //   118: goto            126
        //   121: astore          4
        //   123: goto            266
        //   126: aload_0        
        //   127: getfield        A9/b.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //   130: aload           4
        //   132: ldc_w           "quiesce"
        //   135: ldc_w           "639"
        //   138: iconst_4       
        //   139: anewarray       Ljava/lang/Object;
        //   142: dup            
        //   143: iconst_0       
        //   144: aload_0        
        //   145: getfield        A9/b.n:I
        //   148: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //   151: aastore        
        //   152: dup            
        //   153: iconst_1       
        //   154: aload_0        
        //   155: getfield        A9/b.e:Ljava/util/Vector;
        //   158: invokevirtual   java/util/Vector.size:()I
        //   161: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //   164: aastore        
        //   165: dup            
        //   166: iconst_2       
        //   167: aload_0        
        //   168: getfield        A9/b.o:I
        //   171: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //   174: aastore        
        //   175: dup            
        //   176: iconst_3       
        //   177: iload_3        
        //   178: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //   181: aastore        
        //   182: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
        //   187: aload_0        
        //   188: getfield        A9/b.q:Ljava/lang/Object;
        //   191: lload_1        
        //   192: invokevirtual   java/lang/Object.wait:(J)V
        //   195: aload           6
        //   197: monitorexit    
        //   198: aload_0        
        //   199: getfield        A9/b.p:Ljava/lang/Object;
        //   202: astore          4
        //   204: aload           4
        //   206: dup            
        //   207: astore          7
        //   209: monitorenter   
        //   210: aload_0        
        //   211: getfield        A9/b.d:Ljava/util/Vector;
        //   214: invokevirtual   java/util/Vector.clear:()V
        //   217: aload_0        
        //   218: getfield        A9/b.e:Ljava/util/Vector;
        //   221: invokevirtual   java/util/Vector.clear:()V
        //   224: aload_0        
        //   225: iconst_0       
        //   226: putfield        A9/b.r:Z
        //   229: aload_0        
        //   230: iconst_0       
        //   231: putfield        A9/b.n:I
        //   234: aload           7
        //   236: monitorexit    
        //   237: aload_0        
        //   238: getfield        A9/b.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //   241: getstatic       A9/b.E:Ljava/lang/String;
        //   244: ldc_w           "quiesce"
        //   247: ldc_w           "640"
        //   250: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   255: goto            280
        //   258: astore          5
        //   260: aload           7
        //   262: monitorexit    
        //   263: aload           5
        //   265: athrow         
        //   266: aload           6
        //   268: monitorexit    
        //   269: aload           4
        //   271: athrow         
        //   272: astore          4
        //   274: aload           6
        //   276: monitorexit    
        //   277: aload           4
        //   279: athrow         
        //   280: return         
        //   281: astore          4
        //   283: goto            195
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  55     63     272    280    Any
        //  86     94     281    286    Ljava/lang/InterruptedException;
        //  86     94     121    272    Any
        //  98     118    281    286    Ljava/lang/InterruptedException;
        //  98     118    121    272    Any
        //  126    195    281    286    Ljava/lang/InterruptedException;
        //  126    195    121    272    Any
        //  195    198    121    272    Any
        //  210    237    258    266    Any
        //  260    263    258    266    Any
        //  266    269    121    272    Any
        //  274    277    272    280    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0126:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
