package A9;

import java.util.concurrent.ExecutorService;
import org.eclipse.paho.client.mqttv3.d;
import java.util.Enumeration;
import androidx.appcompat.app.v;
import D9.l;
import D9.u;
import D9.k;
import D9.o;
import org.eclipse.paho.client.mqttv3.j;
import org.eclipse.paho.client.mqttv3.q;
import java.util.concurrent.Future;
import java.util.Vector;
import java.util.Hashtable;
import org.eclipse.paho.client.mqttv3.g;
import org.eclipse.paho.client.mqttv3.f;
import org.eclipse.paho.client.mqttv3.logging.a;

public class c implements Runnable
{
    private static final String r = "A9.c";
    private final org.eclipse.paho.client.mqttv3.logging.a a;
    private f b;
    private g c;
    private Hashtable d;
    private A9.a e;
    private final Vector f;
    private final Vector g;
    private a h;
    private a i;
    private final Object j;
    private Thread k;
    private String l;
    private Future m;
    private final Object n;
    private final Object o;
    private b p;
    private boolean q;
    
    c(final A9.a e) {
        final org.eclipse.paho.client.mqttv3.logging.a a = org.eclipse.paho.client.mqttv3.logging.b.a("org.eclipse.paho.client.mqttv3.internal.nls.logcat", A9.c.r);
        this.a = a;
        final a stopped = A9.c.a.STOPPED;
        this.h = stopped;
        this.i = stopped;
        this.j = new Object();
        this.n = new Object();
        this.o = new Object();
        this.q = false;
        this.e = e;
        this.f = new Vector(10);
        this.g = new Vector(10);
        this.d = new Hashtable();
        a.setResourceName(e.t().a0());
    }
    
    private void f(final q q) {
        monitorenter(q);
        Label_0056: {
            try {
                this.a.fine(A9.c.r, "handleActionComplete", "705", new Object[] { q.a.d() });
                if (q.f()) {
                    this.p.r(q);
                }
                break Label_0056;
            }
            finally {
                monitorexit(q);
                while (true) {
                Block_10:
                    while (true) {
                        iftrue(Label_0134:)(!q.f() || !(q instanceof j));
                        break Block_10;
                        this.b.deliveryComplete((org.eclipse.paho.client.mqttv3.c)q);
                        Label_0107: {
                            this.d(q);
                        }
                        continue;
                    }
                    q.a.u(true);
                    Label_0134: {
                        monitorexit(q);
                    }
                    return;
                    q.a.m();
                    iftrue(Label_0112:)(q.a.k());
                    iftrue(Label_0107:)(this.b == null || !(q instanceof j) || !q.f());
                    continue;
                }
            }
        }
    }
    
    private void g(final o o) {
        final String f = o.F();
        this.a.fine(A9.c.r, "handleMessage", "713", new Object[] { o.q(), f });
        this.c(f, o.q(), o.E());
        if (!this.q) {
            if (o.E().c() == 1) {
                this.e.z(new k(o), new q(this.e.t().a0()));
            }
            else if (o.E().c() == 2) {
                this.e.r(o);
                final l l = new l(o);
                final A9.a e = this.e;
                e.z(l, new q(e.t().a0()));
            }
        }
    }
    
    public void a(final q q) {
        if (this.j()) {
            this.g.addElement((Object)q);
            final Object n = this.n;
            synchronized (n) {
                this.a.fine(A9.c.r, "asyncOperationComplete", "715", new Object[] { q.a.d() });
                this.n.notifyAll();
                return;
            }
        }
        try {
            this.f(q);
        }
        finally {
            final Throwable t;
            this.a.fine(A9.c.r, "asyncOperationComplete", "719", (Object[])null, t);
            this.e.N(null, new org.eclipse.paho.client.mqttv3.k(t));
        }
    }
    
    public void b(final org.eclipse.paho.client.mqttv3.k k) {
        final Throwable t;
        Label_0075: {
            try {
                if (this.b != null && k != null) {
                    this.a.fine(A9.c.r, "connectionLost", "708", new Object[] { k });
                    this.b.connectionLost((Throwable)k);
                }
            }
            finally {
                break Label_0075;
            }
            final g c = this.c;
            if (c != null && t != null) {
                ((f)c).connectionLost(t);
                return;
            }
            return;
        }
        this.a.fine(A9.c.r, "connectionLost", "720", new Object[] { t });
    }
    
    protected boolean c(final String s, final int n, final org.eclipse.paho.client.mqttv3.l l) {
        final Enumeration keys = this.d.keys();
        while (keys.hasMoreElements()) {
            v.a(this.d.get((Object)keys.nextElement()));
        }
        boolean b;
        if (this.b != null) {
            l.g(n);
            this.b.messageArrived(s, l);
            b = true;
        }
        else {
            b = false;
        }
        return b;
    }
    
    public void d(final q q) {
        if (q != null) {
            final org.eclipse.paho.client.mqttv3.a d = q.d();
            if (d != null) {
                if (q.e() == null) {
                    this.a.fine(A9.c.r, "fireActionEvent", "716", new Object[] { q.a.d() });
                    d.onSuccess((d)q);
                }
                else {
                    this.a.fine(A9.c.r, "fireActionEvent", "716", new Object[] { q.a.d() });
                    d.onFailure((d)q, (Throwable)q.e());
                }
            }
        }
    }
    
    protected Thread e() {
        return this.k;
    }
    
    public boolean h() {
        return this.i() && this.g.size() == 0 && this.f.size() == 0;
    }
    
    public boolean i() {
        final Object j = this.j;
        synchronized (j) {
            return this.h == A9.c.a.QUIESCING;
        }
    }
    
    public boolean j() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        A9/c.j:Ljava/lang/Object;
        //     4: astore_2       
        //     5: aload_2        
        //     6: dup            
        //     7: astore          5
        //     9: monitorenter   
        //    10: aload_0        
        //    11: getfield        A9/c.h:LA9/c$a;
        //    14: astore_3       
        //    15: getstatic       A9/c$a.RUNNING:LA9/c$a;
        //    18: astore          4
        //    20: aload_3        
        //    21: aload           4
        //    23: if_acmpeq       40
        //    26: aload_3        
        //    27: getstatic       A9/c$a.QUIESCING:LA9/c$a;
        //    30: if_acmpne       54
        //    33: goto            40
        //    36: astore_3       
        //    37: goto            61
        //    40: aload_0        
        //    41: getfield        A9/c.i:LA9/c$a;
        //    44: aload           4
        //    46: if_acmpne       54
        //    49: iconst_1       
        //    50: istore_1       
        //    51: goto            56
        //    54: iconst_0       
        //    55: istore_1       
        //    56: aload           5
        //    58: monitorexit    
        //    59: iload_1        
        //    60: ireturn        
        //    61: aload           5
        //    63: monitorexit    
        //    64: aload_3        
        //    65: athrow         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type
        //  -----  -----  -----  -----  ----
        //  10     20     36     66     Any
        //  26     33     36     66     Any
        //  40     49     36     66     Any
        //  56     59     36     66     Any
        //  61     64     36     66     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: cmpeq:boolean(getfield:a(c::i, this:c), var_4_12:a)
        //     at w5.m.a(SourceFile:20)
        //     at w5.o.j(SourceFile:110)
        //     at w5.o.e(SourceFile:1)
        //     at w5.f.r(SourceFile:701)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void k(final o p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        A9/c.b:Lorg/eclipse/paho/client/mqttv3/f;
        //     4: ifnonnull       17
        //     7: aload_0        
        //     8: getfield        A9/c.d:Ljava/util/Hashtable;
        //    11: invokevirtual   java/util/Hashtable.size:()I
        //    14: ifle            155
        //    17: aload_0        
        //    18: getfield        A9/c.o:Ljava/lang/Object;
        //    21: astore_3       
        //    22: aload_3        
        //    23: dup            
        //    24: astore          5
        //    26: monitorenter   
        //    27: aload_0        
        //    28: invokevirtual   A9/c.j:()Z
        //    31: ifeq            90
        //    34: aload_0        
        //    35: invokevirtual   A9/c.i:()Z
        //    38: ifne            90
        //    41: aload_0        
        //    42: getfield        A9/c.f:Ljava/util/Vector;
        //    45: invokevirtual   java/util/Vector.size:()I
        //    48: istore_2       
        //    49: iload_2        
        //    50: bipush          10
        //    52: if_icmplt       90
        //    55: aload_0        
        //    56: getfield        A9/c.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //    59: getstatic       A9/c.r:Ljava/lang/String;
        //    62: ldc_w           "messageArrived"
        //    65: ldc_w           "709"
        //    68: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //    73: aload_0        
        //    74: getfield        A9/c.o:Ljava/lang/Object;
        //    77: ldc2_w          200
        //    80: invokevirtual   java/lang/Object.wait:(J)V
        //    83: goto            27
        //    86: astore_1       
        //    87: goto            156
        //    90: aload           5
        //    92: monitorexit    
        //    93: aload_0        
        //    94: invokevirtual   A9/c.i:()Z
        //    97: ifne            155
        //   100: aload_0        
        //   101: getfield        A9/c.f:Ljava/util/Vector;
        //   104: aload_1        
        //   105: invokevirtual   java/util/Vector.addElement:(Ljava/lang/Object;)V
        //   108: aload_0        
        //   109: getfield        A9/c.n:Ljava/lang/Object;
        //   112: astore_1       
        //   113: aload_1        
        //   114: dup            
        //   115: astore          6
        //   117: monitorenter   
        //   118: aload_0        
        //   119: getfield        A9/c.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //   122: getstatic       A9/c.r:Ljava/lang/String;
        //   125: ldc_w           "messageArrived"
        //   128: ldc_w           "710"
        //   131: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   136: aload_0        
        //   137: getfield        A9/c.n:Ljava/lang/Object;
        //   140: invokevirtual   java/lang/Object.notifyAll:()V
        //   143: aload           6
        //   145: monitorexit    
        //   146: goto            155
        //   149: astore_3       
        //   150: aload           6
        //   152: monitorexit    
        //   153: aload_3        
        //   154: athrow         
        //   155: return         
        //   156: aload           5
        //   158: monitorexit    
        //   159: aload_1        
        //   160: athrow         
        //   161: astore          4
        //   163: goto            27
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  27     49     86     161    Any
        //  55     83     161    166    Ljava/lang/InterruptedException;
        //  55     83     86     161    Any
        //  90     93     86     161    Any
        //  118    146    149    155    Any
        //  150    153    149    155    Any
        //  156    159    86     161    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0090:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void l() {
        final Object j;
        monitorenter(j = this.j);
        Label_0033: {
            try {
                if (this.h == A9.c.a.RUNNING) {
                    this.h = A9.c.a.QUIESCING;
                }
                break Label_0033;
            }
            finally {
                monitorexit(j);
                monitorexit(j);
                final Object o = this.o;
                synchronized (o) {
                    this.a.fine(A9.c.r, "quiesce", "711");
                    this.o.notifyAll();
                }
            }
        }
    }
    
    public void m(final String s) {
        this.d.remove((Object)s);
    }
    
    public void n() {
        this.d.clear();
    }
    
    public void o(final f b) {
        this.b = b;
    }
    
    public void p(final b p) {
        this.p = p;
    }
    
    public void q(final g c) {
        this.c = c;
    }
    
    public void r(final String l, final ExecutorService executorService) {
        this.l = l;
        final Object j;
        monitorenter(j = this.j);
        Label_0069: {
            try {
                if (this.h != A9.c.a.STOPPED) {
                    break Label_0069;
                }
                this.f.clear();
                this.g.clear();
                this.i = A9.c.a.RUNNING;
                if (executorService == null) {
                    new Thread((Runnable)this).start();
                    break Label_0069;
                }
                break Label_0069;
            }
            finally {
            Label_0082:
                while (true) {
                    Label_0099: {
                        break Label_0099;
                        while (true) {
                            try {
                                Thread.sleep(100L);
                                break Label_0082;
                                monitorexit(j);
                                return;
                            }
                            catch (final Exception ex) {}
                            if (!this.j()) {
                                continue;
                            }
                            return;
                        }
                    }
                    this.m = executorService.submit((Runnable)this);
                    monitorexit(j);
                    continue Label_0082;
                }
            }
        }
    }
    
    public void run() {
        (this.k = Thread.currentThread()).setName(this.l);
        Object o;
        monitorenter(o = this.j);
        try {
            this.h = A9.c.a.RUNNING;
            monitorexit(o);
            org.eclipse.paho.client.mqttv3.logging.a a;
            String r;
            final Throwable t;
            Object o2;
            Object o3;
            Vector g;
            q q;
            Vector f;
            o o4;
            Object o5;
            final Object o6;
            Label_0270_Outer:Block_14_Outer:Label_0285_Outer:
            while (this.j()) {
                Label_0128: {
                    try {
                        monitorenter(o = this.n);
                        Label_0113: {
                            try {
                                if (this.j() && this.f.isEmpty() && this.g.isEmpty()) {
                                    this.a.fine(A9.c.r, "run", "704");
                                    this.n.wait();
                                }
                                break Label_0113;
                            }
                            finally {
                                monitorexit(o);
                                monitorexit(o);
                            }
                        }
                    }
                    catch (final InterruptedException ex) {
                        break Label_0128;
                    }
                    finally {
                        try {
                            a = this.a;
                            r = A9.c.r;
                            a.fine(r, "run", "714", (Object[])null, t);
                            this.e.N(null, new org.eclipse.paho.client.mqttv3.k(t));
                            o2 = this.o;
                            synchronized (o2) {
                                this.a.fine(r, "run", "706");
                                this.o.notifyAll();
                            }
                        }
                        finally {
                            o3 = this.o;
                            synchronized (o3) {
                                this.a.fine(A9.c.r, "run", "706");
                                this.o.notifyAll();
                                monitorexit(o3);
                            }
                        }
                        while (true) {
                            Block_16: {
                                while (true) {
                                    while (true) {
                                        iftrue(Label_0285:)(!this.i());
                                        break Block_16;
                                        monitorenter(g = this.g);
                                        Label_0182: {
                                            try {
                                                if (!this.g.isEmpty()) {
                                                    q = (q)this.g.elementAt(0);
                                                    this.g.removeElementAt(0);
                                                    break Label_0182;
                                                }
                                                break Label_0182;
                                            }
                                            finally {
                                                monitorexit(g);
                                                q = null;
                                                break Label_0182;
                                                while (true) {
                                                    monitorenter(f = this.f);
                                                    while (true) {
                                                        Label_0243: {
                                                            try {
                                                                if (!this.f.isEmpty()) {
                                                                    o4 = (o)this.f.elementAt(0);
                                                                    this.f.removeElementAt(0);
                                                                    break Label_0245;
                                                                }
                                                                break Label_0243;
                                                            }
                                                            finally {
                                                                monitorexit(f);
                                                                monitorexit(f);
                                                                iftrue(Label_0270:)(o4 == null);
                                                                Block_27: {
                                                                    break Block_27;
                                                                    o4 = null;
                                                                    continue Label_0285_Outer;
                                                                }
                                                                this.g(o4);
                                                                continue Block_14_Outer;
                                                            }
                                                        }
                                                        break;
                                                    }
                                                    monitorexit(g);
                                                    iftrue(Label_0196:)(q == null);
                                                    this.f(q);
                                                    continue Label_0285_Outer;
                                                }
                                            }
                                        }
                                        continue Block_14_Outer;
                                    }
                                    o5 = this.o;
                                    synchronized (o5) {
                                        this.a.fine(A9.c.r, "run", "706");
                                        this.o.notifyAll();
                                        continue Label_0270_Outer;
                                    }
                                    iftrue(Label_0270:)(!this.j());
                                    continue Label_0285_Outer;
                                }
                            }
                            this.p.b();
                            continue;
                        }
                    }
                }
                try {
                    this.h = A9.c.a.STOPPED;
                    monitorexit(o6);
                    this.k = null;
                    return;
                }
                finally {}
            }
            goto Label_0470;
        }
        finally {}
    }
    
    public void s() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        A9/c.j:Ljava/lang/Object;
        //     4: astore_1       
        //     5: aload_1        
        //     6: dup            
        //     7: astore_3       
        //     8: monitorenter   
        //     9: aload_0        
        //    10: getfield        A9/c.m:Ljava/util/concurrent/Future;
        //    13: astore_2       
        //    14: aload_2        
        //    15: ifnull          33
        //    18: aload_2        
        //    19: iconst_1       
        //    20: invokeinterface java/util/concurrent/Future.cancel:(Z)Z
        //    25: pop            
        //    26: goto            33
        //    29: astore_2       
        //    30: goto            190
        //    33: aload_3        
        //    34: monitorexit    
        //    35: aload_0        
        //    36: invokevirtual   A9/c.j:()Z
        //    39: ifeq            189
        //    42: aload_0        
        //    43: getfield        A9/c.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //    46: astore_2       
        //    47: getstatic       A9/c.r:Ljava/lang/String;
        //    50: astore_1       
        //    51: aload_2        
        //    52: aload_1        
        //    53: ldc_w           "stop"
        //    56: ldc_w           "700"
        //    59: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //    64: aload_0        
        //    65: getfield        A9/c.j:Ljava/lang/Object;
        //    68: astore_2       
        //    69: aload_2        
        //    70: dup            
        //    71: astore          4
        //    73: monitorenter   
        //    74: aload_0        
        //    75: getstatic       A9/c$a.STOPPED:LA9/c$a;
        //    78: putfield        A9/c.i:LA9/c$a;
        //    81: aload           4
        //    83: monitorexit    
        //    84: invokestatic    java/lang/Thread.currentThread:()Ljava/lang/Thread;
        //    87: aload_0        
        //    88: getfield        A9/c.k:Ljava/lang/Thread;
        //    91: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //    94: ifne            162
        //    97: aload_0        
        //    98: getfield        A9/c.n:Ljava/lang/Object;
        //   101: astore_2       
        //   102: aload_2        
        //   103: dup            
        //   104: astore          4
        //   106: monitorenter   
        //   107: aload_0        
        //   108: getfield        A9/c.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //   111: aload_1        
        //   112: ldc_w           "stop"
        //   115: ldc_w           "701"
        //   118: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   123: aload_0        
        //   124: getfield        A9/c.n:Ljava/lang/Object;
        //   127: invokevirtual   java/lang/Object.notifyAll:()V
        //   130: aload           4
        //   132: monitorexit    
        //   133: aload_0        
        //   134: invokevirtual   A9/c.j:()Z
        //   137: ifeq            162
        //   140: ldc2_w          100
        //   143: invokestatic    java/lang/Thread.sleep:(J)V
        //   146: aload_0        
        //   147: getfield        A9/c.p:LA9/b;
        //   150: invokevirtual   A9/b.s:()V
        //   153: goto            133
        //   156: astore_1       
        //   157: aload           4
        //   159: monitorexit    
        //   160: aload_1        
        //   161: athrow         
        //   162: aload_0        
        //   163: getfield        A9/c.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //   166: getstatic       A9/c.r:Ljava/lang/String;
        //   169: ldc_w           "stop"
        //   172: ldc_w           "703"
        //   175: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   180: goto            189
        //   183: astore_1       
        //   184: aload           4
        //   186: monitorexit    
        //   187: aload_1        
        //   188: athrow         
        //   189: return         
        //   190: aload_3        
        //   191: monitorexit    
        //   192: aload_2        
        //   193: athrow         
        //   194: astore_1       
        //   195: goto            146
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  9      14     29     194    Any
        //  18     26     29     194    Any
        //  33     35     29     194    Any
        //  74     84     183    189    Any
        //  107    133    156    162    Any
        //  140    146    194    198    Ljava/lang/Exception;
        //  157    160    156    162    Any
        //  184    187    183    189    Any
        //  190    192    29     194    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0146:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private enum a
    {
        private static final a[] $VALUES;
        
        QUIESCING, 
        RUNNING, 
        STOPPED;
        
        private static /* synthetic */ a[] $values() {
            return new a[] { a.STOPPED, a.RUNNING, a.QUIESCING };
        }
        
        static {
            $VALUES = $values();
        }
    }
}
