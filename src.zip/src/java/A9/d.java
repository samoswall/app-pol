package A9;

import java.util.concurrent.ExecutorService;
import java.io.InputStream;
import D9.f;
import java.util.concurrent.Future;
import org.eclipse.paho.client.mqttv3.logging.a;

public class d implements Runnable
{
    private static final String l = "A9.d";
    private org.eclipse.paho.client.mqttv3.logging.a a;
    private a b;
    private a c;
    private final Object d;
    private String e;
    private Future f;
    private b g;
    private A9.a h;
    private f i;
    private A9.f j;
    private Thread k;
    
    public d(final A9.a h, final b g, final A9.f j, final InputStream inputStream) {
        this.a = org.eclipse.paho.client.mqttv3.logging.b.a("org.eclipse.paho.client.mqttv3.internal.nls.logcat", A9.d.l);
        final a stopped = A9.d.a.STOPPED;
        this.b = stopped;
        this.c = stopped;
        this.d = new Object();
        this.g = null;
        this.h = null;
        this.j = null;
        this.k = null;
        this.i = new f(g, inputStream);
        this.h = h;
        this.g = g;
        this.j = j;
        this.a.setResourceName(h.t().a0());
    }
    
    public boolean a() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        A9/d.d:Ljava/lang/Object;
        //     4: astore_2       
        //     5: aload_2        
        //     6: dup            
        //     7: astore          5
        //     9: monitorenter   
        //    10: aload_0        
        //    11: getfield        A9/d.b:LA9/d$a;
        //    14: astore          4
        //    16: getstatic       A9/d$a.RUNNING:LA9/d$a;
        //    19: astore_3       
        //    20: aload           4
        //    22: aload_3        
        //    23: if_acmpeq       41
        //    26: aload           4
        //    28: getstatic       A9/d$a.RECEIVING:LA9/d$a;
        //    31: if_acmpne       54
        //    34: goto            41
        //    37: astore_3       
        //    38: goto            61
        //    41: aload_0        
        //    42: getfield        A9/d.c:LA9/d$a;
        //    45: aload_3        
        //    46: if_acmpne       54
        //    49: iconst_1       
        //    50: istore_1       
        //    51: goto            56
        //    54: iconst_0       
        //    55: istore_1       
        //    56: aload           5
        //    58: monitorexit    
        //    59: iload_1        
        //    60: ireturn        
        //    61: aload           5
        //    63: monitorexit    
        //    64: aload_3        
        //    65: athrow         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type
        //  -----  -----  -----  -----  ----
        //  10     20     37     66     Any
        //  26     34     37     66     Any
        //  41     49     37     66     Any
        //  56     59     37     66     Any
        //  61     64     37     66     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: cmpeq:boolean(getfield:a(d::c, this:d), var_3_13:a)
        //     at w5.m.a(SourceFile:20)
        //     at w5.o.j(SourceFile:110)
        //     at w5.o.e(SourceFile:1)
        //     at w5.f.r(SourceFile:701)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void b(final String e, final ExecutorService executorService) {
        this.e = e;
        this.a.fine(A9.d.l, "start", "855");
        final Object d;
        monitorenter(d = this.d);
        Label_0087: {
            try {
                final a b = this.b;
                final a stopped = A9.d.a.STOPPED;
                if (b != stopped || this.c != stopped) {
                    break Label_0087;
                }
                this.c = A9.d.a.RUNNING;
                if (executorService == null) {
                    new Thread((Runnable)this).start();
                    break Label_0087;
                }
                break Label_0087;
            }
            finally {
            Label_0101:
                while (true) {
                    Label_0118: {
                        break Label_0118;
                        while (true) {
                            try {
                                Thread.sleep(100L);
                                break Label_0101;
                                monitorexit(d);
                                return;
                            }
                            catch (final Exception ex) {}
                            if (!this.a()) {
                                continue;
                            }
                            return;
                        }
                    }
                    this.f = executorService.submit((Runnable)this);
                    monitorexit(d);
                    continue Label_0101;
                }
            }
        }
    }
    
    public void c() {
        final Object d;
        monitorenter(d = this.d);
        Label_0033: {
            try {
                final Future f = this.f;
                if (f != null) {
                    f.cancel(true);
                }
                break Label_0033;
            }
            finally {
                Label_0065:Block_5_Outer:
                while (true) {
                    Label_0098: {
                        break Label_0098;
                    Label_0081_Outer:
                        while (true) {
                            while (true) {
                                try {
                                    Thread.sleep(100L);
                                    break Label_0065;
                                    monitorexit(d);
                                    this.a.fine(A9.d.l, "stop", "851");
                                    return;
                                }
                                catch (final Exception ex) {}
                                if (this.a()) {
                                    continue Label_0081_Outer;
                                }
                                continue Block_5_Outer;
                            }
                        }
                    }
                Label_0063:
                    while (true) {
                        this.c = A9.d.a.STOPPED;
                        break Label_0063;
                        this.a.fine(A9.d.l, "stop", "850");
                        iftrue(Label_0063:)(!this.a());
                        continue;
                    }
                    monitorexit(d);
                    continue Label_0065;
                }
            }
        }
    }
    
    public void run() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: aload_0        
        //     5: aload_1        
        //     6: putfield        A9/d.k:Ljava/lang/Thread;
        //     9: aload_1        
        //    10: aload_0        
        //    11: getfield        A9/d.e:Ljava/lang/String;
        //    14: invokevirtual   java/lang/Thread.setName:(Ljava/lang/String;)V
        //    17: aload_0        
        //    18: getfield        A9/d.d:Ljava/lang/Object;
        //    21: astore_2       
        //    22: aload_2        
        //    23: dup            
        //    24: astore          8
        //    26: monitorenter   
        //    27: aload_0        
        //    28: getstatic       A9/d$a.RUNNING:LA9/d$a;
        //    31: putfield        A9/d.b:LA9/d$a;
        //    34: aload           8
        //    36: monitorexit    
        //    37: aload_0        
        //    38: getfield        A9/d.d:Ljava/lang/Object;
        //    41: astore_1       
        //    42: aload_1        
        //    43: dup            
        //    44: astore          9
        //    46: monitorenter   
        //    47: aload_0        
        //    48: getfield        A9/d.c:LA9/d$a;
        //    51: astore_2       
        //    52: aload           9
        //    54: monitorexit    
        //    55: aconst_null    
        //    56: astore_1       
        //    57: getstatic       A9/d$a.RUNNING:LA9/d$a;
        //    60: astore          5
        //    62: aload_2        
        //    63: aload           5
        //    65: if_acmpne       788
        //    68: aload_0        
        //    69: getfield        A9/d.i:LD9/f;
        //    72: astore_2       
        //    73: aload_2        
        //    74: ifnull          788
        //    77: aload_1        
        //    78: astore_2       
        //    79: aload_1        
        //    80: astore_3       
        //    81: aload_0        
        //    82: getfield        A9/d.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //    85: astore          6
        //    87: aload_1        
        //    88: astore_2       
        //    89: aload_1        
        //    90: astore_3       
        //    91: getstatic       A9/d.l:Ljava/lang/String;
        //    94: astore          4
        //    96: aload_1        
        //    97: astore_2       
        //    98: aload_1        
        //    99: astore_3       
        //   100: aload           6
        //   102: aload           4
        //   104: ldc             "run"
        //   106: ldc             "852"
        //   108: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   113: aload_1        
        //   114: astore_2       
        //   115: aload_1        
        //   116: astore_3       
        //   117: aload_0        
        //   118: getfield        A9/d.i:LD9/f;
        //   121: invokevirtual   D9/f.available:()I
        //   124: ifle            184
        //   127: aload_1        
        //   128: astore_2       
        //   129: aload_1        
        //   130: astore_3       
        //   131: aload_0        
        //   132: getfield        A9/d.d:Ljava/lang/Object;
        //   135: astore          6
        //   137: aload_1        
        //   138: astore_2       
        //   139: aload_1        
        //   140: astore_3       
        //   141: aload           6
        //   143: dup            
        //   144: astore          10
        //   146: monitorenter   
        //   147: aload_0        
        //   148: getstatic       A9/d$a.RECEIVING:LA9/d$a;
        //   151: putfield        A9/d.b:LA9/d$a;
        //   154: aload           10
        //   156: monitorexit    
        //   157: goto            184
        //   160: astore          4
        //   162: aload           10
        //   164: monitorexit    
        //   165: aload_1        
        //   166: astore_2       
        //   167: aload_1        
        //   168: astore_3       
        //   169: aload           4
        //   171: athrow         
        //   172: astore_2       
        //   173: goto            760
        //   176: astore_1       
        //   177: goto            524
        //   180: astore_2       
        //   181: goto            652
        //   184: aload_1        
        //   185: astore_2       
        //   186: aload_1        
        //   187: astore_3       
        //   188: aload_0        
        //   189: getfield        A9/d.i:LD9/f;
        //   192: invokevirtual   D9/f.e:()LD9/u;
        //   195: astore          7
        //   197: aload_1        
        //   198: astore_2       
        //   199: aload_1        
        //   200: astore_3       
        //   201: aload_0        
        //   202: getfield        A9/d.d:Ljava/lang/Object;
        //   205: astore          6
        //   207: aload_1        
        //   208: astore_2       
        //   209: aload_1        
        //   210: astore_3       
        //   211: aload           6
        //   213: dup            
        //   214: astore          10
        //   216: monitorenter   
        //   217: aload_0        
        //   218: aload           5
        //   220: putfield        A9/d.b:LA9/d$a;
        //   223: aload           10
        //   225: monitorexit    
        //   226: aload_1        
        //   227: astore_2       
        //   228: aload_1        
        //   229: astore_3       
        //   230: aload           7
        //   232: instanceof      LD9/b;
        //   235: ifeq            389
        //   238: aload_1        
        //   239: astore_2       
        //   240: aload_1        
        //   241: astore_3       
        //   242: aload_0        
        //   243: getfield        A9/d.j:LA9/f;
        //   246: aload           7
        //   248: invokevirtual   A9/f.e:(LD9/u;)Lorg/eclipse/paho/client/mqttv3/q;
        //   251: astore_1       
        //   252: aload_1        
        //   253: ifnull          298
        //   256: aload_1        
        //   257: astore_2       
        //   258: aload_1        
        //   259: astore_3       
        //   260: aload_1        
        //   261: dup            
        //   262: astore          9
        //   264: monitorenter   
        //   265: aload_0        
        //   266: getfield        A9/d.g:LA9/b;
        //   269: aload           7
        //   271: checkcast       LD9/b;
        //   274: invokevirtual   A9/b.t:(LD9/b;)V
        //   277: aload           9
        //   279: monitorexit    
        //   280: aload_1        
        //   281: astore          4
        //   283: goto            477
        //   286: astore          4
        //   288: aload           9
        //   290: monitorexit    
        //   291: aload_1        
        //   292: astore_2       
        //   293: aload_1        
        //   294: astore_3       
        //   295: aload           4
        //   297: athrow         
        //   298: aload_1        
        //   299: astore_2       
        //   300: aload_1        
        //   301: astore_3       
        //   302: aload           7
        //   304: instanceof      LD9/m;
        //   307: ifne            364
        //   310: aload_1        
        //   311: astore_2       
        //   312: aload_1        
        //   313: astore_3       
        //   314: aload           7
        //   316: instanceof      LD9/l;
        //   319: ifne            364
        //   322: aload_1        
        //   323: astore_2       
        //   324: aload_1        
        //   325: astore_3       
        //   326: aload           7
        //   328: instanceof      LD9/k;
        //   331: ifeq            337
        //   334: goto            364
        //   337: aload_1        
        //   338: astore_2       
        //   339: aload_1        
        //   340: astore_3       
        //   341: new             Lorg/eclipse/paho/client/mqttv3/k;
        //   344: astore          4
        //   346: aload_1        
        //   347: astore_2       
        //   348: aload_1        
        //   349: astore_3       
        //   350: aload           4
        //   352: bipush          6
        //   354: invokespecial   org/eclipse/paho/client/mqttv3/k.<init>:(I)V
        //   357: aload_1        
        //   358: astore_2       
        //   359: aload_1        
        //   360: astore_3       
        //   361: aload           4
        //   363: athrow         
        //   364: aload_1        
        //   365: astore_2       
        //   366: aload_1        
        //   367: astore_3       
        //   368: aload_0        
        //   369: getfield        A9/d.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //   372: aload           4
        //   374: ldc             "run"
        //   376: ldc             "857"
        //   378: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   383: aload_1        
        //   384: astore          4
        //   386: goto            477
        //   389: aload           7
        //   391: ifnull          413
        //   394: aload_1        
        //   395: astore_2       
        //   396: aload_1        
        //   397: astore_3       
        //   398: aload_0        
        //   399: getfield        A9/d.g:LA9/b;
        //   402: aload           7
        //   404: invokevirtual   A9/b.v:(LD9/u;)V
        //   407: aload_1        
        //   408: astore          4
        //   410: goto            477
        //   413: aload_1        
        //   414: astore_2       
        //   415: aload_1        
        //   416: astore_3       
        //   417: aload_1        
        //   418: astore          4
        //   420: aload_0        
        //   421: getfield        A9/d.h:LA9/a;
        //   424: invokevirtual   A9/a.B:()Z
        //   427: ifne            477
        //   430: aload_1        
        //   431: astore_2       
        //   432: aload_1        
        //   433: astore_3       
        //   434: aload_0        
        //   435: getfield        A9/d.h:LA9/a;
        //   438: invokevirtual   A9/a.C:()Z
        //   441: ifeq            450
        //   444: aload_1        
        //   445: astore          4
        //   447: goto            477
        //   450: aload_1        
        //   451: astore_2       
        //   452: aload_1        
        //   453: astore_3       
        //   454: new             Ljava/io/IOException;
        //   457: astore          4
        //   459: aload_1        
        //   460: astore_2       
        //   461: aload_1        
        //   462: astore_3       
        //   463: aload           4
        //   465: ldc             "Connection is lost."
        //   467: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   470: aload_1        
        //   471: astore_2       
        //   472: aload_1        
        //   473: astore_3       
        //   474: aload           4
        //   476: athrow         
        //   477: aload_0        
        //   478: getfield        A9/d.d:Ljava/lang/Object;
        //   481: astore_1       
        //   482: aload_1        
        //   483: dup            
        //   484: astore          9
        //   486: monitorenter   
        //   487: aload_0        
        //   488: aload           5
        //   490: putfield        A9/d.b:LA9/d$a;
        //   493: aload           9
        //   495: monitorexit    
        //   496: aload           4
        //   498: astore_1       
        //   499: goto            721
        //   502: astore_2       
        //   503: aload           9
        //   505: monitorexit    
        //   506: aload_2        
        //   507: athrow         
        //   508: astore_2       
        //   509: goto            842
        //   512: astore          4
        //   514: aload           10
        //   516: monitorexit    
        //   517: aload_1        
        //   518: astore_2       
        //   519: aload_1        
        //   520: astore_3       
        //   521: aload           4
        //   523: athrow         
        //   524: aload_0        
        //   525: getfield        A9/d.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //   528: getstatic       A9/d.l:Ljava/lang/String;
        //   531: ldc             "run"
        //   533: ldc             "853"
        //   535: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   540: aload_0        
        //   541: getfield        A9/d.c:LA9/d$a;
        //   544: astore          4
        //   546: getstatic       A9/d$a.STOPPED:LA9/d$a;
        //   549: astore_3       
        //   550: aload           4
        //   552: aload_3        
        //   553: if_acmpeq       621
        //   556: aload_0        
        //   557: getfield        A9/d.d:Ljava/lang/Object;
        //   560: astore          4
        //   562: aload           4
        //   564: dup            
        //   565: astore          11
        //   567: monitorenter   
        //   568: aload_0        
        //   569: aload_3        
        //   570: putfield        A9/d.c:LA9/d$a;
        //   573: aload           11
        //   575: monitorexit    
        //   576: aload_0        
        //   577: getfield        A9/d.h:LA9/a;
        //   580: invokevirtual   A9/a.E:()Z
        //   583: ifne            621
        //   586: aload_0        
        //   587: getfield        A9/d.h:LA9/a;
        //   590: astore_3       
        //   591: new             Lorg/eclipse/paho/client/mqttv3/k;
        //   594: astore          4
        //   596: aload           4
        //   598: sipush          32109
        //   601: aload_1        
        //   602: invokespecial   org/eclipse/paho/client/mqttv3/k.<init>:(ILjava/lang/Throwable;)V
        //   605: aload_3        
        //   606: aload_2        
        //   607: aload           4
        //   609: invokevirtual   A9/a.N:(Lorg/eclipse/paho/client/mqttv3/q;Lorg/eclipse/paho/client/mqttv3/k;)V
        //   612: goto            621
        //   615: astore_1       
        //   616: aload           11
        //   618: monitorexit    
        //   619: aload_1        
        //   620: athrow         
        //   621: aload_0        
        //   622: getfield        A9/d.d:Ljava/lang/Object;
        //   625: astore_1       
        //   626: aload_1        
        //   627: dup            
        //   628: astore          9
        //   630: monitorenter   
        //   631: aload_0        
        //   632: getstatic       A9/d$a.RUNNING:LA9/d$a;
        //   635: putfield        A9/d.b:LA9/d$a;
        //   638: aload           9
        //   640: monitorexit    
        //   641: aload_2        
        //   642: astore_1       
        //   643: goto            721
        //   646: astore_2       
        //   647: aload           9
        //   649: monitorexit    
        //   650: aload_2        
        //   651: athrow         
        //   652: aload_0        
        //   653: getfield        A9/d.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //   656: getstatic       A9/d.l:Ljava/lang/String;
        //   659: ldc             "run"
        //   661: ldc             "856"
        //   663: aconst_null    
        //   664: aload_2        
        //   665: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V
        //   670: aload_0        
        //   671: getfield        A9/d.d:Ljava/lang/Object;
        //   674: astore_1       
        //   675: aload_1        
        //   676: dup            
        //   677: astore          9
        //   679: monitorenter   
        //   680: aload_0        
        //   681: getstatic       A9/d$a.STOPPED:LA9/d$a;
        //   684: putfield        A9/d.c:LA9/d$a;
        //   687: aload           9
        //   689: monitorexit    
        //   690: aload_0        
        //   691: getfield        A9/d.h:LA9/a;
        //   694: aload_3        
        //   695: aload_2        
        //   696: invokevirtual   A9/a.N:(Lorg/eclipse/paho/client/mqttv3/q;Lorg/eclipse/paho/client/mqttv3/k;)V
        //   699: aload_0        
        //   700: getfield        A9/d.d:Ljava/lang/Object;
        //   703: astore_1       
        //   704: aload_1        
        //   705: dup            
        //   706: astore          9
        //   708: monitorenter   
        //   709: aload_0        
        //   710: getstatic       A9/d$a.RUNNING:LA9/d$a;
        //   713: putfield        A9/d.b:LA9/d$a;
        //   716: aload           9
        //   718: monitorexit    
        //   719: aload_3        
        //   720: astore_1       
        //   721: aload_0        
        //   722: getfield        A9/d.d:Ljava/lang/Object;
        //   725: astore_3       
        //   726: aload_3        
        //   727: dup            
        //   728: astore          12
        //   730: monitorenter   
        //   731: aload_0        
        //   732: getfield        A9/d.c:LA9/d$a;
        //   735: astore_2       
        //   736: aload           12
        //   738: monitorexit    
        //   739: goto            57
        //   742: astore_1       
        //   743: aload           12
        //   745: monitorexit    
        //   746: aload_1        
        //   747: athrow         
        //   748: astore_2       
        //   749: aload           9
        //   751: monitorexit    
        //   752: aload_2        
        //   753: athrow         
        //   754: astore_2       
        //   755: aload           9
        //   757: monitorexit    
        //   758: aload_2        
        //   759: athrow         
        //   760: aload_0        
        //   761: getfield        A9/d.d:Ljava/lang/Object;
        //   764: astore_1       
        //   765: aload_1        
        //   766: dup            
        //   767: astore          9
        //   769: monitorenter   
        //   770: aload_0        
        //   771: getstatic       A9/d$a.RUNNING:LA9/d$a;
        //   774: putfield        A9/d.b:LA9/d$a;
        //   777: aload           9
        //   779: monitorexit    
        //   780: aload_2        
        //   781: athrow         
        //   782: astore_2       
        //   783: aload           9
        //   785: monitorexit    
        //   786: aload_2        
        //   787: athrow         
        //   788: aload_0        
        //   789: getfield        A9/d.d:Ljava/lang/Object;
        //   792: astore_2       
        //   793: aload_2        
        //   794: dup            
        //   795: astore          8
        //   797: monitorenter   
        //   798: aload_0        
        //   799: getstatic       A9/d$a.STOPPED:LA9/d$a;
        //   802: putfield        A9/d.b:LA9/d$a;
        //   805: aload           8
        //   807: monitorexit    
        //   808: aload_0        
        //   809: aconst_null    
        //   810: putfield        A9/d.k:Ljava/lang/Thread;
        //   813: aload_0        
        //   814: getfield        A9/d.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //   817: getstatic       A9/d.l:Ljava/lang/String;
        //   820: ldc             "run"
        //   822: ldc             "854"
        //   824: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   829: return         
        //   830: astore_1       
        //   831: aload           8
        //   833: monitorexit    
        //   834: aload_1        
        //   835: athrow         
        //   836: astore_2       
        //   837: aload           9
        //   839: monitorexit    
        //   840: aload_2        
        //   841: athrow         
        //   842: aload_0        
        //   843: getfield        A9/d.d:Ljava/lang/Object;
        //   846: astore_1       
        //   847: aload_1        
        //   848: dup            
        //   849: astore          9
        //   851: monitorenter   
        //   852: aload_0        
        //   853: getstatic       A9/d$a.STOPPED:LA9/d$a;
        //   856: putfield        A9/d.b:LA9/d$a;
        //   859: aload           9
        //   861: monitorexit    
        //   862: aload_2        
        //   863: athrow         
        //   864: astore_2       
        //   865: aload           9
        //   867: monitorexit    
        //   868: aload_2        
        //   869: athrow         
        //   870: astore_1       
        //   871: aload           8
        //   873: monitorexit    
        //   874: aload_1        
        //   875: athrow         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                              
        //  -----  -----  -----  -----  ----------------------------------
        //  27     37     870    876    Any
        //  37     47     508    870    Any
        //  47     55     836    842    Any
        //  57     62     508    870    Any
        //  68     73     508    870    Any
        //  81     87     180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  81     87     176    652    Ljava/io/IOException;
        //  81     87     172    788    Any
        //  91     96     180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  91     96     176    652    Ljava/io/IOException;
        //  91     96     172    788    Any
        //  100    113    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  100    113    176    652    Ljava/io/IOException;
        //  100    113    172    788    Any
        //  117    127    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  117    127    176    652    Ljava/io/IOException;
        //  117    127    172    788    Any
        //  131    137    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  131    137    176    652    Ljava/io/IOException;
        //  131    137    172    788    Any
        //  141    147    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  141    147    176    652    Ljava/io/IOException;
        //  141    147    172    788    Any
        //  147    157    160    172    Any
        //  162    165    160    172    Any
        //  169    172    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  169    172    176    652    Ljava/io/IOException;
        //  169    172    172    788    Any
        //  188    197    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  188    197    176    652    Ljava/io/IOException;
        //  188    197    172    788    Any
        //  201    207    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  201    207    176    652    Ljava/io/IOException;
        //  201    207    172    788    Any
        //  211    217    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  211    217    176    652    Ljava/io/IOException;
        //  211    217    172    788    Any
        //  217    226    512    524    Any
        //  230    238    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  230    238    176    652    Ljava/io/IOException;
        //  230    238    172    788    Any
        //  242    252    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  242    252    176    652    Ljava/io/IOException;
        //  242    252    172    788    Any
        //  260    265    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  260    265    176    652    Ljava/io/IOException;
        //  260    265    172    788    Any
        //  265    280    286    298    Any
        //  288    291    286    298    Any
        //  295    298    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  295    298    176    652    Ljava/io/IOException;
        //  295    298    172    788    Any
        //  302    310    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  302    310    176    652    Ljava/io/IOException;
        //  302    310    172    788    Any
        //  314    322    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  314    322    176    652    Ljava/io/IOException;
        //  314    322    172    788    Any
        //  326    334    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  326    334    176    652    Ljava/io/IOException;
        //  326    334    172    788    Any
        //  341    346    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  341    346    176    652    Ljava/io/IOException;
        //  341    346    172    788    Any
        //  350    357    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  350    357    176    652    Ljava/io/IOException;
        //  350    357    172    788    Any
        //  361    364    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  361    364    176    652    Ljava/io/IOException;
        //  361    364    172    788    Any
        //  368    383    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  368    383    176    652    Ljava/io/IOException;
        //  368    383    172    788    Any
        //  398    407    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  398    407    176    652    Ljava/io/IOException;
        //  398    407    172    788    Any
        //  420    430    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  420    430    176    652    Ljava/io/IOException;
        //  420    430    172    788    Any
        //  434    444    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  434    444    176    652    Ljava/io/IOException;
        //  434    444    172    788    Any
        //  454    459    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  454    459    176    652    Ljava/io/IOException;
        //  454    459    172    788    Any
        //  463    470    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  463    470    176    652    Ljava/io/IOException;
        //  463    470    172    788    Any
        //  474    477    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  474    477    176    652    Ljava/io/IOException;
        //  474    477    172    788    Any
        //  477    487    508    870    Any
        //  487    496    502    508    Any
        //  503    506    502    508    Any
        //  506    508    508    870    Any
        //  514    517    512    524    Any
        //  521    524    180    760    Lorg/eclipse/paho/client/mqttv3/k;
        //  521    524    176    652    Ljava/io/IOException;
        //  521    524    172    788    Any
        //  524    550    172    788    Any
        //  556    568    172    788    Any
        //  568    576    615    621    Any
        //  576    612    172    788    Any
        //  616    619    615    621    Any
        //  619    621    172    788    Any
        //  621    631    508    870    Any
        //  631    641    646    652    Any
        //  647    650    646    652    Any
        //  650    652    508    870    Any
        //  652    680    172    788    Any
        //  680    690    754    760    Any
        //  690    699    172    788    Any
        //  699    709    508    870    Any
        //  709    719    748    754    Any
        //  721    731    508    870    Any
        //  731    739    742    748    Any
        //  743    746    742    748    Any
        //  746    748    508    870    Any
        //  749    752    748    754    Any
        //  752    754    508    870    Any
        //  755    758    754    760    Any
        //  758    760    172    788    Any
        //  760    770    508    870    Any
        //  770    780    782    788    Any
        //  780    782    508    870    Any
        //  783    786    782    788    Any
        //  786    788    508    870    Any
        //  798    808    830    836    Any
        //  831    834    830    836    Any
        //  837    840    836    842    Any
        //  840    842    508    870    Any
        //  852    862    864    870    Any
        //  865    868    864    870    Any
        //  871    874    870    876    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 533 out of bounds for length 533
        //     at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:266)
        //     at java.util.Objects.checkIndex(Objects.java:359)
        //     at java.util.ArrayList.get(ArrayList.java:434)
        //     at w5.a.o(SourceFile:31)
        //     at w5.a.o(SourceFile:733)
        //     at w5.a.o(SourceFile:323)
        //     at w5.a.o(SourceFile:323)
        //     at w5.a.j(SourceFile:218)
        //     at a6.j.j(SourceFile:23)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private enum a
    {
        private static final a[] $VALUES;
        
        RECEIVING, 
        RUNNING, 
        STARTING, 
        STOPPED;
        
        private static /* synthetic */ a[] $values() {
            return new a[] { a.STOPPED, a.RUNNING, a.STARTING, a.RECEIVING };
        }
        
        static {
            $VALUES = $values();
        }
    }
}
