package A9;

import java.util.concurrent.ExecutorService;
import org.eclipse.paho.client.mqttv3.q;
import org.eclipse.paho.client.mqttv3.k;
import D9.u;
import java.io.OutputStream;
import D9.g;
import java.util.concurrent.Future;
import org.eclipse.paho.client.mqttv3.logging.a;

public class e implements Runnable
{
    private static final String l = "A9.e";
    private org.eclipse.paho.client.mqttv3.logging.a a;
    private a b;
    private a c;
    private final Object d;
    private Thread e;
    private String f;
    private Future g;
    private b h;
    private g i;
    private A9.a j;
    private f k;
    
    public e(final A9.a j, final b h, final f k, final OutputStream outputStream) {
        this.a = org.eclipse.paho.client.mqttv3.logging.b.a("org.eclipse.paho.client.mqttv3.internal.nls.logcat", A9.e.l);
        final a stopped = A9.e.a.STOPPED;
        this.b = stopped;
        this.c = stopped;
        this.d = new Object();
        this.e = null;
        this.h = null;
        this.j = null;
        this.k = null;
        this.i = new g(h, outputStream);
        this.j = j;
        this.h = h;
        this.k = k;
        this.a.setResourceName(j.t().a0());
    }
    
    private void a(final u u, final Exception ex) {
        this.a.fine(A9.e.l, "handleRunException", "804", (Object[])null, (Throwable)ex);
        k k;
        if (!(ex instanceof k)) {
            k = new k(32109, (Throwable)ex);
        }
        else {
            k = (k)ex;
        }
        final Object d = this.d;
        synchronized (d) {
            this.c = A9.e.a.STOPPED;
            monitorexit(d);
            this.j.N(null, k);
        }
    }
    
    public boolean b() {
        final Object d;
        monitorenter(d = this.d);
        Label_0044: {
            try {
                final a b = this.b;
                final a running = A9.e.a.RUNNING;
                if (b == running && this.c == running) {
                    final boolean b2 = true;
                    break Label_0044;
                }
                break Label_0044;
            }
            finally {
                monitorexit(d);
                final boolean b2 = false;
                monitorexit(d);
                return b2;
            }
        }
    }
    
    public void c(final String f, final ExecutorService executorService) {
        this.f = f;
        final Object d;
        monitorenter(d = this.d);
        Label_0070: {
            try {
                final a b = this.b;
                final a stopped = A9.e.a.STOPPED;
                if (b != stopped || this.c != stopped) {
                    break Label_0070;
                }
                this.c = A9.e.a.RUNNING;
                if (executorService == null) {
                    new Thread((Runnable)this).start();
                    break Label_0070;
                }
                break Label_0070;
            }
            finally {
            Label_0084:
                while (true) {
                    Label_0101: {
                        break Label_0101;
                        while (true) {
                            try {
                                Thread.sleep(100L);
                                break Label_0084;
                                monitorexit(d);
                            }
                            catch (final Exception ex) {}
                            if (!this.b()) {
                                continue;
                            }
                            return;
                        }
                    }
                    this.g = executorService.submit((Runnable)this);
                    monitorexit(d);
                    continue Label_0084;
                }
            }
        }
    }
    
    public void d() {
        if (!this.b()) {
            return;
        }
        final Object d;
        monitorenter(d = this.d);
        Label_0041: {
            try {
                final Future g = this.g;
                if (g != null) {
                    g.cancel(true);
                }
                break Label_0041;
            }
            finally {
                while (true) {
                Label_0080:
                    while (true) {
                        Label_0120: {
                            break Label_0120;
                        Label_0103_Outer:
                            while (true) {
                                while (true) {
                                    try {
                                        Thread.sleep(100L);
                                        this.h.s();
                                        break Label_0080;
                                        monitorexit(d);
                                        this.a.fine(A9.e.l, "stop", "801");
                                        return;
                                    }
                                    catch (final Exception ex) {}
                                    if (this.b()) {
                                        continue Label_0103_Outer;
                                    }
                                    continue;
                                }
                            }
                        }
                        this.c = A9.e.a.STOPPED;
                        this.h.s();
                        Label_0078: {
                            monitorexit(d);
                        }
                        continue Label_0080;
                    }
                    this.a.fine(A9.e.l, "stop", "800");
                    iftrue(Label_0078:)(!this.b());
                    continue;
                }
            }
        }
    }
    
    public void run() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: astore_1       
        //     4: aload_0        
        //     5: aload_1        
        //     6: putfield        A9/e.e:Ljava/lang/Thread;
        //     9: aload_1        
        //    10: aload_0        
        //    11: getfield        A9/e.f:Ljava/lang/String;
        //    14: invokevirtual   java/lang/Thread.setName:(Ljava/lang/String;)V
        //    17: aload_0        
        //    18: getfield        A9/e.d:Ljava/lang/Object;
        //    21: astore_1       
        //    22: aload_1        
        //    23: dup            
        //    24: astore          6
        //    26: monitorenter   
        //    27: aload_0        
        //    28: getstatic       A9/e$a.RUNNING:LA9/e$a;
        //    31: putfield        A9/e.b:LA9/e$a;
        //    34: aload           6
        //    36: monitorexit    
        //    37: aload_0        
        //    38: getfield        A9/e.d:Ljava/lang/Object;
        //    41: astore_1       
        //    42: aload_1        
        //    43: dup            
        //    44: astore          6
        //    46: monitorenter   
        //    47: aload_0        
        //    48: getfield        A9/e.c:LA9/e$a;
        //    51: astore_2       
        //    52: aload           6
        //    54: monitorexit    
        //    55: aconst_null    
        //    56: astore_1       
        //    57: aload_2        
        //    58: getstatic       A9/e$a.RUNNING:LA9/e$a;
        //    61: if_acmpne       393
        //    64: aload_0        
        //    65: getfield        A9/e.i:LD9/g;
        //    68: astore_2       
        //    69: aload_2        
        //    70: ifnull          393
        //    73: aload_1        
        //    74: astore_3       
        //    75: aload_0        
        //    76: getfield        A9/e.h:LA9/b;
        //    79: invokevirtual   A9/b.i:()LD9/u;
        //    82: astore_2       
        //    83: aload_2        
        //    84: ifnull          282
        //    87: aload_2        
        //    88: astore_3       
        //    89: aload_2        
        //    90: astore_1       
        //    91: aload_0        
        //    92: getfield        A9/e.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //    95: getstatic       A9/e.l:Ljava/lang/String;
        //    98: ldc             "run"
        //   100: ldc             "802"
        //   102: iconst_2       
        //   103: anewarray       Ljava/lang/Object;
        //   106: dup            
        //   107: iconst_0       
        //   108: aload_2        
        //   109: invokevirtual   D9/u.p:()Ljava/lang/String;
        //   112: aastore        
        //   113: dup            
        //   114: iconst_1       
        //   115: aload_2        
        //   116: aastore        
        //   117: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
        //   122: aload_2        
        //   123: astore_3       
        //   124: aload_2        
        //   125: astore_1       
        //   126: aload_2        
        //   127: instanceof      LD9/b;
        //   130: ifeq            173
        //   133: aload_2        
        //   134: astore_3       
        //   135: aload_2        
        //   136: astore_1       
        //   137: aload_0        
        //   138: getfield        A9/e.i:LD9/g;
        //   141: aload_2        
        //   142: invokevirtual   D9/g.e:(LD9/u;)V
        //   145: aload_2        
        //   146: astore_3       
        //   147: aload_2        
        //   148: astore_1       
        //   149: aload_0        
        //   150: getfield        A9/e.i:LD9/g;
        //   153: invokevirtual   D9/g.flush:()V
        //   156: aload_2        
        //   157: astore_1       
        //   158: goto            366
        //   161: astore_2       
        //   162: goto            447
        //   165: astore_1       
        //   166: goto            349
        //   169: astore_2       
        //   170: goto            360
        //   173: aload_2        
        //   174: astore_3       
        //   175: aload_2        
        //   176: astore_1       
        //   177: aload_2        
        //   178: invokevirtual   D9/u.t:()Lorg/eclipse/paho/client/mqttv3/q;
        //   181: astore          5
        //   183: aload           5
        //   185: astore          4
        //   187: aload           5
        //   189: ifnonnull       206
        //   192: aload_2        
        //   193: astore_3       
        //   194: aload_2        
        //   195: astore_1       
        //   196: aload_0        
        //   197: getfield        A9/e.k:LA9/f;
        //   200: aload_2        
        //   201: invokevirtual   A9/f.e:(LD9/u;)Lorg/eclipse/paho/client/mqttv3/q;
        //   204: astore          4
        //   206: aload_2        
        //   207: astore_1       
        //   208: aload           4
        //   210: ifnull          366
        //   213: aload_2        
        //   214: astore_3       
        //   215: aload_2        
        //   216: astore_1       
        //   217: aload           4
        //   219: dup            
        //   220: astore          7
        //   222: monitorenter   
        //   223: aload_0        
        //   224: getfield        A9/e.i:LD9/g;
        //   227: aload_2        
        //   228: invokevirtual   D9/g.e:(LD9/u;)V
        //   231: aload_0        
        //   232: getfield        A9/e.i:LD9/g;
        //   235: invokevirtual   D9/g.flush:()V
        //   238: goto            254
        //   241: astore          5
        //   243: goto            272
        //   246: astore_1       
        //   247: aload_2        
        //   248: instanceof      LD9/e;
        //   251: ifeq            270
        //   254: aload_0        
        //   255: getfield        A9/e.h:LA9/b;
        //   258: aload_2        
        //   259: invokevirtual   A9/b.x:(LD9/u;)V
        //   262: aload           7
        //   264: monitorexit    
        //   265: aload_2        
        //   266: astore_1       
        //   267: goto            366
        //   270: aload_1        
        //   271: athrow         
        //   272: aload           7
        //   274: monitorexit    
        //   275: aload_2        
        //   276: astore_3       
        //   277: aload_2        
        //   278: astore_1       
        //   279: aload           5
        //   281: athrow         
        //   282: aload_2        
        //   283: astore_3       
        //   284: aload_2        
        //   285: astore_1       
        //   286: aload_0        
        //   287: getfield        A9/e.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //   290: getstatic       A9/e.l:Ljava/lang/String;
        //   293: ldc             "run"
        //   295: ldc             "803"
        //   297: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   302: aload_2        
        //   303: astore_3       
        //   304: aload_2        
        //   305: astore_1       
        //   306: aload_0        
        //   307: getfield        A9/e.d:Ljava/lang/Object;
        //   310: astore          4
        //   312: aload_2        
        //   313: astore_3       
        //   314: aload_2        
        //   315: astore_1       
        //   316: aload           4
        //   318: dup            
        //   319: astore          7
        //   321: monitorenter   
        //   322: aload_0        
        //   323: getstatic       A9/e$a.STOPPED:LA9/e$a;
        //   326: putfield        A9/e.c:LA9/e$a;
        //   329: aload           7
        //   331: monitorexit    
        //   332: aload_2        
        //   333: astore_1       
        //   334: goto            366
        //   337: astore          5
        //   339: aload           7
        //   341: monitorexit    
        //   342: aload_2        
        //   343: astore_3       
        //   344: aload_2        
        //   345: astore_1       
        //   346: aload           5
        //   348: athrow         
        //   349: aload_0        
        //   350: aload_3        
        //   351: aload_1        
        //   352: invokespecial   A9/e.a:(LD9/u;Ljava/lang/Exception;)V
        //   355: aload_3        
        //   356: astore_1       
        //   357: goto            366
        //   360: aload_0        
        //   361: aload_1        
        //   362: aload_2        
        //   363: invokespecial   A9/e.a:(LD9/u;Ljava/lang/Exception;)V
        //   366: aload_0        
        //   367: getfield        A9/e.d:Ljava/lang/Object;
        //   370: astore_3       
        //   371: aload_3        
        //   372: dup            
        //   373: astore          8
        //   375: monitorenter   
        //   376: aload_0        
        //   377: getfield        A9/e.c:LA9/e$a;
        //   380: astore_2       
        //   381: aload           8
        //   383: monitorexit    
        //   384: goto            57
        //   387: astore_1       
        //   388: aload           8
        //   390: monitorexit    
        //   391: aload_1        
        //   392: athrow         
        //   393: aload_0        
        //   394: getfield        A9/e.d:Ljava/lang/Object;
        //   397: astore_1       
        //   398: aload_1        
        //   399: dup            
        //   400: astore          6
        //   402: monitorenter   
        //   403: aload_0        
        //   404: getstatic       A9/e$a.STOPPED:LA9/e$a;
        //   407: putfield        A9/e.b:LA9/e$a;
        //   410: aload_0        
        //   411: aconst_null    
        //   412: putfield        A9/e.e:Ljava/lang/Thread;
        //   415: aload           6
        //   417: monitorexit    
        //   418: aload_0        
        //   419: getfield        A9/e.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //   422: getstatic       A9/e.l:Ljava/lang/String;
        //   425: ldc             "run"
        //   427: ldc             "805"
        //   429: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   434: return         
        //   435: astore_2       
        //   436: aload           6
        //   438: monitorexit    
        //   439: aload_2        
        //   440: athrow         
        //   441: astore_2       
        //   442: aload           6
        //   444: monitorexit    
        //   445: aload_2        
        //   446: athrow         
        //   447: aload_0        
        //   448: getfield        A9/e.d:Ljava/lang/Object;
        //   451: astore_1       
        //   452: aload_1        
        //   453: dup            
        //   454: astore          6
        //   456: monitorenter   
        //   457: aload_0        
        //   458: getstatic       A9/e$a.STOPPED:LA9/e$a;
        //   461: putfield        A9/e.b:LA9/e$a;
        //   464: aload_0        
        //   465: aconst_null    
        //   466: putfield        A9/e.e:Ljava/lang/Thread;
        //   469: aload           6
        //   471: monitorexit    
        //   472: aload_2        
        //   473: athrow         
        //   474: astore_2       
        //   475: aload           6
        //   477: monitorexit    
        //   478: aload_2        
        //   479: athrow         
        //   480: astore_2       
        //   481: aload           6
        //   483: monitorexit    
        //   484: aload_2        
        //   485: athrow         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                              
        //  -----  -----  -----  -----  ----------------------------------
        //  27     37     480    486    Any
        //  37     47     161    480    Any
        //  47     55     441    447    Any
        //  57     69     161    480    Any
        //  75     83     169    173    Lorg/eclipse/paho/client/mqttv3/k;
        //  75     83     165    360    Ljava/lang/Exception;
        //  75     83     161    480    Any
        //  91     122    169    173    Lorg/eclipse/paho/client/mqttv3/k;
        //  91     122    165    360    Ljava/lang/Exception;
        //  91     122    161    480    Any
        //  126    133    169    173    Lorg/eclipse/paho/client/mqttv3/k;
        //  126    133    165    360    Ljava/lang/Exception;
        //  126    133    161    480    Any
        //  137    145    169    173    Lorg/eclipse/paho/client/mqttv3/k;
        //  137    145    165    360    Ljava/lang/Exception;
        //  137    145    161    480    Any
        //  149    156    169    173    Lorg/eclipse/paho/client/mqttv3/k;
        //  149    156    165    360    Ljava/lang/Exception;
        //  149    156    161    480    Any
        //  177    183    169    173    Lorg/eclipse/paho/client/mqttv3/k;
        //  177    183    165    360    Ljava/lang/Exception;
        //  177    183    161    480    Any
        //  196    206    169    173    Lorg/eclipse/paho/client/mqttv3/k;
        //  196    206    165    360    Ljava/lang/Exception;
        //  196    206    161    480    Any
        //  217    223    169    173    Lorg/eclipse/paho/client/mqttv3/k;
        //  217    223    165    360    Ljava/lang/Exception;
        //  217    223    161    480    Any
        //  223    231    241    282    Any
        //  231    238    246    254    Ljava/io/IOException;
        //  231    238    241    282    Any
        //  247    254    241    282    Any
        //  254    265    241    282    Any
        //  270    272    241    282    Any
        //  272    275    241    282    Any
        //  279    282    169    173    Lorg/eclipse/paho/client/mqttv3/k;
        //  279    282    165    360    Ljava/lang/Exception;
        //  279    282    161    480    Any
        //  286    302    169    173    Lorg/eclipse/paho/client/mqttv3/k;
        //  286    302    165    360    Ljava/lang/Exception;
        //  286    302    161    480    Any
        //  306    312    169    173    Lorg/eclipse/paho/client/mqttv3/k;
        //  306    312    165    360    Ljava/lang/Exception;
        //  306    312    161    480    Any
        //  316    322    169    173    Lorg/eclipse/paho/client/mqttv3/k;
        //  316    322    165    360    Ljava/lang/Exception;
        //  316    322    161    480    Any
        //  322    332    337    349    Any
        //  339    342    337    349    Any
        //  346    349    169    173    Lorg/eclipse/paho/client/mqttv3/k;
        //  346    349    165    360    Ljava/lang/Exception;
        //  346    349    161    480    Any
        //  349    355    161    480    Any
        //  360    366    161    480    Any
        //  366    376    161    480    Any
        //  376    384    387    393    Any
        //  388    391    387    393    Any
        //  391    393    161    480    Any
        //  403    418    435    441    Any
        //  436    439    435    441    Any
        //  442    445    441    447    Any
        //  445    447    161    480    Any
        //  457    472    474    480    Any
        //  475    478    474    480    Any
        //  481    484    480    486    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0057:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private enum a
    {
        private static final a[] $VALUES;
        
        RUNNING, 
        STARTING, 
        STOPPED;
        
        private static /* synthetic */ a[] $values() {
            return new a[] { a.STOPPED, a.RUNNING, a.STARTING };
        }
        
        static {
            $VALUES = $values();
        }
    }
}
