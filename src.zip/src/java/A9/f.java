package A9;

import D9.o;
import D9.u;
import java.util.Enumeration;
import org.eclipse.paho.client.mqttv3.q;
import java.util.Vector;
import org.eclipse.paho.client.mqttv3.j;
import org.eclipse.paho.client.mqttv3.logging.b;
import org.eclipse.paho.client.mqttv3.k;
import java.util.Hashtable;
import org.eclipse.paho.client.mqttv3.logging.a;

public class f
{
    private static final String e = "A9.f";
    private a a;
    private final Hashtable b;
    private String c;
    private k d;
    
    public f(final String s) {
        final String e = f.e;
        final a a = org.eclipse.paho.client.mqttv3.logging.b.a("org.eclipse.paho.client.mqttv3.internal.nls.logcat", e);
        this.a = a;
        this.d = null;
        a.setResourceName(s);
        this.b = new Hashtable();
        this.c = s;
        this.a.fine(e, "<Init>", "308");
    }
    
    public void a() {
        this.a.fine(f.e, "clear", "305", new Object[] { this.b.size() });
        final Hashtable b = this.b;
        synchronized (b) {
            this.b.clear();
        }
    }
    
    public int b() {
        final Hashtable b = this.b;
        synchronized (b) {
            return this.b.size();
        }
    }
    
    public j[] c() {
        final Hashtable b;
        monitorenter(b = this.b);
        Label_0099: {
            try {
                this.a.fine(f.e, "getOutstandingDelTokens", "311");
                final Vector vector = new Vector();
                final Enumeration elements = this.b.elements();
                while (elements.hasMoreElements()) {
                    final q q = (q)elements.nextElement();
                    if (q != null && q instanceof j && !q.a.k()) {
                        vector.addElement((Object)q);
                    }
                }
                break Label_0099;
            }
            finally {
                monitorexit(b);
                final Vector vector;
                final j[] array = (j[])vector.toArray((Object[])new j[vector.size()]);
                monitorexit(b);
                return array;
            }
        }
    }
    
    public Vector d() {
        final Hashtable b;
        monitorenter(b = this.b);
        Label_0080: {
            try {
                this.a.fine(f.e, "getOutstandingTokens", "312");
                final Vector vector = new Vector();
                final Enumeration elements = this.b.elements();
                while (elements.hasMoreElements()) {
                    final q q = (q)elements.nextElement();
                    if (q != null) {
                        vector.addElement((Object)q);
                    }
                }
                break Label_0080;
            }
            finally {
                monitorexit(b);
                monitorexit(b);
                return;
            }
        }
    }
    
    public q e(final u u) {
        return (q)this.b.get((Object)u.p());
    }
    
    public q f(final String s) {
        return (q)this.b.get((Object)s);
    }
    
    public void g() {
        final Hashtable b = this.b;
        synchronized (b) {
            this.a.fine(f.e, "open", "310");
            this.d = null;
        }
    }
    
    protected void h(final k d) {
        final Hashtable b = this.b;
        synchronized (b) {
            this.a.fine(f.e, "quiesce", "309", new Object[] { d });
            this.d = d;
        }
    }
    
    public q i(final u u) {
        if (u != null) {
            return this.j(u.p());
        }
        return null;
    }
    
    public q j(final String s) {
        this.a.fine(f.e, "removeToken", "306", new Object[] { s });
        if (s != null) {
            return (q)this.b.remove((Object)s);
        }
        return null;
    }
    
    protected j k(final o o) {
        final Hashtable b;
        monitorenter(b = this.b);
        Label_0086: {
            try {
                final String string = Integer.toString(o.q());
                if (this.b.containsKey((Object)string)) {
                    final j j = (j)this.b.get((Object)string);
                    this.a.fine(f.e, "restoreToken", "302", new Object[] { string, o, j });
                    final j i = j;
                    break Label_0086;
                }
                break Label_0086;
            }
            finally {
                monitorexit(b);
                final j k = new j(this.c);
                final String string;
                ((q)k).a.r(string);
                this.b.put((Object)string, (Object)k);
                this.a.fine(f.e, "restoreToken", "303", new Object[] { string, o, k });
                final j i = k;
                monitorexit(b);
                return i;
            }
        }
    }
    
    protected void l(final q q, final u u) {
        final Hashtable b;
        monitorenter(b = this.b);
        try {
            final k d = this.d;
            if (d == null) {
                final String p2 = u.p();
                this.a.fine(f.e, "saveToken", "300", new Object[] { p2, u });
                this.m(q, p2);
                monitorexit(b);
                return;
            }
            throw d;
        }
        finally {
            monitorexit(b);
            throw;
        }
    }
    
    protected void m(final q q, final String s) {
        final Hashtable b = this.b;
        synchronized (b) {
            this.a.fine(f.e, "saveToken", "307", new Object[] { s, q.toString() });
            q.a.r(s);
            this.b.put((Object)s, (Object)q);
        }
    }
    
    @Override
    public String toString() {
        final String property = System.getProperty("line.separator", "\n");
        final StringBuffer sb = new StringBuffer();
        final Hashtable b;
        monitorenter(b = this.b);
        Label_0113: {
            try {
                final Enumeration elements = this.b.elements();
                while (elements.hasMoreElements()) {
                    final s a = ((q)elements.nextElement()).a;
                    final StringBuilder sb2 = new StringBuilder();
                    sb2.append("{");
                    sb2.append((Object)a);
                    sb2.append("}");
                    sb2.append(property);
                    sb.append(sb2.toString());
                }
                break Label_0113;
            }
            finally {
                monitorexit(b);
                final String string = sb.toString();
                monitorexit(b);
                return string;
            }
        }
    }
}
