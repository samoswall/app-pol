package A9;

import org.eclipse.paho.client.mqttv3.n;
import org.eclipse.paho.client.mqttv3.b;
import D9.u;
import org.eclipse.paho.client.mqttv3.k;
import org.eclipse.paho.client.mqttv3.d;
import org.eclipse.paho.client.mqttv3.q;
import org.eclipse.paho.client.mqttv3.i;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.h;
import org.eclipse.paho.client.mqttv3.a;

public class g implements a
{
    private h a;
    private MqttAsyncClient b;
    private A9.a c;
    private i d;
    private q e;
    private Object f;
    private a g;
    private int h;
    private org.eclipse.paho.client.mqttv3.g i;
    private boolean j;
    
    public g(final MqttAsyncClient b, final h a, final A9.a c, final i d, final q e, final Object f, final a g, final boolean j) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = d.g();
        this.j = j;
    }
    
    public void a() {
        final q q = new q(this.b.a0());
        q.g((a)this);
        q.h((Object)this);
        this.a.X(this.b.a0(), this.b.v0());
        if (this.d.q()) {
            this.a.clear();
        }
        if (this.d.g() == 0) {
            this.d.u(4);
        }
        try {
            this.c.p(this.d, q);
        }
        catch (final k k) {
            this.onFailure((d)q, (Throwable)k);
        }
    }
    
    public void b(final org.eclipse.paho.client.mqttv3.g i) {
        this.i = i;
    }
    
    @Override
    public void onFailure(final d d, final Throwable t) {
        final int length = this.c.w().length;
        final int n = this.c.v() + 1;
        if (n >= length && (this.h != 0 || this.d.g() != 4)) {
            if (this.h == 0) {
                this.d.u(0);
            }
            k k;
            if (t instanceof k) {
                k = (k)t;
            }
            else {
                k = new k(t);
            }
            this.e.a.l(null, k);
            this.e.a.m();
            this.e.a.p((b)this.b);
            if (this.g != null) {
                this.e.h(this.f);
                this.g.onFailure((d)this.e, t);
            }
        }
        else {
            if (this.h == 0) {
                if (this.d.g() == 4) {
                    this.d.u(3);
                }
                else {
                    this.d.u(4);
                    this.c.J(n);
                }
            }
            else {
                this.c.J(n);
            }
            try {
                this.a();
            }
            catch (final n n2) {
                this.onFailure(d, (Throwable)n2);
            }
        }
    }
    
    @Override
    public void onSuccess(final d d) {
        if (this.h == 0) {
            this.d.u(0);
        }
        this.e.a.l(d.b(), null);
        this.e.a.m();
        this.e.a.p((b)this.b);
        this.c.F();
        if (this.g != null) {
            this.e.h(this.f);
            this.g.onSuccess((d)this.e);
        }
        if (this.i != null) {
            this.i.connectComplete(this.j, this.c.w()[this.c.v()].a());
        }
    }
}
