package A9;

import org.eclipse.paho.client.mqttv3.p;
import org.eclipse.paho.client.mqttv3.k;

public abstract class h
{
    public static k a(final int n) {
        if (n != 4 && n != 5) {
            return new k(n);
        }
        return (k)new p(n);
    }
    
    public static k b(final Throwable t) {
        if (t.getClass().getName().equals((Object)"java.security.GeneralSecurityException")) {
            return (k)new p(t);
        }
        return new k(t);
    }
    
    public static boolean c(final String className) {
        boolean b;
        try {
            Class.forName(className);
            b = true;
        }
        catch (final ClassNotFoundException ex) {
            b = false;
        }
        return b;
    }
}
