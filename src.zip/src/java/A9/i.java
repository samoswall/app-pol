package A9;

public interface i
{
    long b();
}
