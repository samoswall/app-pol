package A9;

public abstract class j
{
    private static j a;
    
    public static final String b(final int n) {
        if (j.a == null) {
            if (h.c("java.util.ResourceBundle")) {
                try {
                    j.a = m.class.newInstance();
                    return j.a.a(n);
                }
                catch (final Exception ex) {
                    return "";
                }
            }
            if (h.c("org.eclipse.paho.client.mqttv3.internal.MIDPCatalog")) {
                try {
                    j.a = (j)Class.forName("org.eclipse.paho.client.mqttv3.internal.MIDPCatalog").newInstance();
                }
                catch (final Exception ex2) {
                    return "";
                }
            }
        }
        return j.a.a(n);
    }
    
    protected abstract String a(final int p0);
}
