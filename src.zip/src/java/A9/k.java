package A9;

import java.io.InputStream;
import java.io.OutputStream;

public interface k
{
    String a();
    
    OutputStream b();
    
    InputStream c();
    
    void start();
    
    void stop();
}
