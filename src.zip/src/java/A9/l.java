package A9;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.util.Iterator;
import java.net.URISyntaxException;
import org.eclipse.paho.client.mqttv3.i;
import java.util.regex.Matcher;
import java.net.URI;
import org.eclipse.paho.client.mqttv3.logging.b;
import java.util.regex.Pattern;
import java.util.ServiceLoader;
import org.eclipse.paho.client.mqttv3.logging.a;

public abstract class l
{
    private static a a;
    private static final ServiceLoader b;
    private static final Pattern c;
    
    static {
        l.a = org.eclipse.paho.client.mqttv3.logging.b.a("org.eclipse.paho.client.mqttv3.internal.nls.logcat", l.class.getSimpleName());
        b = ServiceLoader.load((Class)F9.a.class, l.class.getClassLoader());
        c = Pattern.compile("((.+)@)?([^:]*)(:(\\d+))?");
    }
    
    public static void a(final URI uri) {
        if (uri != null && uri.getHost() == null && uri.getAuthority() != null) {
            if (!uri.getAuthority().isEmpty()) {
                final Matcher matcher = l.c.matcher((CharSequence)uri.getAuthority());
                if (matcher.find()) {
                    c(uri, "userInfo", matcher.group(2));
                    c(uri, "host", matcher.group(3));
                    final String group = matcher.group(5);
                    int int1;
                    if (group != null) {
                        int1 = Integer.parseInt(group);
                    }
                    else {
                        int1 = -1;
                    }
                    c(uri, "port", int1);
                }
            }
        }
    }
    
    public static k b(final String s, final i i, final String s2) {
        try {
            final URI uri = new URI(s);
            a(uri);
            final String lowerCase = uri.getScheme().toLowerCase();
            final ServiceLoader b = l.b;
            final ServiceLoader serviceLoader;
            monitorenter(serviceLoader = b);
            Label_0101: {
                try {
                    Block_5: {
                        for (final F9.a a : b) {
                            if (a.a().contains((Object)lowerCase)) {
                                break Block_5;
                            }
                        }
                        break Label_0101;
                    }
                    final F9.a a;
                    final k b2 = a.b(uri, i, s2);
                    monitorexit(serviceLoader);
                    return b2;
                }
                finally {
                    monitorexit(serviceLoader);
                    monitorexit(serviceLoader);
                    throw new IllegalArgumentException(uri.toString());
                }
            }
        }
        catch (final URISyntaxException ex) {}
    }
    
    private static void c(final URI uri, final String s, final Object o) {
        try {
            final Field declaredField = URI.class.getDeclaredField(s);
            ((AccessibleObject)declaredField).setAccessible(true);
            declaredField.set((Object)uri, o);
        }
        catch (final NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException ex) {
            l.a.warning(l.class.getName(), "setURIField", "115", new Object[] { uri.toString() }, (Throwable)ex);
        }
    }
    
    public static void d(final String s) {
        try {
            final URI uri = new URI(s);
            final String scheme = uri.getScheme();
            if (scheme != null && !scheme.isEmpty()) {
                final String lowerCase = scheme.toLowerCase();
                final ServiceLoader b = l.b;
                final ServiceLoader serviceLoader;
                monitorenter(serviceLoader = b);
                Label_0099: {
                    try {
                        Block_7: {
                            for (final F9.a a : b) {
                                if (a.a().contains((Object)lowerCase)) {
                                    break Block_7;
                                }
                            }
                            break Label_0099;
                        }
                        final F9.a a;
                        a.c(uri);
                        monitorexit(serviceLoader);
                        return;
                    }
                    finally {
                        monitorexit(serviceLoader);
                        monitorexit(serviceLoader);
                        final StringBuilder sb = new StringBuilder();
                        sb.append("no NetworkModule installed for scheme \"");
                        sb.append(lowerCase);
                        sb.append("\" of URI \"");
                        sb.append(s);
                        sb.append("\"");
                        throw new IllegalArgumentException(sb.toString());
                    }
                }
            }
        }
        catch (final URISyntaxException ex) {}
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("missing scheme in broker URI: ");
        sb2.append(s);
        throw new IllegalArgumentException(sb2.toString());
    }
}
