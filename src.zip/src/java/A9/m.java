package A9;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class m extends j
{
    private ResourceBundle b;
    
    public m() {
        this.b = ResourceBundle.getBundle("org.eclipse.paho.client.mqttv3.internal.nls.messages");
    }
    
    @Override
    protected String a(final int n) {
        try {
            return this.b.getString(Integer.toString(n));
        }
        catch (final MissingResourceException ex) {
            return "MqttException";
        }
    }
}
