package A9;

import javax.net.ssl.SSLSocket;
import org.eclipse.paho.client.mqttv3.logging.b;
import javax.net.SocketFactory;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.HostnameVerifier;
import org.eclipse.paho.client.mqttv3.logging.a;

public class n extends q
{
    private static final String o = "A9.n";
    private a h;
    private String[] i;
    private int j;
    private HostnameVerifier k;
    private boolean l;
    private String m;
    private int n;
    
    public n(final SSLSocketFactory sslSocketFactory, final String m, final int n, final String resourceName) {
        super((SocketFactory)sslSocketFactory, m, n, resourceName);
        final a a = org.eclipse.paho.client.mqttv3.logging.b.a("org.eclipse.paho.client.mqttv3.internal.nls.logcat", A9.n.o);
        this.h = a;
        this.l = false;
        this.m = m;
        this.n = n;
        a.setResourceName(resourceName);
    }
    
    @Override
    public String a() {
        final String m = this.m;
        final int n = this.n;
        final StringBuilder sb = new StringBuilder();
        sb.append("ssl://");
        sb.append(m);
        sb.append(":");
        sb.append(n);
        return sb.toString();
    }
    
    public void e(final String[] array) {
        if (array != null) {
            this.i = array.clone();
        }
        if (super.b != null && this.i != null) {
            if (this.h.isLoggable(5)) {
                String string = "";
                for (int i = 0; i < this.i.length; ++i) {
                    String string2 = string;
                    if (i > 0) {
                        final StringBuilder sb = new StringBuilder();
                        sb.append(string);
                        sb.append(",");
                        string2 = sb.toString();
                    }
                    final String s = this.i[i];
                    final StringBuilder sb2 = new StringBuilder();
                    sb2.append(string2);
                    sb2.append(s);
                    string = sb2.toString();
                }
                this.h.fine(A9.n.o, "setEnabledCiphers", "260", new Object[] { string });
            }
            ((SSLSocket)super.b).setEnabledCipherSuites(this.i);
        }
    }
    
    public void f(final boolean l) {
        this.l = l;
    }
    
    public void g(final HostnameVerifier k) {
        this.k = k;
    }
    
    public void h(final int j) {
        super.d(j);
        this.j = j;
    }
    
    @Override
    public void start() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokespecial   A9/q.start:()V
        //     4: aload_0        
        //     5: aload_0        
        //     6: getfield        A9/n.i:[Ljava/lang/String;
        //     9: invokevirtual   A9/n.e:([Ljava/lang/String;)V
        //    12: aload_0        
        //    13: getfield        A9/q.b:Ljava/net/Socket;
        //    16: invokevirtual   java/net/Socket.getSoTimeout:()I
        //    19: istore_1       
        //    20: aload_0        
        //    21: getfield        A9/q.b:Ljava/net/Socket;
        //    24: aload_0        
        //    25: getfield        A9/n.j:I
        //    28: sipush          1000
        //    31: imul           
        //    32: invokevirtual   java/net/Socket.setSoTimeout:(I)V
        //    35: new             Ljavax/net/ssl/SSLParameters;
        //    38: astore          4
        //    40: aload           4
        //    42: invokespecial   javax/net/ssl/SSLParameters.<init>:()V
        //    45: new             Ljava/util/ArrayList;
        //    48: astore_3       
        //    49: aload_3        
        //    50: iconst_1       
        //    51: invokespecial   java/util/ArrayList.<init>:(I)V
        //    54: new             Ljavax/net/ssl/SNIHostName;
        //    57: astore_2       
        //    58: aload_2        
        //    59: aload_0        
        //    60: getfield        A9/n.m:Ljava/lang/String;
        //    63: invokespecial   javax/net/ssl/SNIHostName.<init>:(Ljava/lang/String;)V
        //    66: aload_3        
        //    67: aload_2        
        //    68: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //    73: pop            
        //    74: aload           4
        //    76: aload_3        
        //    77: invokevirtual   javax/net/ssl/SSLParameters.setServerNames:(Ljava/util/List;)V
        //    80: aload_0        
        //    81: getfield        A9/q.b:Ljava/net/Socket;
        //    84: checkcast       Ljavax/net/ssl/SSLSocket;
        //    87: aload           4
        //    89: invokevirtual   javax/net/ssl/SSLSocket.setSSLParameters:(Ljavax/net/ssl/SSLParameters;)V
        //    92: aload_0        
        //    93: getfield        A9/n.l:Z
        //    96: ifeq            124
        //    99: new             Ljavax/net/ssl/SSLParameters;
        //   102: astore_2       
        //   103: aload_2        
        //   104: invokespecial   javax/net/ssl/SSLParameters.<init>:()V
        //   107: aload_2        
        //   108: ldc             "HTTPS"
        //   110: invokevirtual   javax/net/ssl/SSLParameters.setEndpointIdentificationAlgorithm:(Ljava/lang/String;)V
        //   113: aload_0        
        //   114: getfield        A9/q.b:Ljava/net/Socket;
        //   117: checkcast       Ljavax/net/ssl/SSLSocket;
        //   120: aload_2        
        //   121: invokevirtual   javax/net/ssl/SSLSocket.setSSLParameters:(Ljavax/net/ssl/SSLParameters;)V
        //   124: aload_0        
        //   125: getfield        A9/q.b:Ljava/net/Socket;
        //   128: checkcast       Ljavax/net/ssl/SSLSocket;
        //   131: invokevirtual   javax/net/ssl/SSLSocket.startHandshake:()V
        //   134: aload_0        
        //   135: getfield        A9/n.k:Ljavax/net/ssl/HostnameVerifier;
        //   138: ifnull          256
        //   141: aload_0        
        //   142: getfield        A9/n.l:Z
        //   145: ifne            256
        //   148: aload_0        
        //   149: getfield        A9/q.b:Ljava/net/Socket;
        //   152: checkcast       Ljavax/net/ssl/SSLSocket;
        //   155: invokevirtual   javax/net/ssl/SSLSocket.getSession:()Ljavax/net/ssl/SSLSession;
        //   158: astore_3       
        //   159: aload_0        
        //   160: getfield        A9/n.k:Ljavax/net/ssl/HostnameVerifier;
        //   163: aload_0        
        //   164: getfield        A9/n.m:Ljava/lang/String;
        //   167: aload_3        
        //   168: invokeinterface javax/net/ssl/HostnameVerifier.verify:(Ljava/lang/String;Ljavax/net/ssl/SSLSession;)Z
        //   173: ifeq            179
        //   176: goto            256
        //   179: aload_3        
        //   180: invokeinterface javax/net/ssl/SSLSession.invalidate:()V
        //   185: aload_0        
        //   186: getfield        A9/q.b:Ljava/net/Socket;
        //   189: invokevirtual   java/net/Socket.close:()V
        //   192: aload_0        
        //   193: getfield        A9/n.m:Ljava/lang/String;
        //   196: astore_2       
        //   197: aload_3        
        //   198: invokeinterface javax/net/ssl/SSLSession.getPeerHost:()Ljava/lang/String;
        //   203: astore_3       
        //   204: new             Ljava/lang/StringBuilder;
        //   207: dup            
        //   208: invokespecial   java/lang/StringBuilder.<init>:()V
        //   211: astore          4
        //   213: aload           4
        //   215: ldc             "Host: "
        //   217: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   220: pop            
        //   221: aload           4
        //   223: aload_2        
        //   224: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   227: pop            
        //   228: aload           4
        //   230: ldc             ", Peer Host: "
        //   232: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   235: pop            
        //   236: aload           4
        //   238: aload_3        
        //   239: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   242: pop            
        //   243: new             Ljavax/net/ssl/SSLPeerUnverifiedException;
        //   246: dup            
        //   247: aload           4
        //   249: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   252: invokespecial   javax/net/ssl/SSLPeerUnverifiedException.<init>:(Ljava/lang/String;)V
        //   255: athrow         
        //   256: aload_0        
        //   257: getfield        A9/q.b:Ljava/net/Socket;
        //   260: iload_1        
        //   261: invokevirtual   java/net/Socket.setSoTimeout:(I)V
        //   264: return         
        //   265: astore_2       
        //   266: goto            92
        //   269: astore_2       
        //   270: goto            124
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  35     92     265    269    Ljava/lang/NoClassDefFoundError;
        //  99     124    269    273    Ljava/lang/NoSuchMethodError;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0124:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
