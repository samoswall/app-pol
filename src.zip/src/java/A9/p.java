package A9;

public class p implements i
{
    @Override
    public long b() {
        return System.nanoTime();
    }
}
