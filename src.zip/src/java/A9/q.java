package A9;

import java.net.ConnectException;
import java.net.SocketAddress;
import java.net.InetSocketAddress;
import java.io.InputStream;
import java.io.OutputStream;
import org.eclipse.paho.client.mqttv3.logging.b;
import javax.net.SocketFactory;
import java.net.Socket;
import org.eclipse.paho.client.mqttv3.logging.a;

public class q implements k
{
    private static final String g = "A9.q";
    private a a;
    protected Socket b;
    private SocketFactory c;
    private String d;
    private int e;
    private int f;
    
    public q(final SocketFactory c, final String d, final int e, final String resourceName) {
        (this.a = org.eclipse.paho.client.mqttv3.logging.b.a("org.eclipse.paho.client.mqttv3.internal.nls.logcat", q.g)).setResourceName(resourceName);
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    @Override
    public String a() {
        final String d = this.d;
        final int e = this.e;
        final StringBuilder sb = new StringBuilder();
        sb.append("tcp://");
        sb.append(d);
        sb.append(":");
        sb.append(e);
        return sb.toString();
    }
    
    @Override
    public OutputStream b() {
        return this.b.getOutputStream();
    }
    
    @Override
    public InputStream c() {
        return this.b.getInputStream();
    }
    
    public void d(final int f) {
        this.f = f;
    }
    
    @Override
    public void start() {
        try {
            this.a.fine(q.g, "start", "252", new Object[] { this.d, this.e, this.f * 1000 });
            (this.b = this.c.createSocket()).connect((SocketAddress)new InetSocketAddress(this.d, this.e), this.f * 1000);
            this.b.setSoTimeout(1000);
        }
        catch (final ConnectException ex) {
            this.a.fine(q.g, "start", "250", (Object[])null, (Throwable)ex);
            throw new org.eclipse.paho.client.mqttv3.k(32103, (Throwable)ex);
        }
    }
    
    @Override
    public void stop() {
        final Socket b = this.b;
        if (b != null) {
            b.close();
        }
    }
}
