package A9;

import javax.net.ssl.SSLSocketFactory;
import javax.net.SocketFactory;
import org.eclipse.paho.client.mqttv3.i;
import java.net.URI;
import java.util.Collections;
import java.util.Collection;
import java.util.HashSet;
import java.util.Arrays;
import java.util.Set;
import F9.a;

public class r implements a
{
    @Override
    public Set a() {
        return Collections.unmodifiableSet((Set)new HashSet((Collection)Arrays.asList((Object[])new String[] { "tcp" })));
    }
    
    @Override
    public k b(final URI uri, final i i, final String s) {
        final String host = uri.getHost();
        int port;
        if ((port = uri.getPort()) == -1) {
            port = 1883;
        }
        final String path = uri.getPath();
        if (path != null && !path.isEmpty()) {
            throw new IllegalArgumentException(uri.toString());
        }
        SocketFactory socketFactory = i.l();
        if (socketFactory == null) {
            socketFactory = SocketFactory.getDefault();
        }
        else if (socketFactory instanceof SSLSocketFactory) {
            throw h.a(32105);
        }
        final q q = new q(socketFactory, host, port, s);
        q.d(i.a());
        return q;
    }
    
    @Override
    public void c(final URI uri) {
        final String path = uri.getPath();
        if (path != null && !path.isEmpty()) {
            final String string = uri.toString();
            final StringBuilder sb = new StringBuilder();
            sb.append("URI path must be empty \"");
            sb.append(string);
            sb.append("\"");
            throw new IllegalArgumentException(sb.toString());
        }
    }
}
