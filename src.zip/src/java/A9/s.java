package A9;

import org.eclipse.paho.client.mqttv3.b;
import org.eclipse.paho.client.mqttv3.k;
import D9.u;
import org.eclipse.paho.client.mqttv3.l;
import org.eclipse.paho.client.mqttv3.logging.a;

public class s
{
    private static final String q = "A9.s";
    private a a;
    private volatile boolean b;
    private boolean c;
    private boolean d;
    private final Object e;
    private final Object f;
    protected l g;
    private u h;
    private k i;
    private String[] j;
    private String k;
    private b l;
    private org.eclipse.paho.client.mqttv3.a m;
    private Object n;
    private int o;
    private boolean p;
    
    public s(final String resourceName) {
        this.a = org.eclipse.paho.client.mqttv3.logging.b.a("org.eclipse.paho.client.mqttv3.internal.nls.logcat", s.q);
        this.b = false;
        this.c = false;
        this.d = false;
        this.e = new Object();
        this.f = new Object();
        this.g = null;
        this.h = null;
        this.i = null;
        this.j = null;
        this.l = null;
        this.m = null;
        this.n = null;
        this.o = 0;
        this.p = false;
        this.a.setResourceName(resourceName);
    }
    
    public org.eclipse.paho.client.mqttv3.a a() {
        return this.m;
    }
    
    public b b() {
        return this.l;
    }
    
    public k c() {
        return this.i;
    }
    
    public String d() {
        return this.k;
    }
    
    public u e() {
        return this.h;
    }
    
    public String[] f() {
        return this.j;
    }
    
    public Object g() {
        return this.n;
    }
    
    public u h() {
        return this.h;
    }
    
    public boolean i() {
        return this.b;
    }
    
    protected boolean j() {
        return this.c;
    }
    
    public boolean k() {
        return this.p;
    }
    
    protected void l(final u h, final k i) {
        this.a.fine(s.q, "markComplete", "404", new Object[] { this.d(), h, i });
        final Object e;
        monitorenter(e = this.e);
        Label_0064: {
            try {
                if (h instanceof D9.b) {
                    this.g = null;
                }
                break Label_0064;
            }
            finally {
                monitorexit(e);
                this.c = true;
                this.h = h;
                this.i = i;
                monitorexit(e);
            }
        }
    }
    
    protected void m() {
        this.a.fine(s.q, "notifyComplete", "404", new Object[] { this.d(), this.h, this.i });
        final Object e;
        monitorenter(e = this.e);
        Label_0081: {
            try {
                if (this.i == null && this.c) {
                    this.b = true;
                    this.c = false;
                    break Label_0081;
                }
                break Label_0081;
            }
            finally {
                monitorexit(e);
                this.c = false;
                this.e.notifyAll();
                monitorexit(e);
                final Object f = this.f;
                synchronized (f) {
                    this.d = true;
                    this.f.notifyAll();
                }
            }
        }
    }
    
    protected void n() {
        this.a.fine(s.q, "notifySent", "403", new Object[] { this.d() });
        final Object e = this.e;
        synchronized (e) {
            this.h = null;
            this.b = false;
            monitorexit(e);
            synchronized (this.f) {
                this.d = true;
                this.f.notifyAll();
            }
        }
    }
    
    public void o(final org.eclipse.paho.client.mqttv3.a m) {
        this.m = m;
    }
    
    protected void p(final b l) {
        this.l = l;
    }
    
    public void q(final k i) {
        final Object e = this.e;
        synchronized (e) {
            this.i = i;
        }
    }
    
    public void r(final String k) {
        this.k = k;
    }
    
    public void s(final l g) {
        this.g = g;
    }
    
    public void t(final int o) {
        this.o = o;
    }
    
    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer();
        sb.append("key=");
        sb.append(this.d());
        sb.append(" ,topics=");
        if (this.f() != null) {
            for (int i = 0; i < this.f().length; ++i) {
                sb.append(this.f()[i]);
                sb.append(", ");
            }
        }
        sb.append(" ,usercontext=");
        sb.append(this.g());
        sb.append(" ,isComplete=");
        sb.append(this.i());
        sb.append(" ,isNotified=");
        sb.append(this.k());
        sb.append(" ,exception=");
        sb.append((Object)this.c());
        sb.append(" ,actioncallback=");
        sb.append((Object)this.a());
        return sb.toString();
    }
    
    public void u(final boolean p) {
        this.p = p;
    }
    
    public void v(final String[] array) {
        this.j = array.clone();
    }
    
    public void w(final Object n) {
        this.n = n;
    }
    
    public void x() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        A9/s.f:Ljava/lang/Object;
        //     4: astore_2       
        //     5: aload_2        
        //     6: dup            
        //     7: astore          5
        //     9: monitorenter   
        //    10: aload_0        
        //    11: getfield        A9/s.e:Ljava/lang/Object;
        //    14: astore_3       
        //    15: aload_3        
        //    16: dup            
        //    17: astore          6
        //    19: monitorenter   
        //    20: aload_0        
        //    21: getfield        A9/s.i:Lorg/eclipse/paho/client/mqttv3/k;
        //    24: astore          4
        //    26: aload           4
        //    28: ifnonnull       114
        //    31: aload           6
        //    33: monitorexit    
        //    34: aload_0        
        //    35: getfield        A9/s.d:Z
        //    38: istore_1       
        //    39: iload_1        
        //    40: ifne            84
        //    43: aload_0        
        //    44: getfield        A9/s.a:Lorg/eclipse/paho/client/mqttv3/logging/a;
        //    47: getstatic       A9/s.q:Ljava/lang/String;
        //    50: ldc             "waitUntilSent"
        //    52: ldc             "409"
        //    54: iconst_1       
        //    55: anewarray       Ljava/lang/Object;
        //    58: dup            
        //    59: iconst_0       
        //    60: aload_0        
        //    61: invokevirtual   A9/s.d:()Ljava/lang/String;
        //    64: aastore        
        //    65: invokeinterface org/eclipse/paho/client/mqttv3/logging/a.fine:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
        //    70: aload_0        
        //    71: getfield        A9/s.f:Ljava/lang/Object;
        //    74: invokevirtual   java/lang/Object.wait:()V
        //    77: goto            34
        //    80: astore_3       
        //    81: goto            123
        //    84: iload_1        
        //    85: ifne            105
        //    88: aload_0        
        //    89: getfield        A9/s.i:Lorg/eclipse/paho/client/mqttv3/k;
        //    92: astore_3       
        //    93: aload_3        
        //    94: ifnonnull       103
        //    97: bipush          6
        //    99: invokestatic    A9/h.a:(I)Lorg/eclipse/paho/client/mqttv3/k;
        //   102: athrow         
        //   103: aload_3        
        //   104: athrow         
        //   105: aload           5
        //   107: monitorexit    
        //   108: return         
        //   109: astore          4
        //   111: goto            117
        //   114: aload           4
        //   116: athrow         
        //   117: aload           6
        //   119: monitorexit    
        //   120: aload           4
        //   122: athrow         
        //   123: aload           5
        //   125: monitorexit    
        //   126: aload_3        
        //   127: athrow         
        //   128: astore_3       
        //   129: goto            34
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  10     20     80     128    Any
        //  20     26     109    123    Any
        //  31     34     109    123    Any
        //  34     39     80     128    Any
        //  43     77     128    132    Ljava/lang/InterruptedException;
        //  43     77     80     128    Any
        //  88     93     80     128    Any
        //  97     103    80     128    Any
        //  103    105    80     128    Any
        //  105    108    80     128    Any
        //  114    117    109    123    Any
        //  117    120    109    123    Any
        //  120    123    80     128    Any
        //  123    126    80     128    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 74 out of bounds for length 74
        //     at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:266)
        //     at java.util.Objects.checkIndex(Objects.java:359)
        //     at java.util.ArrayList.get(ArrayList.java:434)
        //     at w5.a.o(SourceFile:31)
        //     at w5.a.j(SourceFile:218)
        //     at a6.j.j(SourceFile:23)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
