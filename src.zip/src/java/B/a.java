package b;

import com.syncleoiot.core.infrastructure.profile.ProfileRepositoryImpl;
import kotlin.coroutines.jvm.internal.d;

public final class a extends d
{
    public Object A;
    public final ProfileRepositoryImpl B;
    public int C;
    public Object y;
    public Exception z;
    
    public a(final ProfileRepositoryImpl b, final P8.d d) {
        this.B = b;
        super(d);
    }
    
    public final Object invokeSuspend(final Object a) {
        this.A = a;
        this.C |= Integer.MIN_VALUE;
        return ProfileRepositoryImpl.access$handleLoadError(this.B, (Exception)null, (String)null, (P8.d)this);
    }
}
