package b;

import r9.a;
import com.syncleoiot.core.infrastructure.profile.ProfileRepositoryImpl;
import com.syncleoiot.core.data.model.UserProfile;
import kotlin.coroutines.jvm.internal.d;

public final class b extends d
{
    public UserProfile A;
    public Object B;
    public final ProfileRepositoryImpl C;
    public int H;
    public Object y;
    public a z;
    
    public b(final ProfileRepositoryImpl c, final P8.d d) {
        this.C = c;
        super(d);
    }
    
    public final Object invokeSuspend(final Object b) {
        this.B = b;
        this.H |= Integer.MIN_VALUE;
        return this.C.refreshProfile((P8.d)this);
    }
}
