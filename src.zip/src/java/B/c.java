package b;

import com.syncleoiot.core.data.model.UserProfile;
import com.syncleoiot.core.infrastructure.profile.ProfileRepositoryImpl;
import kotlin.coroutines.jvm.internal.d;

public final class c extends d
{
    public Object A;
    public final ProfileRepositoryImpl B;
    public int C;
    public ProfileRepositoryImpl y;
    public UserProfile z;
    
    public c(final ProfileRepositoryImpl b, final P8.d d) {
        this.B = b;
        super(d);
    }
    
    public final Object invokeSuspend(final Object a) {
        this.A = a;
        this.C |= Integer.MIN_VALUE;
        return this.B.updateUserProfile((UserProfile)null, (P8.d)this);
    }
}
