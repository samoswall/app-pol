package B;

import R8.b;
import R8.a;

public enum d
{
    private static final a $ENTRIES;
    private static final d[] $VALUES;
    
    const, 
    mac;
    
    private static final /* synthetic */ d[] $values() {
        return new d[] { d.const, d.mac };
    }
    
    static {
        $ENTRIES = b.a((Enum[])($VALUES = $values()));
    }
    
    public static a getEntries() {
        return d.$ENTRIES;
    }
}
