package B;

import java.util.Collection;
import java.util.Iterator;
import com.syncleoiot.core.SyncleoAppConfig$updateTransportVendors$5$WhenMappings;
import java.util.Map$Entry;
import java.util.Map;
import java.util.List;
import android.bluetooth.BluetoothDevice;
import com.syncleoiot.transport.core.models.DeviceFirmware;
import com.syncleoiot.transport.core.base.DeviceVendor;
import com.syncleoiot.transport.core.models.MacAddress;
import kotlin.jvm.internal.v;
import com.syncleoiot.transport.ble.discovery.BleDeviceEntry;
import com.syncleoiot.transport.ble.discovery.BleDiscoveredDevice;
import com.syncleoiot.core.data.model.Device;
import X8.p;
import kotlin.jvm.internal.w;

public final class e extends w implements p
{
    public final Device H;
    
    public e(final Device h) {
        this.H = h;
        super(2);
    }
    
    public final Object invoke(Object value, final Object o) {
        final BleDiscoveredDevice bleDiscoveredDevice = (BleDiscoveredDevice)value;
        final BleDeviceEntry bleDeviceEntry = (BleDeviceEntry)o;
        v.j((Object)bleDiscoveredDevice, "bleDev");
        v.j((Object)bleDeviceEntry, "deviceEntry");
        final BleDiscoveredDevice copy$default = BleDiscoveredDevice.copy$default(bleDiscoveredDevice, (MacAddress)null, (DeviceVendor)null, (short)this.H.getType(), (short)0, (String)null, (DeviceFirmware)null, (BluetoothDevice)null, false, (List)null, 507, (Object)null);
        value = this.H.getParams().get((Object)"advFormat");
        Map map2 = null;
        Label_0160: {
            if (value != null && value instanceof Map) {
                final Map map = (Map)value;
                if (map.isEmpty()) {
                    map2 = map;
                    break Label_0160;
                }
                final Iterator iterator = map.entrySet().iterator();
                Map$Entry map$Entry;
                do {
                    map2 = map;
                    if (!iterator.hasNext()) {
                        break Label_0160;
                    }
                    map$Entry = (Map$Entry)iterator.next();
                } while (map$Entry.getKey() instanceof String && map$Entry.getValue() != null);
            }
            map2 = null;
        }
        BleDiscoveredDevice bleDiscoveredDevice2 = copy$default;
        if (map2 != null) {
            if (map2.isEmpty()) {
                bleDiscoveredDevice2 = copy$default;
            }
            else {
                final a fromMap = a.b.fromMap(map2);
                Object a;
                if (fromMap != null) {
                    a = fromMap.a;
                }
                else {
                    a = null;
                }
                if (a != null) {
                    if (!((Collection)a).isEmpty()) {
                        final String name = bleDeviceEntry.getName();
                        final Iterator iterator2 = ((List)a).iterator();
                        int n = 0;
                        int n2 = 0;
                        int n3 = 0;
                        Label_0401: {
                            while (true) {
                                n3 = n;
                                bleDiscoveredDevice2 = copy$default;
                                if (!iterator2.hasNext()) {
                                    break Label_0401;
                                }
                                final c c = (c)iterator2.next();
                                final int n4 = SyncleoAppConfig$updateTransportVendors$5$WhenMappings.$EnumSwitchMapping$0[c.a.ordinal()];
                                if (n4 != 1) {
                                    if (n4 != 2) {
                                        continue;
                                    }
                                    n += 12;
                                    if (name.length() < n) {
                                        break;
                                    }
                                    n2 += 12;
                                }
                                else {
                                    final String b = c.b;
                                    if (b == null) {
                                        continue;
                                    }
                                    final int length = b.length();
                                    n += length;
                                    if (name.length() < n) {
                                        break;
                                    }
                                    final String substring = name.substring(n2, length);
                                    v.i((Object)substring, "substring(...)");
                                    if (!v.e((Object)substring, (Object)b)) {
                                        break;
                                    }
                                    n2 += length;
                                }
                            }
                            while (true) {
                                bleDiscoveredDevice2 = null;
                                n3 = n;
                                break Label_0401;
                                continue;
                            }
                        }
                        if (name.length() == n3) {
                            return bleDiscoveredDevice2;
                        }
                    }
                }
                bleDiscoveredDevice2 = null;
            }
        }
        return bleDiscoveredDevice2;
    }
}
