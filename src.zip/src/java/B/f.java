package B;

import K8.M;
import com.syncleoiot.sdk.analyticsclient.SyncleoAnalyticsClient;
import kotlin.jvm.internal.v;
import X8.l;
import kotlin.jvm.internal.w;

public final class f extends w implements l
{
    public static final f H;
    
    static {
        H = new f();
    }
    
    public f() {
        super(1);
    }
    
    public final Object invoke(final Object o) {
        final String s = (String)o;
        v.j((Object)s, "it");
        SyncleoAnalyticsClient.INSTANCE.registerPushToken(s);
        return M.a;
    }
}
