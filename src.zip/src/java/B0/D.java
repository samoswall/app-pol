package b0;

import X8.l;

public interface d
{
    int a();
    
    void b(final int p0, final int p1, final l p2);
    
    a get(final int p0);
    
    public static final class a
    {
        private final int a;
        private final int b;
        private final Object c;
        
        public a(final int a, final int b, final Object c) {
            this.a = a;
            this.b = b;
            this.c = c;
            if (a < 0) {
                final StringBuilder sb = new StringBuilder();
                sb.append("startIndex should be >= 0, but was ");
                sb.append(a);
                throw new IllegalArgumentException(sb.toString().toString());
            }
            if (b > 0) {
                return;
            }
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("size should be >0, but was ");
            sb2.append(b);
            throw new IllegalArgumentException(sb2.toString().toString());
        }
        
        public final int a() {
            return this.b;
        }
        
        public final int b() {
            return this.a;
        }
        
        public final Object c() {
            return this.c;
        }
    }
}
