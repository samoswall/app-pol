package b0;

import x0.b;

public abstract class e
{
    private static final int b(final b b, final int n) {
        int n2 = b.q() - 1;
        int i = 0;
        while (i < n2) {
            final int n3 = (n2 - i) / 2 + i;
            final int b2 = ((d.a)b.p()[n3]).b();
            if (b2 == n) {
                return n3;
            }
            if (b2 < n) {
                if (n < ((d.a)b.p()[i = n3 + 1]).b()) {
                    return n3;
                }
                continue;
            }
            else {
                n2 = n3 - 1;
            }
        }
        return i;
    }
}
