package b0;

import S.k;
import java.util.concurrent.CancellationException;

final class f extends CancellationException
{
    private final int a;
    private final k b;
    
    public f(final int a, final k b) {
        this.a = a;
        this.b = b;
    }
    
    public final int a() {
        return this.a;
    }
    
    public final k b() {
        return this.b;
    }
}
