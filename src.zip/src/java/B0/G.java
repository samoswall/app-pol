package b0;

import S.i;
import S.n0;
import d9.n;
import kotlin.jvm.internal.w;
import kotlin.jvm.internal.O;
import S.k;
import kotlin.jvm.internal.S;
import kotlin.jvm.internal.M;
import kotlin.jvm.internal.P;
import K8.x;
import Q8.b;
import V.v;
import kotlin.coroutines.jvm.internal.l;
import X8.p;
import A1.d;
import A1.h;

public abstract class g
{
    private static final float a;
    private static final float b;
    private static final float c;
    
    static {
        a = h.i((float)2500);
        b = h.i((float)1500);
        c = h.i((float)50);
    }
    
    public static final /* synthetic */ float a() {
        return g.b;
    }
    
    public static final /* synthetic */ float b() {
        return g.c;
    }
    
    public static final /* synthetic */ float c() {
        return g.a;
    }
    
    public static final Object d(final b0.h h, final int n, final int n2, final int n3, final d d, final P8.d d2) {
        final Object b = h.b((p)new p(n, d, h, n2, n3, null) {
            Object A;
            float B;
            float C;
            float H;
            int L;
            int M;
            private Object Q;
            final int W;
            final d X;
            final b0.h Y;
            final int Z;
            final int a0;
            Object y;
            Object z;
            
            private static final boolean l(final boolean b, final b0.h h, final int n, final int n2) {
                final boolean b2 = false;
                if (b) {
                    if (h.g() <= n) {
                        boolean b3 = b2;
                        if (h.g() != n) {
                            return b3;
                        }
                        b3 = b2;
                        if (h.d() <= n2) {
                            return b3;
                        }
                    }
                }
                else if (h.g() >= n) {
                    boolean b3 = b2;
                    if (h.g() != n) {
                        return b3;
                    }
                    b3 = b2;
                    if (h.d() >= n2) {
                        return b3;
                    }
                }
                return true;
            }
            
            public final P8.d create(final Object q, final P8.d d) {
                final p p2 = (p)new p(this.W, this.X, this.Y, this.Z, this.a0, d) {
                    Object A;
                    float B;
                    float C;
                    float H;
                    int L;
                    int M;
                    private Object Q;
                    final int W;
                    final d X;
                    final b0.h Y;
                    final int Z;
                    final int a0;
                    Object y;
                    Object z;
                    
                    private static final boolean l(final boolean b, final b0.h h, final int n, final int n2) {
                        final boolean b2 = false;
                        if (b) {
                            if (h.g() <= n) {
                                boolean b3 = b2;
                                if (h.g() != n) {
                                    return b3;
                                }
                                b3 = b2;
                                if (h.d() <= n2) {
                                    return b3;
                                }
                            }
                        }
                        else if (h.g() >= n) {
                            boolean b3 = b2;
                            if (h.g() != n) {
                                return b3;
                            }
                            b3 = b2;
                            if (h.d() >= n2) {
                                return b3;
                            }
                        }
                        return true;
                    }
                };
                p2.Q = q;
                return (P8.d)p2;
            }
            
            public final Object invokeSuspend(Object f) {
                S f2;
                Object z = f2 = (S)Q8.b.f();
                final int m = this.M;
                Label_0895: {
                    Object a = null;
                    Label_0720: {
                    Label_0144:
                        while (true) {
                            Block_6: {
                                if (m != 0) {
                                    if (m != 1) {
                                        if (m == 2) {
                                            final Object o = this.Q;
                                            x.b((Object)f);
                                            f = (f)o;
                                            break Label_0895;
                                        }
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                    else {
                                        final int l = this.L;
                                        final float h = this.H;
                                        final float c = this.C;
                                        final float b = this.B;
                                        final P p = (P)this.A;
                                        z = this.z;
                                        final Object y = this.y;
                                        a = this.Q;
                                        try {
                                            x.b((Object)f);
                                            f = (f)a;
                                            a = p;
                                            break Label_0144;
                                        }
                                        catch (final f f3) {
                                            final f f4 = (f)a;
                                            a = f3;
                                            f = f4;
                                        }
                                    }
                                }
                                else {
                                    x.b((Object)f);
                                    a = this.Q;
                                    final int w = this.W;
                                    if (w >= 0.0f) {
                                        break Block_6;
                                    }
                                    f = (f)new StringBuilder();
                                    ((StringBuilder)f).append("Index should be non-negative (");
                                    ((StringBuilder)f).append(w);
                                    ((StringBuilder)f).append(')');
                                    throw new IllegalArgumentException(((StringBuilder)f).toString().toString());
                                }
                                break Label_0720;
                            }
                            try {
                                final float b = this.X.X0(g.c());
                                final float c = this.X.X0(g.a());
                                float x0 = this.X.X0(g.b());
                                final Object y = new M();
                                ((M)y).a = true;
                                final S s = new S();
                                s.a = S.l.c(0.0f, 0.0f, 0L, 0L, false, 30, (Object)null);
                                if (g.e(this.Y, this.W)) {
                                    break Label_0720;
                                }
                                int l;
                                if (this.W > this.Y.g()) {
                                    l = 1;
                                }
                                else {
                                    l = 0;
                                }
                                final P p2 = new P();
                                p2.a = 1;
                                f = (f)a;
                                a = p2;
                                z = s;
                                try {
                                    while (((M)y).a && this.Y.a() > 0) {
                                        final float n = this.Y.f(this.W) + this.Z;
                                        float max = 0.0f;
                                        Label_0436: {
                                            while (true) {
                                                Label_0420: {
                                                    if (Math.abs(n) >= b) {
                                                        break Label_0420;
                                                    }
                                                    try {
                                                        max = Math.max(Math.abs(n), x0);
                                                        if (l == 0) {
                                                            max = -max;
                                                        }
                                                        break Label_0436;
                                                    }
                                                    catch (final f a) {
                                                        continue Label_0144;
                                                    }
                                                }
                                                if (l == 0) {
                                                    max = -b;
                                                    continue;
                                                }
                                                break;
                                            }
                                            max = b;
                                        }
                                        ((S)z).a = S.l.g((k)((S)z).a, 0.0f, 0.0f, 0L, 0L, false, 30, (Object)null);
                                        final O o2 = new O();
                                        final k k = (k)((S)z).a;
                                        final Float d = kotlin.coroutines.jvm.internal.b.d(max);
                                        final boolean b2 = ((Number)((k)((S)z).a).n()).floatValue() != 0.0f;
                                        final b0.h y2 = this.Y;
                                        final int w2 = this.W;
                                        final boolean b3 = l != 0;
                                        final int a2 = this.a0;
                                        try {
                                            final X8.l i = (X8.l)new X8.l(y2, w2, max, o2, f, y, b3, c, a, a2, this.Z, z) {
                                                final b0.h H;
                                                final int L;
                                                final float M;
                                                final O Q;
                                                final v W;
                                                final M X;
                                                final boolean Y;
                                                final float Z;
                                                final P a0;
                                                final int b0;
                                                final int c0;
                                                final S d0;
                                                
                                                public final void a(final S.h h) {
                                                    if (!g.e(this.H, this.L)) {
                                                        float n;
                                                        if (this.M > 0.0f) {
                                                            n = d9.n.j(((Number)h.e()).floatValue(), this.M);
                                                        }
                                                        else {
                                                            n = d9.n.e(((Number)h.e()).floatValue(), this.M);
                                                        }
                                                        final float n2 = n - this.Q.a;
                                                        final float a = this.W.a(n2);
                                                        if (!g.e(this.H, this.L)) {
                                                            if (!l(this.Y, this.H, this.L, this.c0)) {
                                                                if (n2 != a) {
                                                                    h.a();
                                                                    this.X.a = false;
                                                                    return;
                                                                }
                                                                final O q = this.Q;
                                                                q.a += n2;
                                                                if (this.Y) {
                                                                    if (((Number)h.e()).floatValue() > this.Z) {
                                                                        h.a();
                                                                    }
                                                                }
                                                                else if (((Number)h.e()).floatValue() < -this.Z) {
                                                                    h.a();
                                                                }
                                                                if (this.Y) {
                                                                    if (this.a0.a >= 2) {
                                                                        final int l = this.L;
                                                                        final int c = this.H.c();
                                                                        final int b0 = this.b0;
                                                                        if (l - c > b0) {
                                                                            this.H.e(this.W, this.L - b0, 0);
                                                                        }
                                                                    }
                                                                }
                                                                else if (this.a0.a >= 2) {
                                                                    final int g = this.H.g();
                                                                    final int i = this.L;
                                                                    final int b2 = this.b0;
                                                                    if (g - i > b2) {
                                                                        this.H.e(this.W, i + b2, 0);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                    if (l(this.Y, this.H, this.L, this.c0)) {
                                                        this.H.e(this.W, this.L, this.c0);
                                                        this.X.a = false;
                                                        h.a();
                                                        return;
                                                    }
                                                    if (!g.e(this.H, this.L)) {
                                                        return;
                                                    }
                                                    throw new f(Z8.b.e(this.H.f(this.L)), (k)this.d0.a);
                                                }
                                            };
                                            this.Q = f;
                                            this.y = y;
                                            this.z = z;
                                            this.A = a;
                                            this.B = b;
                                            this.C = c;
                                            this.H = x0;
                                            this.L = l;
                                            this.M = 1;
                                            try {
                                                if (n0.j(k, (Object)d, (i)null, b2, (X8.l)i, (P8.d)this, 2, (Object)null) == f2) {
                                                    return f2;
                                                }
                                                final float h = x0;
                                                try {
                                                    ++((P)a).a;
                                                    x0 = h;
                                                }
                                                catch (final f a) {}
                                            }
                                            catch (final f f5) {}
                                        }
                                        catch (final f a) {}
                                    }
                                }
                                catch (final f a) {}
                            }
                            catch (final f f6) {}
                            break;
                        }
                        while (true) {
                            f2 = (S)z;
                            final f f7 = f;
                            f = (f)a;
                            a = f7;
                            break Label_0720;
                            try {
                                final S s;
                                f = new f(Z8.b.e(this.Y.f(this.W)), (k)s.a);
                                throw f;
                            }
                            catch (final f f) {
                                continue;
                            }
                            break;
                        }
                    }
                    final k g = S.l.g(((f)a).b(), 0.0f, 0.0f, 0L, 0L, false, 30, (Object)null);
                    final float n2 = (float)(((f)a).a() + this.Z);
                    final O o3 = new O();
                    final Float d2 = kotlin.coroutines.jvm.internal.b.d(n2);
                    final boolean b4 = ((Number)g.n()).floatValue() == 0.0f;
                    final X8.l j = (X8.l)new X8.l(n2, o3, f) {
                        final float H;
                        final O L;
                        final v M;
                        
                        public final void a(final S.h h) {
                            final float h2 = this.H;
                            float n = 0.0f;
                            if (h2 > 0.0f) {
                                n = d9.n.j(((Number)h.e()).floatValue(), this.H);
                            }
                            else if (h2 < 0.0f) {
                                n = d9.n.e(((Number)h.e()).floatValue(), this.H);
                            }
                            final float n2 = n - this.L.a;
                            if (n2 != this.M.a(n2) || n != ((Number)h.e()).floatValue()) {
                                h.a();
                            }
                            final O l = this.L;
                            l.a += n2;
                        }
                    };
                    this.Q = f;
                    this.y = null;
                    this.z = null;
                    this.A = null;
                    this.M = 2;
                    if (n0.j(g, (Object)d2, (i)null, true ^ b4, (X8.l)j, (P8.d)this, 2, (Object)null) == f2) {
                        return f2;
                    }
                }
                this.Y.e((v)f, this.W, this.Z);
                return K8.M.a;
            }
            
            public final Object j(final v v, final P8.d d) {
                return ((g$a)this.create(v, d)).invokeSuspend(K8.M.a);
            }
        }, d2);
        if (b == Q8.b.f()) {
            return b;
        }
        return K8.M.a;
    }
    
    public static final boolean e(final b0.h h, final int n) {
        final int g = h.g();
        final int c = h.c();
        boolean b = false;
        if (n <= c) {
            b = b;
            if (g <= n) {
                b = true;
            }
        }
        return b;
    }
}
