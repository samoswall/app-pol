package b0;

import A1.d;
import S.G;
import g1.p0;
import androidx.compose.ui.e$c;

public final class i extends e$c implements p0
{
    private G n;
    private G o;
    private G p;
    
    public i(final G n, final G o, final G p3) {
        this.n = n;
        this.o = o;
        this.p = p3;
    }
    
    public Object h(final d d, final Object o) {
        return this;
    }
    
    public final G q2() {
        return this.n;
    }
    
    public final G r2() {
        return this.p;
    }
    
    public final G s2() {
        return this.o;
    }
    
    public final void t2(final G n) {
        this.n = n;
    }
    
    public final void u2(final G p) {
        this.p = p;
    }
    
    public final void v2(final G o) {
        this.o = o;
    }
}
