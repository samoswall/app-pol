package b0;

import x0.b;

public final class j
{
    public static final int b;
    private final b a;
    
    static {
        b = x0.b.d;
    }
    
    public j() {
        this.a = new b((Object[])new a[16], 0);
    }
    
    public final a a(final int n, final int n2) {
        final a a = new a(n, n2);
        this.a.b((Object)a);
        return a;
    }
    
    public final int b() {
        final int a = ((a)this.a.o()).a();
        final b a2 = this.a;
        final int q = a2.q();
        int n = a;
        if (q > 0) {
            final Object[] p = a2.p();
            int n2 = 0;
            int n3 = a;
            int n4;
            int a4;
            do {
                final a a3 = (a)p[n2];
                if (a3.a() > (a4 = n3)) {
                    a4 = a3.a();
                }
                n4 = n2 + 1;
                n3 = a4;
            } while ((n2 = n4) < q);
            n = a4;
        }
        return n;
    }
    
    public final int c() {
        final int b = ((a)this.a.o()).b();
        final b a = this.a;
        final int q = a.q();
        int n = b;
        if (q > 0) {
            final Object[] p = a.p();
            int n2 = 0;
            int n3 = b;
            int n4;
            int b2;
            do {
                final a a2 = (a)p[n2];
                if (a2.b() < (b2 = n3)) {
                    b2 = a2.b();
                }
                n4 = n2 + 1;
                n3 = b2;
            } while ((n2 = n4) < q);
            n = b2;
        }
        if (n >= 0) {
            return n;
        }
        throw new IllegalArgumentException("negative minIndex");
    }
    
    public final boolean d() {
        return this.a.t();
    }
    
    public final void e(final a a) {
        this.a.w((Object)a);
    }
    
    public static final class a
    {
        private final int a;
        private final int b;
        
        public a(final int a, final int b) {
            this.a = a;
            this.b = b;
            if (a < 0) {
                throw new IllegalArgumentException("negative start index");
            }
            if (b >= a) {
                return;
            }
            throw new IllegalArgumentException("end index greater than start");
        }
        
        public final int a() {
            return this.b;
        }
        
        public final int b() {
            return this.a;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof a)) {
                return false;
            }
            final a a = (a)o;
            return this.a == a.a && this.b == a.b;
        }
        
        @Override
        public int hashCode() {
            return Integer.hashCode(this.a) * 31 + Integer.hashCode(this.b);
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append("Interval(start=");
            sb.append(this.a);
            sb.append(", end=");
            sb.append(this.b);
            sb.append(')');
            return sb.toString();
        }
    }
}
