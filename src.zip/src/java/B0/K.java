package b0;

import e1.f;
import kotlin.jvm.internal.S;
import e1.e$b$a;
import K8.s;
import e1.e$b;
import V.q;
import A1.t;
import e1.e;
import f1.j;

public final class k implements j, e
{
    public static final b g;
    private static final k$a h;
    private final m b;
    private final b0.j c;
    private final boolean d;
    private final t e;
    private final q f;
    
    static {
        g = new b(null);
        h = new a() {
            private final boolean a;
            
            @Override
            public boolean a() {
                return this.a;
            }
        };
    }
    
    public k(final m b, final b0.j c, final boolean d, final t e, final q f) {
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    
    private final b0.j.a l(final b0.j.a a, int n) {
        final int b = a.b();
        int a2 = a.a();
        if (this.o(n)) {
            ++a2;
            n = b;
        }
        else {
            n = b - 1;
        }
        return this.c.a(n, a2);
    }
    
    private final boolean n(final b0.j.a a, final int n) {
        final boolean p2 = this.p(n);
        boolean b = false;
        if (p2) {
            return false;
        }
        if (this.o(n)) {
            if (a.a() >= this.b.a() - 1) {
                return b;
            }
        }
        else if (a.b() <= 0) {
            return b;
        }
        b = true;
        return b;
    }
    
    private final boolean o(int n) {
        final e$b$a a = e$b.a;
        final boolean h = e$b.h(n, a.c());
        boolean b = false;
        if (!h) {
            if (!e$b.h(n, a.b())) {
                if (e$b.h(n, a.a())) {
                    b = this.d;
                    return b;
                }
                if (e$b.h(n, a.d())) {
                    if (this.d) {
                        return b;
                    }
                }
                else if (e$b.h(n, a.e())) {
                    n = k.c.a[((Enum)this.e).ordinal()];
                    if (n == 1) {
                        b = this.d;
                        return b;
                    }
                    if (n != 2) {
                        throw new s();
                    }
                    if (this.d) {
                        return b;
                    }
                }
                else {
                    if (!e$b.h(n, a.f())) {
                        l.a();
                        throw new K8.j();
                    }
                    n = k.c.a[((Enum)this.e).ordinal()];
                    if (n != 1) {
                        if (n == 2) {
                            b = this.d;
                            return b;
                        }
                        throw new s();
                    }
                    else if (this.d) {
                        return b;
                    }
                }
            }
            b = true;
        }
        return b;
    }
    
    private final boolean p(final int n) {
        final e$b$a a = e$b.a;
        final boolean h = e$b.h(n, a.a());
        final boolean b = true;
        final int n2 = 1;
        if (h || e$b.h(n, a.d())) {
            if (this.f == q.Horizontal) {
                return b;
            }
        }
        else if (e$b.h(n, a.e()) || e$b.h(n, a.f())) {
            if (this.f == q.Vertical) {
                return b;
            }
        }
        else {
            int h2;
            if (e$b.h(n, a.c())) {
                h2 = n2;
            }
            else {
                h2 = (e$b.h(n, a.b()) ? 1 : 0);
            }
            if (h2 == 0) {
                l.a();
                throw new K8.j();
            }
        }
        return false;
    }
    
    public Object d(final int n, final X8.l l) {
        if (this.b.a() > 0 && this.b.d()) {
            int n2;
            if (this.o(n)) {
                n2 = this.b.b();
            }
            else {
                n2 = this.b.e();
            }
            final S s = new S();
            s.a = this.c.a(n2, n2);
            Object invoke;
            for (invoke = null; invoke == null && this.n((b0.j.a)s.a, n); invoke = l.invoke((Object)new a(this, s, n) {
                final k a;
                final S b;
                final int c;
                
                @Override
                public boolean a() {
                    return this.a.n((b0.j.a)this.b.a, this.c);
                }
            })) {
                final b0.j.a i = this.l((b0.j.a)s.a, n);
                this.c.e((b0.j.a)s.a);
                s.a = i;
                this.b.c();
            }
            this.c.e((b0.j.a)s.a);
            this.b.c();
            return invoke;
        }
        return l.invoke((Object)k.h);
    }
    
    public f1.l getKey() {
        return e1.f.a();
    }
    
    public e m() {
        return this;
    }
    
    public static final class b
    {
        private b() {
        }
    }
}
