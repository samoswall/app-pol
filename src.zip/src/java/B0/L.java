package b0;

import v0.p;
import V.q;
import A1.t;
import androidx.compose.ui.e;

public abstract class l
{
    public static final e b(e f, final m m, final j j, final boolean b, final t t, final q q, final boolean b2, final v0.m i, final int n) {
        if (p.J()) {
            p.S(1331498025, n, -1, "androidx.compose.foundation.lazy.layout.lazyLayoutBeyondBoundsModifier (LazyLayoutBeyondBoundsModifierLocal.kt:51)");
        }
        if (!b2) {
            i.a0(-1890658823);
            i.O();
        }
        else {
            i.a0(-1890632411);
            boolean b3 = false;
            final boolean b4 = (((n & 0x70) ^ 0x30) > 32 && i.Y((Object)m)) || (n & 0x30) == 0x20;
            final boolean b5 = (((n & 0x380) ^ 0x180) > 256 && i.Y((Object)j)) || (n & 0x180) == 0x100;
            final boolean b6 = (((n & 0x1C00) ^ 0xC00) > 2048 && i.d(b)) || (n & 0xC00) == 0x800;
            final boolean b7 = (((0xE000 & n) ^ 0x6000) > 16384 && i.Y((Object)t)) || (n & 0x6000) == 0x4000;
            if ((((0x70000 & n) ^ 0x30000) > 131072 && i.Y((Object)q)) || (n & 0x30000) == 0x20000) {
                b3 = true;
            }
            final Object g = i.g();
            k k;
            if ((b4 | b5 | b6 | b7 | b3) || (k = (k)g) == v0.m.a.a()) {
                k = new k(m, j, b, t, q);
                i.P((Object)k);
            }
            f = f.f((e)k);
            i.O();
        }
        if (p.J()) {
            p.R();
        }
        return f;
    }
    
    private static final Void c() {
        throw new IllegalStateException("Lazy list does not support beyond bounds layout for the specified direction");
    }
}
