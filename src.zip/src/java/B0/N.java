package b0;

import d9.h;
import java.util.ArrayList;
import java.util.List;

public abstract class n
{
    public static final List a(final t t, final E e, final j j) {
        if (!j.d() && e.isEmpty()) {
            return L8.t.n();
        }
        final ArrayList list = new ArrayList();
        d9.j a;
        if (j.d()) {
            a = new d9.j(j.c(), Math.min(j.b(), t.a() - 1));
        }
        else {
            a = d9.j.e.a();
        }
        for (int size = ((List)e).size(), i = 0; i < size; ++i) {
            final E.a a2 = (E.a)((List)e).get(i);
            final int a3 = u.a(t, a2.getKey(), a2.getIndex());
            final int q = ((h)a).q();
            if (a3 > ((h)a).s() || q > a3) {
                if (a3 >= 0 && a3 < t.a()) {
                    ((List)list).add((Object)a3);
                }
            }
        }
        int q2 = ((h)a).q();
        final int s = ((h)a).s();
        if (q2 <= s) {
            while (true) {
                ((List)list).add((Object)q2);
                if (q2 == s) {
                    break;
                }
                ++q2;
            }
        }
        return (List)list;
    }
}
