package b0;

import S.j;
import S.J0;
import A1.n;
import S.i0;

public abstract class p
{
    private static final i0 a;
    
    static {
        a = j.j(0.0f, 400.0f, (Object)n.b(J0.c(n.b)), 1, (Object)null);
    }
}
