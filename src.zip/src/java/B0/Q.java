package b0;

import androidx.compose.foundation.lazy.layout.b;

public abstract class q
{
    private static final b[] a;
    
    static {
        a = new b[0];
    }
    
    private static final i c(final Object o) {
        i i;
        if (o instanceof i) {
            i = (i)o;
        }
        else {
            i = null;
        }
        return i;
    }
}
