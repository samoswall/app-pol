package b0;

import v0.b1;
import v0.P0;
import D0.c;
import K8.M;
import kotlin.jvm.internal.w;
import F0.d;
import v0.p;
import v0.m;

public abstract class s
{
    private static final void a(final t t, final Object o, final int n, final Object o2, m v, final int n2) {
        v = v.v(1439843069);
        int n4;
        if ((n2 & 0x6) == 0x0) {
            int n3;
            if (v.Y((Object)t)) {
                n3 = 4;
            }
            else {
                n3 = 2;
            }
            n4 = (n3 | n2);
        }
        else {
            n4 = n2;
        }
        int n5 = n4;
        if ((n2 & 0x30) == 0x0) {
            int n6;
            if (v.Y(o)) {
                n6 = 32;
            }
            else {
                n6 = 16;
            }
            n5 = (n4 | n6);
        }
        int n7 = n5;
        if ((n2 & 0x180) == 0x0) {
            int n8;
            if (v.j(n)) {
                n8 = 256;
            }
            else {
                n8 = 128;
            }
            n7 = (n5 | n8);
        }
        int n9 = n7;
        if ((n2 & 0xC00) == 0x0) {
            int n10;
            if (v.Y(o2)) {
                n10 = 2048;
            }
            else {
                n10 = 1024;
            }
            n9 = (n7 | n10);
        }
        if ((n9 & 0x493) == 0x492 && v.y()) {
            v.G();
        }
        else {
            if (p.J()) {
                p.S(1439843069, n9, -1, "androidx.compose.foundation.lazy.layout.SkippableItem (LazyLayoutItemContentFactory.kt:133)");
            }
            ((d)o).d(o2, (X8.p)c.e(980966366, true, (Object)new X8.p(t, n, o2) {
                final t H;
                final int L;
                final Object M;
                
                public final void a(final m m, final int n) {
                    if ((n & 0x3) == 0x2 && m.y()) {
                        m.G();
                    }
                    else {
                        if (p.J()) {
                            p.S(980966366, n, -1, "androidx.compose.foundation.lazy.layout.SkippableItem.<anonymous> (LazyLayoutItemContentFactory.kt:135)");
                        }
                        this.H.h(this.L, this.M, m, 0);
                        if (p.J()) {
                            p.R();
                        }
                    }
                }
            }, v, 54), v, 48);
            if (p.J()) {
                p.R();
            }
        }
        final b1 c = v.C();
        if (c != null) {
            c.a((X8.p)new X8.p(t, o, n, o2, n2) {
                final t H;
                final Object L;
                final int M;
                final Object Q;
                final int W;
                
                public final void a(final m m, final int n) {
                    a(this.H, this.L, this.M, this.Q, m, P0.a(this.W | 0x1));
                }
            });
        }
    }
}
