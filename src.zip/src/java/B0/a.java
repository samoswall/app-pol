package b0;

import android.view.Display;
import kotlin.jvm.internal.m;
import android.view.Choreographer;
import x0.b;
import android.view.View;
import android.view.Choreographer$FrameCallback;
import v0.W0;

public final class a implements Q, W0, Runnable, Choreographer$FrameCallback
{
    public static final a g;
    public static final int h;
    private static long i;
    private final View a;
    private final x0.b b;
    private boolean c;
    private final Choreographer d;
    private boolean e;
    private long f;
    
    static {
        g = new a(null);
        h = 8;
    }
    
    public a(final View a) {
        this.a = a;
        this.b = new x0.b((Object[])new O[16], 0);
        this.d = Choreographer.getInstance();
        b0.a.g.b(a);
    }
    
    public static final /* synthetic */ long e() {
        return a.i;
    }
    
    public static final /* synthetic */ void f(final long i) {
        a.i = i;
    }
    
    @Override
    public void a(final O o) {
        this.b.b((Object)o);
        if (!this.c) {
            this.c = true;
            this.a.post((Runnable)this);
        }
    }
    
    public void b() {
    }
    
    public void c() {
        this.e = false;
        this.a.removeCallbacks((Runnable)this);
        this.d.removeFrameCallback((Choreographer$FrameCallback)this);
    }
    
    public void d() {
        this.e = true;
    }
    
    public void doFrame(final long f) {
        if (this.e) {
            this.f = f;
            this.a.post((Runnable)this);
        }
    }
    
    public void run() {
        if (!this.b.s() && this.c && this.e && this.a.getWindowVisibility() == 0) {
            final b b = new b(this.f + b0.a.i);
            int n = 0;
            while (this.b.t() && n == 0) {
                if (b.a() <= 0L || ((O)this.b.p()[0]).a(b)) {
                    n = 1;
                }
                else {
                    this.b.y(0);
                }
            }
            if (n != 0) {
                this.d.postFrameCallback((Choreographer$FrameCallback)this);
            }
            else {
                this.c = false;
            }
            return;
        }
        this.c = false;
    }
    
    public static final class a
    {
        private a() {
        }
        
        private final void b(final View view) {
            if (b0.a.e() == 0L) {
                final Display display = view.getDisplay();
                float refreshRate = 0.0f;
                Label_0042: {
                    if (!view.isInEditMode() && display != null) {
                        refreshRate = display.getRefreshRate();
                        if (refreshRate >= 30.0f) {
                            break Label_0042;
                        }
                    }
                    refreshRate = 60.0f;
                }
                b0.a.f((long)(1000000000 / refreshRate));
            }
        }
    }
    
    public static final class b implements P
    {
        private final long a;
        
        public b(final long a) {
            this.a = a;
        }
        
        @Override
        public long a() {
            return Math.max(0L, this.a - System.nanoTime());
        }
    }
}
