package b0;

import e1.s;
import K8.w$a;
import K8.w;
import kotlin.coroutines.jvm.internal.h;
import P8.i;
import K8.M;
import K8.x;
import P8.d;
import e1.O;

public final class b implements O
{
    private boolean b;
    private d c;
    
    public final Object d(d d) {
        kotlin.coroutines.jvm.internal.d d3 = null;
        Label_0047: {
            if (d instanceof b$a) {
                final kotlin.coroutines.jvm.internal.d d2 = (b$a)d;
                final int c = d2.C;
                if ((c & Integer.MIN_VALUE) != 0x0) {
                    d2.C = c + Integer.MIN_VALUE;
                    d3 = d2;
                    break Label_0047;
                }
            }
            d3 = new kotlin.coroutines.jvm.internal.d(this, d) {
                Object A;
                final b B;
                int C;
                Object y;
                Object z;
                
                public final Object invokeSuspend(final Object a) {
                    this.A = a;
                    this.C |= Integer.MIN_VALUE;
                    return this.B.d((d)this);
                }
            };
        }
        final Object a = d3.A;
        final Object f = Q8.b.f();
        final int c2 = d3.C;
        if (c2 != 0) {
            if (c2 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            final d d4 = (d)d3.z;
            final b b = (b)d3.y;
            x.b(a);
            d = d4;
        }
        else {
            x.b(a);
            if (this.b) {
                return M.a;
            }
            final d c3 = this.c;
            d3.y = this;
            d3.z = c3;
            d3.C = 1;
            final i c4 = new i(Q8.b.d((d)d3));
            this.c = (d)c4;
            final Object a2 = c4.a();
            if (a2 == Q8.b.f()) {
                h.c((d)d3);
            }
            if (a2 == f) {
                return f;
            }
            d = c3;
        }
        if (d != null) {
            final w$a b2 = w.b;
            d.resumeWith(w.b((Object)M.a));
        }
        return M.a;
    }
    
    @Override
    public void u(final s s) {
        if (!this.b) {
            this.b = true;
            final d c = this.c;
            if (c != null) {
                final w$a b = w.b;
                c.resumeWith(w.b((Object)M.a));
            }
            this.c = null;
        }
    }
}
