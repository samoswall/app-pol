package b0;

import android.os.Parcel;
import kotlin.jvm.internal.m;
import android.os.Parcelable$Creator;
import android.os.Parcelable;

final class c implements Parcelable
{
    public static final Parcelable$Creator<c> CREATOR;
    public static final b b;
    private final int a;
    
    static {
        b = new b(null);
        CREATOR = (Parcelable$Creator)new Parcelable$Creator() {
            public c a(final Parcel parcel) {
                return new c(parcel.readInt());
            }
            
            public c[] b(final int n) {
                return new c[n];
            }
        };
    }
    
    public c(final int a) {
        this.a = a;
    }
    
    public int describeContents() {
        return 0;
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o instanceof c && this.a == ((c)o).a);
    }
    
    @Override
    public int hashCode() {
        return Integer.hashCode(this.a);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("DefaultLazyKey(index=");
        sb.append(this.a);
        sb.append(')');
        return sb.toString();
    }
    
    public void writeToParcel(final Parcel parcel, final int n) {
        parcel.writeInt(this.a);
    }
    
    public static final class b
    {
        private b() {
        }
    }
}
