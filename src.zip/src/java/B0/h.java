package b0;

import v0.b1;
import F0.j;
import v0.P0;
import v0.x;
import v0.M0;
import D0.c;
import K8.M;
import F0.f;
import F0.b;
import L8.P;
import kotlin.jvm.internal.w;
import X8.a;
import v0.v;
import F0.i;
import F0.g;
import v0.p;
import v0.m;
import X8.q;

public abstract class H
{
    public static final void a(final q q, final m m, final int n) {
        final m v = m.v(674185128);
        int n3;
        if ((n & 0x6) == 0x0) {
            int n2;
            if (v.m((Object)q)) {
                n2 = 4;
            }
            else {
                n2 = 2;
            }
            n3 = (n2 | n);
        }
        else {
            n3 = n;
        }
        if ((n3 & 0x3) == 0x2 && v.y()) {
            v.G();
        }
        else {
            if (p.J()) {
                p.S(674185128, n3, -1, "androidx.compose.foundation.lazy.layout.LazySaveableStateHolderProvider (LazySaveableStateHolder.kt:41)");
            }
            final g g = (g)v.p((v)i.d());
            final j a = G.d.a(g);
            final boolean i = v.m((Object)g);
            final Object g2 = v.g();
            Object o;
            if (i || (o = g2) == m.a.a()) {
                o = new a(g) {
                    final g H;
                    
                    public final G a() {
                        return new G(this.H, P.j());
                    }
                };
                v.P(o);
            }
            final G g3 = (G)b.d(new Object[] { g }, a, (String)null, (a)o, v, 0, 4);
            x.a(F0.i.d().d((Object)g3), (X8.p)c.e(1863926504, true, (Object)new X8.p(g3, q) {
                final G H;
                final q L;
                
                public final void a(final m m, final int n) {
                    if ((n & 0x3) == 0x2 && m.y()) {
                        m.G();
                    }
                    else {
                        if (p.J()) {
                            p.S(1863926504, n, -1, "androidx.compose.foundation.lazy.layout.LazySaveableStateHolderProvider.<anonymous> (LazySaveableStateHolder.kt:49)");
                        }
                        this.H.i(f.a(m, 0));
                        this.L.invoke((Object)this.H, (Object)m, (Object)0);
                        if (p.J()) {
                            p.R();
                        }
                    }
                }
            }, v, 54), v, M0.i | 0x30);
            if (p.J()) {
                p.R();
            }
        }
        final b1 c = v.C();
        if (c != null) {
            c.a((X8.p)new X8.p(q, n) {
                final q H;
                final int L;
                
                public final void a(final m m, final int n) {
                    b0.H.a(this.H, m, P0.a(this.L | 0x1));
                }
            });
        }
    }
}
