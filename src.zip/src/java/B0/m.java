package b0;

import v0.v1;
import kotlin.jvm.internal.m;
import v0.t0;

public abstract class M
{
    public static final void a(final t0 t0) {
        t0.getValue();
    }
    
    public static t0 b(final t0 t0) {
        return t0;
    }
    
    public static final void d(final t0 t0) {
        t0.setValue((Object)K8.M.a);
    }
}
