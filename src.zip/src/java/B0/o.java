package b0;

public interface O
{
    boolean a(final P p0);
}
