package b0;

import D0.c;
import v0.Q;
import v0.L;
import v0.M;
import X8.l;
import v0.m;
import kotlin.jvm.internal.w;
import kotlin.jvm.internal.v;
import X8.p;
import java.util.LinkedHashMap;
import java.util.Map;
import X8.a;
import F0.d;

public final class r
{
    private final d a;
    private final X8.a b;
    private final Map c;
    
    public r(final d a, final X8.a b) {
        this.a = a;
        this.b = b;
        this.c = (Map)new LinkedHashMap();
    }
    
    public static final /* synthetic */ d a(final r r) {
        return r.a;
    }
    
    public final p b(final int n, final Object o, final Object o2) {
        final a a = (a)this.c.get(o);
        p p3;
        if (a != null && a.f() == n && v.e(a.e(), o2)) {
            p3 = a.d();
        }
        else {
            final a a2 = new a(n, o, o2);
            this.c.put(o, (Object)a2);
            p3 = a2.d();
        }
        return p3;
    }
    
    public final Object c(Object o) {
        final Object o2 = null;
        if (o == null) {
            return null;
        }
        final a a = (a)this.c.get(o);
        if (a != null) {
            o = a.e();
        }
        else {
            final t t = (t)this.b.invoke();
            final int d = t.d(o);
            o = o2;
            if (d != -1) {
                o = t.e(d);
            }
        }
        return o;
    }
    
    public final X8.a d() {
        return this.b;
    }
    
    private final class a
    {
        private final Object a;
        private final Object b;
        private int c;
        private p d;
        final r e;
        
        public a(final r e, final int c, final Object a, final Object b) {
            this.e = e;
            this.a = a;
            this.b = b;
            this.c = c;
        }
        
        public static final /* synthetic */ void a(final a a, final int c) {
            a.c = c;
        }
        
        public static final /* synthetic */ void b(final a a, final p d) {
            a.d = d;
        }
        
        private final p c() {
            return (p)D0.c.c(1403994769, true, (Object)new p(this.e, this) {
                final r H;
                final a L;
                
                public final void a(final m m, int n) {
                    if ((n & 0x3) == 0x2 && m.y()) {
                        m.G();
                    }
                    else {
                        if (v0.p.J()) {
                            v0.p.S(1403994769, n, -1, "androidx.compose.foundation.lazy.layout.LazyLayoutItemContentFactory.CachedItemContent.createContentLambda.<anonymous> (LazyLayoutItemContentFactory.kt:91)");
                        }
                        final t t = (t)this.H.d().invoke();
                        final int f = this.L.f();
                        while (true) {
                            Label_0108: {
                                if (f >= t.a()) {
                                    break Label_0108;
                                }
                                n = f;
                                if (!v.e(t.b(f), this.L.g())) {
                                    break Label_0108;
                                }
                                if (n != -1) {
                                    m.a0(-660479623);
                                    s.b(t, T.a(r.a(this.H)), n, T.a(this.L.g()), m, 0);
                                    m.O();
                                }
                                else {
                                    m.a0(-660272047);
                                    m.O();
                                }
                                final Object g = this.L.g();
                                final boolean i = m.m((Object)this.L);
                                final a l = this.L;
                                final Object g2 = m.g();
                                Object o;
                                if (i || (o = g2) == m.a.a()) {
                                    o = new l(l) {
                                        final a H;
                                        
                                        public final L a(final M m) {
                                            return (L)new L(this.H) {
                                                final a a;
                                                
                                                public void dispose() {
                                                    r.a.b(this.a, null);
                                                }
                                            };
                                        }
                                    };
                                    m.P(o);
                                }
                                Q.a(g, (l)o, m, 0);
                                if (v0.p.J()) {
                                    v0.p.R();
                                    return;
                                }
                                return;
                            }
                            final int d = t.d(this.L.g());
                            if ((n = d) != -1) {
                                r.a.a(this.L, d);
                                n = d;
                            }
                            continue;
                        }
                    }
                }
            });
        }
        
        public final p d() {
            p d;
            if ((d = this.d) == null) {
                d = this.c();
                this.d = d;
            }
            return d;
        }
        
        public final Object e() {
            return this.b;
        }
        
        public final int f() {
            return this.c;
        }
        
        public final Object g() {
            return this.a;
        }
    }
}
