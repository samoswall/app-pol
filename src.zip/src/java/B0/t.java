package b0;

abstract class T
{
    public static Object a(final Object o) {
        return o;
    }
}
