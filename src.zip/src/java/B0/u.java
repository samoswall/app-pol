package b0;

import kotlin.jvm.internal.v;

public abstract class u
{
    public static final int a(final t t, final Object o, final int n) {
        if (o != null) {
            if (t.a() != 0) {
                if (n < t.a() && v.e(o, t.b(n))) {
                    return n;
                }
                final int d = t.d(o);
                if (d != -1) {
                    return d;
                }
            }
        }
        return n;
    }
}
