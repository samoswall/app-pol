package b0;

import java.util.Iterator;
import e1.g0$a;
import java.util.LinkedHashMap;
import java.util.Map;
import e1.g0;

final class v implements g0
{
    private final r a;
    private final Map b;
    
    public v(final r a) {
        this.a = a;
        this.b = (Map)new LinkedHashMap();
    }
    
    @Override
    public void a(final g0$a g0$a) {
        this.b.clear();
        final Iterator iterator = g0$a.iterator();
        while (iterator.hasNext()) {
            final Object c = this.a.c(iterator.next());
            final Integer n = (Integer)this.b.get(c);
            int intValue;
            if (n != null) {
                intValue = n;
            }
            else {
                intValue = 0;
            }
            if (intValue == 7) {
                iterator.remove();
            }
            else {
                this.b.put(c, (Object)(intValue + 1));
            }
        }
    }
    
    @Override
    public boolean b(final Object o, final Object o2) {
        return kotlin.jvm.internal.v.e(this.a.c(o), this.a.c(o2));
    }
}
