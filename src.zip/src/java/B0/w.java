package b0;

import v0.b1;
import v0.P0;
import D0.c;
import v0.m$a;
import e1.d0;
import A1.b;
import e1.G;
import e1.f0;
import androidx.compose.foundation.lazy.layout.h;
import v0.L;
import v0.M;
import X8.l;
import e1.g0;
import e1.e0;
import v0.G1;
import X8.q;
import v0.v1;
import v0.m;
import X8.p;
import androidx.compose.foundation.lazy.layout.d;
import androidx.compose.ui.e;
import X8.a;

public abstract class w
{
    public static final void a(final a a, e a2, d d, final p p7, final m m, final int n, final int n2) {
        final m v = m.v(2002163445);
        int n3;
        if ((n2 & 0x1) != 0x0) {
            n3 = (n | 0x6);
        }
        else if ((n & 0x6) == 0x0) {
            int n4;
            if (v.m((Object)a)) {
                n4 = 4;
            }
            else {
                n4 = 2;
            }
            n3 = (n4 | n);
        }
        else {
            n3 = n;
        }
        final int n5 = n2 & 0x2;
        int n6;
        if (n5 != 0) {
            n6 = (n3 | 0x30);
        }
        else {
            n6 = n3;
            if ((n & 0x30) == 0x0) {
                int n7;
                if (v.Y((Object)a2)) {
                    n7 = 32;
                }
                else {
                    n7 = 16;
                }
                n6 = (n3 | n7);
            }
        }
        final int n8 = n2 & 0x4;
        int n9;
        if (n8 != 0) {
            n9 = (n6 | 0x180);
        }
        else {
            n9 = n6;
            if ((n & 0x180) == 0x0) {
                int n10;
                if (v.Y((Object)d)) {
                    n10 = 256;
                }
                else {
                    n10 = 128;
                }
                n9 = (n6 | n10);
            }
        }
        int n11;
        if ((n2 & 0x8) != 0x0) {
            n11 = (n9 | 0xC00);
        }
        else {
            n11 = n9;
            if ((n & 0xC00) == 0x0) {
                int n12;
                if (v.m((Object)p7)) {
                    n12 = 2048;
                }
                else {
                    n12 = 1024;
                }
                n11 = (n9 | n12);
            }
        }
        d d2;
        e e;
        if ((n11 & 0x493) == 0x492 && v.y()) {
            v.G();
            d2 = d;
            e = a2;
        }
        else {
            if (n5 != 0) {
                a2 = (e)androidx.compose.ui.e.a;
            }
            if (n8 != 0) {
                d = null;
            }
            if (v0.p.J()) {
                v0.p.S(2002163445, n11, -1, "androidx.compose.foundation.lazy.layout.LazyLayout (LazyLayout.kt:78)");
            }
            H.a((q)c.e(-1488997347, true, (Object)new q(d, a2, p7, v1.n((Object)a, v, n11 & 0xE)) {
                final d H;
                final e L;
                final p M;
                final G1 Q;
                
                public final void a(final F0.d d, final m m, final int n) {
                    if (v0.p.J()) {
                        v0.p.S(-1488997347, n, -1, "androidx.compose.foundation.lazy.layout.LazyLayout.<anonymous> (LazyLayout.kt:82)");
                    }
                    final G1 q = this.Q;
                    final Object g = m.g();
                    final m$a a = m.a;
                    r r;
                    if ((r = (r)g) == a.a()) {
                        r = new r(d, (a)new a(q) {
                            final G1 H;
                            
                            public final t a() {
                                return (t)((a)this.H.getValue()).invoke();
                            }
                        });
                        m.P((Object)r);
                    }
                    final r r2 = r;
                    Object g2;
                    if ((g2 = m.g()) == a.a()) {
                        g2 = new e0((g0)new v(r2));
                        m.P(g2);
                    }
                    final e0 e0 = (e0)g2;
                    if (this.H != null) {
                        m.a0(205264983);
                        Q q2 = this.H.d();
                        if (q2 == null) {
                            m.a0(6622915);
                            q2 = S.a(m, 0);
                        }
                        else {
                            m.a0(6621830);
                        }
                        m.O();
                        final d h = this.H;
                        final boolean y = m.Y((Object)this.H);
                        final boolean i = m.m((Object)r2);
                        final boolean j = m.m((Object)e0);
                        final boolean k = m.m((Object)q2);
                        final d h2 = this.H;
                        final Object g3 = m.g();
                        Object o;
                        if ((y | i | j | k) || (o = g3) == a.a()) {
                            o = new l(h2, r2, e0, q2) {
                                final d H;
                                final r L;
                                final e0 M;
                                final Q Q;
                                
                                public final L a(final M m) {
                                    this.H.f(new h(this.L, this.M, this.Q));
                                    return (L)new L(this.H) {
                                        final d a;
                                        
                                        public void dispose() {
                                            this.a.f((h)null);
                                        }
                                    };
                                }
                            };
                            m.P(o);
                        }
                        v0.Q.d(new Object[] { h, r2, e0, q2 }, (l)o, m, 0);
                        m.O();
                    }
                    else {
                        m.a0(205858881);
                        m.O();
                    }
                    final e b = androidx.compose.foundation.lazy.layout.e.b(this.L, this.H);
                    final boolean y2 = m.Y((Object)r2);
                    final boolean y3 = m.Y((Object)this.M);
                    final p l = this.M;
                    final Object g4 = m.g();
                    Object o2;
                    if ((y2 | y3) || (o2 = g4) == a.a()) {
                        o2 = new p(r2, l) {
                            final r H;
                            final p L;
                            
                            public final G a(final f0 f0, final long n) {
                                return (G)this.L.invoke((Object)new y(this.H, f0), (Object)A1.b.a(n));
                            }
                        };
                        m.P(o2);
                    }
                    d0.b(e0, b, (p)o2, m, e1.e0.f, 0);
                    if (v0.p.J()) {
                        v0.p.R();
                    }
                }
            }, v, 54), v, 6);
            e = a2;
            d2 = d;
            if (v0.p.J()) {
                v0.p.R();
                e = a2;
                d2 = d;
            }
        }
        final b1 c = v.C();
        if (c != null) {
            c.a((p)new p(a, e, d2, p7, n, n2) {
                final a H;
                final e L;
                final d M;
                final p Q;
                final int W;
                final int X;
                
                public final void a(final m m, final int n) {
                    w.a(this.H, this.L, this.M, this.Q, m, P0.a(this.W | 0x1), this.X);
                }
            });
        }
    }
}
