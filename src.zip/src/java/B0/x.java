package b0;

import java.util.List;
import e1.H;

public interface x extends H
{
    List E0(final int p0, final long p1);
    
    float v(final int p0);
}
