package b0;

import e1.o;
import A1.d;
import e1.G;
import X8.l;
import java.util.Map;
import e1.E;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import e1.f0;
import e1.H;

public final class y implements x, H
{
    private final r a;
    private final f0 b;
    private final t c;
    private final HashMap d;
    
    public y(final r a, final f0 b) {
        this.a = a;
        this.b = b;
        this.c = (t)a.d().invoke();
        this.d = new HashMap();
    }
    
    public float D1(final long n) {
        return ((d)this.b).D1(n);
    }
    
    @Override
    public List E0(final int n, final long n2) {
        Object o = this.d.get((Object)n);
        if (o == null) {
            final Object b = this.c.b(n);
            final List j1 = this.b.J1(b, this.a.b(n, b, this.c.e(n)));
            final int size = j1.size();
            o = new ArrayList(size);
            for (int i = 0; i < size; ++i) {
                ((ArrayList)o).add((Object)((E)j1.get(i)).e0(n2));
            }
            ((Map)this.d).put((Object)n, o);
        }
        return (List)o;
    }
    
    public float F0(final float n) {
        return ((d)this.b).F0(n);
    }
    
    public float P0() {
        return ((A1.l)this.b).P0();
    }
    
    @Override
    public boolean U0() {
        return ((o)this.b).U0();
    }
    
    public long V(final float n) {
        return ((A1.l)this.b).V(n);
    }
    
    public long W(final long n) {
        return ((d)this.b).W(n);
    }
    
    public float X0(final float n) {
        return ((d)this.b).X0(n);
    }
    
    @Override
    public G a0(final int n, final int n2, final Map map, final l l, final l i) {
        return ((H)this.b).a0(n, n2, map, l, i);
    }
    
    @Override
    public G c1(final int n, final int n2, final Map map, final l l) {
        return ((H)this.b).c1(n, n2, map, l);
    }
    
    public int g1(final long n) {
        return ((d)this.b).g1(n);
    }
    
    public float getDensity() {
        return ((d)this.b).getDensity();
    }
    
    @Override
    public A1.t getLayoutDirection() {
        return ((o)this.b).getLayoutDirection();
    }
    
    public float h0(final long n) {
        return ((A1.l)this.b).h0(n);
    }
    
    public int p1(final float n) {
        return ((d)this.b).p1(n);
    }
    
    @Override
    public float v(final int n) {
        return ((d)this.b).v(n);
    }
    
    public long w0(final float n) {
        return ((d)this.b).w0(n);
    }
    
    public long y1(final long n) {
        return ((d)this.b).y1(n);
    }
}
