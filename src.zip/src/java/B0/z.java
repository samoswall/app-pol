package b0;

public interface z
{
    int c();
    
    long d();
    
    void e(final boolean p0);
    
    int f();
    
    int g();
    
    int getIndex();
    
    Object getKey();
    
    Object h(final int p0);
    
    boolean i();
    
    long j(final int p0);
    
    int k();
    
    void n(final int p0, final int p1, final int p2, final int p3);
}
