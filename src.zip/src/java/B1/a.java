package b1;

public final class a
{
    private long a;
    private float b;
    
    public a(final long a, final float b) {
        this.a = a;
        this.b = b;
    }
    
    public final float a() {
        return this.b;
    }
    
    public final long b() {
        return this.a;
    }
    
    public final void c(final float b) {
        this.b = b;
    }
    
    public final void d(final long a) {
        this.a = a;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof a)) {
            return false;
        }
        final a a = (a)o;
        return this.a == a.a && Float.compare(this.b, a.b) == 0;
    }
    
    @Override
    public int hashCode() {
        return Long.hashCode(this.a) * 31 + Float.hashCode(this.b);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("DataPointAtTime(time=");
        sb.append(this.a);
        sb.append(", dataPoint=");
        sb.append(this.b);
        sb.append(')');
        return sb.toString();
    }
}
