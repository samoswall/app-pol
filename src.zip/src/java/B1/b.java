package b1;

import kotlin.jvm.internal.v;
import java.util.Arrays;
import a1.x;

public final class b
{
    private int a;
    private long[] b;
    
    public b() {
        this.b = new long[2];
    }
    
    public final boolean a(final long n) {
        if (!this.d(n)) {
            this.k(this.a, n);
            return true;
        }
        return false;
    }
    
    public final boolean b(final long n) {
        return this.a(n);
    }
    
    public final void c() {
        this.a = 0;
    }
    
    public final boolean d(final long n) {
        for (int a = this.a, i = 0; i < a; ++i) {
            if (this.b[i] == n) {
                return true;
            }
        }
        return false;
    }
    
    public final long e(final int n) {
        return x.b(this.b[n]);
    }
    
    public final int f() {
        return this.a;
    }
    
    public final boolean g() {
        return this.a == 0;
    }
    
    public final boolean h(final long n) {
        for (int a = this.a, i = 0; i < a; ++i) {
            if (n == this.e(i)) {
                this.j(i);
                return true;
            }
        }
        return false;
    }
    
    public final boolean i(final long n) {
        return this.h(n);
    }
    
    public final boolean j(int i) {
        final int a = this.a;
        if (i < a) {
            while (i < a - 1) {
                final long[] b = this.b;
                final int n = i + 1;
                b[i] = b[n];
                i = n;
            }
            --this.a;
            return true;
        }
        return false;
    }
    
    public final void k(final int n, final long n2) {
        final long[] b = this.b;
        if (n >= b.length) {
            final long[] copy = Arrays.copyOf(b, Math.max(n + 1, b.length * 2));
            v.i((Object)copy, "copyOf(this, newSize)");
            this.b = copy;
        }
        this.b[n] = n2;
        if (n >= this.a) {
            this.a = n + 1;
        }
    }
}
