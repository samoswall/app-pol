package b1;

import L8.l;
import d9.n;
import kotlin.jvm.internal.m;
import K8.s;

public final class c
{
    private final boolean a;
    private final a b;
    private final int c;
    private final b1.a[] d;
    private int e;
    private final float[] f;
    private final float[] g;
    private final float[] h;
    
    public c(final boolean a, final a b) {
        this.a = a;
        this.b = b;
        if (a && b.equals(b1.c.a.Lsq2)) {
            throw new IllegalStateException("Lsq2 not (yet) supported for differential axes");
        }
        final int n = b1.c.b.a[b.ordinal()];
        int c = 2;
        if (n != 1) {
            if (n != 2) {
                throw new s();
            }
            c = 3;
        }
        this.c = c;
        this.d = new b1.a[20];
        this.f = new float[20];
        this.g = new float[20];
        this.h = new float[3];
    }
    
    private final float b(final float[] array, final float[] array2, final int n) {
        float n2;
        try {
            n2 = b1.e.i(array2, array, n, 2, this.h)[1];
        }
        catch (final IllegalArgumentException ex) {
            n2 = 0.0f;
        }
        return n2;
    }
    
    public final void a(final long n, final float n2) {
        final int e = (this.e + 1) % 20;
        this.e = e;
        b1.e.b(this.d, e, n, n2);
    }
    
    public final float c() {
        final float[] f = this.f;
        final float[] g = this.g;
        int e = this.e;
        final b1.a a = this.d[e];
        if (a == null) {
            return 0.0f;
        }
        int n = 0;
        b1.a a2 = a;
        int n2;
        while (true) {
            final b1.a a3 = this.d[e];
            if (a3 == null) {
                n2 = n;
                break;
            }
            final float n3 = (float)(a.b() - a3.b());
            final float n4 = (float)Math.abs(a3.b() - a2.b());
            if (this.b != b1.c.a.Lsq2 && !this.a) {
                a2 = a;
            }
            else {
                a2 = a3;
            }
            n2 = n;
            if (n3 > 100.0f) {
                break;
            }
            if (n4 > 40.0f) {
                n2 = n;
                break;
            }
            f[n] = a3.a();
            g[n] = -n3;
            int n5;
            if ((n5 = e) == 0) {
                n5 = 20;
            }
            e = n5 - 1;
            if (++n >= 20) {
                n2 = n;
                break;
            }
        }
        if (n2 >= this.c) {
            final int n6 = b1.c.b.a[this.b.ordinal()];
            float n7;
            if (n6 != 1) {
                if (n6 != 2) {
                    throw new s();
                }
                n7 = this.b(f, g, n2);
            }
            else {
                n7 = b1.e.a(f, g, n2, this.a);
            }
            return n7 * 1000;
        }
        return 0.0f;
    }
    
    public final float d(float n) {
        final float n2 = 0.0f;
        if (n <= 0.0f) {
            final StringBuilder sb = new StringBuilder();
            sb.append("maximumVelocity should be a positive value. You specified=");
            sb.append(n);
            d1.a.b(sb.toString());
        }
        final float c = this.c();
        if (c == 0.0f) {
            n = n2;
        }
        else if (Float.isNaN(c)) {
            n = n2;
        }
        else if (c > 0.0f) {
            n = n.j(c, n);
        }
        else {
            n = n.e(c, -n);
        }
        return n;
    }
    
    public final void e() {
        l.z((Object[])this.d, (Object)null, 0, 0, 6, (Object)null);
        this.e = 0;
    }
    
    public enum a
    {
        private static final a[] $VALUES;
        
        Impulse, 
        Lsq2;
        
        private static final /* synthetic */ a[] $values() {
            return new a[] { a.Lsq2, a.Impulse };
        }
        
        static {
            $VALUES = $values();
        }
    }
}
