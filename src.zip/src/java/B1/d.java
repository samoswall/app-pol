package b1;

import A1.z;
import d1.a;
import A1.y;
import O0.g;
import kotlin.jvm.internal.m;

public final class d
{
    private final c.a a;
    private final c b;
    private final c c;
    private long d;
    private long e;
    
    public d() {
        c.a a;
        if (b1.e.h()) {
            a = b1.c.a.Impulse;
        }
        else {
            a = b1.c.a.Lsq2;
        }
        this.a = a;
        this.b = new c(false, a, 1, null);
        this.c = new c(false, a, 1, null);
        this.d = g.b.c();
    }
    
    public final void a(final long n, final long n2) {
        this.b.a(n, g.m(n2));
        this.c.a(n, g.n(n2));
    }
    
    public final long b(final long n) {
        if (y.h(n) <= 0.0f || y.i(n) <= 0.0f) {
            final StringBuilder sb = new StringBuilder();
            sb.append("maximumVelocity should be a positive value. You specified=");
            sb.append((Object)y.n(n));
            d1.a.b(sb.toString());
        }
        return z.a(this.b.d(y.h(n)), this.c.d(y.i(n)));
    }
    
    public final long c() {
        return this.d;
    }
    
    public final long d() {
        return this.e;
    }
    
    public final void e() {
        this.b.e();
        this.c.e();
        this.e = 0L;
    }
    
    public final void f(final long d) {
        this.d = d;
    }
    
    public final void g(final long e) {
        this.e = e;
    }
}
