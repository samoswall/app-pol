package b1;

import L8.l;
import java.util.List;
import O0.g;
import a1.n;
import a1.y;

public abstract class e
{
    private static boolean a = true;
    private static boolean b;
    
    public static final void c(final d d, final y y) {
        if (e.a) {
            e(d, y);
        }
        else {
            d(d, y);
        }
    }
    
    private static final void d(final d d, final y y) {
        if (n.b(y)) {
            d.f(y.h());
            d.e();
        }
        long n = y.k();
        final List e = y.e();
        for (int size = e.size(), i = 0; i < size; ++i) {
            final a1.e e2 = (a1.e)e.get(i);
            final long q = g.q(e2.b(), n);
            n = e2.b();
            d.f(g.r(d.c(), q));
            d.a(e2.c(), d.c());
        }
        d.f(g.r(d.c(), g.q(y.h(), n)));
        d.a(y.o(), d.c());
    }
    
    private static final void e(final d d, final y y) {
        if (n.b(y)) {
            d.e();
        }
        if (!n.d(y)) {
            final List e = y.e();
            for (int size = e.size(), i = 0; i < size; ++i) {
                final a1.e e2 = (a1.e)e.get(i);
                d.a(e2.c(), e2.a());
            }
            d.a(y.o(), y.g());
        }
        if (n.d(y) && y.o() - d.d() > 40L) {
            d.e();
        }
        d.g(y.o());
    }
    
    private static final float f(final float[] array, final float[] array2, int i, final boolean b) {
        final int n = i - 1;
        float n2 = array2[n];
        float n3 = 0.0f;
        int n4;
        float n5;
        float n6;
        float n7;
        float n8;
        for (i = n; i > 0; --i, n2 = n5) {
            n4 = i - 1;
            n5 = array2[n4];
            if (n2 != n5) {
                if (b) {
                    n6 = -array[n4];
                }
                else {
                    n6 = array[i] - array[n4];
                }
                n7 = n6 / (n2 - n5);
                n8 = (n3 += (n7 - Math.signum(n3) * (float)Math.sqrt((double)(2 * Math.abs(n3)))) * Math.abs(n7));
                if (i == n) {
                    n3 = n8 * 0.5f;
                }
            }
        }
        return Math.signum(n3) * (float)Math.sqrt((double)(2 * Math.abs(n3)));
    }
    
    private static final float g(final float[] array, final float[] array2) {
        final int length = array.length;
        float n = 0.0f;
        for (int i = 0; i < length; ++i) {
            n += array[i] * array2[i];
        }
        return n;
    }
    
    public static final boolean h() {
        return e.b;
    }
    
    public static final float[] i(final float[] array, final float[] array2, int n, int n2, final float[] array3) {
        final int n3 = n2;
        if (n3 < 1) {
            d1.a.a("The degree must be at positive integer");
        }
        if (n == 0) {
            d1.a.a("At least one point must be provided");
        }
        if ((n2 = n3) >= n) {
            n2 = n - 1;
        }
        final int n4 = n2 + 1;
        final float[][] array4 = new float[n4][];
        for (int i = 0; i < n4; ++i) {
            array4[i] = new float[n];
        }
        for (int j = 0; j < n; ++j) {
            array4[0][j] = 1.0f;
            for (int k = 1; k < n4; ++k) {
                array4[k][j] = array4[k - 1][j] * array[j];
            }
        }
        final float[][] array5 = new float[n4][];
        for (int l = 0; l < n4; ++l) {
            array5[l] = new float[n];
        }
        final float[][] array6 = new float[n4][];
        for (int n5 = 0; n5 < n4; ++n5) {
            array6[n5] = new float[n4];
        }
        for (int n6 = 0; n6 < n4; ++n6) {
            final float[] array7 = array5[n6];
            l.k(array4[n6], array7, 0, 0, n);
            for (final float[] array8 : array5) {
                final float g = g(array7, array8);
                for (int n8 = 0; n8 < n; ++n8) {
                    array7[n8] -= array8[n8] * g;
                }
            }
            float n9;
            if ((n9 = (float)Math.sqrt((double)g(array7, array7))) < 1.0E-6f) {
                n9 = 1.0E-6f;
            }
            final float n10 = 1.0f / n9;
            for (int n11 = 0; n11 < n; ++n11) {
                array7[n11] *= n10;
            }
            final float[] array9 = array6[n6];
            for (int n12 = 0; n12 < n4; ++n12) {
                float g2;
                if (n12 < n6) {
                    g2 = 0.0f;
                }
                else {
                    g2 = g(array7, array4[n12]);
                }
                array9[n12] = g2;
            }
        }
        float g3;
        float[] array10;
        int n13;
        float n14;
        int n15;
        for (n = n2; -1 < n; --n) {
            g3 = g(array5[n], array2);
            array10 = array6[n];
            n13 = n + 1;
            n14 = g3;
            if (n13 <= n2) {
                n15 = n2;
                while (true) {
                    g3 = (n14 = g3 - array10[n15] * array3[n15]);
                    if (n15 == n13) {
                        break;
                    }
                    --n15;
                }
            }
            array3[n] = n14 / array10[n];
        }
        return array3;
    }
    
    private static final void j(final a[] array, final int n, final long n2, final float n3) {
        final a a = array[n];
        if (a == null) {
            array[n] = new a(n2, n3);
        }
        else {
            a.d(n2);
            a.c(n3);
        }
    }
}
