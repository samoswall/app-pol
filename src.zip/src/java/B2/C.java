package b2;

public interface c
{
    void close();
}
