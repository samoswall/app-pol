package b2;

import kotlin.jvm.internal.m;
import kotlin.jvm.internal.v;
import java.io.IOException;

public final class d extends IOException
{
    public d(final String s, final Throwable t) {
        v.j((Object)s, "message");
        super(s, t);
    }
}
