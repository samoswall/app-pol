package b2;

public interface e
{
    Object a(final d p0, final P8.d p1);
}
