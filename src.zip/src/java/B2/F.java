package b2;

import kotlin.jvm.internal.m;

public final class f extends D
{
    private final Object b;
    private final int c;
    
    public f(final Object b, final int c, final int n) {
        super(n, null);
        this.b = b;
        this.c = c;
    }
    
    public final void b() {
        final Object b = this.b;
        int hashCode;
        if (b != null) {
            hashCode = b.hashCode();
        }
        else {
            hashCode = 0;
        }
        if (hashCode == this.c) {
            return;
        }
        throw new IllegalStateException("Data in DataStore was mutated but DataStore is only compatible with Immutable types.");
    }
    
    public final Object c() {
        return this.b;
    }
}
