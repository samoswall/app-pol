package b2;

public interface g
{
}
