package b2;

import kotlin.jvm.internal.S;
import K8.M;
import X8.p;
import java.util.ArrayList;
import X8.l;
import K8.g;
import kotlin.jvm.internal.v;
import K8.x;
import java.util.Iterator;
import Q8.b;
import P8.d;
import java.util.List;
import kotlin.jvm.internal.m;

public abstract class h
{
    public static final a a;
    
    static {
        a = new a(null);
    }
    
    public static final class a
    {
        private a() {
        }
        
        private final Object c(List o, final s s, final d d) {
            Object o2 = null;
            Label_0054: {
                if (d instanceof h$a$b) {
                    final kotlin.coroutines.jvm.internal.d d2 = (h$a$b)d;
                    final int c = d2.C;
                    if ((c & Integer.MIN_VALUE) != 0x0) {
                        d2.C = c + Integer.MIN_VALUE;
                        o2 = d2;
                        break Label_0054;
                    }
                }
                o2 = new kotlin.coroutines.jvm.internal.d(this, d) {
                    Object A;
                    final a B;
                    int C;
                    Object y;
                    Object z;
                    
                    public final Object invokeSuspend(final Object a) {
                        this.A = a;
                        this.C |= Integer.MIN_VALUE;
                        return this.B.c(null, null, (d)this);
                    }
                };
            }
            final Object a = ((h$a$b)o2).A;
            final Object f = b.f();
            final int c2 = ((h$a$b)o2).C;
            Object y = null;
        Label_0368:
            while (true) {
                Label_0151: {
                    if (c2 == 0) {
                        break Label_0151;
                    }
                    Label_0135: {
                        if (c2 == 1) {
                            break Label_0135;
                        }
                        Label_0125: {
                            if (c2 != 2) {
                                break Label_0125;
                            }
                            Iterator iterator = (Iterator)((h$a$b)o2).z;
                            y = ((h$a$b)o2).y;
                            final kotlin.coroutines.jvm.internal.d d3 = (kotlin.coroutines.jvm.internal.d)o2;
                            final Iterator iterator2 = iterator;
                            final S s2 = (S)y;
                            try {
                                x.b(a);
                                break Label_0225;
                            }
                            finally {
                                final Object a2 = s2.a;
                                if (a2 == null) {
                                    final Throwable a3;
                                    s2.a = a3;
                                    o2 = d3;
                                    iterator = iterator2;
                                    y = s2;
                                }
                                else {
                                    v.g(a2);
                                    final Throwable a3;
                                    g.a((Throwable)a2, a3);
                                    o2 = d3;
                                    iterator = iterator2;
                                    y = s2;
                                }
                                while (iterator.hasNext()) {
                                    final l l = (l)iterator.next();
                                    ((h$a$b)o2).y = y;
                                    ((h$a$b)o2).z = iterator;
                                    ((h$a$b)o2).C = 2;
                                    if (l.invoke(o2) == f) {
                                        return f;
                                    }
                                }
                                break Label_0368;
                                Label_0204: {
                                    final Object y2;
                                    o = y2;
                                }
                                Label_0207: {
                                    break Label_0207;
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    x.b(a);
                                    final Object y2 = new ArrayList();
                                    final p p3 = (p)new p(o, y2, null) {
                                        Object A;
                                        int B;
                                        Object C;
                                        final List H;
                                        final List L;
                                        Object y;
                                        Object z;
                                        
                                        public final d create(final Object c, final d d) {
                                            final p p2 = (p)new p(this.H, this.L, d) {
                                                Object A;
                                                int B;
                                                Object C;
                                                final List H;
                                                final List L;
                                                Object y;
                                                Object z;
                                            };
                                            p2.C = c;
                                            return (d)p2;
                                        }
                                        
                                        public final Object invoke(final Object o, final d d) {
                                            return ((h$a$c)this.create(o, d)).invokeSuspend(M.a);
                                        }
                                        
                                        public final Object invokeSuspend(Object c) {
                                            b.f();
                                            final int b = this.B;
                                            Iterator iterator;
                                            List l;
                                            if (b != 0) {
                                                if (b != 1) {
                                                    if (b != 2) {
                                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                                    }
                                                    iterator = (Iterator)this.y;
                                                    l = (List)this.C;
                                                    x.b(c);
                                                }
                                                else {
                                                    final Object a = this.A;
                                                    androidx.appcompat.app.v.a(this.z);
                                                    iterator = (Iterator)this.y;
                                                    l = (List)this.C;
                                                    x.b(c);
                                                    if (c) {
                                                        l.add((Object)new l(null, null) {
                                                            int y;
                                                            
                                                            public final d create(final d d) {
                                                                return (d)new l(null, d) {
                                                                    int y;
                                                                };
                                                            }
                                                            
                                                            public final Object f(final d d) {
                                                                return ((h$a$c$a)this.create(d)).invokeSuspend(M.a);
                                                            }
                                                            
                                                            public final Object invokeSuspend(final Object o) {
                                                                Q8.b.f();
                                                                final int y = this.y;
                                                                if (y == 0) {
                                                                    x.b(o);
                                                                    this.y = 1;
                                                                    throw null;
                                                                }
                                                                if (y == 1) {
                                                                    x.b(o);
                                                                    return M.a;
                                                                }
                                                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                                            }
                                                        });
                                                        this.C = l;
                                                        this.y = iterator;
                                                        this.z = null;
                                                        this.A = null;
                                                        this.B = 2;
                                                        throw null;
                                                    }
                                                    c = a;
                                                }
                                            }
                                            else {
                                                x.b(c);
                                                c = this.C;
                                                final Iterable iterable = (Iterable)this.H;
                                                l = this.L;
                                                iterator = iterable.iterator();
                                            }
                                            if (!iterator.hasNext()) {
                                                return c;
                                            }
                                            androidx.appcompat.app.v.a(iterator.next());
                                            this.C = l;
                                            this.y = iterator;
                                            this.z = null;
                                            this.A = c;
                                            this.B = 1;
                                            throw null;
                                        }
                                    };
                                    ((h$a$b)o2).y = y2;
                                    ((h$a$b)o2).C = 1;
                                    iftrue(Label_0204:)(s.a((p)p3, (d)o2) != f);
                                    return f;
                                    o = ((h$a$b)o2).y;
                                    x.b(a);
                                }
                                y = new S();
                                iterator = ((Iterable)o).iterator();
                                continue;
                            }
                        }
                    }
                }
                continue;
            }
            final Throwable t = (Throwable)((S)y).a;
            if (t == null) {
                return M.a;
            }
            throw t;
        }
        
        public final p b(final List list) {
            v.j((Object)list, "migrations");
            return (p)new p(list, null) {
                final List A;
                int y;
                Object z;
                
                public final d create(final Object z, final d d) {
                    final p p2 = (p)new p(this.A, d) {
                        final List A;
                        int y;
                        Object z;
                    };
                    p2.z = z;
                    return (d)p2;
                }
                
                public final Object f(final s s, final d d) {
                    return ((h$a$a)this.create(s, d)).invokeSuspend(M.a);
                }
                
                public final Object invokeSuspend(final Object o) {
                    final Object f = b.f();
                    final int y = this.y;
                    if (y != 0) {
                        if (y != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        x.b(o);
                    }
                    else {
                        x.b(o);
                        final s s = (s)this.z;
                        final a a = h.a;
                        final List a2 = this.A;
                        this.y = 1;
                        if (a.c(a2, s, (d)this) == f) {
                            return f;
                        }
                    }
                    return M.a;
                }
            };
        }
    }
}
