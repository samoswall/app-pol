package b2;

import l9.g;
import P8.d;
import X8.p;

public interface i
{
    Object a(final p p0, final d p1);
    
    g getData();
}
