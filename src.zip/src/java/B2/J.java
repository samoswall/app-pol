package b2;

import kotlin.jvm.internal.m;
import X8.l;
import kotlin.jvm.internal.v;
import i9.N;
import P8.g;
import i9.z0;
import i9.W0;
import i9.c0;
import L8.t;
import X8.a;
import i9.M;
import java.util.List;
import c2.b;

public final class j
{
    public static final j a;
    
    static {
        a = new j();
    }
    
    private j() {
    }
    
    public final i a(final A a, final b b, final List list, final M m, final a a2) {
        v.j((Object)a, "serializer");
        v.j((Object)list, "migrations");
        v.j((Object)m, "scope");
        v.j((Object)a2, "produceFile");
        return this.b(new o(a, null, a2, 2, null), b, list, m);
    }
    
    public final i b(final E e, b b, final List list, final M m) {
        v.j((Object)e, "storage");
        v.j((Object)list, "migrations");
        v.j((Object)m, "scope");
        if (b == null) {
            b = (b)new c2.a();
        }
        return new k(e, t.e((Object)h.a.b(list)), b, m);
    }
}
