package b2;

import i9.U;
import r9.c;
import java.util.Iterator;
import P8.g$c;
import kotlin.jvm.internal.P;
import kotlin.jvm.internal.S;
import K8.u;
import K8.w$a;
import i9.z;
import h9.a$a;
import l9.H$a;
import K8.o;
import kotlin.jvm.internal.w;
import java.util.concurrent.CancellationException;
import i9.z0$a;
import X8.q;
import i9.z0;
import K8.j;
import i9.O;
import K8.s;
import l9.I;
import h9.a;
import l9.H;
import K8.x;
import Q8.b;
import l9.h;
import P8.d;
import X8.p;
import kotlin.jvm.internal.v;
import java.util.List;
import kotlin.jvm.internal.m;
import K8.n;
import l9.g;
import l9.B;
import i9.M;

public final class k implements i
{
    public static final a l;
    private final E a;
    private final e b;
    private final M c;
    private final B d;
    private final g e;
    private final g f;
    private final l g;
    private final b h;
    private final n i;
    private final n j;
    private final b2.B k;
    
    static {
        l = new a(null);
    }
    
    public k(final E a, final List list, final e b, final M c) {
        v.j((Object)a, "storage");
        v.j((Object)list, "initTasksList");
        v.j((Object)b, "corruptionHandler");
        v.j((Object)c, "scope");
        this.a = a;
        this.b = b;
        this.c = c;
        final g x = l9.i.x((p)new p(this, null) {
            int y;
            final k z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.z, d) {
                    int y;
                    final k z;
                };
            }
            
            public final Object invoke(final h h, final d d) {
                return ((k$r)this.create(h, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(Object o) {
                final Object f = Q8.b.f();
                final int y = this.y;
                if (y != 0) {
                    if (y != 1) {
                        if (y == 2) {
                            K8.x.b(o);
                            return K8.M.a;
                        }
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    else {
                        K8.x.b(o);
                    }
                }
                else {
                    K8.x.b(o);
                    final b e = b2.k.e(this.z);
                    this.y = 1;
                    if (e.a((d)this) == f) {
                        return f;
                    }
                }
                final g l = l9.i.l(this.z.q().d());
                o = new h(this.z) {
                    final k a;
                    
                    public final Object b(final K8.M m, final d d) {
                        if (b2.k.c(this.a).a() instanceof r) {
                            return K8.M.a;
                        }
                        final Object l = this.a.u(true, d);
                        if (l == Q8.b.f()) {
                            return l;
                        }
                        return K8.M.a;
                    }
                };
                this.y = 2;
                if (l.collect((h)o, (d)this) == f) {
                    return f;
                }
                return K8.M.a;
            }
        });
        final H$a a2 = H.a;
        final a$a b2 = h9.a.b;
        this.d = l9.i.I(x, c, I.a(a2, b2.b(), b2.b()), 0);
        this.e = l9.i.x((p)new p(this, null) {
            private Object A;
            final k B;
            Object y;
            int z;
            
            public final d create(final Object a, final d d) {
                final p p2 = (p)new p(this.B, d) {
                    private Object A;
                    final k B;
                    Object y;
                    int z;
                };
                p2.A = a;
                return (d)p2;
            }
            
            public final Object invoke(final h h, final d d) {
                return ((k$g)this.create(h, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(Object o) {
                final Object f = Q8.b.f();
                final int z = this.z;
                h h3 = null;
                D d2 = null;
                Label_0228: {
                    D d = null;
                    h h2 = null;
                    Label_0192: {
                        if (z != 0) {
                            if (z != 1) {
                                if (z == 2) {
                                    d = (D)this.y;
                                    final h h = (h)this.A;
                                    K8.x.b(o);
                                    h2 = h;
                                    break Label_0192;
                                }
                                if (z == 3) {
                                    K8.x.b(o);
                                    return K8.M.a;
                                }
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            else {
                                h3 = (h)this.A;
                                K8.x.b(o);
                            }
                        }
                        else {
                            K8.x.b(o);
                            h3 = (h)this.A;
                            final k b = this.B;
                            this.A = h3;
                            this.z = 1;
                            o = b.x(false, (d)this);
                            if (o == f) {
                                return f;
                            }
                        }
                        final D y = (D)o;
                        if (y instanceof f) {
                            final Object c = ((f)y).c();
                            this.A = h3;
                            this.y = y;
                            this.z = 2;
                            if (h3.emit(c, (d)this) == f) {
                                return f;
                            }
                            final f f2 = (f)y;
                            h2 = h3;
                            d = f2;
                        }
                        else {
                            if (y instanceof b2.H) {
                                throw new IllegalStateException("This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542");
                            }
                            if (y instanceof b2.x) {
                                throw ((b2.x)y).b();
                            }
                            d2 = y;
                            if (y instanceof r) {
                                return K8.M.a;
                            }
                            break Label_0228;
                        }
                    }
                    d2 = d;
                    h3 = h2;
                }
                o = new g(l9.i.p(l9.i.L(b2.k.c(this.B).b(), (p)new p(null) {
                    int y;
                    Object z;
                    
                    public final d create(final Object z, final d d) {
                        final p p2 = (p)new p(d) {
                            int y;
                            Object z;
                        };
                        p2.z = z;
                        return (d)p2;
                    }
                    
                    public final Object f(final D d, final d d2) {
                        return ((k$g$a)this.create(d, d2)).invokeSuspend(K8.M.a);
                    }
                    
                    public final Object invokeSuspend(final Object o) {
                        Q8.b.f();
                        if (this.y == 0) {
                            K8.x.b(o);
                            return kotlin.coroutines.jvm.internal.b.a(((D)this.z) instanceof r ^ true);
                        }
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }), (p)new p(d2, null) {
                    final D A;
                    int y;
                    Object z;
                    
                    public final d create(final Object z, final d d) {
                        final p p2 = (p)new p(this.A, d) {
                            final D A;
                            int y;
                            Object z;
                        };
                        p2.z = z;
                        return (d)p2;
                    }
                    
                    public final Object f(final D d, final d d2) {
                        return ((k$g$b)this.create(d, d2)).invokeSuspend(K8.M.a);
                    }
                    
                    public final Object invokeSuspend(final Object o) {
                        Q8.b.f();
                        if (this.y == 0) {
                            K8.x.b(o);
                            final D d = (D)this.z;
                            return kotlin.coroutines.jvm.internal.b.a(d instanceof f && d.a() <= this.A.a());
                        }
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                })) {
                    final g a;
                    
                    public Object collect(final h h, final d d) {
                        final Object collect = this.a.collect((h)new h(h) {
                            final h a;
                            
                            public final Object emit(Object c, final d d) {
                                kotlin.coroutines.jvm.internal.d d3 = null;
                                Label_0051: {
                                    if (d instanceof k$g$c$a$a) {
                                        final kotlin.coroutines.jvm.internal.d d2 = (k$g$c$a$a)d;
                                        final int z = d2.z;
                                        if ((z & Integer.MIN_VALUE) != 0x0) {
                                            d2.z = z + Integer.MIN_VALUE;
                                            d3 = d2;
                                            break Label_0051;
                                        }
                                    }
                                    d3 = new kotlin.coroutines.jvm.internal.d(this, d) {
                                        final k$g$c$a A;
                                        Object y;
                                        int z;
                                        
                                        public final Object invokeSuspend(final Object y) {
                                            this.y = y;
                                            this.z |= Integer.MIN_VALUE;
                                            return this.A.emit(null, (d)this);
                                        }
                                    };
                                }
                                final Object y = d3.y;
                                final Object f = Q8.b.f();
                                final int z2 = d3.z;
                                boolean b = true;
                                if (z2 != 0) {
                                    if (z2 != 1) {
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                    K8.x.b(y);
                                }
                                else {
                                    K8.x.b(y);
                                    final h a = this.a;
                                    final D d4 = (D)c;
                                    if (d4 instanceof b2.x) {
                                        throw ((b2.x)d4).b();
                                    }
                                    if (d4 instanceof f) {
                                        c = ((f)d4).c();
                                        d3.z = 1;
                                        if (a.emit(c, (d)d3) == f) {
                                            return f;
                                        }
                                    }
                                    else {
                                        if (!(d4 instanceof r)) {
                                            b = (d4 instanceof b2.H);
                                        }
                                        if (b) {
                                            throw new IllegalStateException("This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542");
                                        }
                                        throw new s();
                                    }
                                }
                                return K8.M.a;
                            }
                        }, d);
                        if (collect == Q8.b.f()) {
                            return collect;
                        }
                        return K8.M.a;
                    }
                };
                this.A = null;
                this.y = null;
                this.z = 3;
                if (l9.i.r(h3, (g)o, (d)this) == f) {
                    return f;
                }
                return K8.M.a;
            }
        });
        this.f = l9.i.h((p)new p(this, null) {
            final k A;
            int y;
            private Object z;
            
            public final d create(final Object z, final d d) {
                final p p2 = (p)new p(this.A, d) {
                    final k A;
                    int y;
                    private Object z;
                };
                p2.z = z;
                return (d)p2;
            }
            
            public final Object invoke(final k9.r r, final d d) {
                return ((k$d)this.create(r, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(final Object o) {
                final Object f = Q8.b.f();
                final int y = this.y;
                if (y != 0) {
                    if (y != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    K8.x.b(o);
                }
                else {
                    K8.x.b(o);
                    final k9.r r = (k9.r)this.z;
                    final z0 d = i9.i.d((M)r, (P8.g)null, O.LAZY, (p)new p(this.A, null) {
                        int y;
                        final k z;
                        
                        public final d create(final Object o, final d d) {
                            return (d)new p(this.z, d) {
                                int y;
                                final k z;
                            };
                        }
                        
                        public final Object invoke(final M m, final d d) {
                            return ((k$d$d)this.create(m, d)).invokeSuspend(K8.M.a);
                        }
                        
                        public final Object invokeSuspend(final Object o) {
                            final Object f = Q8.b.f();
                            final int y = this.y;
                            if (y != 0) {
                                if (y != 1) {
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                K8.x.b(o);
                            }
                            else {
                                K8.x.b(o);
                                final B h = b2.k.h(this.z);
                                final h a = (h)k$d$d$a.a;
                                this.y = 1;
                                if (h.collect((h)a, (d)this) == f) {
                                    return f;
                                }
                            }
                            throw new j();
                        }
                    }, 1, (Object)null);
                    final g d2 = l9.i.D(l9.i.F(b2.k.d(this.A), (p)new p(d, null) {
                        int y;
                        final z0 z;
                        
                        public final d create(final Object o, final d d) {
                            return (d)new p(this.z, d) {
                                int y;
                                final z0 z;
                            };
                        }
                        
                        public final Object invoke(final h h, final d d) {
                            return ((k$d$a)this.create(h, d)).invokeSuspend(K8.M.a);
                        }
                        
                        public final Object invokeSuspend(final Object o) {
                            Q8.b.f();
                            if (this.y == 0) {
                                K8.x.b(o);
                                this.z.start();
                                return K8.M.a;
                            }
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }), (q)new q(d, null) {
                        int y;
                        final z0 z;
                        
                        public final Object invoke(final h h, final Throwable t, final d d) {
                            return new q(this.z, d) {
                                int y;
                                final z0 z;
                            }.invokeSuspend(K8.M.a);
                        }
                        
                        public final Object invokeSuspend(final Object o) {
                            Q8.b.f();
                            if (this.y == 0) {
                                K8.x.b(o);
                                z0$a.b(this.z, (CancellationException)null, 1, (Object)null);
                                return K8.M.a;
                            }
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    });
                    final h h = (h)new h(r) {
                        final k9.r a;
                        
                        public final Object emit(Object k, final d d) {
                            k = ((k9.u)this.a).k(k, d);
                            if (k == Q8.b.f()) {
                                return k;
                            }
                            return K8.M.a;
                        }
                    };
                    this.y = 1;
                    if (d2.collect((h)h, (d)this) == f) {
                        return f;
                    }
                }
                return K8.M.a;
            }
        });
        this.g = new l();
        this.h = new b(list);
        this.i = o.b((X8.a)new X8.a(this) {
            final k H;
            
            public final F a() {
                return b2.k.f(this.H).a();
            }
        });
        this.j = o.b((X8.a)new X8.a(this) {
            final k H;
            
            public final t a() {
                return this.H.r().c();
            }
        });
        this.k = new b2.B(c, (X8.l)new X8.l(this) {
            final k H;
            
            public final void invoke(final Throwable t) {
                if (t != null) {
                    b2.k.c(this.H).c(new r(t));
                }
                if (b2.k.g(this.H).a()) {
                    this.H.r().close();
                }
            }
        }, (p)k$u.H, (p)new p(this, null) {
            final k A;
            int y;
            Object z;
            
            public final d create(final Object z, final d d) {
                final p p2 = (p)new p(this.A, d) {
                    final k A;
                    int y;
                    Object z;
                };
                p2.z = z;
                return (d)p2;
            }
            
            public final Object f(final b2.w.a a, final d d) {
                return ((k$v)this.create(a, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(final Object o) {
                final Object f = Q8.b.f();
                final int y = this.y;
                if (y != 0) {
                    if (y != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    K8.x.b(o);
                }
                else {
                    K8.x.b(o);
                    final b2.w.a a = (b2.w.a)this.z;
                    final k a2 = this.A;
                    this.y = 1;
                    if (a2.s(a, (d)this) == f) {
                        return f;
                    }
                }
                return K8.M.a;
            }
        });
    }
    
    public static final /* synthetic */ l c(final k k) {
        return k.g;
    }
    
    public static final /* synthetic */ g d(final k k) {
        return k.e;
    }
    
    public static final /* synthetic */ b e(final k k) {
        return k.h;
    }
    
    public static final /* synthetic */ E f(final k k) {
        return k.a;
    }
    
    public static final /* synthetic */ n g(final k k) {
        return k.i;
    }
    
    public static final /* synthetic */ B h(final k k) {
        return k.d;
    }
    
    public static final /* synthetic */ b2.B i(final k k) {
        return k.k;
    }
    
    private final Object p(final boolean b, final X8.l l, final d d) {
        if (b) {
            return l.invoke((Object)d);
        }
        return this.q().a((X8.l)new X8.l(l, null) {
            int y;
            final X8.l z;
            
            public final d create(final d d) {
                return (d)new X8.l(this.z, d) {
                    int y;
                    final X8.l z;
                };
            }
            
            public final Object f(final d d) {
                return ((k$e)this.create(d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(Object invoke) {
                final Object f = Q8.b.f();
                final int y = this.y;
                if (y != 0) {
                    if (y != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    x.b(invoke);
                }
                else {
                    x.b(invoke);
                    final X8.l z = this.z;
                    this.y = 1;
                    if ((invoke = z.invoke((Object)this)) == f) {
                        return f;
                    }
                }
                return invoke;
            }
        }, d);
    }
    
    private final t q() {
        return (t)this.j.getValue();
    }
    
    private final Object s(b2.w.a y, d d) {
        Object o = null;
        Label_0051: {
            if (d instanceof k$f) {
                o = d;
                final int h = ((k$f)o).H;
                if ((h & Integer.MIN_VALUE) != 0x0) {
                    ((k$f)o).H = h + Integer.MIN_VALUE;
                    break Label_0051;
                }
            }
            o = new kotlin.coroutines.jvm.internal.d(this, d) {
                Object A;
                Object B;
                final k C;
                int H;
                Object y;
                Object z;
                
                public final Object invokeSuspend(final Object b) {
                    this.B = b;
                    this.H |= Integer.MIN_VALUE;
                    return this.C.s(null, (d)this);
                }
            };
        }
        final Object b = ((k$f)o).B;
        final Object f = Q8.b.f();
        final int h2 = ((k$f)o).H;
        boolean b2 = true;
        Object b4 = null;
        Label_0579: {
            final Throwable a;
            Label_0566: {
                while (true) {
                    Object o2 = null;
                    Object o3 = null;
                    Object y2 = null;
                    Label_0406: {
                        if (h2 != 0) {
                            if (h2 != 1) {
                                if (h2 == 2) {
                                    final i9.x x = (i9.x)((k$f)o).A;
                                    o2 = ((k$f)o).z;
                                    o3 = ((k$f)o).y;
                                    K8.x.b(b);
                                    y2 = x;
                                    break Label_0406;
                                }
                                if (h2 != 3) {
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                d = (d)((k$f)o).y;
                            }
                            else {
                                d = (d)((k$f)o).y;
                            }
                            y = (b2.w.a)d;
                            Label_0484: {
                                try {
                                    x.b(b);
                                    break Label_0484;
                                }
                                finally {
                                    break Label_0566;
                                }
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            final Object b3 = K8.w.b((Object)a);
                            y = (b2.w.a)d;
                            b4 = b3;
                            break Label_0579;
                        }
                        x.b(b);
                        final d y3 = d = (d)y.a();
                        try {
                            o2 = K8.w.b;
                            d = y3;
                            o2 = this.g.a();
                            d = y3;
                            if (o2 instanceof f) {
                                d = y3;
                                o2 = y.d();
                                d = y3;
                                final P8.g b5 = y.b();
                                d = y3;
                                ((k$f)o).y = y3;
                                d = y3;
                                ((k$f)o).H = 1;
                                d = y3;
                                o = (d = (d)this.y((p)o2, b5, (d)o));
                                y2 = y3;
                                if (o == f) {
                                    return f;
                                }
                            }
                        }
                        finally {
                            y = (b2.w.a)d;
                            break Label_0566;
                        }
                        if (!(o2 instanceof b2.x)) {
                            b2 = (o2 instanceof b2.H);
                        }
                        if (b2) {
                            if (o2 != y.c()) {
                                v.h(o2, "null cannot be cast to non-null type androidx.datastore.core.ReadException<T of androidx.datastore.core.DataStoreImpl.handleUpdate$lambda$0>");
                                throw ((b2.x)o2).b();
                            }
                            ((k$f)o).y = y;
                            ((k$f)o).z = this;
                            ((k$f)o).A = a;
                            ((k$f)o).H = 2;
                            o2 = this;
                            o3 = y;
                            y2 = a;
                            if (this.t((d)o) == f) {
                                return f;
                            }
                        }
                        else {
                            if (o2 instanceof r) {
                                throw ((r)o2).b();
                            }
                            throw new s();
                        }
                    }
                    final p d2 = ((b2.w.a)o3).d();
                    final P8.g b6 = ((b2.w.a)o3).b();
                    ((k$f)o).y = y2;
                    ((k$f)o).z = null;
                    ((k$f)o).A = null;
                    ((k$f)o).H = 3;
                    if ((d = (d)((k)o2).y(d2, b6, (d)o)) == f) {
                        return f;
                    }
                    continue;
                }
            }
            final w$a b7 = K8.w.b;
            b4 = K8.w.b(x.a(a));
        }
        z.c((i9.x)y, b4);
        return K8.M.a;
    }
    
    private final Object t(d y) {
        Object o = null;
        Label_0047: {
            if (y instanceof k$h) {
                o = y;
                final int c = ((k$h)o).C;
                if ((c & Integer.MIN_VALUE) != 0x0) {
                    ((k$h)o).C = c + Integer.MIN_VALUE;
                    break Label_0047;
                }
            }
            o = new kotlin.coroutines.jvm.internal.d(this, y) {
                Object A;
                final k B;
                int C;
                Object y;
                int z;
                
                public final Object invokeSuspend(final Object a) {
                    this.A = a;
                    this.C |= Integer.MIN_VALUE;
                    return this.B.t((d)this);
                }
            };
        }
        Object a = ((k$h)o).A;
        final Object f = Q8.b.f();
        final int c2 = ((k$h)o).C;
        int z = 0;
        Label_0220: {
            if (c2 != 0) {
                if (c2 != 1) {
                    if (c2 == 2) {
                        z = ((k$h)o).z;
                        y = (d)((k$h)o).y;
                        try {
                            x.b(a);
                            break Label_0220;
                        }
                        finally {
                            break Label_0220;
                        }
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                y = (d)((k$h)o).y;
                x.b(a);
            }
            else {
                x.b(a);
                final t q = this.q();
                ((k$h)o).y = this;
                ((k$h)o).C = 1;
                final Object c3 = q.c((d)o);
                y = (d)this;
                if ((a = c3) == f) {
                    return f;
                }
            }
            z = ((Number)a).intValue();
            try {
                final b h = ((k)y).h;
                ((k$h)o).y = y;
                ((k$h)o).z = z;
                ((k$h)o).C = 2;
                if (h.c((d)o) == f) {
                    return f;
                }
                return K8.M.a;
            }
            finally {}
        }
        final Throwable t;
        ((k)y).g.c(new b2.x(t, z));
        throw t;
    }
    
    private final Object u(boolean a, final d d) {
        kotlin.coroutines.jvm.internal.d d2 = null;
        Label_0051: {
            if (d instanceof k$i) {
                d2 = (k$i)d;
                final int h = d2.H;
                if ((h & Integer.MIN_VALUE) != 0x0) {
                    d2.H = h + Integer.MIN_VALUE;
                    break Label_0051;
                }
            }
            d2 = new kotlin.coroutines.jvm.internal.d(this, d) {
                boolean A;
                Object B;
                final k C;
                int H;
                Object y;
                Object z;
                
                public final Object invokeSuspend(final Object b) {
                    this.B = b;
                    this.H |= Integer.MIN_VALUE;
                    return this.C.u(false, (d)this);
                }
            };
        }
        Object o = d2.B;
        final Object f = Q8.b.f();
        final int h2 = d2.H;
        k k = null;
        u u = null;
        Label_0425: {
            Label_0418: {
                Label_0349: {
                    D a2;
                    if (h2 != 0) {
                        if (h2 != 1) {
                            if (h2 == 2) {
                                k = (k)d2.y;
                                x.b(o);
                                break Label_0349;
                            }
                            if (h2 == 3) {
                                k = (k)d2.y;
                                x.b(o);
                                break Label_0418;
                            }
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        else {
                            a = d2.A;
                            a2 = (D)d2.z;
                            k = (k)d2.y;
                            x.b(o);
                        }
                    }
                    else {
                        x.b(o);
                        a2 = this.g.a();
                        if (a2 instanceof b2.H) {
                            throw new IllegalStateException("This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542");
                        }
                        final t q = this.q();
                        d2.y = this;
                        d2.z = a2;
                        d2.A = a;
                        d2.H = 1;
                        o = q.c((d)d2);
                        if (o == f) {
                            return f;
                        }
                        k = this;
                    }
                    final int intValue = ((Number)o).intValue();
                    final boolean b = a2 instanceof f;
                    int a3;
                    if (b) {
                        a3 = a2.a();
                    }
                    else {
                        a3 = -1;
                    }
                    if (b && intValue == a3) {
                        return a2;
                    }
                    if (a) {
                        final t q2 = k.q();
                        final X8.l l = (X8.l)new X8.l(k, null) {
                            final k A;
                            Object y;
                            int z;
                            
                            public final d create(final d d) {
                                return (d)new X8.l(this.A, d) {
                                    final k A;
                                    Object y;
                                    int z;
                                };
                            }
                            
                            public final Object f(final d d) {
                                return ((k$j)this.create(d)).invokeSuspend(K8.M.a);
                            }
                            
                            public final Object invokeSuspend(Object c) {
                                final Object f = Q8.b.f();
                                final int z = this.z;
                                Object n = null;
                                Label_0060: {
                                    if (z == 0) {
                                        break Label_0060;
                                    }
                                    if (z != 1) {
                                        if (z == 2) {
                                            n = this.y;
                                            x.b(c);
                                            break Label_0060;
                                        }
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                    Label_0092: {
                                        try {
                                            x.b(c);
                                            break Label_0092;
                                        }
                                        finally {
                                            final t b = this.A.q();
                                            this.y = n;
                                            this.z = 2;
                                            c = b.c((d)this);
                                            if (c == f) {
                                                return f;
                                            }
                                            break Label_0060;
                                            x.b(c);
                                            final k a = this.A;
                                            this.z = 1;
                                            n = a.w(true, (d)this);
                                            iftrue(Label_0092:)((c = n) != f);
                                            return f;
                                            c = c;
                                            return K8.B.a(c, (Object)kotlin.coroutines.jvm.internal.b.a(true));
                                        }
                                    }
                                }
                                c = new b2.x((Throwable)n, ((Number)c).intValue());
                                return K8.B.a(c, (Object)kotlin.coroutines.jvm.internal.b.a(true));
                            }
                        };
                        d2.y = k;
                        d2.z = null;
                        d2.H = 2;
                        o = q2.a((X8.l)l, (d)d2);
                        if (o == f) {
                            return f;
                        }
                    }
                    else {
                        final t q3 = k.q();
                        final p p2 = (p)new p(k, a3, null) {
                            boolean A;
                            final k B;
                            final int C;
                            Object y;
                            int z;
                            
                            public final d create(final Object o, final d d) {
                                final p p2 = (p)new p(this.B, this.C, d) {
                                    boolean A;
                                    final k B;
                                    final int C;
                                    Object y;
                                    int z;
                                };
                                p2.A = (boolean)o;
                                return (d)p2;
                            }
                            
                            public final Object f(final boolean b, final d d) {
                                return ((k$k)this.create(b, d)).invokeSuspend(K8.M.a);
                            }
                            
                            public final Object invokeSuspend(Object n) {
                                final Object f = Q8.b.f();
                                final int z = this.z;
                                boolean a = false;
                                int n2 = 0;
                                Label_0227: {
                                    Object o = null;
                                    Object o2 = null;
                                    Label_0207: {
                                        Label_0222: {
                                            Label_0078: {
                                                if (z == 0) {
                                                    break Label_0078;
                                                }
                                                if (z != 1) {
                                                    if (z == 2) {
                                                        a = this.A;
                                                        o = this.y;
                                                        x.b(n);
                                                        o2 = n;
                                                        break Label_0207;
                                                    }
                                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                                }
                                                boolean a2 = a = this.A;
                                                Label_0138: {
                                                    try {
                                                        x.b(n);
                                                        break Label_0138;
                                                    }
                                                    finally {
                                                        if (!a) {
                                                            break Label_0222;
                                                        }
                                                        final t b = this.B.q();
                                                        this.y = n;
                                                        this.A = a;
                                                        this.z = 2;
                                                        final Object c = b.c((d)this);
                                                        if (c == f) {
                                                            return f;
                                                        }
                                                        o2 = c;
                                                        o = n;
                                                        n = n;
                                                        a = a2;
                                                        return K8.B.a(n, (Object)kotlin.coroutines.jvm.internal.b.a(a));
                                                        x.b(n);
                                                        a2 = this.A;
                                                        final k b2 = this.B;
                                                        this.A = a2;
                                                        this.z = 1;
                                                        iftrue(Label_0138:)((n = b2.w(a2, (d)this)) != f);
                                                        return f;
                                                    }
                                                }
                                            }
                                            break Label_0207;
                                        }
                                        n2 = this.C;
                                        break Label_0227;
                                    }
                                    n2 = ((Number)o2).intValue();
                                    n = o;
                                }
                                n = new b2.x((Throwable)n, n2);
                                return K8.B.a(n, (Object)kotlin.coroutines.jvm.internal.b.a(a));
                            }
                        };
                        d2.y = k;
                        d2.z = null;
                        d2.H = 3;
                        o = q3.b((p)p2, (d)d2);
                        if (o == f) {
                            return f;
                        }
                        break Label_0418;
                    }
                }
                u = (u)o;
                break Label_0425;
            }
            u = (u)o;
        }
        final D d3 = (D)u.a();
        if (u.b()) {
            k.g.c(d3);
        }
        return d3;
    }
    
    private final Object v(final d d) {
        return G.a(this.r(), d);
    }
    
    private final Object w(boolean c, d d) {
        Object o = null;
        Label_0051: {
            if (d instanceof k$l) {
                o = d;
                final int q = ((k$l)o).Q;
                if ((q & Integer.MIN_VALUE) != 0x0) {
                    ((k$l)o).Q = q + Integer.MIN_VALUE;
                    break Label_0051;
                }
            }
            o = new kotlin.coroutines.jvm.internal.d(this, d) {
                Object A;
                Object B;
                boolean C;
                int H;
                Object L;
                final k M;
                int Q;
                Object y;
                Object z;
                
                public final Object invokeSuspend(final Object l) {
                    this.L = l;
                    this.Q |= Integer.MIN_VALUE;
                    return this.M.w(false, (d)this);
                }
            };
        }
        Object z = ((k$l)o).L;
        final Object f = Q8.b.f();
        final int q2 = ((k$l)o).Q;
        final int n = 0;
        S s2 = null;
        Label_1023: {
            Object o3 = null;
            Object z2 = null;
            Object o4 = null;
            Object a = null;
            Label_0928: {
                Label_0841: {
                    k y = null;
                    Label_0699: {
                        k y2 = null;
                        switch (q2) {
                            default: {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            case 6: {
                                final Object o2 = ((k$l)o).A;
                                final S s = (S)((k$l)o).z;
                                d = (d)((k$l)o).y;
                                try {
                                    x.b(z);
                                    d = (d)o2;
                                    break Label_1023;
                                }
                                finally {
                                    break Label_1023;
                                }
                            }
                            case 5: {
                                c = ((k$l)o).C;
                                o3 = ((k$l)o).B;
                                z2 = ((k$l)o).A;
                                d = (d)((k$l)o).z;
                                o4 = ((k$l)o).y;
                                x.b(z);
                                a = z;
                                break Label_0928;
                            }
                            case 4: {
                                c = ((k$l)o).C;
                                final Object o5 = d = (d)((k$l)o).y;
                                final boolean b = c;
                                try {
                                    x.b(z);
                                    d = (d)o5;
                                    return z;
                                }
                                catch (final b2.d z3) {
                                    c = b;
                                    break Label_0841;
                                }
                            }
                            case 3: {
                                c = ((k$l)o).C;
                                y = (k)((k$l)o).y;
                                x.b(z);
                                break Label_0699;
                            }
                            case 2: {
                                final int h = ((k$l)o).H;
                                final boolean c2 = ((k$l)o).C;
                                final Object z4 = ((k$l)o).z;
                                final Object o6 = d = (d)((k$l)o).y;
                                c = c2;
                                try {
                                    x.b(z);
                                    d = (d)o6;
                                    c = c2;
                                    final Object c3 = z;
                                    return new f(z4, h, ((Number)c3).intValue());
                                }
                                catch (final b2.d z3) {
                                    break Label_0841;
                                }
                            }
                            case 1: {
                                c = ((k$l)o).C;
                                y2 = (k)((k$l)o).y;
                                x.b(z);
                                break;
                            }
                            case 0: {
                                x.b(z);
                                if (c) {
                                    ((k$l)o).y = this;
                                    ((k$l)o).C = c;
                                    ((k$l)o).Q = 1;
                                    final Object v = this.v((d)o);
                                    y2 = this;
                                    if ((z = v) == f) {
                                        return f;
                                    }
                                    break;
                                }
                                else {
                                    final t q3 = this.q();
                                    ((k$l)o).y = this;
                                    ((k$l)o).C = c;
                                    ((k$l)o).Q = 3;
                                    final Object c4 = q3.c((d)o);
                                    y = this;
                                    if ((z = c4) == f) {
                                        return f;
                                    }
                                    break Label_0699;
                                }
                                break;
                            }
                        }
                        int h;
                        if (z != null) {
                            h = z.hashCode();
                        }
                        else {
                            h = 0;
                        }
                        final t q4 = y2.q();
                        ((k$l)o).y = y2;
                        ((k$l)o).z = z;
                        ((k$l)o).C = c;
                        ((k$l)o).H = h;
                        ((k$l)o).Q = 2;
                        final Object c3 = q4.c((d)o);
                        if (c3 == f) {
                            return f;
                        }
                        final Object z4 = z;
                        return new f(z4, h, ((Number)c3).intValue());
                    }
                    final int intValue = ((Number)z).intValue();
                    final t q5 = y.q();
                    final p p = (p)new p(y, intValue, null) {
                        boolean A;
                        final k B;
                        final int C;
                        Object y;
                        int z;
                        
                        public final d create(final Object o, final d d) {
                            final p p2 = (p)new p(this.B, this.C, d) {
                                boolean A;
                                final k B;
                                final int C;
                                Object y;
                                int z;
                            };
                            p2.A = (boolean)o;
                            return (d)p2;
                        }
                        
                        public final Object f(final boolean b, final d d) {
                            return ((k$m)this.create(b, d)).invokeSuspend(K8.M.a);
                        }
                        
                        public final Object invokeSuspend(Object m) {
                            final Object f = Q8.b.f();
                            final int z = this.z;
                            int n = 0;
                            Label_0175: {
                                Object y = null;
                                Label_0156: {
                                    boolean a;
                                    if (z != 0) {
                                        if (z != 1) {
                                            if (z == 2) {
                                                y = this.y;
                                                x.b(m);
                                                break Label_0156;
                                            }
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                        }
                                        else {
                                            a = this.A;
                                            x.b(m);
                                        }
                                    }
                                    else {
                                        x.b(m);
                                        a = this.A;
                                        final k b = this.B;
                                        this.A = a;
                                        this.z = 1;
                                        if ((m = b.v((d)this)) == f) {
                                            return f;
                                        }
                                    }
                                    if (!a) {
                                        n = this.C;
                                        break Label_0175;
                                    }
                                    final t b2 = this.B.q();
                                    this.y = m;
                                    this.z = 2;
                                    final Object c = b2.c((d)this);
                                    if (c == f) {
                                        return f;
                                    }
                                    y = m;
                                    m = c;
                                }
                                n = ((Number)m).intValue();
                                m = y;
                            }
                            int hashCode;
                            if (m != null) {
                                hashCode = m.hashCode();
                            }
                            else {
                                hashCode = 0;
                            }
                            return new f(m, hashCode, n);
                        }
                    };
                    ((k$l)o).y = y;
                    ((k$l)o).C = c;
                    ((k$l)o).Q = 4;
                    if ((z = q5.b((p)p, (d)o)) == f) {
                        return f;
                    }
                    return (f)z;
                }
                z2 = new S();
                final e b2 = ((k)d).b;
                ((k$l)o).y = d;
                final d z3;
                ((k$l)o).z = z3;
                ((k$l)o).A = z2;
                ((k$l)o).B = z2;
                ((k$l)o).C = c;
                ((k$l)o).Q = 5;
                a = b2.a((b2.d)z3, (d)o);
                if (a == f) {
                    return f;
                }
                o3 = z2;
                o4 = d;
                d = z3;
            }
            ((S)o3).a = a;
            final Object a2 = new P();
            try {
                final X8.l l = (X8.l)new X8.l(z2, o4, a2, null) {
                    final S A;
                    final k B;
                    final P C;
                    Object y;
                    int z;
                    
                    public final d create(final d d) {
                        return (d)new X8.l(this.A, this.B, this.C, d) {
                            final S A;
                            final k B;
                            final P C;
                            Object y;
                            int z;
                        };
                    }
                    
                    public final Object f(final d d) {
                        return ((k$n)this.create(d)).invokeSuspend(K8.M.a);
                    }
                    
                    public final Object invokeSuspend(Object a) {
                        final Object f = Q8.b.f();
                        final int z = this.z;
                        P c = null;
                        Label_0084: {
                            if (z == 0) {
                                break Label_0084;
                            }
                            Label_0069: {
                                if (z == 1) {
                                    break Label_0069;
                                }
                                if (z != 2) {
                                    if (z == 3) {
                                        c = (P)this.y;
                                        x.b(a);
                                        break Label_0084;
                                    }
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                P c2 = (P)this.y;
                                try {
                                    x.b(a);
                                    Label_0178: {
                                        c2.a = ((Number)a).intValue();
                                    }
                                    return K8.M.a;
                                    x.b(a);
                                    S a2 = this.A;
                                    final k b = this.B;
                                    this.y = a2;
                                    this.z = 1;
                                    iftrue(Label_0128:)((a = b.v((d)this)) != f);
                                    return f;
                                    a2 = (S)this.y;
                                    x.b(a);
                                    Label_0128:
                                    a2.a = a;
                                    c2 = this.C;
                                    final t b2 = this.B.q();
                                    this.y = c2;
                                    this.z = 2;
                                    iftrue(Label_0178:)((a = b2.c((d)this)) != f);
                                    return f;
                                }
                                catch (final b2.d d) {
                                    c = this.C;
                                    final k b3 = this.B;
                                    a = this.A.a;
                                    this.y = c;
                                    this.z = 3;
                                    a = b3.z(a, true, (d)this);
                                    if (a == f) {
                                        return f;
                                    }
                                }
                            }
                        }
                        c.a = ((Number)a).intValue();
                        return K8.M.a;
                    }
                };
                ((k$l)o).y = d;
                ((k$l)o).z = z2;
                ((k$l)o).A = a2;
                ((k$l)o).B = null;
                ((k$l)o).Q = 6;
                if (((k)o4).p(c, (X8.l)l, (d)o) == f) {
                    return f;
                }
                d = (d)a2;
                s2 = (S)z2;
                final Object a3 = s2.a;
                int hashCode = n;
                if (a3 != null) {
                    hashCode = a3.hashCode();
                }
                return new f(a3, hashCode, ((P)d).a);
            }
            finally {}
        }
        K8.g.a((Throwable)d, (Throwable)s2);
        throw d;
    }
    
    private final Object x(final boolean b, final d d) {
        return i9.i.g(this.c.getCoroutineContext(), (p)new p(this, b, null) {
            final boolean A;
            int y;
            final k z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.z, this.A, d) {
                    final boolean A;
                    int y;
                    final k z;
                };
            }
            
            public final Object invoke(final M m, final d d) {
                return ((k$o)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(Object o) {
                final Object f = Q8.b.f();
                final int y = this.y;
                Label_0111: {
                    Label_0052: {
                        if (y != 0) {
                            if (y == 1) {
                                try {
                                    x.b(o);
                                    break Label_0111;
                                }
                                finally {
                                    final Throwable t;
                                    return new b2.x(t, -1);
                                }
                                break Label_0052;
                            }
                            if (y == 2) {
                                x.b(o);
                                return o;
                            }
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                    x.b(o);
                    if (b2.k.c(this.z).a() instanceof r) {
                        return b2.k.c(this.z).a();
                    }
                    final k z = this.z;
                    this.y = 1;
                    o = z.t((d)this);
                    if (o == f) {
                        return f;
                    }
                }
                final k z2 = this.z;
                final boolean a2 = this.A;
                this.y = 2;
                if ((o = z2.u(a2, (d)this)) == f) {
                    return f;
                }
                return (D)o;
            }
        }, d);
    }
    
    private final Object y(final p p3, final P8.g g, final d d) {
        return this.q().a((X8.l)new X8.l(this, g, p3, null) {
            final k A;
            final P8.g B;
            final p C;
            Object y;
            int z;
            
            public final d create(final d d) {
                return (d)new X8.l(this.A, this.B, this.C, d) {
                    final k A;
                    final P8.g B;
                    final p C;
                    Object y;
                    int z;
                };
            }
            
            public final Object f(final d d) {
                return ((k$q)this.create(d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(Object y) {
                final Object f = Q8.b.f();
                final int z = this.z;
                f y2 = null;
                Label_0164: {
                    if (z != 0) {
                        if (z != 1) {
                            if (z == 2) {
                                y2 = (f)this.y;
                                x.b(y);
                                break Label_0164;
                            }
                            if (z == 3) {
                                final Object y3 = this.y;
                                x.b(y);
                                y = y3;
                                return y;
                            }
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        else {
                            x.b(y);
                        }
                    }
                    else {
                        x.b(y);
                        final k a = this.A;
                        this.z = 1;
                        if ((y = a.w(true, (d)this)) == f) {
                            return f;
                        }
                    }
                    y2 = (f)y;
                    final P8.g b = this.B;
                    y = new p(this.C, y2, null) {
                        final f A;
                        int y;
                        final p z;
                        
                        public final d create(final Object o, final d d) {
                            return (d)new p(this.z, this.A, d) {
                                final f A;
                                int y;
                                final p z;
                            };
                        }
                        
                        public final Object invoke(final M m, final d d) {
                            return ((k$q$a)this.create(m, d)).invokeSuspend(K8.M.a);
                        }
                        
                        public final Object invokeSuspend(Object invoke) {
                            final Object f = Q8.b.f();
                            final int y = this.y;
                            if (y != 0) {
                                if (y != 1) {
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                x.b(invoke);
                            }
                            else {
                                x.b(invoke);
                                final p z = this.z;
                                final Object c = this.A.c();
                                this.y = 1;
                                if ((invoke = z.invoke(c, (Object)this)) == f) {
                                    return f;
                                }
                            }
                            return invoke;
                        }
                    };
                    this.y = y2;
                    this.z = 2;
                    if ((y = i9.i.g(b, (p)y, (d)this)) == f) {
                        return f;
                    }
                }
                y2.b();
                Object o = y;
                if (v.e(y2.c(), y)) {
                    return o;
                }
                final k a2 = this.A;
                this.y = y;
                this.z = 3;
                if (a2.z(y, true, (d)this) == f) {
                    return f;
                }
                o = y;
                return o;
            }
        }, d);
    }
    
    @Override
    public Object a(final p p2, final d d) {
        final J j = (J)d.getContext().get((g$c)J.a.a.a);
        if (j != null) {
            j.a(this);
        }
        return i9.i.g((P8.g)new J(j, this), (p)new p(this, p2, null) {
            final k A;
            final p B;
            int y;
            private Object z;
            
            public final d create(final Object z, final d d) {
                final p p2 = (p)new p(this.A, this.B, d) {
                    final k A;
                    final p B;
                    int y;
                    private Object z;
                };
                p2.z = z;
                return (d)p2;
            }
            
            public final Object invoke(final M m, final d d) {
                return ((k$s)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(Object await) {
                final Object f = Q8.b.f();
                final int y = this.y;
                if (y != 0) {
                    if (y != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    x.b(await);
                }
                else {
                    x.b(await);
                    final M m = (M)this.z;
                    final i9.x b = i9.z.b((z0)null, 1, (Object)null);
                    b2.k.i(this.A).e(new b2.w.a(this.B, b, b2.k.c(this.A).a(), m.getCoroutineContext()));
                    this.y = 1;
                    if ((await = ((U)b).await((d)this)) == f) {
                        return f;
                    }
                }
                return await;
            }
        }, d);
    }
    
    @Override
    public g getData() {
        return this.f;
    }
    
    public final F r() {
        return (F)this.i.getValue();
    }
    
    public final Object z(Object o, final boolean b, final d d) {
        kotlin.coroutines.jvm.internal.d d3 = null;
        Label_0056: {
            if (d instanceof k$w) {
                final kotlin.coroutines.jvm.internal.d d2 = (k$w)d;
                final int b2 = d2.B;
                if ((b2 & Integer.MIN_VALUE) != 0x0) {
                    d2.B = b2 + Integer.MIN_VALUE;
                    d3 = d2;
                    break Label_0056;
                }
            }
            d3 = new kotlin.coroutines.jvm.internal.d(this, d) {
                final k A;
                int B;
                Object y;
                Object z;
                
                public final Object invokeSuspend(final Object z) {
                    this.z = z;
                    this.B |= Integer.MIN_VALUE;
                    return this.A.z(null, false, (d)this);
                }
            };
        }
        final Object z = d3.z;
        final Object f = b.f();
        final int b3 = d3.B;
        if (b3 != 0) {
            if (b3 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            o = d3.y;
            x.b(z);
        }
        else {
            x.b(z);
            final P y = new P();
            final F r = this.r();
            o = new p(y, this, o, b, null) {
                private Object A;
                final P B;
                final k C;
                final Object H;
                final boolean L;
                Object y;
                int z;
                
                public final d create(final Object a, final d d) {
                    final p p2 = (p)new p(this.B, this.C, this.H, this.L, d) {
                        private Object A;
                        final P B;
                        final k C;
                        final Object H;
                        final boolean L;
                        Object y;
                        int z;
                    };
                    p2.A = a;
                    return (d)p2;
                }
                
                public final Object f(final K k, final d d) {
                    return ((k$x)this.create(k, d)).invokeSuspend(K8.M.a);
                }
                
                public final Object invokeSuspend(Object o) {
                    final Object f = Q8.b.f();
                    final int z = this.z;
                    Label_0172: {
                        P b;
                        K a;
                        if (z != 0) {
                            if (z != 1) {
                                if (z == 2) {
                                    x.b(o);
                                    break Label_0172;
                                }
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            else {
                                b = (P)this.y;
                                a = (K)this.A;
                                x.b(o);
                            }
                        }
                        else {
                            x.b(o);
                            a = (K)this.A;
                            b = this.B;
                            final t b2 = this.C.q();
                            this.A = a;
                            this.y = b;
                            this.z = 1;
                            o = b2.e((d)this);
                            if (o == f) {
                                return f;
                            }
                        }
                        b.a = ((Number)o).intValue();
                        o = this.H;
                        this.A = null;
                        this.y = null;
                        this.z = 2;
                        if (a.b(o, (d)this) == f) {
                            return f;
                        }
                    }
                    if (this.L) {
                        final l c = b2.k.c(this.C);
                        o = this.H;
                        int hashCode;
                        if (o != null) {
                            hashCode = o.hashCode();
                        }
                        else {
                            hashCode = 0;
                        }
                        c.c(new f(o, hashCode, this.B.a));
                    }
                    return K8.M.a;
                }
            };
            d3.y = y;
            d3.B = 1;
            if (r.a((p)o, (d)d3) == f) {
                return f;
            }
            o = y;
        }
        return kotlin.coroutines.jvm.internal.b.e(((P)o).a);
    }
    
    public static final class a
    {
        private a() {
        }
    }
    
    private final class b extends z
    {
        private List c;
        final k d;
        
        public b(final k d, final List list) {
            v.j((Object)list, "initTasksList");
            this.d = d;
            this.c = L8.t.U0((Iterable)list);
        }
        
        public static final /* synthetic */ List d(final b b) {
            return b.c;
        }
        
        public static final /* synthetic */ void e(final b b, final List c) {
            b.c = c;
        }
        
        @Override
        protected Object b(final d d) {
            Object o = null;
            Label_0047: {
                if (d instanceof k$b$a) {
                    final kotlin.coroutines.jvm.internal.d d2 = (k$b$a)d;
                    final int b = d2.B;
                    if ((b & Integer.MIN_VALUE) != 0x0) {
                        d2.B = b + Integer.MIN_VALUE;
                        o = d2;
                        break Label_0047;
                    }
                }
                o = new kotlin.coroutines.jvm.internal.d(this, d) {
                    final b A;
                    int B;
                    Object y;
                    Object z;
                    
                    public final Object invokeSuspend(final Object z) {
                        this.z = z;
                        this.B |= Integer.MIN_VALUE;
                        return this.A.b((d)this);
                    }
                };
            }
            Object z = ((k$b$a)o).z;
            final Object f = Q8.b.f();
            final int b2 = ((k$b$a)o).B;
            b b3 = null;
            f f2 = null;
            Label_0255: {
                Label_0250: {
                    Label_0204: {
                        if (b2 != 0) {
                            if (b2 == 1) {
                                b3 = (b)((k$b$a)o).y;
                                x.b(z);
                                break Label_0250;
                            }
                            if (b2 != 2) {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            b3 = (b)((k$b$a)o).y;
                            x.b(z);
                        }
                        else {
                            x.b(z);
                            final List c = this.c;
                            if (c != null) {
                                v.g((Object)c);
                                if (!c.isEmpty()) {
                                    final t b4 = this.d.q();
                                    final X8.l l = (X8.l)new X8.l(this.d, this, null) {
                                        Object A;
                                        Object B;
                                        Object C;
                                        int H;
                                        int L;
                                        final k M;
                                        final b Q;
                                        Object y;
                                        Object z;
                                        
                                        public final d create(final d d) {
                                            return (d)new X8.l(this.M, this.Q, d) {
                                                Object A;
                                                Object B;
                                                Object C;
                                                int H;
                                                int L;
                                                final k M;
                                                final b Q;
                                                Object y;
                                                Object z;
                                            };
                                        }
                                        
                                        public final Object f(final d d) {
                                            return ((k$b$b)this.create(d)).invokeSuspend(K8.M.a);
                                        }
                                        
                                        public final Object invokeSuspend(Object a) {
                                            final Object f = Q8.b.f();
                                            final int l = this.L;
                                            int h = 0;
                                            Label_0614: {
                                                S s4 = null;
                                                kotlin.jvm.internal.M i = null;
                                                Label_0456: {
                                                    S s2 = null;
                                                    kotlin.jvm.internal.M z = null;
                                                    r9.a b = null;
                                                    while (true) {
                                                        S s = null;
                                                        Object n = null;
                                                        Label_0292: {
                                                            Iterator c2;
                                                            Object b2;
                                                            if (l != 0) {
                                                                if (l == 1) {
                                                                    s = (S)this.B;
                                                                    s2 = (S)this.A;
                                                                    z = (kotlin.jvm.internal.M)this.z;
                                                                    b = (r9.a)this.y;
                                                                    x.b(a);
                                                                    n = a;
                                                                    break Label_0292;
                                                                }
                                                                if (l != 2) {
                                                                    if (l == 3) {
                                                                        final r9.a a2 = (r9.a)this.A;
                                                                        final S s3 = (S)this.z;
                                                                        final kotlin.jvm.internal.M m = (kotlin.jvm.internal.M)this.y;
                                                                        x.b(a);
                                                                        a = a2;
                                                                        break Label_0614;
                                                                    }
                                                                    if (l == 4) {
                                                                        h = this.H;
                                                                        final Object y = this.y;
                                                                        x.b(a);
                                                                        final Object c = a;
                                                                        break Label_0614;
                                                                    }
                                                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                                                }
                                                                else {
                                                                    c2 = (Iterator)this.C;
                                                                    b2 = this.B;
                                                                    s4 = (S)this.A;
                                                                    i = (kotlin.jvm.internal.M)this.z;
                                                                    final r9.a a3 = (r9.a)this.y;
                                                                    x.b(a);
                                                                    a = a3;
                                                                }
                                                            }
                                                            else {
                                                                x.b(a);
                                                                b = r9.c.b(false, 1, (Object)null);
                                                                z = new kotlin.jvm.internal.M();
                                                                final S s5 = new S();
                                                                final k j = this.M;
                                                                this.y = b;
                                                                this.z = z;
                                                                this.A = s5;
                                                                this.B = s5;
                                                                this.L = 1;
                                                                n = j.w(true, (d)this);
                                                                if (n == f) {
                                                                    return f;
                                                                }
                                                                s2 = s5;
                                                                s = s5;
                                                                break Label_0292;
                                                            }
                                                            while (c2.hasNext()) {
                                                                final p p = (p)c2.next();
                                                                this.y = a;
                                                                this.z = i;
                                                                this.A = s4;
                                                                this.B = b2;
                                                                this.C = c2;
                                                                this.L = 2;
                                                                if (p.invoke(b2, (Object)this) == f) {
                                                                    return f;
                                                                }
                                                            }
                                                            break Label_0456;
                                                        }
                                                        s.a = ((f)n).c();
                                                        Object b2 = new b2.s(b, z, s2, this.M) {
                                                            final r9.a a;
                                                            final kotlin.jvm.internal.M b;
                                                            final S c;
                                                            final k d;
                                                            
                                                            @Override
                                                            public Object a(p y, final d d) {
                                                                kotlin.coroutines.jvm.internal.d d2 = null;
                                                                Label_0049: {
                                                                    if (d instanceof k$b$b$a$a) {
                                                                        d2 = (k$b$b$a$a)d;
                                                                        final int m = d2.M;
                                                                        if ((m & Integer.MIN_VALUE) != 0x0) {
                                                                            d2.M = m + Integer.MIN_VALUE;
                                                                            break Label_0049;
                                                                        }
                                                                    }
                                                                    d2 = new kotlin.coroutines.jvm.internal.d(this, d) {
                                                                        Object A;
                                                                        Object B;
                                                                        Object C;
                                                                        Object H;
                                                                        final k$b$b$a L;
                                                                        int M;
                                                                        Object y;
                                                                        Object z;
                                                                        
                                                                        public final Object invokeSuspend(final Object h) {
                                                                            this.H = h;
                                                                            this.M |= Integer.MIN_VALUE;
                                                                            return this.L.a(null, (d)this);
                                                                        }
                                                                    };
                                                                }
                                                                Object o = d2.H;
                                                                final Object f = Q8.b.f();
                                                                final int i = d2.M;
                                                                Label_0549: {
                                                                    Label_0415: {
                                                                        k d3;
                                                                        Object c;
                                                                        Object o4;
                                                                        kotlin.jvm.internal.M b;
                                                                        if (i != 0) {
                                                                            if (i != 1) {
                                                                                if (i != 2) {
                                                                                    if (i == 3) {
                                                                                        final Object a = d2.A;
                                                                                        final Object o2 = d2.z;
                                                                                        y = (p)d2.y;
                                                                                        try {
                                                                                            x.b(o);
                                                                                            o = a;
                                                                                            break Label_0415;
                                                                                        }
                                                                                        finally {
                                                                                            break Label_0549;
                                                                                        }
                                                                                    }
                                                                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                                                                }
                                                                                final k k = (k)d2.A;
                                                                                final S s = (S)d2.z;
                                                                                final Object o3 = d2.y;
                                                                                try {
                                                                                    x.b(o);
                                                                                    break Label_0415;
                                                                                }
                                                                                finally {
                                                                                    y = (p)o3;
                                                                                    break Label_0549;
                                                                                }
                                                                            }
                                                                            d3 = (k)d2.C;
                                                                            c = d2.B;
                                                                            final kotlin.jvm.internal.M j = (kotlin.jvm.internal.M)d2.A;
                                                                            y = (p)d2.z;
                                                                            o4 = d2.y;
                                                                            x.b(o);
                                                                            b = j;
                                                                        }
                                                                        else {
                                                                            x.b(o);
                                                                            final Object a2 = this.a;
                                                                            b = this.b;
                                                                            c = this.c;
                                                                            d3 = this.d;
                                                                            d2.y = y;
                                                                            d2.z = a2;
                                                                            d2.A = b;
                                                                            d2.B = c;
                                                                            d2.C = d3;
                                                                            d2.M = 1;
                                                                            o4 = y;
                                                                            y = (p)a2;
                                                                            if (((r9.a)a2).b((Object)null, (d)d2) == f) {
                                                                                return f;
                                                                            }
                                                                        }
                                                                        try {
                                                                            if (!b.a) {
                                                                                final Object a3 = ((S)c).a;
                                                                                d2.y = y;
                                                                                d2.z = c;
                                                                                d2.A = d3;
                                                                                d2.B = null;
                                                                                d2.C = null;
                                                                                d2.M = 2;
                                                                                o = ((p)o4).invoke(a3, (Object)d2);
                                                                                if (o == f) {
                                                                                    return f;
                                                                                }
                                                                                final k k = d3;
                                                                                Object o2;
                                                                                Object o5;
                                                                                if (!v.e(o, ((S)c).a)) {
                                                                                    d2.y = y;
                                                                                    d2.z = c;
                                                                                    d2.A = o;
                                                                                    d2.M = 3;
                                                                                    if (k.z(o, false, (d)d2) == f) {
                                                                                        return f;
                                                                                    }
                                                                                    o2 = c;
                                                                                    o5 = y;
                                                                                    y = (p)o5;
                                                                                    ((S)o2).a = o;
                                                                                }
                                                                                else {
                                                                                    o2 = c;
                                                                                    o5 = y;
                                                                                }
                                                                                y = (p)o5;
                                                                                final Object a4 = ((S)o2).a;
                                                                                ((r9.a)o5).e((Object)null);
                                                                                return a4;
                                                                            }
                                                                        }
                                                                        finally {
                                                                            break Label_0549;
                                                                        }
                                                                    }
                                                                    final IllegalStateException ex = new IllegalStateException("InitializerApi.updateData should not be called after initialization is complete.");
                                                                }
                                                                ((r9.a)y).e((Object)null);
                                                            }
                                                        };
                                                        final List d = b2.k.b.d(this.Q);
                                                        if (d != null) {
                                                            final Iterator iterator = ((Iterable)d).iterator();
                                                            a = b;
                                                            final kotlin.jvm.internal.M k = z;
                                                            s4 = s2;
                                                            i = k;
                                                            final Iterator c2 = iterator;
                                                            continue;
                                                        }
                                                        break;
                                                    }
                                                    final kotlin.jvm.internal.M m2 = z;
                                                    s4 = s2;
                                                    i = m2;
                                                    a = b;
                                                }
                                                b.e(this.Q, null);
                                                this.y = i;
                                                this.z = s4;
                                                this.A = a;
                                                this.B = null;
                                                this.C = null;
                                                this.L = 3;
                                                if (((r9.a)a).b((Object)null, (d)this) == f) {
                                                    return f;
                                                }
                                                final S s6 = s4;
                                                final kotlin.jvm.internal.M m = i;
                                                final S s3 = s6;
                                                try {
                                                    m.a = true;
                                                    final K8.M a4 = K8.M.a;
                                                    ((r9.a)a).e((Object)null);
                                                    a = s3.a;
                                                    if (a != null) {
                                                        h = a.hashCode();
                                                    }
                                                    final t b3 = this.M.q();
                                                    this.y = a;
                                                    this.z = null;
                                                    this.A = null;
                                                    this.H = h;
                                                    this.L = 4;
                                                    final Object c = b3.c((d)this);
                                                    if (c == f) {
                                                        return f;
                                                    }
                                                    final Object y = a;
                                                    return new f(y, h, ((Number)c).intValue());
                                                }
                                                finally {
                                                    ((r9.a)a).e((Object)null);
                                                }
                                            }
                                        }
                                    };
                                    ((k$b$a)o).y = this;
                                    ((k$b$a)o).B = 2;
                                    final Object a = b4.a((X8.l)l, (d)o);
                                    b3 = this;
                                    if ((z = a) == f) {
                                        return f;
                                    }
                                    break Label_0204;
                                }
                            }
                            final k d3 = this.d;
                            ((k$b$a)o).y = this;
                            ((k$b$a)o).B = 1;
                            final Object n = d3.w(false, (d)o);
                            b3 = this;
                            if ((z = n) == f) {
                                return f;
                            }
                            break Label_0250;
                        }
                    }
                    f2 = (f)z;
                    break Label_0255;
                }
                f2 = (f)z;
            }
            b2.k.c(b3.d).c(f2);
            return K8.M.a;
        }
    }
}
