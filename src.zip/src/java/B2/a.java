package b2;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.nio.file.CopyOption;
import kotlin.jvm.internal.v;
import java.io.File;

final class a
{
    public static final a a;
    
    static {
        a = new a();
    }
    
    private a() {
    }
    
    public final boolean a(final File file, final File file2) {
        v.j((Object)file, "srcFile");
        v.j((Object)file2, "dstFile");
        try {
            Files.move(file.toPath(), file2.toPath(), new CopyOption[] { (CopyOption)StandardCopyOption.REPLACE_EXISTING });
            return true;
        }
        catch (final IOException ex) {
            return false;
        }
    }
}
