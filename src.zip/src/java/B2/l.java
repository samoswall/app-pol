package b2;

import K8.s;
import l9.g;
import l9.O;
import kotlin.jvm.internal.v;
import l9.x;

public final class l
{
    private final x a;
    
    public l() {
        final H b = H.b;
        v.h((Object)b, "null cannot be cast to non-null type androidx.datastore.core.State<T of androidx.datastore.core.DataStoreInMemoryCache>");
        this.a = O.a((Object)b);
    }
    
    public final D a() {
        return (D)this.a.getValue();
    }
    
    public final g b() {
        return (g)this.a;
    }
    
    public final D c(final D d) {
        v.j((Object)d, "newState");
        final x a = this.a;
        Object value;
        D d2;
        do {
            value = a.getValue();
            final D d3 = (D)value;
            if (!(d3 instanceof b2.x) && !v.e((Object)d3, (Object)H.b)) {
                if (d3 instanceof f) {
                    d2 = d3;
                    if (d.a() <= d3.a()) {
                        continue;
                    }
                }
                else {
                    if (d3 instanceof r) {
                        d2 = d3;
                        continue;
                    }
                    throw new s();
                }
            }
            d2 = d;
        } while (!a.a(value, (Object)d2));
        return d2;
    }
}
