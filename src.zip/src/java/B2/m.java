package b2;

import kotlin.jvm.internal.v;
import java.io.File;

public abstract class m
{
    public static final boolean a(final File file, final File file2) {
        v.j((Object)file, "<this>");
        v.j((Object)file2, "toFile");
        return a.a.a(file, file2);
    }
}
