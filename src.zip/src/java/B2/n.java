package b2;

import java.io.FileNotFoundException;
import java.io.Closeable;
import V8.c;
import java.io.InputStream;
import java.io.FileInputStream;
import K8.x;
import Q8.b;
import P8.d;
import kotlin.jvm.internal.v;
import java.util.concurrent.atomic.AtomicBoolean;
import java.io.File;

public class n implements y
{
    private final File a;
    private final A b;
    private final AtomicBoolean c;
    
    public n(final File a, final A b) {
        v.j((Object)a, "file");
        v.j((Object)b, "serializer");
        this.a = a;
        this.b = b;
        this.c = new AtomicBoolean(false);
    }
    
    static /* synthetic */ Object i(n n, d from) {
        Object o = null;
        Label_0045: {
            if (from instanceof n$a) {
                o = from;
                final int c = ((n$a)o).C;
                if ((c & Integer.MIN_VALUE) != 0x0) {
                    ((n$a)o).C = c + Integer.MIN_VALUE;
                    break Label_0045;
                }
            }
            o = new kotlin.coroutines.jvm.internal.d(n, from) {
                Object A;
                final n B;
                int C;
                Object y;
                Object z;
                
                public final Object invokeSuspend(final Object a) {
                    this.A = a;
                    this.C |= Integer.MIN_VALUE;
                    return n.i(this.B, (d)this);
                }
            };
        }
        final Object a = ((n$a)o).A;
        final Object f = b.f();
        final int c2 = ((n$a)o).C;
        Label_0227: {
            if (c2 != 0) {
                if (c2 != 1) {
                    if (c2 == 2) {
                        n = (n)((n$a)o).y;
                        try {
                            x.b(a);
                            break Label_0227;
                        }
                        finally {
                            from = (FileNotFoundException)n;
                            n = (n)o;
                            break Label_0227;
                        }
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                final Object o2 = ((n$a)o).z;
                n = (n)((n$a)o).y;
                try {
                    x.b(a);
                    break Label_0227;
                }
                finally {
                    from = (FileNotFoundException)n;
                    break Label_0227;
                }
            }
            x.b(a);
            n.f();
            while (true) {
                try {
                    from = (FileNotFoundException)new FileInputStream(n.a);
                    Object o2;
                    try {
                        final A b = n.b;
                        ((n$a)o).y = n;
                        ((n$a)o).z = from;
                        ((n$a)o).C = 1;
                        final Object from2 = b.readFrom((InputStream)from, (d)o);
                        if (from2 == f) {
                            return f;
                        }
                        o2 = from;
                        from = (FileNotFoundException)from2;
                        try {
                            V8.c.a((Closeable)o2, (Throwable)null);
                            return from;
                        }
                        catch (FileNotFoundException from) {
                            from = (FileNotFoundException)n;
                        }
                    }
                    finally {
                        o2 = from;
                        from = (FileNotFoundException)n;
                    }
                    try {
                        throw;
                    }
                    finally {
                        n = (n)from;
                        final Throwable t;
                        V8.c.a((Closeable)o2, t);
                        n = (n)from;
                    }
                    if (((n)from).a.exists()) {
                        n = (n)new FileInputStream(((n)from).a);
                        try {
                            final A b2 = ((n)from).b;
                            ((n$a)o).y = n;
                            ((n$a)o).z = null;
                            ((n$a)o).C = 2;
                            from = (FileNotFoundException)b2.readFrom((InputStream)n, (d)o);
                            if (from == f) {
                                return f;
                            }
                            V8.c.a((Closeable)n, (Throwable)null);
                            return from;
                        }
                        finally {
                            o = n;
                            final n n2;
                            n = n2;
                            from = (FileNotFoundException)o;
                        }
                        try {
                            throw n;
                        }
                        finally {
                            V8.c.a((Closeable)from, (Throwable)n);
                        }
                    }
                    return ((n)from).b.getDefaultValue();
                }
                catch (final FileNotFoundException ex) {
                    from = (FileNotFoundException)n;
                    continue;
                }
                break;
            }
        }
    }
    
    @Override
    public void close() {
        this.c.set(true);
    }
    
    @Override
    public Object d(final d d) {
        return i(this, d);
    }
    
    protected final void f() {
        if (!this.c.get()) {
            return;
        }
        throw new IllegalStateException("This scope has already been closed.");
    }
    
    protected final File g() {
        return this.a;
    }
    
    protected final A h() {
        return this.b;
    }
}
