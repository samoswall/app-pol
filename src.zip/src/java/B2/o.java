package b2;

import K8.M;
import kotlin.jvm.internal.w;
import java.io.File;
import kotlin.jvm.internal.v;
import java.util.LinkedHashSet;
import kotlin.jvm.internal.m;
import X8.a;
import X8.l;
import java.util.Set;

public final class o implements E
{
    public static final b d;
    private static final Set e;
    private static final Object f;
    private final A a;
    private final l b;
    private final a c;
    
    static {
        d = new b(null);
        e = (Set)new LinkedHashSet();
        f = new Object();
    }
    
    public o(final A a, final l b, final a c) {
        v.j((Object)a, "serializer");
        v.j((Object)b, "coordinatorProducer");
        v.j((Object)c, "produceFile");
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public static final /* synthetic */ Set b() {
        return o.e;
    }
    
    public static final /* synthetic */ Object c() {
        return o.f;
    }
    
    @Override
    public F a() {
        final File canonicalFile = ((File)this.c.invoke()).getCanonicalFile();
        final Object f;
        monitorenter(f = o.f);
        Label_0158: {
            try {
                final String absolutePath = canonicalFile.getAbsolutePath();
                final Set e = o.e;
                if (!e.contains((Object)absolutePath)) {
                    v.i((Object)absolutePath, "path");
                    e.add((Object)absolutePath);
                    monitorexit(f);
                    v.i((Object)canonicalFile, "file");
                    return new p(canonicalFile, this.a, (t)this.b.invoke((Object)canonicalFile), (a)new a(canonicalFile) {
                        final File H;
                        
                        public final void invoke() {
                            final b d = o.d;
                            final Object b = d.b();
                            final File h = this.H;
                            synchronized (b) {
                                d.a().remove((Object)h.getAbsolutePath());
                                final M a = M.a;
                            }
                        }
                    });
                }
            }
            finally {
                break Label_0158;
            }
            final StringBuilder sb = new StringBuilder();
            sb.append("There are multiple DataStores active for the same file: ");
            final String s;
            sb.append(s);
            sb.append(". You should either maintain your DataStore as a singleton or confirm that there is no two DataStore's active on the same file (by confirming that the scope is cancelled).");
            throw new IllegalStateException(sb.toString().toString());
        }
        monitorexit(f);
    }
    
    public static final class b
    {
        private b() {
        }
        
        public final Set a() {
            return o.b();
        }
        
        public final Object b() {
            return o.c();
        }
    }
}
