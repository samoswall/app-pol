package b2;

import K8.g;
import r9.a$a;
import K8.x;
import Q8.b;
import X8.q;
import P8.d;
import java.io.IOException;
import r9.c;
import kotlin.jvm.internal.v;
import java.util.concurrent.atomic.AtomicBoolean;
import X8.a;
import java.io.File;

public final class p implements F
{
    private final File a;
    private final A b;
    private final t c;
    private final a d;
    private final AtomicBoolean e;
    private final r9.a f;
    
    public p(final File a, final A b, final t c, final a d) {
        v.j((Object)a, "file");
        v.j((Object)b, "serializer");
        v.j((Object)c, "coordinator");
        v.j((Object)d, "onClose");
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = new AtomicBoolean(false);
        this.f = r9.c.b(false, 1, (Object)null);
    }
    
    private final void f() {
        if (!this.e.get()) {
            return;
        }
        throw new IllegalStateException("StorageConnection has already been disposed.");
    }
    
    private final void g(final File file) {
        final File parentFile = file.getCanonicalFile().getParentFile();
        if (parentFile != null) {
            parentFile.mkdirs();
            if (!parentFile.isDirectory()) {
                final StringBuilder sb = new StringBuilder();
                sb.append("Unable to create parent directories of ");
                sb.append((Object)file);
                throw new IOException(sb.toString());
            }
        }
    }
    
    @Override
    public Object a(final X8.p p0, final d p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: instanceof      Lb2/p$b;
        //     4: ifeq            38
        //     7: aload_2        
        //     8: checkcast       Lb2/p$b;
        //    11: astore          6
        //    13: aload           6
        //    15: getfield        b2/p$b.L:I
        //    18: istore_3       
        //    19: iload_3        
        //    20: ldc             -2147483648
        //    22: iand           
        //    23: ifeq            38
        //    26: aload           6
        //    28: iload_3        
        //    29: ldc             -2147483648
        //    31: iadd           
        //    32: putfield        b2/p$b.L:I
        //    35: goto            49
        //    38: new             Lb2/p$b;
        //    41: dup            
        //    42: aload_0        
        //    43: aload_2        
        //    44: invokespecial   b2/p$b.<init>:(Lb2/p;LP8/d;)V
        //    47: astore          6
        //    49: aload           6
        //    51: getfield        b2/p$b.C:Ljava/lang/Object;
        //    54: astore          10
        //    56: invokestatic    Q8/b.f:()Ljava/lang/Object;
        //    59: astore          9
        //    61: aload           6
        //    63: getfield        b2/p$b.L:I
        //    66: istore_3       
        //    67: iload_3        
        //    68: ifeq            195
        //    71: iload_3        
        //    72: iconst_1       
        //    73: if_icmpeq       158
        //    76: iload_3        
        //    77: iconst_2       
        //    78: if_icmpne       148
        //    81: aload           6
        //    83: getfield        b2/p$b.B:Ljava/lang/Object;
        //    86: checkcast       Lb2/c;
        //    89: astore          7
        //    91: aload           6
        //    93: getfield        b2/p$b.A:Ljava/lang/Object;
        //    96: checkcast       Ljava/io/File;
        //    99: astore_2       
        //   100: aload           6
        //   102: getfield        b2/p$b.z:Ljava/lang/Object;
        //   105: checkcast       Lr9/a;
        //   108: astore_1       
        //   109: aload           6
        //   111: getfield        b2/p$b.y:Ljava/lang/Object;
        //   114: checkcast       Lb2/p;
        //   117: astore          8
        //   119: aload_1        
        //   120: astore          6
        //   122: aload           7
        //   124: astore          5
        //   126: aload_2        
        //   127: astore          4
        //   129: aload           10
        //   131: invokestatic    K8/x.b:(Ljava/lang/Object;)V
        //   134: goto            406
        //   137: astore          7
        //   139: aload           6
        //   141: astore_1       
        //   142: aload           4
        //   144: astore_2       
        //   145: goto            702
        //   148: new             Ljava/lang/IllegalStateException;
        //   151: dup            
        //   152: ldc             "call to 'resume' before 'invoke' with coroutine"
        //   154: invokespecial   java/lang/IllegalStateException.<init>:(Ljava/lang/String;)V
        //   157: athrow         
        //   158: aload           6
        //   160: getfield        b2/p$b.A:Ljava/lang/Object;
        //   163: checkcast       Lr9/a;
        //   166: astore_1       
        //   167: aload           6
        //   169: getfield        b2/p$b.z:Ljava/lang/Object;
        //   172: checkcast       LX8/p;
        //   175: astore          8
        //   177: aload           6
        //   179: getfield        b2/p$b.y:Ljava/lang/Object;
        //   182: checkcast       Lb2/p;
        //   185: astore          5
        //   187: aload           10
        //   189: invokestatic    K8/x.b:(Ljava/lang/Object;)V
        //   192: goto            266
        //   195: aload           10
        //   197: invokestatic    K8/x.b:(Ljava/lang/Object;)V
        //   200: aload_0        
        //   201: invokespecial   b2/p.f:()V
        //   204: aload_0        
        //   205: aload_0        
        //   206: getfield        b2/p.a:Ljava/io/File;
        //   209: invokespecial   b2/p.g:(Ljava/io/File;)V
        //   212: aload_0        
        //   213: getfield        b2/p.f:Lr9/a;
        //   216: astore_2       
        //   217: aload           6
        //   219: aload_0        
        //   220: putfield        b2/p$b.y:Ljava/lang/Object;
        //   223: aload           6
        //   225: aload_1        
        //   226: putfield        b2/p$b.z:Ljava/lang/Object;
        //   229: aload           6
        //   231: aload_2        
        //   232: putfield        b2/p$b.A:Ljava/lang/Object;
        //   235: aload           6
        //   237: iconst_1       
        //   238: putfield        b2/p$b.L:I
        //   241: aload_0        
        //   242: astore          5
        //   244: aload_1        
        //   245: astore          8
        //   247: aload_2        
        //   248: astore_1       
        //   249: aload_2        
        //   250: aconst_null    
        //   251: aload           6
        //   253: invokeinterface r9/a.b:(Ljava/lang/Object;LP8/d;)Ljava/lang/Object;
        //   258: aload           9
        //   260: if_acmpne       266
        //   263: aload           9
        //   265: areturn        
        //   266: aload_1        
        //   267: astore          4
        //   269: new             Ljava/io/File;
        //   272: astore_2       
        //   273: aload_1        
        //   274: astore          4
        //   276: new             Ljava/lang/StringBuilder;
        //   279: astore          7
        //   281: aload_1        
        //   282: astore          4
        //   284: aload           7
        //   286: invokespecial   java/lang/StringBuilder.<init>:()V
        //   289: aload_1        
        //   290: astore          4
        //   292: aload           7
        //   294: aload           5
        //   296: getfield        b2/p.a:Ljava/io/File;
        //   299: invokevirtual   java/io/File.getAbsolutePath:()Ljava/lang/String;
        //   302: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   305: pop            
        //   306: aload_1        
        //   307: astore          4
        //   309: aload           7
        //   311: ldc             ".tmp"
        //   313: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   316: pop            
        //   317: aload_1        
        //   318: astore          4
        //   320: aload_2        
        //   321: aload           7
        //   323: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   326: invokespecial   java/io/File.<init>:(Ljava/lang/String;)V
        //   329: aload_1        
        //   330: astore          4
        //   332: new             Lb2/q;
        //   335: dup            
        //   336: aload_2        
        //   337: aload           5
        //   339: getfield        b2/p.b:Lb2/A;
        //   342: invokespecial   b2/q.<init>:(Ljava/io/File;Lb2/A;)V
        //   345: astore          7
        //   347: aload           6
        //   349: aload           5
        //   351: putfield        b2/p$b.y:Ljava/lang/Object;
        //   354: aload           6
        //   356: aload_1        
        //   357: putfield        b2/p$b.z:Ljava/lang/Object;
        //   360: aload           6
        //   362: aload_2        
        //   363: putfield        b2/p$b.A:Ljava/lang/Object;
        //   366: aload           6
        //   368: aload           7
        //   370: putfield        b2/p$b.B:Ljava/lang/Object;
        //   373: aload           6
        //   375: iconst_2       
        //   376: putfield        b2/p$b.L:I
        //   379: aload           8
        //   381: aload           7
        //   383: aload           6
        //   385: invokeinterface X8/p.invoke:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   390: astore          4
        //   392: aload           4
        //   394: aload           9
        //   396: if_acmpne       402
        //   399: aload           9
        //   401: areturn        
        //   402: aload           5
        //   404: astore          8
        //   406: aload_1        
        //   407: astore          6
        //   409: aload           7
        //   411: astore          5
        //   413: aload_2        
        //   414: astore          4
        //   416: getstatic       K8/M.a:LK8/M;
        //   419: astore          9
        //   421: aload           7
        //   423: invokeinterface b2/c.close:()V
        //   428: aconst_null    
        //   429: astore          7
        //   431: goto            436
        //   434: astore          7
        //   436: aload           7
        //   438: ifnonnull       680
        //   441: aload_1        
        //   442: astore          4
        //   444: aload_1        
        //   445: astore          5
        //   447: aload_2        
        //   448: astore          6
        //   450: aload_2        
        //   451: invokevirtual   java/io/File.exists:()Z
        //   454: ifeq            662
        //   457: aload_1        
        //   458: astore          4
        //   460: aload_1        
        //   461: astore          5
        //   463: aload_2        
        //   464: astore          6
        //   466: aload_2        
        //   467: aload           8
        //   469: getfield        b2/p.a:Ljava/io/File;
        //   472: invokestatic    b2/m.a:(Ljava/io/File;Ljava/io/File;)Z
        //   475: ifeq            481
        //   478: goto            662
        //   481: aload_1        
        //   482: astore          4
        //   484: aload_1        
        //   485: astore          5
        //   487: aload_2        
        //   488: astore          6
        //   490: new             Ljava/io/IOException;
        //   493: astore          7
        //   495: aload_1        
        //   496: astore          4
        //   498: aload_1        
        //   499: astore          5
        //   501: aload_2        
        //   502: astore          6
        //   504: new             Ljava/lang/StringBuilder;
        //   507: astore          9
        //   509: aload_1        
        //   510: astore          4
        //   512: aload_1        
        //   513: astore          5
        //   515: aload_2        
        //   516: astore          6
        //   518: aload           9
        //   520: invokespecial   java/lang/StringBuilder.<init>:()V
        //   523: aload_1        
        //   524: astore          4
        //   526: aload_1        
        //   527: astore          5
        //   529: aload_2        
        //   530: astore          6
        //   532: aload           9
        //   534: ldc             "Unable to rename "
        //   536: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   539: pop            
        //   540: aload_1        
        //   541: astore          4
        //   543: aload_1        
        //   544: astore          5
        //   546: aload_2        
        //   547: astore          6
        //   549: aload           9
        //   551: aload_2        
        //   552: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   555: pop            
        //   556: aload_1        
        //   557: astore          4
        //   559: aload_1        
        //   560: astore          5
        //   562: aload_2        
        //   563: astore          6
        //   565: aload           9
        //   567: ldc             " to "
        //   569: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   572: pop            
        //   573: aload_1        
        //   574: astore          4
        //   576: aload_1        
        //   577: astore          5
        //   579: aload_2        
        //   580: astore          6
        //   582: aload           9
        //   584: aload           8
        //   586: getfield        b2/p.a:Ljava/io/File;
        //   589: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   592: pop            
        //   593: aload_1        
        //   594: astore          4
        //   596: aload_1        
        //   597: astore          5
        //   599: aload_2        
        //   600: astore          6
        //   602: aload           9
        //   604: ldc             ". This likely means that there are multiple instances of DataStore for this file. Ensure that you are only creating a single instance of datastore for this file."
        //   606: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   609: pop            
        //   610: aload_1        
        //   611: astore          4
        //   613: aload_1        
        //   614: astore          5
        //   616: aload_2        
        //   617: astore          6
        //   619: aload           7
        //   621: aload           9
        //   623: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   626: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   629: aload_1        
        //   630: astore          4
        //   632: aload_1        
        //   633: astore          5
        //   635: aload_2        
        //   636: astore          6
        //   638: aload           7
        //   640: athrow         
        //   641: astore_1       
        //   642: goto            772
        //   645: astore_1       
        //   646: aload           6
        //   648: astore_2       
        //   649: aload           5
        //   651: astore          4
        //   653: aload_1        
        //   654: astore          5
        //   656: aload           4
        //   658: astore_1       
        //   659: goto            748
        //   662: aload_1        
        //   663: astore          4
        //   665: getstatic       K8/M.a:LK8/M;
        //   668: astore_2       
        //   669: aload_1        
        //   670: aconst_null    
        //   671: invokeinterface r9/a.e:(Ljava/lang/Object;)V
        //   676: getstatic       K8/M.a:LK8/M;
        //   679: areturn        
        //   680: aload_1        
        //   681: astore          4
        //   683: aload_1        
        //   684: astore          5
        //   686: aload_2        
        //   687: astore          6
        //   689: aload           7
        //   691: athrow         
        //   692: astore          4
        //   694: aload           7
        //   696: astore          5
        //   698: aload           4
        //   700: astore          7
        //   702: aload           5
        //   704: invokeinterface b2/c.close:()V
        //   709: goto            730
        //   712: astore          8
        //   714: aload_1        
        //   715: astore          4
        //   717: aload_1        
        //   718: astore          5
        //   720: aload_2        
        //   721: astore          6
        //   723: aload           7
        //   725: aload           8
        //   727: invokestatic    K8/g.a:(Ljava/lang/Throwable;Ljava/lang/Throwable;)V
        //   730: aload_1        
        //   731: astore          4
        //   733: aload_1        
        //   734: astore          5
        //   736: aload_2        
        //   737: astore          6
        //   739: aload           7
        //   741: athrow         
        //   742: astore_1       
        //   743: goto            772
        //   746: astore          5
        //   748: aload_1        
        //   749: astore          4
        //   751: aload_2        
        //   752: invokevirtual   java/io/File.exists:()Z
        //   755: ifeq            766
        //   758: aload_1        
        //   759: astore          4
        //   761: aload_2        
        //   762: invokevirtual   java/io/File.delete:()Z
        //   765: pop            
        //   766: aload_1        
        //   767: astore          4
        //   769: aload           5
        //   771: athrow         
        //   772: aload           4
        //   774: aconst_null    
        //   775: invokeinterface r9/a.e:(Ljava/lang/Object;)V
        //   780: aload_1        
        //   781: athrow         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  129    134    137    148    Any
        //  269    273    742    746    Any
        //  276    281    742    746    Any
        //  284    289    742    746    Any
        //  292    306    742    746    Any
        //  309    317    742    746    Any
        //  320    329    742    746    Any
        //  332    347    746    748    Ljava/io/IOException;
        //  332    347    742    746    Any
        //  347    392    692    702    Any
        //  416    421    137    148    Any
        //  421    428    434    436    Any
        //  450    457    645    662    Ljava/io/IOException;
        //  450    457    641    645    Any
        //  466    478    645    662    Ljava/io/IOException;
        //  466    478    641    645    Any
        //  490    495    645    662    Ljava/io/IOException;
        //  490    495    641    645    Any
        //  504    509    645    662    Ljava/io/IOException;
        //  504    509    641    645    Any
        //  518    523    645    662    Ljava/io/IOException;
        //  518    523    641    645    Any
        //  532    540    645    662    Ljava/io/IOException;
        //  532    540    641    645    Any
        //  549    556    645    662    Ljava/io/IOException;
        //  549    556    641    645    Any
        //  565    573    645    662    Ljava/io/IOException;
        //  565    573    641    645    Any
        //  582    593    645    662    Ljava/io/IOException;
        //  582    593    641    645    Any
        //  602    610    645    662    Ljava/io/IOException;
        //  602    610    641    645    Any
        //  619    629    645    662    Ljava/io/IOException;
        //  619    629    641    645    Any
        //  638    641    645    662    Ljava/io/IOException;
        //  638    641    641    645    Any
        //  665    669    641    645    Any
        //  689    692    645    662    Ljava/io/IOException;
        //  689    692    641    645    Any
        //  702    709    712    730    Any
        //  723    730    645    662    Ljava/io/IOException;
        //  723    730    641    645    Any
        //  739    742    645    662    Ljava/io/IOException;
        //  739    742    641    645    Any
        //  751    758    742    746    Any
        //  761    766    742    746    Any
        //  769    772    742    746    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0402:
        //     at w5.m.a(SourceFile:20)
        //     at w5.f.o(SourceFile:122)
        //     at w5.f.r(SourceFile:571)
        //     at w5.f.q(SourceFile:3)
        //     at a6.j.j(SourceFile:32)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public t c() {
        return this.c;
    }
    
    @Override
    public void close() {
        this.e.set(true);
        this.d.invoke();
    }
    
    @Override
    public Object e(q q, d invoke) {
        Object o = null;
        Label_0049: {
            if (invoke instanceof p$a) {
                o = invoke;
                final int h = ((p$a)o).H;
                if ((h & Integer.MIN_VALUE) != 0x0) {
                    ((p$a)o).H = h + Integer.MIN_VALUE;
                    break Label_0049;
                }
            }
            o = new kotlin.coroutines.jvm.internal.d(this, invoke) {
                boolean A;
                Object B;
                final p C;
                int H;
                Object y;
                Object z;
                
                public final Object invokeSuspend(final Object b) {
                    this.B = b;
                    this.H |= Integer.MIN_VALUE;
                    return this.C.e(null, (d)this);
                }
            };
        }
        final Object b = ((p$a)o).B;
        final Object f = Q8.b.f();
        final int h2 = ((p$a)o).H;
        boolean a = false;
        d d = null;
        Label_0297: {
            if (h2 != 0) {
                if (h2 == 1) {
                    a = ((p$a)o).A;
                    invoke = (d)((p$a)o).z;
                    q = (q)((p$a)o).y;
                    try {
                        x.b(b);
                        invoke = (d)b;
                        break Label_0297;
                    }
                    finally {
                        final boolean b2 = a;
                        final Object o2 = invoke;
                        break Label_0297;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            x.b(b);
            this.f();
            final boolean b2 = a$a.b(this.f, (Object)null, 1, (Object)null);
            invoke = (d)this;
            a = b2;
            try {
                Object z = new n(this.a, this.b);
                Object o2;
                try {
                    final Boolean a2 = kotlin.coroutines.jvm.internal.b.a(b2);
                    ((p$a)o).y = this;
                    ((p$a)o).z = z;
                    ((p$a)o).A = b2;
                    ((p$a)o).H = 1;
                    invoke = (d)q.invoke(z, (Object)a2, o);
                    if (invoke == f) {
                        return f;
                    }
                    q = (q)this;
                    a = b2;
                    try {
                        ((c)z).close();
                    }
                    finally {}
                    if (z == null) {
                        if (a) {
                            a$a.c(((p)q).f, (Object)null, 1, (Object)null);
                        }
                        return invoke;
                    }
                    try {
                        throw z;
                    }
                    finally {
                        final c c;
                        z = c;
                    }
                }
                finally {
                    o2 = z;
                    q = (q)this;
                    z = invoke;
                }
                try {
                    ((c)o2).close();
                }
                finally {
                    invoke = (d)q;
                    a = b2;
                    final Throwable t;
                    g.a((Throwable)z, t);
                }
                invoke = (d)q;
                a = b2;
                throw z;
            }
            finally {
                d = invoke;
            }
        }
        if (a) {
            a$a.c(((p)d).f, (Object)null, 1, (Object)null);
        }
    }
}
