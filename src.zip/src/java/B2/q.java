package b2;

import java.io.Closeable;
import V8.c;
import K8.M;
import java.io.OutputStream;
import K8.x;
import java.io.FileOutputStream;
import Q8.b;
import P8.d;
import kotlin.jvm.internal.v;
import java.io.File;

public final class q extends n implements K
{
    public q(final File file, final A a) {
        v.j((Object)file, "file");
        v.j((Object)a, "serializer");
        super(file, a);
    }
    
    @Override
    public Object b(Object writeTo, d d) {
        Object o = null;
        Label_0049: {
            if (d instanceof q$a) {
                o = d;
                final int c = ((q$a)o).C;
                if ((c & Integer.MIN_VALUE) != 0x0) {
                    ((q$a)o).C = c + Integer.MIN_VALUE;
                    break Label_0049;
                }
            }
            o = new kotlin.coroutines.jvm.internal.d(this, d) {
                Object A;
                final q B;
                int C;
                Object y;
                Object z;
                
                public final Object invokeSuspend(final Object a) {
                    this.A = a;
                    this.C |= Integer.MIN_VALUE;
                    return this.B.b(null, (d)this);
                }
            };
        }
        final Object a = ((q$a)o).A;
        final Object f = Q8.b.f();
        final int c2 = ((q$a)o).C;
        Label_0243: {
            if (c2 != 0) {
                if (c2 == 1) {
                    final FileOutputStream fileOutputStream = (FileOutputStream)((q$a)o).z;
                    writeTo = ((q$a)o).y;
                    try {
                        x.b(a);
                    }
                    finally {
                        final Object o2 = writeTo;
                        break Label_0243;
                    }
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            x.b(a);
            this.f();
            d = (d)new FileOutputStream(this.g());
            Object o2;
            try {
                final A h = this.h();
                final I i = new I((FileOutputStream)d);
                ((q$a)o).y = d;
                ((q$a)o).z = d;
                ((q$a)o).C = 1;
                writeTo = h.writeTo(writeTo, i, (d)o);
                if (writeTo == f) {
                    return f;
                }
                writeTo = (o2 = (d = d));
                writeTo = d;
                ((FileOutputStream)o2).getFD().sync();
                writeTo = d;
                final M a2 = M.a;
                c.a((Closeable)d, (Throwable)null);
                return M.a;
            }
            finally {
                o2 = d;
                final d d2;
                d = d2;
            }
            try {
                throw d;
            }
            finally {
                c.a((Closeable)o2, (Throwable)d);
            }
        }
    }
}
