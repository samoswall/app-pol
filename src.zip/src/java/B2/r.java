package b2;

import kotlin.jvm.internal.m;
import kotlin.jvm.internal.v;

public final class r extends D
{
    private final Throwable b;
    
    public r(final Throwable b) {
        v.j((Object)b, "finalException");
        super(Integer.MAX_VALUE, null);
        this.b = b;
    }
    
    public final Throwable b() {
        return this.b;
    }
}
