package b2;

import P8.d;
import X8.p;

public interface s
{
    Object a(final p p0, final d p1);
}
