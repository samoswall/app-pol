package b2;

import l9.g;
import X8.p;
import P8.d;
import X8.l;

public interface t
{
    Object a(final l p0, final d p1);
    
    Object b(final p p0, final d p1);
    
    Object c(final d p0);
    
    g d();
    
    Object e(final d p0);
}
