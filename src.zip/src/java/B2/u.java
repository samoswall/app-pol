package b2;

import kotlin.jvm.internal.v;

public abstract class u
{
    public static final t a(final String s) {
        v.j((Object)s, "filePath");
        return new C(s);
    }
}
