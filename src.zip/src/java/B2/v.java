package b2;

import java.io.File;

public abstract class v
{
    public static final t a(final File file) {
        kotlin.jvm.internal.v.j((Object)file, "file");
        final String absolutePath = file.getCanonicalFile().getAbsolutePath();
        kotlin.jvm.internal.v.i((Object)absolutePath, "file.canonicalFile.absolutePath");
        return u.a(absolutePath);
    }
}
