package b2;

import kotlin.jvm.internal.v;
import P8.g;
import i9.x;
import X8.p;
import kotlin.jvm.internal.m;

public abstract class w
{
    private w() {
    }
    
    public static final class a extends w
    {
        private final p a;
        private final x b;
        private final D c;
        private final g d;
        
        public a(final p a, final x b, final D c, final g d) {
            v.j((Object)a, "transform");
            v.j((Object)b, "ack");
            v.j((Object)d, "callerContext");
            super(null);
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
        }
        
        public final x a() {
            return this.b;
        }
        
        public final g b() {
            return this.d;
        }
        
        public D c() {
            return this.c;
        }
        
        public final p d() {
            return this.a;
        }
    }
}
