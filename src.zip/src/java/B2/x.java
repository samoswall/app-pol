package b2;

import kotlin.jvm.internal.m;
import kotlin.jvm.internal.v;

public final class x extends D
{
    private final Throwable b;
    
    public x(final Throwable b, final int n) {
        v.j((Object)b, "readException");
        super(n, null);
        this.b = b;
    }
    
    public final Throwable b() {
        return this.b;
    }
}
