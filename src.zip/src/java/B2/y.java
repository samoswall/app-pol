package b2;

import P8.d;

public interface y extends c
{
    Object d(final d p0);
}
