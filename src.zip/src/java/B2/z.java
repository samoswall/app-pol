package b2;

import i9.U;
import K8.M;
import Q8.b;
import P8.d;
import i9.z0;
import r9.c;
import i9.x;
import r9.a;

public abstract class z
{
    private final a a;
    private final x b;
    
    public z() {
        this.a = c.b(false, 1, (Object)null);
        this.b = i9.z.b((z0)null, 1, (Object)null);
    }
    
    public final Object a(final d d) {
        final Object await = ((U)this.b).await(d);
        if (await == Q8.b.f()) {
            return await;
        }
        return M.a;
    }
    
    protected abstract Object b(final d p0);
    
    public final Object c(d z) {
        Object o = null;
        Label_0049: {
            if (z instanceof z$a) {
                o = z;
                final int c = ((z$a)o).C;
                if ((c & Integer.MIN_VALUE) != 0x0) {
                    ((z$a)o).C = c + Integer.MIN_VALUE;
                    break Label_0049;
                }
            }
            o = new kotlin.coroutines.jvm.internal.d(this, z) {
                Object A;
                final z B;
                int C;
                Object y;
                Object z;
                
                public final Object invokeSuspend(final Object a) {
                    this.A = a;
                    this.C |= Integer.MIN_VALUE;
                    return this.B.c((d)this);
                }
            };
        }
        final Object a = ((z$a)o).A;
        final Object f = Q8.b.f();
        final int c2 = ((z$a)o).C;
        Label_0327: {
            Object o3 = null;
            final d d;
            Label_0289: {
                z z2;
                if (c2 != 0) {
                    if (c2 != 1) {
                        if (c2 == 2) {
                            final Object o2 = ((z$a)o).z;
                            o3 = ((z$a)o).y;
                            z = (d)o2;
                            try {
                                K8.x.b(a);
                                break Label_0289;
                            }
                            finally {
                                break Label_0327;
                            }
                        }
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    z = (d)((z$a)o).z;
                    z2 = (z)((z$a)o).y;
                    K8.x.b(a);
                }
                else {
                    K8.x.b(a);
                    if (((z0)this.b).isCompleted()) {
                        return M.a;
                    }
                    final Object a2 = this.a;
                    ((z$a)o).y = this;
                    ((z$a)o).z = a2;
                    ((z$a)o).C = 1;
                    z2 = this;
                    z = (d)a2;
                    if (((a)a2).b((Object)null, (d)o) == f) {
                        return f;
                    }
                }
                try {
                    if (((z0)z2.b).isCompleted()) {
                        final M a3 = M.a;
                        ((a)z).e((Object)null);
                        return a3;
                    }
                }
                finally {
                    break Label_0327;
                }
                final z y;
                ((z$a)o).y = y;
                ((z$a)o).z = z;
                ((z$a)o).C = 2;
                if (y.b((d)o) == f) {
                    return f;
                }
                o3 = y;
                d = z;
            }
            final x b = ((z)o3).b;
            final M a4 = M.a;
            b.b0((Object)a4);
            ((a)d).e((Object)null);
            return a4;
        }
        ((a)z).e((Object)null);
    }
}
