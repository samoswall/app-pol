package b3;

public interface a
{
}
