package B3;

import java.io.File;
import E3.k;
import g9.o;
import kotlin.jvm.internal.v;
import I3.j;
import android.net.Uri;

public final class b implements d
{
    private final boolean b(final Uri uri) {
        final boolean p = j.p(uri);
        boolean b2;
        final boolean b = b2 = false;
        if (!p) {
            final String scheme = uri.getScheme();
            if (scheme != null) {
                b2 = b;
                if (!v.e((Object)scheme, (Object)"file")) {
                    return b2;
                }
            }
            String path;
            if ((path = uri.getPath()) == null) {
                path = "";
            }
            b2 = b;
            if (o.Q0((CharSequence)path, '/', false, 2, (Object)null)) {
                b2 = b;
                if (j.h(uri) != null) {
                    b2 = true;
                }
            }
        }
        return b2;
    }
    
    public File c(final Uri uri, final k k) {
        final boolean b = this.b(uri);
        final File file = null;
        if (!b) {
            return null;
        }
        if (v.e((Object)uri.getScheme(), (Object)"file")) {
            final String path = uri.getPath();
            File file2 = file;
            if (path != null) {
                file2 = new File(path);
            }
            return file2;
        }
        return new File(uri.toString());
    }
}
