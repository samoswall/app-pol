package B3;

import okhttp3.HttpUrl;
import E3.k;

public final class c implements d
{
    public String b(final HttpUrl httpUrl, final k k) {
        return httpUrl.toString();
    }
}
