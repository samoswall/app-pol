package B3;

import E3.k;

public interface d
{
    Object a(final Object p0, final k p1);
}
