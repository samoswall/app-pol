package B3;

import android.net.Uri;
import E3.k;
import android.content.res.Resources$NotFoundException;
import android.content.Context;

public final class e implements d
{
    private final boolean b(final int n, final Context context) {
        boolean b = false;
        try {
            if (context.getResources().getResourceEntryName(n) != null) {
                b = true;
            }
            return b;
        }
        catch (final Resources$NotFoundException ex) {
            return b;
        }
    }
    
    public Uri c(final int n, final k k) {
        if (!this.b(n, k.g())) {
            return null;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("android.resource://");
        sb.append(k.g().getPackageName());
        sb.append('/');
        sb.append(n);
        return Uri.parse(sb.toString());
    }
}
