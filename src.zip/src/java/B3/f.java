package B3;

import java.util.List;
import android.content.res.Resources;
import E3.k;
import java.util.Collection;
import g9.o;
import kotlin.jvm.internal.v;
import android.net.Uri;

public final class f implements d
{
    private final boolean b(final Uri uri) {
        if (v.e((Object)uri.getScheme(), (Object)"android.resource")) {
            final String authority = uri.getAuthority();
            if (authority != null) {
                if (!o.D((CharSequence)authority)) {
                    if (((Collection)uri.getPathSegments()).size() == 2) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public Uri c(final Uri uri, final k k) {
        if (!this.b(uri)) {
            return null;
        }
        String authority;
        if ((authority = uri.getAuthority()) == null) {
            authority = "";
        }
        final Resources resourcesForApplication = k.g().getPackageManager().getResourcesForApplication(authority);
        final List pathSegments = uri.getPathSegments();
        final int identifier = resourcesForApplication.getIdentifier((String)pathSegments.get(1), (String)pathSegments.get(0), authority);
        if (identifier != 0) {
            final StringBuilder sb = new StringBuilder();
            sb.append("android.resource://");
            sb.append(authority);
            sb.append('/');
            sb.append(identifier);
            return Uri.parse(sb.toString());
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("Invalid android.resource URI: ");
        sb2.append((Object)uri);
        throw new IllegalStateException(sb2.toString().toString());
    }
}
