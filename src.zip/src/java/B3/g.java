package B3;

import android.net.Uri;
import E3.k;

public final class g implements d
{
    public Uri b(final String s, final k k) {
        return Uri.parse(s);
    }
}
