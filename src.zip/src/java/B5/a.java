package b5;

import c5.m;
import com.google.android.gms.common.internal.t0;
import android.content.ComponentName;
import android.content.pm.PackageManager$NameNotFoundException;
import android.util.Log;
import e5.c;
import java.util.concurrent.Executor;
import android.content.Intent;
import java.util.NoSuchElementException;
import android.content.ServiceConnection;
import android.content.Context;
import com.google.android.gms.common.internal.r;
import java.util.concurrent.ConcurrentHashMap;

public class a
{
    private static final Object b;
    private static volatile a c;
    public final ConcurrentHashMap a;
    
    static {
        b = new Object();
    }
    
    private a() {
        this.a = new ConcurrentHashMap();
    }
    
    public static a b() {
        if (a.c == null) {
            final Object b;
            monitorenter(b = a.b);
            Label_0039: {
                try {
                    if (a.c == null) {
                        a.c = new a();
                    }
                    break Label_0039;
                }
                finally {
                    monitorexit(b);
                    monitorexit(b);
                }
            }
        }
        final a c = a.c;
        r.l((Object)c);
        return c;
    }
    
    private static void e(final Context context, final ServiceConnection serviceConnection) {
        try {
            context.unbindService(serviceConnection);
        }
        catch (final IllegalArgumentException | IllegalStateException | NoSuchElementException ex) {}
    }
    
    private final boolean f(final Context context, final String s, final Intent intent, final ServiceConnection serviceConnection, final int n, boolean b, final Executor executor) {
        final ComponentName component = intent.getComponent();
        while (true) {
            if (component == null) {
                break Label_0062;
            }
            final String packageName = component.getPackageName();
            "com.google.android.gms".equals((Object)packageName);
            try {
                if ((e5.c.a(context).c(packageName, 0).flags & 0x200000) != 0x0) {
                    Log.w("ConnectionTracker", "Attempted to bind to a service in a STOPPED package.");
                    return false;
                }
                if (g(serviceConnection)) {
                    final ServiceConnection serviceConnection2 = (ServiceConnection)this.a.putIfAbsent((Object)serviceConnection, (Object)serviceConnection);
                    if (serviceConnection2 != null && serviceConnection != serviceConnection2) {
                        Log.w("ConnectionTracker", String.format("Duplicate binding with the same ServiceConnection: %s, %s, %s.", new Object[] { serviceConnection, s, intent.getAction() }));
                    }
                    try {
                        b = h(context, intent, serviceConnection, n, executor);
                        if (b) {
                            return b;
                        }
                        return false;
                    }
                    finally {
                        this.a.remove((Object)serviceConnection, (Object)serviceConnection);
                    }
                }
                b = h(context, intent, serviceConnection, n, executor);
                return b;
            }
            catch (final PackageManager$NameNotFoundException ex) {
                continue;
            }
            break;
        }
    }
    
    private static boolean g(final ServiceConnection serviceConnection) {
        return !(serviceConnection instanceof t0);
    }
    
    private static final boolean h(final Context context, final Intent intent, final ServiceConnection serviceConnection, final int n, final Executor executor) {
        Executor executor2 = executor;
        if (executor == null) {
            executor2 = null;
        }
        if (m.j() && executor2 != null) {
            return context.bindService(intent, n, executor2, serviceConnection);
        }
        return context.bindService(intent, serviceConnection, n);
    }
    
    public boolean a(final Context context, final Intent intent, final ServiceConnection serviceConnection, final int n) {
        return this.f(context, context.getClass().getName(), intent, serviceConnection, n, true, null);
    }
    
    public void c(final Context context, final ServiceConnection serviceConnection) {
        if (g(serviceConnection) && this.a.containsKey((Object)serviceConnection)) {
            try {
                e(context, (ServiceConnection)this.a.get((Object)serviceConnection));
                return;
            }
            finally {
                this.a.remove((Object)serviceConnection);
            }
        }
        e(context, serviceConnection);
    }
    
    public final boolean d(final Context context, final String s, final Intent intent, final ServiceConnection serviceConnection, final int n, final Executor executor) {
        return this.f(context, s, intent, serviceConnection, 4225, true, executor);
    }
}
