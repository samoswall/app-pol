package b6;

public interface b
{
    a a(final c p0, final String p1, final String p2);
    
    public interface a
    {
        void a();
        
        void b(final int p0, final long p1);
    }
}
