package b6;

import java.util.Collections;
import java.security.GeneralSecurityException;
import S5.k;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Objects;
import java.util.List;

public final class c
{
    private final a a;
    private final List b;
    private final Integer c;
    
    private c(final a a, final List b, final Integer c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public static b a() {
        return new b();
    }
    
    @Override
    public boolean equals(final Object o) {
        final boolean b = o instanceof c;
        final boolean b2 = false;
        if (!b) {
            return false;
        }
        final c c = (c)o;
        boolean b3 = b2;
        if (this.a.equals(c.a)) {
            b3 = b2;
            if (this.b.equals((Object)c.b)) {
                b3 = b2;
                if (Objects.equals((Object)this.c, (Object)c.c)) {
                    b3 = true;
                }
            }
        }
        return b3;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(new Object[] { this.a, this.b });
    }
    
    @Override
    public String toString() {
        return String.format("(annotations=%s, entries=%s, primaryKeyId=%s)", new Object[] { this.a, this.b, this.c });
    }
    
    public static final class b
    {
        private ArrayList a;
        private a b;
        private Integer c;
        
        public b() {
            this.a = new ArrayList();
            this.b = a.b;
            this.c = null;
        }
        
        private boolean c(final int n) {
            final Iterator iterator = this.a.iterator();
            while (iterator.hasNext()) {
                if (((c)iterator.next()).a() == n) {
                    return true;
                }
            }
            return false;
        }
        
        public b a(final k k, final int n, final String s, final String s2) {
            final ArrayList a = this.a;
            if (a != null) {
                a.add((Object)new c(k, n, s, s2));
                return this;
            }
            throw new IllegalStateException("addEntry cannot be called after build()");
        }
        
        public c b() {
            if (this.a == null) {
                throw new IllegalStateException("cannot call build() twice");
            }
            final Integer c = this.c;
            if (c != null && !this.c(c)) {
                throw new GeneralSecurityException("primary key ID is not present in entries");
            }
            final c c2 = new c(this.b, Collections.unmodifiableList((List)this.a), this.c, null);
            this.a = null;
            return c2;
        }
        
        public b d(final a b) {
            if (this.a != null) {
                this.b = b;
                return this;
            }
            throw new IllegalStateException("setAnnotations cannot be called after build()");
        }
        
        public b e(final int n) {
            if (this.a != null) {
                this.c = n;
                return this;
            }
            throw new IllegalStateException("setPrimaryKeyId cannot be called after build()");
        }
    }
    
    public static final class c
    {
        private final k a;
        private final int b;
        private final String c;
        private final String d;
        
        private c(final k a, final int b, final String c, final String d) {
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
        }
        
        public int a() {
            return this.b;
        }
        
        @Override
        public boolean equals(final Object o) {
            final boolean b = o instanceof c;
            final boolean b2 = false;
            if (!b) {
                return false;
            }
            final c c = (c)o;
            boolean b3 = b2;
            if (this.a == c.a) {
                b3 = b2;
                if (this.b == c.b) {
                    b3 = b2;
                    if (this.c.equals((Object)c.c)) {
                        b3 = b2;
                        if (this.d.equals((Object)c.d)) {
                            b3 = true;
                        }
                    }
                }
            }
            return b3;
        }
        
        @Override
        public int hashCode() {
            return Objects.hash(new Object[] { this.a, this.b, this.c, this.d });
        }
        
        @Override
        public String toString() {
            return String.format("(status=%s, keyId=%s, keyType='%s', keyPrefix='%s')", new Object[] { this.a, this.b, this.c, this.d });
        }
    }
}
