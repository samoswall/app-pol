package b7;

import f7.i;
import h7.e;
import h7.c;
import Y6.m;
import Y6.t;
import f7.b;

public final class a
{
    private static final int[] g;
    private final b a;
    private boolean b;
    private int c;
    private int d;
    private int e;
    private int f;
    
    static {
        g = new int[] { 3808, 476, 2107, 1799 };
    }
    
    public a(final b a) {
        this.a = a;
    }
    
    private static float b(final t t, final t t2) {
        return a.a(t.c(), t.d(), t2.c(), t2.d());
    }
    
    private static float c(final a a, final a a2) {
        return a.b(a.a(), a.b(), a2.a(), a2.b());
    }
    
    private static t[] d(final t[] array, final int n, final int n2) {
        final float n3 = n2 / (n * 2.0f);
        final float c = array[0].c();
        final float c2 = array[2].c();
        final float d = array[0].d();
        final float d2 = array[2].d();
        final float n4 = (array[0].c() + array[2].c()) / 2.0f;
        final float n5 = (array[0].d() + array[2].d()) / 2.0f;
        final float n6 = (c - c2) * n3;
        final float n7 = (d - d2) * n3;
        final t t = new t(n4 + n6, n5 + n7);
        final t t2 = new t(n4 - n6, n5 - n7);
        final float c3 = array[1].c();
        final float c4 = array[3].c();
        final float d3 = array[1].d();
        final float d4 = array[3].d();
        final float n8 = (array[1].c() + array[3].c()) / 2.0f;
        final float n9 = (array[1].d() + array[3].d()) / 2.0f;
        final float n10 = (c3 - c4) * n3;
        final float n11 = n3 * (d3 - d4);
        return new t[] { t, new t(n8 + n10, n9 + n11), t2, new t(n8 - n10, n9 - n11) };
    }
    
    private void e(final t[] array) {
        int i = 0;
        if (!this.o(array[0]) || !this.o(array[1]) || !this.o(array[2]) || !this.o(array[3])) {
            throw m.a();
        }
        final int n = this.e * 2;
        final int[] array2 = { this.r(array[0], array[1], n), this.r(array[1], array[2], n), this.r(array[2], array[3], n), this.r(array[3], array[0], n) };
        this.f = m(array2, n);
        long n2 = 0L;
        while (i < 4) {
            final int n3 = array2[(this.f + i) % 4];
            long n4;
            long n5;
            if (this.b) {
                n4 = n2 << 7;
                n5 = (n3 >> 1 & 0x7F);
            }
            else {
                n4 = n2 << 10;
                n5 = (n3 >> 2 & 0x3E0) + (n3 >> 1 & 0x1F);
            }
            n2 = n4 + n5;
            ++i;
        }
        final int h = h(n2, this.b);
        if (this.b) {
            this.c = (h >> 6) + 1;
            this.d = (h & 0x3F) + 1;
            return;
        }
        this.c = (h >> 11) + 1;
        this.d = (h & 0x7FF) + 1;
    }
    
    private t[] f(a a) {
        final boolean b = true;
        this.e = 1;
        a a2 = a;
        final a a4;
        a a3 = a4 = a2;
        boolean b2 = true;
        a a5 = a;
        a = a4;
        while (this.e < 9) {
            final a j = this.j(a5, b2, 1, -1);
            final a i = this.j(a2, b2, 1, 1);
            final a k = this.j(a3, b2, -1, 1);
            final a l = this.j(a, b2, -1, -1);
            if (this.e > 2) {
                final double n = c(l, j) * this.e / (c(a, a5) * (this.e + 2));
                if (n < 0.75 || n > 1.25 || !this.p(j, i, k, l)) {
                    break;
                }
            }
            b2 ^= true;
            ++this.e;
            a = l;
            a5 = j;
            a2 = i;
            a3 = k;
        }
        final int e = this.e;
        if (e != 5 && e != 7) {
            throw m.a();
        }
        this.b = (e == 5 && b);
        final t t = new t(a5.a() + 0.5f, a5.b() - 0.5f);
        final t t2 = new t(a2.a() + 0.5f, a2.b() + 0.5f);
        final t t3 = new t(a3.a() - 0.5f, a3.b() + 0.5f);
        final t t4 = new t(a.a() - 0.5f, a.b() - 0.5f);
        final int e2 = this.e;
        return d(new t[] { t, t2, t3, t4 }, e2 * 2 - 3, e2 * 2);
    }
    
    private int g(final a a, final a a2) {
        final float c = c(a, a2);
        final float n = (a2.a() - a.a()) / c;
        final float n2 = (a2.b() - a.b()) / c;
        float n3 = (float)a.a();
        float n4 = (float)a.b();
        final boolean e = this.a.e(a.a(), a.b());
        final int n5 = (int)Math.ceil((double)c);
        int n6 = 0;
        int i = 0;
        int n7 = 0;
        while (i < n5) {
            n3 += n;
            n4 += n2;
            int n8 = n7;
            if (this.a.e(a.c(n3), a.c(n4)) != e) {
                n8 = n7 + 1;
            }
            ++i;
            n7 = n8;
        }
        final float n9 = n7 / c;
        if (n9 > 0.1f && n9 < 0.9f) {
            return 0;
        }
        if (n9 <= 0.1f) {
            n6 = 1;
        }
        if (n6 == (e ? 1 : 0)) {
            return 1;
        }
        return -1;
    }
    
    private static int h(long n, final boolean b) {
        int n2;
        int n3;
        if (b) {
            n2 = 7;
            n3 = 2;
        }
        else {
            n2 = 10;
            n3 = 4;
        }
        final int[] array = new int[n2];
        for (int i = n2 - 1; i >= 0; --i) {
            array[i] = ((int)n & 0xF);
            n >>= 4;
        }
        try {
            new c(h7.a.k).a(array, n2 - n3);
            int j = 0;
            int n4 = 0;
            while (j < n3) {
                n4 = (n4 << 4) + array[j];
                ++j;
            }
            return n4;
        }
        catch (final e e) {
            throw m.a();
        }
    }
    
    private int i() {
        if (this.b) {
            return this.c * 4 + 11;
        }
        final int c = this.c;
        if (c <= 4) {
            return c * 4 + 15;
        }
        return c * 4 + ((c - 4) / 8 + 1) * 2 + 15;
    }
    
    private a j(final a a, final boolean b, int n, final int n2) {
        int n3 = a.a() + n;
        int b2 = a.b();
        while (true) {
            b2 += n2;
            if (!this.n(n3, b2) || this.a.e(n3, b2) != b) {
                break;
            }
            n3 += n;
        }
        final int n4 = n3 - n;
        int n5;
        int n6;
        for (n5 = b2 - n2, n6 = n4; this.n(n6, n5) && this.a.e(n6, n5) == b; n6 += n) {}
        int n7;
        for (n7 = n6 - n, n = n5; this.n(n7, n) && this.a.e(n7, n) == b; n += n2) {}
        return new a(n7, n - n2);
    }
    
    private a k() {
        t c2;
        t c3;
        t c4;
        t c5;
        try {
            final t[] c = new g7.b(this.a).c();
            c2 = c[0];
            c3 = c[1];
            c4 = c[2];
            c5 = c[3];
        }
        catch (final m m) {
            final int n = this.a.l() / 2;
            int n2 = this.a.i() / 2;
            final int n3 = n + 7;
            final int n4 = n2 - 7;
            c2 = this.j(new a(n3, n4), false, 1, -1).c();
            n2 += 7;
            c3 = this.j(new a(n3, n2), false, 1, 1).c();
            final int n5 = n - 7;
            c4 = this.j(new a(n5, n2), false, -1, 1).c();
            c5 = this.j(new a(n5, n4), false, -1, -1).c();
        }
        int c6 = g7.a.c((c2.c() + c5.c() + c3.c() + c4.c()) / 4.0f);
        int c7 = g7.a.c((c2.d() + c5.d() + c3.d() + c4.d()) / 4.0f);
        t c9;
        t c10;
        t c11;
        t c12;
        try {
            final t[] c8 = new g7.b(this.a, 15, c6, c7).c();
            c9 = c8[0];
            c10 = c8[1];
            c11 = c8[2];
            c12 = c8[3];
        }
        catch (final m i) {
            final int n6 = c6 + 7;
            final int n7 = c7 - 7;
            c9 = this.j(new a(n6, n7), false, 1, -1).c();
            c7 += 7;
            c10 = this.j(new a(n6, c7), false, 1, 1).c();
            c6 -= 7;
            c11 = this.j(new a(c6, c7), false, -1, 1).c();
            c12 = this.j(new a(c6, n7), false, -1, -1).c();
        }
        return new a(g7.a.c((c9.c() + c12.c() + c10.c() + c11.c()) / 4.0f), g7.a.c((c9.d() + c12.d() + c10.d() + c11.d()) / 4.0f));
    }
    
    private t[] l(final t[] array) {
        return d(array, this.e * 2, this.i());
    }
    
    private static int m(final int[] array, int i) {
        final int length = array.length;
        final int n = 0;
        int j = 0;
        int n2 = 0;
        while (j < length) {
            final int n3 = array[j];
            n2 = (n2 << 3) + ((n3 >> i - 2 << 1) + (n3 & 0x1));
            ++j;
        }
        for (i = n; i < 4; ++i) {
            if (Integer.bitCount(a.g[i] ^ ((n2 & 0x1) << 11) + (n2 >> 1)) <= 2) {
                return i;
            }
        }
        throw m.a();
    }
    
    private boolean n(final int n, final int n2) {
        return n >= 0 && n < this.a.l() && n2 > 0 && n2 < this.a.i();
    }
    
    private boolean o(final t t) {
        return this.n(g7.a.c(t.c()), g7.a.c(t.d()));
    }
    
    private boolean p(a a, a a2, a a3, a a4) {
        a = new a(a.a() - 3, a.b() + 3);
        a2 = new a(a2.a() - 3, a2.b() - 3);
        a3 = new a(a3.a() + 3, a3.b() - 3);
        a4 = new a(a4.a() + 3, a4.b() + 3);
        final int g = this.g(a4, a);
        return g != 0 && this.g(a, a2) == g && this.g(a2, a3) == g && this.g(a3, a4) == g;
    }
    
    private b q(final b b, final t t, final t t2, final t t3, final t t4) {
        final i b2 = i.b();
        final int i = this.i();
        final float n = i / 2.0f;
        final int e = this.e;
        final float n2 = n - e;
        final float n3 = n + e;
        return b2.c(b, i, i, n2, n2, n3, n2, n3, n3, n2, n3, t.c(), t.d(), t2.c(), t2.d(), t3.c(), t3.d(), t4.c(), t4.d());
    }
    
    private int r(final t t, final t t2, final int n) {
        final float b = b(t, t2);
        final float n2 = b / n;
        final float c = t.c();
        final float d = t.d();
        final float n3 = (t2.c() - t.c()) * n2 / b;
        final float n4 = n2 * (t2.d() - t.d()) / b;
        int i = 0;
        int n5 = 0;
        while (i < n) {
            final b a = this.a;
            final float n6 = (float)i;
            int n7 = n5;
            if (a.e(g7.a.c(n6 * n3 + c), g7.a.c(n6 * n4 + d))) {
                n7 = (n5 | 1 << n - i - 1);
            }
            ++i;
            n5 = n7;
        }
        return n5;
    }
    
    public Z6.a a(final boolean b) {
        final t[] f = this.f(this.k());
        if (b) {
            final t t = f[0];
            f[0] = f[2];
            f[2] = t;
        }
        this.e(f);
        final b a = this.a;
        final int f2 = this.f;
        return new Z6.a(this.q(a, f[f2 % 4], f[(f2 + 1) % 4], f[(f2 + 2) % 4], f[(f2 + 3) % 4]), this.l(f), this.b, this.d, this.c);
    }
    
    static final class a
    {
        private final int a;
        private final int b;
        
        a(final int a, final int b) {
            this.a = a;
            this.b = b;
        }
        
        int a() {
            return this.a;
        }
        
        int b() {
            return this.b;
        }
        
        t c() {
            return new t((float)this.a, (float)this.b);
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder("<");
            sb.append(this.a);
            sb.append(' ');
            sb.append(this.b);
            sb.append('>');
            return sb.toString();
        }
    }
}
