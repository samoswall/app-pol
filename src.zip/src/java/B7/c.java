package B7;

import java.util.Iterator;
import android.hardware.Camera$Parameters;
import android.util.Log;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import android.hardware.Camera$Area;
import android.graphics.Rect;
import java.util.List;
import java.util.regex.Pattern;

public abstract class c
{
    private static final Pattern a;
    
    static {
        a = Pattern.compile(";");
    }
    
    private static List a(final int n) {
        final int n2 = -n;
        return Collections.singletonList((Object)new Camera$Area(new Rect(n2, n2, n, n), 1));
    }
    
    private static String b(final String s, final Collection collection, final String... array) {
        final StringBuilder sb = new StringBuilder();
        sb.append("Requesting ");
        sb.append(s);
        sb.append(" value from among: ");
        sb.append(Arrays.toString((Object[])array));
        Log.i("CameraConfiguration", sb.toString());
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("Supported ");
        sb2.append(s);
        sb2.append(" values: ");
        sb2.append((Object)collection);
        Log.i("CameraConfiguration", sb2.toString());
        if (collection != null) {
            for (final String s2 : array) {
                if (collection.contains((Object)s2)) {
                    final StringBuilder sb3 = new StringBuilder();
                    sb3.append("Can set ");
                    sb3.append(s);
                    sb3.append(" to: ");
                    sb3.append(s2);
                    Log.i("CameraConfiguration", sb3.toString());
                    return s2;
                }
            }
        }
        Log.i("CameraConfiguration", "No supported values match");
        return null;
    }
    
    public static void c(final Camera$Parameters camera$Parameters) {
        if ("barcode".equals((Object)camera$Parameters.getSceneMode())) {
            Log.i("CameraConfiguration", "Barcode scene mode already set");
            return;
        }
        final String b = b("scene mode", (Collection)camera$Parameters.getSupportedSceneModes(), "barcode");
        if (b != null) {
            camera$Parameters.setSceneMode(b);
        }
    }
    
    public static void d(final Camera$Parameters camera$Parameters, final boolean b) {
        final int minExposureCompensation = camera$Parameters.getMinExposureCompensation();
        final int maxExposureCompensation = camera$Parameters.getMaxExposureCompensation();
        final float exposureCompensationStep = camera$Parameters.getExposureCompensationStep();
        if (minExposureCompensation != 0 || maxExposureCompensation != 0) {
            float n = 0.0f;
            if (exposureCompensationStep > 0.0f) {
                if (!b) {
                    n = 1.5f;
                }
                final int round = Math.round(n / exposureCompensationStep);
                final float n2 = exposureCompensationStep * round;
                final int max = Math.max(Math.min(round, maxExposureCompensation), minExposureCompensation);
                if (camera$Parameters.getExposureCompensation() == max) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append("Exposure compensation already set to ");
                    sb.append(max);
                    sb.append(" / ");
                    sb.append(n2);
                    Log.i("CameraConfiguration", sb.toString());
                    return;
                }
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("Setting exposure compensation to ");
                sb2.append(max);
                sb2.append(" / ");
                sb2.append(n2);
                Log.i("CameraConfiguration", sb2.toString());
                camera$Parameters.setExposureCompensation(max);
                return;
            }
        }
        Log.i("CameraConfiguration", "Camera does not support exposure compensation");
    }
    
    public static void e(final Camera$Parameters camera$Parameters) {
        f(camera$Parameters, 10, 20);
    }
    
    public static void f(final Camera$Parameters camera$Parameters, final int n, final int n2) {
        final List supportedPreviewFpsRange = camera$Parameters.getSupportedPreviewFpsRange();
        final StringBuilder sb = new StringBuilder();
        sb.append("Supported FPS ranges: ");
        sb.append(n((Collection)supportedPreviewFpsRange));
        Log.i("CameraConfiguration", sb.toString());
        if (supportedPreviewFpsRange != null && !supportedPreviewFpsRange.isEmpty()) {
            while (true) {
                for (final int[] array : supportedPreviewFpsRange) {
                    final int n3 = array[0];
                    final int n4 = array[1];
                    if (n3 >= n * 1000 && n4 <= n2 * 1000) {
                        if (array == null) {
                            Log.i("CameraConfiguration", "No suitable FPS range?");
                            return;
                        }
                        final int[] array2 = new int[2];
                        camera$Parameters.getPreviewFpsRange(array2);
                        if (Arrays.equals(array2, array)) {
                            final StringBuilder sb2 = new StringBuilder();
                            sb2.append("FPS range already set to ");
                            sb2.append(Arrays.toString(array));
                            Log.i("CameraConfiguration", sb2.toString());
                            return;
                        }
                        final StringBuilder sb3 = new StringBuilder();
                        sb3.append("Setting FPS range to ");
                        sb3.append(Arrays.toString(array));
                        Log.i("CameraConfiguration", sb3.toString());
                        camera$Parameters.setPreviewFpsRange(array[0], array[1]);
                        return;
                    }
                }
                int[] array = null;
                continue;
            }
        }
    }
    
    public static void g(final Camera$Parameters camera$Parameters, final i.a a, final boolean b) {
        final List supportedFocusModes = camera$Parameters.getSupportedFocusModes();
        String s;
        if (!b && a != i.a.AUTO) {
            if (a == i.a.CONTINUOUS) {
                s = b("focus mode", (Collection)supportedFocusModes, "continuous-picture", "continuous-video", "auto");
            }
            else if (a == i.a.INFINITY) {
                s = b("focus mode", (Collection)supportedFocusModes, "infinity");
            }
            else if (a == i.a.MACRO) {
                s = b("focus mode", (Collection)supportedFocusModes, "macro");
            }
            else {
                s = null;
            }
        }
        else {
            s = b("focus mode", (Collection)supportedFocusModes, "auto");
        }
        String b2 = s;
        if (!b && (b2 = s) == null) {
            b2 = b("focus mode", (Collection)supportedFocusModes, "macro", "edof");
        }
        if (b2 != null) {
            if (b2.equals((Object)camera$Parameters.getFocusMode())) {
                final StringBuilder sb = new StringBuilder();
                sb.append("Focus mode already set to ");
                sb.append(b2);
                Log.i("CameraConfiguration", sb.toString());
            }
            else {
                camera$Parameters.setFocusMode(b2);
            }
        }
    }
    
    public static void h(final Camera$Parameters camera$Parameters) {
        if (camera$Parameters.getMaxNumFocusAreas() > 0) {
            final StringBuilder sb = new StringBuilder();
            sb.append("Old focus areas: ");
            sb.append(m((Iterable)camera$Parameters.getFocusAreas()));
            Log.i("CameraConfiguration", sb.toString());
            final List a = a(400);
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("Setting focus area to : ");
            sb2.append(m((Iterable)a));
            Log.i("CameraConfiguration", sb2.toString());
            camera$Parameters.setFocusAreas(a);
        }
        else {
            Log.i("CameraConfiguration", "Device does not support focus areas");
        }
    }
    
    public static void i(final Camera$Parameters camera$Parameters) {
        if ("negative".equals((Object)camera$Parameters.getColorEffect())) {
            Log.i("CameraConfiguration", "Negative effect already set");
            return;
        }
        final String b = b("color effect", (Collection)camera$Parameters.getSupportedColorEffects(), "negative");
        if (b != null) {
            camera$Parameters.setColorEffect(b);
        }
    }
    
    public static void j(final Camera$Parameters camera$Parameters) {
        if (camera$Parameters.getMaxNumMeteringAreas() > 0) {
            final StringBuilder sb = new StringBuilder();
            sb.append("Old metering areas: ");
            sb.append((Object)camera$Parameters.getMeteringAreas());
            Log.i("CameraConfiguration", sb.toString());
            final List a = a(400);
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("Setting metering area to : ");
            sb2.append(m((Iterable)a));
            Log.i("CameraConfiguration", sb2.toString());
            camera$Parameters.setMeteringAreas(a);
        }
        else {
            Log.i("CameraConfiguration", "Device does not support metering areas");
        }
    }
    
    public static void k(final Camera$Parameters camera$Parameters, final boolean b) {
        final List supportedFlashModes = camera$Parameters.getSupportedFlashModes();
        String flashMode;
        if (b) {
            flashMode = b("flash mode", (Collection)supportedFlashModes, "torch", "on");
        }
        else {
            flashMode = b("flash mode", (Collection)supportedFlashModes, "off");
        }
        if (flashMode != null) {
            if (flashMode.equals((Object)camera$Parameters.getFlashMode())) {
                final StringBuilder sb = new StringBuilder();
                sb.append("Flash mode already set to ");
                sb.append(flashMode);
                Log.i("CameraConfiguration", sb.toString());
            }
            else {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("Setting flash mode to ");
                sb2.append(flashMode);
                Log.i("CameraConfiguration", sb2.toString());
                camera$Parameters.setFlashMode(flashMode);
            }
        }
    }
    
    public static void l(final Camera$Parameters camera$Parameters) {
        if (camera$Parameters.isVideoStabilizationSupported()) {
            if (camera$Parameters.getVideoStabilization()) {
                Log.i("CameraConfiguration", "Video stabilization already enabled");
            }
            else {
                Log.i("CameraConfiguration", "Enabling video stabilization...");
                camera$Parameters.setVideoStabilization(true);
            }
        }
        else {
            Log.i("CameraConfiguration", "This device does not support video stabilization");
        }
    }
    
    private static String m(final Iterable iterable) {
        if (iterable == null) {
            return null;
        }
        final StringBuilder sb = new StringBuilder();
        for (final Camera$Area camera$Area : iterable) {
            sb.append((Object)camera$Area.rect);
            sb.append(':');
            sb.append(camera$Area.weight);
            sb.append(' ');
        }
        return sb.toString();
    }
    
    private static String n(final Collection collection) {
        if (collection != null && !collection.isEmpty()) {
            final StringBuilder sb = new StringBuilder();
            sb.append('[');
            final Iterator iterator = collection.iterator();
            while (iterator.hasNext()) {
                sb.append(Arrays.toString((int[])iterator.next()));
                if (iterator.hasNext()) {
                    sb.append(", ");
                }
            }
            sb.append(']');
            return sb.toString();
        }
        return "[]";
    }
}
