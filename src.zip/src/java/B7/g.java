package B7;

import A7.r;
import A7.t;
import android.util.Log;
import android.content.Context;
import android.os.Handler;

public class g
{
    private static final String n = "g";
    private k a;
    private j b;
    private h c;
    private Handler d;
    private m e;
    private boolean f;
    private boolean g;
    private Handler h;
    private i i;
    private Runnable j;
    private Runnable k;
    private Runnable l;
    private Runnable m;
    
    public g(final Context context) {
        this.f = false;
        this.g = true;
        this.i = new i();
        this.j = (Runnable)new Runnable() {
            final g a;
            
            public void run() {
                try {
                    Log.d(B7.g.n, "Opening camera");
                    this.a.c.l();
                }
                catch (final Exception ex) {
                    this.a.t(ex);
                    Log.e(B7.g.n, "Failed to open camera", (Throwable)ex);
                }
            }
        };
        this.k = (Runnable)new Runnable() {
            final g a;
            
            public void run() {
                try {
                    Log.d(B7.g.n, "Configuring camera");
                    this.a.c.e();
                    if (this.a.d != null) {
                        this.a.d.obtainMessage(d7.k.j, (Object)this.a.o()).sendToTarget();
                    }
                }
                catch (final Exception ex) {
                    this.a.t(ex);
                    Log.e(B7.g.n, "Failed to configure camera", (Throwable)ex);
                }
            }
        };
        this.l = (Runnable)new Runnable() {
            final g a;
            
            public void run() {
                try {
                    Log.d(B7.g.n, "Starting preview");
                    this.a.c.s(this.a.b);
                    this.a.c.u();
                }
                catch (final Exception ex) {
                    this.a.t(ex);
                    Log.e(B7.g.n, "Failed to start preview", (Throwable)ex);
                }
            }
        };
        this.m = (Runnable)new Runnable() {
            final g a;
            
            public void run() {
                try {
                    Log.d(B7.g.n, "Closing camera");
                    this.a.c.v();
                    this.a.c.d();
                }
                catch (final Exception ex) {
                    Log.e(B7.g.n, "Failed to close camera", (Throwable)ex);
                }
                this.a.g = true;
                this.a.d.sendEmptyMessage(d7.k.c);
                this.a.a.b();
            }
        };
        t.a();
        this.a = B7.k.d();
        (this.c = new h(context)).o(this.i);
        this.h = new Handler();
    }
    
    private void C() {
        if (this.f) {
            return;
        }
        throw new IllegalStateException("CameraInstance is not open");
    }
    
    private r o() {
        return this.c.h();
    }
    
    private void t(final Exception ex) {
        final Handler d = this.d;
        if (d != null) {
            d.obtainMessage(d7.k.d, (Object)ex).sendToTarget();
        }
    }
    
    public void A(final boolean b) {
        t.a();
        if (this.f) {
            this.a.c((Runnable)new e(this, b));
        }
    }
    
    public void B() {
        t.a();
        this.C();
        this.a.c(this.l);
    }
    
    public void l() {
        t.a();
        if (this.f) {
            this.a.c(this.m);
        }
        else {
            this.g = true;
        }
        this.f = false;
    }
    
    public void m() {
        t.a();
        this.C();
        this.a.c(this.k);
    }
    
    public m n() {
        return this.e;
    }
    
    public boolean p() {
        return this.g;
    }
    
    public void u() {
        t.a();
        this.f = true;
        this.g = false;
        this.a.e(this.j);
    }
    
    public void v(final p p) {
        this.h.post((Runnable)new d(this, p));
    }
    
    public void w(final i i) {
        if (!this.f) {
            this.i = i;
            this.c.o(i);
        }
    }
    
    public void x(final m e) {
        this.e = e;
        this.c.q(e);
    }
    
    public void y(final Handler d) {
        this.d = d;
    }
    
    public void z(final j b) {
        this.b = b;
    }
}
