package B7;

import A7.s;
import android.hardware.Camera$PreviewCallback;
import android.os.Build;
import java.util.Iterator;
import android.hardware.Camera$Size;
import java.util.ArrayList;
import java.util.List;
import android.hardware.Camera$Parameters;
import android.util.Log;
import android.content.Context;
import A7.r;
import d7.b;
import android.hardware.Camera$CameraInfo;
import android.hardware.Camera;

public final class h
{
    private static final String n = "h";
    private Camera a;
    private Camera$CameraInfo b;
    private B7.a c;
    private b d;
    private boolean e;
    private String f;
    private i g;
    private m h;
    private r i;
    private r j;
    private int k;
    private Context l;
    private final a m;
    
    public h(final Context l) {
        this.g = new i();
        this.k = -1;
        this.l = l;
        this.m = new a();
    }
    
    private int c() {
        final int c = this.h.c();
        int n2;
        final int n = n2 = 0;
        if (c != 0) {
            if (c != 1) {
                if (c != 2) {
                    if (c != 3) {
                        n2 = n;
                    }
                    else {
                        n2 = 270;
                    }
                }
                else {
                    n2 = 180;
                }
            }
            else {
                n2 = 90;
            }
        }
        final Camera$CameraInfo b = this.b;
        int n3;
        if (b.facing == 1) {
            n3 = (360 - (b.orientation + n2) % 360) % 360;
        }
        else {
            n3 = (b.orientation - n2 + 360) % 360;
        }
        final String n4 = B7.h.n;
        final StringBuilder sb = new StringBuilder();
        sb.append("Camera Display Orientation: ");
        sb.append(n3);
        Log.i(n4, sb.toString());
        return n3;
    }
    
    private Camera$Parameters g() {
        final Camera$Parameters parameters = this.a.getParameters();
        final String f = this.f;
        if (f == null) {
            this.f = parameters.flatten();
        }
        else {
            parameters.unflatten(f);
        }
        return parameters;
    }
    
    private static List i(final Camera$Parameters camera$Parameters) {
        final List supportedPreviewSizes = camera$Parameters.getSupportedPreviewSizes();
        final ArrayList list = new ArrayList();
        if (supportedPreviewSizes == null) {
            final Camera$Size previewSize = camera$Parameters.getPreviewSize();
            if (previewSize != null) {
                new r(previewSize.width, previewSize.height);
                ((List)list).add((Object)new r(previewSize.width, previewSize.height));
            }
            return (List)list;
        }
        for (final Camera$Size camera$Size : supportedPreviewSizes) {
            ((List)list).add((Object)new r(camera$Size.width, camera$Size.height));
        }
        return (List)list;
    }
    
    private void n(final int displayOrientation) {
        this.a.setDisplayOrientation(displayOrientation);
    }
    
    private void p(final boolean b) {
        final Camera$Parameters g = this.g();
        if (g == null) {
            Log.w(B7.h.n, "Device error: no camera parameters are available. Proceeding without configuration.");
            return;
        }
        final String n = B7.h.n;
        final StringBuilder sb = new StringBuilder();
        sb.append("Initial camera parameters: ");
        sb.append(g.flatten());
        Log.i(n, sb.toString());
        if (b) {
            Log.w(n, "In camera config safe mode -- most settings will not be honored");
        }
        B7.c.g(g, this.g.a(), b);
        if (!b) {
            B7.c.k(g, false);
            if (this.g.h()) {
                B7.c.i(g);
            }
            if (this.g.e()) {
                B7.c.c(g);
            }
            if (this.g.g()) {
                B7.c.l(g);
                B7.c.h(g);
                B7.c.j(g);
            }
        }
        final List i = i(g);
        if (i.size() == 0) {
            this.i = null;
        }
        else {
            final r a = this.h.a(i, this.j());
            this.i = a;
            g.setPreviewSize(a.a, a.b);
        }
        if (Build.DEVICE.equals((Object)"glass-1")) {
            B7.c.e(g);
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("Final camera parameters: ");
        sb2.append(g.flatten());
        Log.i(n, sb2.toString());
        this.a.setParameters(g);
    }
    
    private void r() {
        try {
            this.n(this.k = this.c());
        }
        catch (final Exception ex) {
            Log.w(B7.h.n, "Failed to set rotation.");
        }
        try {
            this.p(false);
        }
        catch (final Exception ex2) {
            try {
                this.p(true);
            }
            catch (final Exception ex3) {
                Log.w(B7.h.n, "Camera rejected even safe-mode parameters! No configuration");
            }
        }
        final Camera$Size previewSize = this.a.getParameters().getPreviewSize();
        if (previewSize == null) {
            this.j = this.i;
        }
        else {
            this.j = new r(previewSize.width, previewSize.height);
        }
        this.m.b(this.j);
    }
    
    public void d() {
        final Camera a = this.a;
        if (a != null) {
            a.release();
            this.a = null;
        }
    }
    
    public void e() {
        if (this.a != null) {
            this.r();
            return;
        }
        throw new RuntimeException("Camera not open");
    }
    
    public int f() {
        return this.k;
    }
    
    public r h() {
        if (this.j == null) {
            return null;
        }
        if (this.j()) {
            return this.j.c();
        }
        return this.j;
    }
    
    public boolean j() {
        final int k = this.k;
        if (k != -1) {
            return k % 180 != 0;
        }
        throw new IllegalStateException("Rotation not calculated yet. Call configure() first.");
    }
    
    public boolean k() {
        final Camera$Parameters parameters = this.a.getParameters();
        boolean b2;
        final boolean b = b2 = false;
        if (parameters != null) {
            final String flashMode = parameters.getFlashMode();
            b2 = b;
            if (flashMode != null) {
                if (!"on".equals((Object)flashMode)) {
                    b2 = b;
                    if (!"torch".equals((Object)flashMode)) {
                        return b2;
                    }
                }
                b2 = true;
            }
        }
        return b2;
    }
    
    public void l() {
        final Camera b = e7.a.b(this.g.b());
        this.a = b;
        if (b != null) {
            Camera.getCameraInfo(e7.a.a(this.g.b()), this.b = new Camera$CameraInfo());
            return;
        }
        throw new RuntimeException("Failed to open camera");
    }
    
    public void m(final p p) {
        final Camera a = this.a;
        if (a != null && this.e) {
            this.m.a(p);
            a.setOneShotPreviewCallback((Camera$PreviewCallback)this.m);
        }
    }
    
    public void o(final i g) {
        this.g = g;
    }
    
    public void q(final m h) {
        this.h = h;
    }
    
    public void s(final j j) {
        j.a(this.a);
    }
    
    public void t(final boolean b) {
        if (this.a != null) {
            Label_0087: {
                try {
                    if (b == this.k()) {
                        return;
                    }
                    final B7.a c = this.c;
                    if (c != null) {
                        c.j();
                    }
                }
                catch (final RuntimeException ex) {
                    break Label_0087;
                }
                final Camera$Parameters parameters = this.a.getParameters();
                B7.c.k(parameters, b);
                if (this.g.f()) {
                    B7.c.d(parameters, b);
                }
                this.a.setParameters(parameters);
                final B7.a c2 = this.c;
                if (c2 != null) {
                    c2.i();
                    return;
                }
                return;
            }
            final RuntimeException ex;
            Log.e(B7.h.n, "Failed to set torch", (Throwable)ex);
        }
    }
    
    public void u() {
        final Camera a = this.a;
        if (a != null && !this.e) {
            a.startPreview();
            this.e = true;
            this.c = new B7.a(this.a, this.g);
            (this.d = new b(this.l, this, this.g)).d();
        }
    }
    
    public void v() {
        final B7.a c = this.c;
        if (c != null) {
            c.j();
            this.c = null;
        }
        final b d = this.d;
        if (d != null) {
            d.e();
            this.d = null;
        }
        final Camera a = this.a;
        if (a != null && this.e) {
            a.stopPreview();
            this.m.a(null);
            this.e = false;
        }
    }
    
    private final class a implements Camera$PreviewCallback
    {
        private p a;
        private r b;
        final h c;
        
        public a(final h c) {
            this.c = c;
        }
        
        public void a(final p a) {
            this.a = a;
        }
        
        public void b(final r b) {
            this.b = b;
        }
        
        public void onPreviewFrame(final byte[] array, final Camera camera) {
            final r b = this.b;
            final p a = this.a;
            if (b != null && a != null) {
                if (array == null) {
                    throw new NullPointerException("No preview data received");
                }
                Label_0110: {
                    s s;
                    try {
                        s = new s(array, b.a, b.b, camera.getParameters().getPreviewFormat(), this.c.f());
                        if (this.c.b.facing == 1) {
                            s.e(true);
                        }
                    }
                    catch (final RuntimeException ex) {
                        break Label_0110;
                    }
                    a.b(s);
                    return;
                }
                final RuntimeException ex;
                Log.e(B7.h.n, "Camera preview failed", (Throwable)ex);
                a.a((Exception)ex);
            }
            else {
                Log.d(B7.h.n, "Got preview callback, but no handler or resolution available");
                if (a != null) {
                    a.a(new Exception("No resolution available"));
                }
            }
        }
    }
}
