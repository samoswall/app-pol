package B7;

public class i
{
    private int a;
    private boolean b;
    private boolean c;
    private boolean d;
    private boolean e;
    private boolean f;
    private boolean g;
    private boolean h;
    private a i;
    
    public i() {
        this.a = -1;
        this.b = false;
        this.c = false;
        this.d = false;
        this.e = true;
        this.f = false;
        this.g = false;
        this.h = false;
        this.i = B7.i.a.AUTO;
    }
    
    public a a() {
        return this.i;
    }
    
    public int b() {
        return this.a;
    }
    
    public boolean c() {
        return this.e;
    }
    
    public boolean d() {
        return this.h;
    }
    
    public boolean e() {
        return this.c;
    }
    
    public boolean f() {
        return this.g;
    }
    
    public boolean g() {
        return this.d;
    }
    
    public boolean h() {
        return this.b;
    }
    
    public void i(final int a) {
        this.a = a;
    }
    
    public enum a
    {
        private static final a[] $VALUES;
        
        AUTO, 
        CONTINUOUS, 
        INFINITY, 
        MACRO;
        
        private static /* synthetic */ a[] $values() {
            return new a[] { a.AUTO, a.CONTINUOUS, a.INFINITY, a.MACRO };
        }
        
        static {
            $VALUES = $values();
        }
    }
}
