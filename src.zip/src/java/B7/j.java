package B7;

import android.hardware.Camera;
import android.graphics.SurfaceTexture;
import android.view.SurfaceHolder;

public class j
{
    private SurfaceHolder a;
    private SurfaceTexture b;
    
    public j(final SurfaceTexture b) {
        if (b != null) {
            this.b = b;
            return;
        }
        throw new IllegalArgumentException("surfaceTexture may not be null");
    }
    
    public j(final SurfaceHolder a) {
        if (a != null) {
            this.a = a;
            return;
        }
        throw new IllegalArgumentException("surfaceHolder may not be null");
    }
    
    public void a(final Camera camera) {
        final SurfaceHolder a = this.a;
        if (a != null) {
            camera.setPreviewDisplay(a);
        }
        else {
            camera.setPreviewTexture(this.b);
        }
    }
}
