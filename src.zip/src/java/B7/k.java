package B7;

import android.os.HandlerThread;
import android.os.Handler;

class k
{
    private static k e;
    private Handler a;
    private HandlerThread b;
    private int c;
    private final Object d;
    
    private k() {
        this.c = 0;
        this.d = new Object();
    }
    
    private void a() {
        final Object d;
        monitorenter(d = this.d);
        Label_0081: {
            try {
                if (this.a != null) {
                    break Label_0081;
                }
                if (this.c > 0) {
                    ((Thread)(this.b = new HandlerThread("CameraThread"))).start();
                    this.a = new Handler(this.b.getLooper());
                    break Label_0081;
                }
                throw new IllegalStateException("CameraThread is not open");
            }
            finally {
                monitorexit(d);
                throw new IllegalStateException("CameraThread is not open");
                monitorexit(d);
            }
        }
    }
    
    public static k d() {
        if (k.e == null) {
            k.e = new k();
        }
        return k.e;
    }
    
    private void f() {
        final Object d = this.d;
        synchronized (d) {
            this.b.quit();
            this.b = null;
            this.a = null;
        }
    }
    
    protected void b() {
        final Object d;
        monitorenter(d = this.d);
        Label_0037: {
            try {
                final int c = this.c - 1;
                this.c = c;
                if (c == 0) {
                    this.f();
                }
                break Label_0037;
            }
            finally {
                monitorexit(d);
                monitorexit(d);
            }
        }
    }
    
    protected void c(final Runnable runnable) {
        final Object d = this.d;
        synchronized (d) {
            this.a();
            this.a.post(runnable);
        }
    }
    
    protected void e(final Runnable runnable) {
        final Object d = this.d;
        synchronized (d) {
            ++this.c;
            this.c(runnable);
        }
    }
}
