package B7;

import android.util.Log;
import android.graphics.Rect;
import A7.r;

public class l extends q
{
    private static final String b = "l";
    
    @Override
    protected float c(final r r, final r r2) {
        if (r.a > 0 && r.b > 0) {
            final r e = r.e(r2);
            float n2;
            final float n = n2 = e.a * 1.0f / r.a;
            if (n > 1.0f) {
                n2 = (float)Math.pow((double)(1.0f / n), 1.1);
            }
            final float n3 = e.a * 1.0f / r2.a + e.b * 1.0f / r2.b;
            return n2 * (1.0f / n3 / n3);
        }
        return 0.0f;
    }
    
    @Override
    public Rect d(final r r, final r r2) {
        final r e = r.e(r2);
        final String b = l.b;
        final StringBuilder sb = new StringBuilder();
        sb.append("Preview: ");
        sb.append((Object)r);
        sb.append("; Scaled: ");
        sb.append((Object)e);
        sb.append("; Want: ");
        sb.append((Object)r2);
        Log.i(b, sb.toString());
        final int n = (e.a - r2.a) / 2;
        final int n2 = (e.b - r2.b) / 2;
        return new Rect(-n, -n2, e.a - n, e.b - n2);
    }
}
