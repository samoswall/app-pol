package B7;

import android.graphics.Rect;
import java.util.List;
import A7.r;

public class m
{
    private r a;
    private int b;
    private boolean c;
    private q d;
    
    public m(final int b, final r a) {
        this.c = false;
        this.d = new n();
        this.b = b;
        this.a = a;
    }
    
    public r a(final List list, final boolean b) {
        return this.d.b(list, this.b(b));
    }
    
    public r b(final boolean b) {
        final r a = this.a;
        if (a == null) {
            return null;
        }
        r c = a;
        if (b) {
            c = a.c();
        }
        return c;
    }
    
    public int c() {
        return this.b;
    }
    
    public Rect d(final r r) {
        return this.d.d(r, this.a);
    }
    
    public void e(final q d) {
        this.d = d;
    }
}
