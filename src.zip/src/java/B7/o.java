package B7;

import android.graphics.Rect;
import A7.r;

public class o extends q
{
    private static float e(final float n) {
        if (n < 1.0f) {
            return 1.0f / n;
        }
        return n;
    }
    
    @Override
    protected float c(final r r, final r r2) {
        final int a = r.a;
        if (a > 0 && r.b > 0) {
            final float n = 1.0f / e(a * 1.0f / r2.a) / e(r.b * 1.0f / r2.b);
            final float e = e(r.a * 1.0f / r.b / (r2.a * 1.0f / r2.b));
            return n * (1.0f / e / e / e);
        }
        return 0.0f;
    }
    
    @Override
    public Rect d(final r r, final r r2) {
        return new Rect(0, 0, r2.a, r2.b);
    }
}
