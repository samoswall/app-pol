package B7;

import A7.s;

public interface p
{
    void a(final Exception p0);
    
    void b(final s p0);
}
