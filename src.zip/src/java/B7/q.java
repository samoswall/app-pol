package B7;

import android.graphics.Rect;
import android.util.Log;
import java.util.Collections;
import java.util.Comparator;
import A7.r;
import java.util.List;

public abstract class q
{
    private static final String a = "q";
    
    public List a(final List list, final r r) {
        if (r == null) {
            return list;
        }
        Collections.sort(list, (Comparator)new Comparator(this, r) {
            final r a;
            final q b;
            
            public int a(final r r, final r r2) {
                return Float.compare(this.b.c(r2, this.a), this.b.c(r, this.a));
            }
        });
        return list;
    }
    
    public r b(List a, final r r) {
        a = this.a(a, r);
        final String a2 = q.a;
        final StringBuilder sb = new StringBuilder();
        sb.append("Viewfinder size: ");
        sb.append((Object)r);
        Log.i(a2, sb.toString());
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("Preview in order of preference: ");
        sb2.append((Object)a);
        Log.i(a2, sb2.toString());
        return (r)a.get(0);
    }
    
    protected abstract float c(final r p0, final r p1);
    
    public abstract Rect d(final r p0, final r p1);
}
