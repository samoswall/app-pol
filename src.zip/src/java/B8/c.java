package B8;

import com.syncleoiot.core.application.auth.usecases.SignOutUseCase;
import K8.x;
import Q8.b;
import i9.M;
import P8.d;
import com.syncleoiot.core.application.auth.AuthViewModel;
import X8.p;
import kotlin.coroutines.jvm.internal.l;

public final class c extends l implements p
{
    public int y;
    public final AuthViewModel z;
    
    public c(final AuthViewModel z, final d d) {
        this.z = z;
        super(2, d);
    }
    
    public final d create(final Object o, final d d) {
        return (d)new c(this.z, d);
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final M m = (M)o;
        return new c(this.z, (d)o2).invokeSuspend(K8.M.a);
    }
    
    public final Object invokeSuspend(final Object o) {
        final Object f = b.f();
        final int y = this.y;
        if (y != 0) {
            if (y != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            x.b(o);
        }
        else {
            x.b(o);
            AuthViewModel.access$get_isAnonSkipped$p(this.z).setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
            final SignOutUseCase access$getSignOut$p = AuthViewModel.access$getSignOut$p(this.z);
            this.y = 1;
            if (access$getSignOut$p.invoke((d)this) == f) {
                return f;
            }
        }
        AuthViewModel.access$getUserDeviceManager$p(this.z).deleteDeleted();
        return K8.M.a;
    }
}
