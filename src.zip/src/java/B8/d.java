package B8;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.syncleoiot.core.application.auth.SignInViewModel;
import com.syncleoiot.core.domain.auth.entities.YandexSignInAccount;

public final class d extends kotlin.coroutines.jvm.internal.d
{
    public YandexSignInAccount A;
    public Object B;
    public final SignInViewModel C;
    public int H;
    public SignInViewModel y;
    public GoogleSignInAccount z;
    
    public d(final SignInViewModel c, final P8.d d) {
        this.C = c;
        super(d);
    }
    
    public final Object invokeSuspend(final Object b) {
        this.B = b;
        this.H |= Integer.MIN_VALUE;
        return SignInViewModel.access$checkAndUpdateProfile(this.C, (GoogleSignInAccount)null, (YandexSignInAccount)null, (P8.d)this);
    }
}
