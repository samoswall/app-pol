package B8;

import com.syncleoiot.core.application.auth.usecases.InitAuthWithEmailUseCase;
import com.syncleoiot.core.application.auth.usecases.InitAuthWithPhoneUseCase;
import com.syncleoiot.core.domain.auth.entities.Initiation;
import K8.s;
import com.syncleoiot.core.domain.core.objects.Either$Right;
import com.syncleoiot.core.domain.auth.AuthFailure$TooManyRequests;
import com.syncleoiot.core.domain.auth.AuthFailure$AlreadyAuthorized;
import com.syncleoiot.core.domain.auth.AuthFailure;
import com.syncleoiot.core.domain.core.objects.Either$Left;
import com.syncleoiot.core.domain.core.objects.Either;
import com.syncleoiot.core.domain.auth.EmailAddress;
import kotlin.jvm.internal.v;
import android.content.Context;
import android.widget.Toast;
import com.syncleoiot.core.R$string;
import com.syncleoiot.core.domain.core.failures.IFailable;
import com.syncleoiot.core.domain.core.failures.FailuresKt;
import com.syncleoiot.core.domain.auth.PhoneNumber;
import com.syncleoiot.core.domain.auth.IdentityType;
import K8.x;
import Q8.b;
import i9.M;
import P8.d;
import com.syncleoiot.core.application.auth.SignInViewModel;
import X8.p;
import kotlin.coroutines.jvm.internal.l;

public final class e extends l implements p
{
    public int y;
    public final SignInViewModel z;
    
    public e(final SignInViewModel z, final d d) {
        this.z = z;
        super(2, d);
    }
    
    public final d create(final Object o, final d d) {
        return (d)new e(this.z, d);
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final M m = (M)o;
        return new e(this.z, (d)o2).invokeSuspend(K8.M.a);
    }
    
    public final Object invokeSuspend(Object o) {
        final Object f = b.f();
        final int y = this.y;
        Either value = null;
        Label_0304: {
            Label_0299: {
                if (y != 0) {
                    if (y != 1) {
                        if (y == 2) {
                            x.b(o);
                            break Label_0299;
                        }
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    else {
                        x.b(o);
                    }
                }
                else {
                    x.b(o);
                    SignInViewModel.access$get_response$p(this.z).setValue((Object)"");
                    if (this.z.getAuthMethod().getValue() == IdentityType.PHONE) {
                        final PhoneNumber phoneNumber = (PhoneNumber)SignInViewModel.access$get_phoneLogin$p(this.z).getValue();
                        if (!FailuresKt.isValid((IFailable)phoneNumber)) {
                            Toast.makeText((Context)this.z.getContext(), R$string.phone_invalid, 1).show();
                            return K8.M.a;
                        }
                        SignInViewModel.access$get_isSubmitting$p(this.z).setValue((Object)kotlin.coroutines.jvm.internal.b.a(true));
                        final l9.x access$get_phoneLogin$p = SignInViewModel.access$get_phoneLogin$p(this.z);
                        final String formattedValueOrCrash = phoneNumber.getFormattedValueOrCrash();
                        v.g((Object)formattedValueOrCrash);
                        access$get_phoneLogin$p.setValue((Object)new PhoneNumber(formattedValueOrCrash));
                        final InitAuthWithPhoneUseCase access$getInitAuthWithPhoneUseCase$p = SignInViewModel.access$getInitAuthWithPhoneUseCase$p(this.z);
                        this.y = 1;
                        if ((o = access$getInitAuthWithPhoneUseCase$p.invoke(phoneNumber, (d)this)) == f) {
                            return f;
                        }
                    }
                    else {
                        final EmailAddress emailAddress = (EmailAddress)SignInViewModel.access$get_emailLogin$p(this.z).getValue();
                        if (!FailuresKt.isValid((IFailable)emailAddress)) {
                            Toast.makeText((Context)this.z.getContext(), R$string.email_invalid, 1).show();
                            return K8.M.a;
                        }
                        SignInViewModel.access$get_isSubmitting$p(this.z).setValue((Object)kotlin.coroutines.jvm.internal.b.a(true));
                        final InitAuthWithEmailUseCase access$getInitAuthWithEmailUseCase$p = SignInViewModel.access$getInitAuthWithEmailUseCase$p(this.z);
                        this.y = 2;
                        if ((o = access$getInitAuthWithEmailUseCase$p.invoke(emailAddress, (d)this)) == f) {
                            return f;
                        }
                        break Label_0299;
                    }
                }
                value = (Either)o;
                break Label_0304;
            }
            value = (Either)o;
        }
        SignInViewModel.access$get_isSubmitting$p(this.z).setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
        SignInViewModel.access$get_initiation$p(this.z).setValue((Object)value);
        final SignInViewModel z = this.z;
        if (value instanceof Either$Left) {
            final AuthFailure authFailure = (AuthFailure)((Either$Left)value).getValue();
            if (!v.e((Object)authFailure, (Object)AuthFailure$AlreadyAuthorized.INSTANCE) && authFailure instanceof AuthFailure$TooManyRequests) {
                final long retryAfterTimestamp = ((AuthFailure$TooManyRequests)authFailure).getRetryAfterTimestamp();
                if (retryAfterTimestamp > 0L) {
                    SignInViewModel.access$startTimer(z, retryAfterTimestamp);
                }
            }
        }
        else {
            if (!(value instanceof Either$Right)) {
                throw new s();
            }
            final Initiation initiation = (Initiation)((Either$Right)value).getValue();
            SignInViewModel.access$startTimer(z, System.currentTimeMillis() + 60000);
        }
        return K8.M.a;
    }
}
