package B8;

import i9.X;
import d9.n;
import K8.x;
import Q8.b;
import K8.M;
import P8.d;
import com.syncleoiot.core.application.auth.SignInViewModel;
import X8.p;
import kotlin.coroutines.jvm.internal.l;

public final class f extends l implements p
{
    public final SignInViewModel A;
    public final long B;
    public int y;
    public final long z;
    
    public f(final long z, final SignInViewModel a, final long b, final d d) {
        this.z = z;
        this.A = a;
        this.B = b;
        super(2, d);
    }
    
    public final d create(final Object o, final d d) {
        return (d)new f(this.z, this.A, this.B, d);
    }
    
    public final Object invoke(final Object o, final Object o2) {
        return ((f)this.create(o, (d)o2)).invokeSuspend(M.a);
    }
    
    public final Object invokeSuspend(final Object o) {
        final Object f = b.f();
        final int y = this.y;
        while (true) {
            Label_0101: {
                long n;
                if (y != 0) {
                    if (y == 1) {
                        x.b(o);
                        break Label_0101;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                else {
                    x.b(o);
                    n = System.currentTimeMillis();
                }
                if (n >= this.z) {
                    SignInViewModel.access$get_resendTimeMillis$p(this.A).setValue((Object)kotlin.coroutines.jvm.internal.b.f(0L));
                    return M.a;
                }
                SignInViewModel.access$get_resendTimeMillis$p(this.A).setValue((Object)kotlin.coroutines.jvm.internal.b.f(d9.n.g(this.z - n, 0L)));
                final long b = this.B;
                this.y = 1;
                if (X.b(b, (d)this) == f) {
                    return f;
                }
            }
            long n = System.currentTimeMillis();
            continue;
        }
    }
}
