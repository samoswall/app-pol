package B8;

import com.syncleoiot.core.domain.profile.ProfileRepository;
import K8.x;
import Q8.b;
import K8.M;
import P8.d;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.syncleoiot.core.application.auth.SignInViewModel;
import com.syncleoiot.core.domain.auth.entities.YandexSignInAccount;
import X8.p;
import kotlin.coroutines.jvm.internal.l;

public final class g extends l implements p
{
    public final YandexSignInAccount A;
    public final SignInViewModel B;
    public int y;
    public final GoogleSignInAccount z;
    
    public g(final GoogleSignInAccount z, final YandexSignInAccount a, final SignInViewModel b, final d d) {
        this.z = z;
        this.A = a;
        this.B = b;
        super(2, d);
    }
    
    public final d create(final Object o, final d d) {
        return (d)new g(this.z, this.A, this.B, d);
    }
    
    public final Object invoke(final Object o, final Object o2) {
        return ((g)this.create(o, (d)o2)).invokeSuspend(M.a);
    }
    
    public final Object invokeSuspend(final Object o) {
        final Object f = b.f();
        final int y = this.y;
        if (y != 0) {
            if (y != 1 && y != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            x.b(o);
        }
        else {
            x.b(o);
            final GoogleSignInAccount z = this.z;
            if (z == null && this.A == null) {
                final ProfileRepository access$getProfileRepository$p = SignInViewModel.access$getProfileRepository$p(this.B);
                this.y = 1;
                if (access$getProfileRepository$p.refreshProfile((d)this) == f) {
                    return f;
                }
            }
            else {
                final SignInViewModel b = this.B;
                final YandexSignInAccount a = this.A;
                this.y = 2;
                if (SignInViewModel.access$checkAndUpdateProfile(b, z, a, (d)this) == f) {
                    return f;
                }
            }
        }
        SignInViewModel.access$getUserDeviceManager$p(this.B).deleteDeleted();
        return M.a;
    }
}
