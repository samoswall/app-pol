package B8;

import com.syncleoiot.core.application.auth.usecases.ResponseAuthUseCase;
import com.syncleoiot.core.domain.auth.entities.YandexSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import K8.s;
import com.syncleoiot.core.domain.core.objects.Either$Right;
import android.content.Context;
import android.widget.Toast;
import com.syncleoiot.core.R$string;
import com.syncleoiot.core.domain.auth.AuthFailure;
import com.syncleoiot.core.domain.core.objects.Either$Left;
import com.syncleoiot.core.domain.core.objects.Either;
import K8.x;
import Q8.b;
import K8.M;
import P8.d;
import com.syncleoiot.core.domain.auth.entities.Initiation;
import com.syncleoiot.core.application.auth.SignInViewModel;
import X8.p;
import kotlin.coroutines.jvm.internal.l;

public final class h extends l implements p
{
    public final SignInViewModel A;
    public final Initiation B;
    public final String C;
    public SignInViewModel y;
    public int z;
    
    public h(final SignInViewModel a, final Initiation b, final String c, final d d) {
        this.A = a;
        this.B = b;
        this.C = c;
        super(2, d);
    }
    
    public final d create(final Object o, final d d) {
        return (d)new h(this.A, this.B, this.C, d);
    }
    
    public final Object invoke(final Object o, final Object o2) {
        return ((h)this.create(o, (d)o2)).invokeSuspend(M.a);
    }
    
    public final Object invokeSuspend(Object invoke) {
        final Object f = b.f();
        final int z = this.z;
        SignInViewModel a = null;
        Label_0238: {
            if (z != 0) {
                if (z != 1) {
                    if (z == 2) {
                        final SignInViewModel y = this.y;
                        x.b(invoke);
                        a = y;
                        break Label_0238;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                else {
                    x.b(invoke);
                }
            }
            else {
                x.b(invoke);
                SignInViewModel.access$get_isSubmitting$p(this.A).setValue((Object)kotlin.coroutines.jvm.internal.b.a(true));
                final ResponseAuthUseCase access$getResponseAuthUseCase$p = SignInViewModel.access$getResponseAuthUseCase$p(this.A);
                final Initiation b = this.B;
                final String c = this.C;
                this.z = 1;
                if ((invoke = access$getResponseAuthUseCase$p.invoke(b, c, (d)this)) == f) {
                    return f;
                }
            }
            final Either value = (Either)invoke;
            SignInViewModel.access$get_responseResult$p(this.A).setValue((Object)value);
            a = this.A;
            if (value instanceof Either$Left) {
                final AuthFailure authFailure = (AuthFailure)((Either$Left)value).getValue();
                Toast.makeText((Context)a.getContext(), R$string.authorization_failed, 1).show();
                SignInViewModel.access$get_isSubmitting$p(a).setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
                return M.a;
            }
            if (!(value instanceof Either$Right)) {
                throw new s();
            }
            final M m = (M)((Either$Right)value).getValue();
            SignInViewModel.access$resetState(a);
            this.y = a;
            this.z = 2;
            if (SignInViewModel.a(a, (GoogleSignInAccount)null, (YandexSignInAccount)null, (l)this, 3) == f) {
                return f;
            }
        }
        SignInViewModel.access$get_isSubmitting$p(a).setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
        return M.a;
    }
}
