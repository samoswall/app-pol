package B8;

import K8.x;
import Q8.b;
import i9.M;
import P8.d;
import com.syncleoiot.core.application.auth.SignInViewModel;
import com.syncleoiot.core.domain.auth.IdentityType;
import X8.p;
import kotlin.coroutines.jvm.internal.l;

public final class i extends l implements p
{
    public final IdentityType y;
    public final SignInViewModel z;
    
    public i(final IdentityType y, final SignInViewModel z, final d d) {
        this.y = y;
        this.z = z;
        super(2, d);
    }
    
    public final d create(final Object o, final d d) {
        return (d)new i(this.y, this.z, d);
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final M m = (M)o;
        return new i(this.y, this.z, (d)o2).invokeSuspend(K8.M.a);
    }
    
    public final Object invokeSuspend(final Object o) {
        b.f();
        x.b(o);
        if (this.y == null) {
            SignInViewModel.access$resetState(this.z);
        }
        else {
            SignInViewModel.access$get_authMethod$p(this.z).setValue((Object)this.y);
        }
        return K8.M.a;
    }
}
