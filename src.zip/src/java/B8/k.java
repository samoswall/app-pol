package B8;

import com.syncleoiot.core.application.auth.usecases.SignInWithGoogleUseCase;
import com.syncleoiot.core.domain.auth.entities.YandexSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import K8.s;
import com.syncleoiot.core.domain.core.objects.Either$Right;
import i9.O;
import P8.g;
import i9.i;
import i9.c0;
import androidx.lifecycle.e0;
import androidx.lifecycle.f0;
import kotlin.jvm.internal.v;
import com.syncleoiot.core.domain.auth.AuthFailure$AlreadyAuthorized;
import com.syncleoiot.core.domain.auth.AuthFailure;
import com.syncleoiot.core.domain.core.objects.Either$Left;
import com.syncleoiot.core.domain.core.objects.Either;
import K8.x;
import Q8.b;
import i9.M;
import P8.d;
import com.google.android.gms.tasks.Task;
import com.syncleoiot.core.application.auth.SignInViewModel;
import X8.p;
import kotlin.coroutines.jvm.internal.l;

public final class k extends l implements p
{
    public final SignInViewModel A;
    public final Task B;
    public SignInViewModel y;
    public int z;
    
    public k(final SignInViewModel a, final Task b, final d d) {
        this.A = a;
        this.B = b;
        super(2, d);
    }
    
    public final d create(final Object o, final d d) {
        return (d)new k(this.A, this.B, d);
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final M m = (M)o;
        return new k(this.A, this.B, (d)o2).invokeSuspend(K8.M.a);
    }
    
    public final Object invokeSuspend(Object y) {
        final Object f = b.f();
        final int z = this.z;
        Label_0302: {
            if (z != 0) {
                if (z != 1) {
                    if (z == 2) {
                        final SignInViewModel y2 = this.y;
                        x.b(y);
                        y = y2;
                        break Label_0302;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                else {
                    x.b(y);
                }
            }
            else {
                x.b(y);
                this.A.resetUI();
                SignInViewModel.access$get_isSubmitting$p(this.A).setValue((Object)kotlin.coroutines.jvm.internal.b.a(true));
                final SignInWithGoogleUseCase access$getSignInWithGoogleUseCase$p = SignInViewModel.access$getSignInWithGoogleUseCase$p(this.A);
                final Task b = this.B;
                this.z = 1;
                if ((y = access$getSignInWithGoogleUseCase$p.invoke(b, (d)this)) == f) {
                    return f;
                }
            }
            final Either either = (Either)y;
            y = this.A;
            final Task b2 = this.B;
            if (either instanceof Either$Left) {
                final AuthFailure authFailure = (AuthFailure)((Either$Left)either).getValue();
                if (!v.e((Object)authFailure, (Object)AuthFailure$AlreadyAuthorized.INSTANCE)) {
                    try {
                        i9.i.d(f0.a((e0)y), (g)c0.c(), (O)null, (p)new j((SignInViewModel)y, null), 2, (Object)null);
                    }
                    catch (final Exception ex) {
                        ((Throwable)ex).printStackTrace();
                    }
                }
                SignInViewModel.access$get_isSubmitting$p((SignInViewModel)y).setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
                SignInViewModel.access$get_responseResult$p((SignInViewModel)y).setValue((Object)new Either$Left((Object)authFailure));
                return K8.M.a;
            }
            if (!(either instanceof Either$Right)) {
                throw new s();
            }
            final K8.M m = (K8.M)((Either$Right)either).getValue();
            SignInViewModel.access$resetState((SignInViewModel)y);
            final GoogleSignInAccount googleSignInAccount = (GoogleSignInAccount)b2.getResult();
            this.y = (SignInViewModel)y;
            this.z = 2;
            if (SignInViewModel.a((SignInViewModel)y, googleSignInAccount, (YandexSignInAccount)null, (l)this, 2) == f) {
                return f;
            }
        }
        SignInViewModel.access$get_isSubmitting$p((SignInViewModel)y).setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
        SignInViewModel.access$get_responseResult$p((SignInViewModel)y).setValue((Object)new Either$Right((Object)K8.M.a));
        return K8.M.a;
    }
}
