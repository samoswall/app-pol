package B8;

import android.content.Context;
import android.widget.Toast;
import com.syncleoiot.core.R$string;
import K8.x;
import Q8.b;
import i9.M;
import P8.d;
import com.syncleoiot.core.application.auth.SignInViewModel;
import X8.p;

public final class l extends kotlin.coroutines.jvm.internal.l implements p
{
    public final SignInViewModel y;
    
    public l(final SignInViewModel y, final d d) {
        this.y = y;
        super(2, d);
    }
    
    public final d create(final Object o, final d d) {
        return (d)new l(this.y, d);
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final M m = (M)o;
        return new l(this.y, (d)o2).invokeSuspend(K8.M.a);
    }
    
    public final Object invokeSuspend(final Object o) {
        b.f();
        x.b(o);
        Toast.makeText((Context)this.y.getContext(), R$string.something_went_wrong, 1).show();
        return K8.M.a;
    }
}
