package B8;

import com.syncleoiot.core.domain.auth.entities.YandexSignInAccount;
import com.syncleoiot.core.application.auth.usecases.SignInWithYandexUseCase;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.syncleoiot.core.domain.auth.entities.YandexSignInAccountKt;
import K8.s;
import com.syncleoiot.core.domain.core.objects.Either$Right;
import i9.O;
import P8.g;
import i9.i;
import i9.c0;
import androidx.lifecycle.e0;
import androidx.lifecycle.f0;
import kotlin.jvm.internal.v;
import com.syncleoiot.core.domain.auth.AuthFailure$AlreadyAuthorized;
import com.syncleoiot.core.domain.auth.AuthFailure;
import com.syncleoiot.core.domain.core.objects.Either$Left;
import com.syncleoiot.core.domain.core.objects.Either;
import K8.x;
import Q8.b;
import K8.M;
import l8.e;
import l8.d;
import com.syncleoiot.core.application.auth.SignInViewModel;
import X8.p;
import kotlin.coroutines.jvm.internal.l;

public final class m extends l implements p
{
    public final SignInViewModel A;
    public final d B;
    public final e C;
    public SignInViewModel y;
    public int z;
    
    public m(final SignInViewModel a, final d b, final e c, final P8.d d) {
        this.A = a;
        this.B = b;
        this.C = c;
        super(2, d);
    }
    
    public final P8.d create(final Object o, final P8.d d) {
        return (P8.d)new m(this.A, this.B, this.C, d);
    }
    
    public final Object invoke(final Object o, final Object o2) {
        return ((m)this.create(o, (P8.d)o2)).invokeSuspend(M.a);
    }
    
    public final Object invokeSuspend(Object y) {
        final Object f = b.f();
        final int z = this.z;
        Label_0307: {
            if (z != 0) {
                if (z != 1) {
                    if (z == 2) {
                        final SignInViewModel y2 = this.y;
                        x.b(y);
                        y = y2;
                        break Label_0307;
                    }
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                else {
                    x.b(y);
                }
            }
            else {
                x.b(y);
                this.A.resetUI();
                SignInViewModel.access$get_isSubmitting$p(this.A).setValue((Object)kotlin.coroutines.jvm.internal.b.a(true));
                final SignInWithYandexUseCase access$getSignInWithYandexUseCase$p = SignInViewModel.access$getSignInWithYandexUseCase$p(this.A);
                final d b = this.B;
                this.z = 1;
                if ((y = access$getSignInWithYandexUseCase$p.invoke(b, (P8.d)this)) == f) {
                    return f;
                }
            }
            final Either either = (Either)y;
            y = this.A;
            final d b2 = this.B;
            final e c = this.C;
            if (either instanceof Either$Left) {
                final AuthFailure authFailure = (AuthFailure)((Either$Left)either).getValue();
                if (!v.e((Object)authFailure, (Object)AuthFailure$AlreadyAuthorized.INSTANCE)) {
                    try {
                        i9.i.d(f0.a((e0)y), (g)c0.c(), (O)null, (p)new B8.l((SignInViewModel)y, null), 2, (Object)null);
                    }
                    catch (final Exception ex) {
                        ((Throwable)ex).printStackTrace();
                    }
                }
                SignInViewModel.access$get_isSubmitting$p((SignInViewModel)y).setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
                SignInViewModel.access$get_responseResult$p((SignInViewModel)y).setValue((Object)new Either$Left((Object)authFailure));
                return M.a;
            }
            if (!(either instanceof Either$Right)) {
                throw new s();
            }
            final M m = (M)((Either$Right)either).getValue();
            SignInViewModel.access$resetState((SignInViewModel)y);
            final YandexSignInAccount accountOrNull = YandexSignInAccountKt.parseAccountOrNull(b2, c);
            this.y = (SignInViewModel)y;
            this.z = 2;
            if (SignInViewModel.a((SignInViewModel)y, (GoogleSignInAccount)null, accountOrNull, (l)this, 1) == f) {
                return f;
            }
        }
        SignInViewModel.access$get_isSubmitting$p((SignInViewModel)y).setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
        SignInViewModel.access$get_responseResult$p((SignInViewModel)y).setValue((Object)new Either$Right((Object)M.a));
        return M.a;
    }
}
