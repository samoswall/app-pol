package b9;

import java.util.Random;
import kotlin.jvm.internal.v;

public abstract class a extends c
{
    @Override
    public int b(final int n) {
        return d.d(this.h().nextInt(), n);
    }
    
    @Override
    public byte[] d(final byte[] array) {
        v.j((Object)array, "array");
        this.h().nextBytes(array);
        return array;
    }
    
    @Override
    public int e() {
        return this.h().nextInt();
    }
    
    @Override
    public int f(final int n) {
        return this.h().nextInt(n);
    }
    
    public abstract Random h();
}
