package b9;

import kotlin.jvm.internal.v;
import java.util.Random;

public final class b extends a
{
    private final b$a c;
    
    public b() {
        this.c = new ThreadLocal() {
            protected Random a() {
                return new Random();
            }
        };
    }
    
    @Override
    public Random h() {
        final Object value = this.c.get();
        v.i(value, "get(...)");
        return (Random)value;
    }
}
