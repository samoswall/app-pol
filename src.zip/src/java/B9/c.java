package b9;

import kotlin.jvm.internal.v;
import java.io.Serializable;
import S8.b;
import kotlin.jvm.internal.m;

public abstract class c
{
    public static final a a;
    private static final c b;
    
    static {
        a = new a(null);
        b = S8.b.a.b();
    }
    
    public static final /* synthetic */ c a() {
        return c.b;
    }
    
    public abstract int b(final int p0);
    
    public byte[] c(final int n) {
        return this.d(new byte[n]);
    }
    
    public abstract byte[] d(final byte[] p0);
    
    public abstract int e();
    
    public abstract int f(final int p0);
    
    public int g(final int n, int b) {
        d.b(n, b);
        final int n2 = b - n;
        if (n2 <= 0 && n2 != Integer.MIN_VALUE) {
            int e;
            do {
                e = this.e();
            } while (n > e || e >= b);
            return e;
        }
        if ((-n2 & n2) == n2) {
            b = this.b(d.c(n2));
        }
        else {
            int n3;
            do {
                n3 = this.e() >>> 1;
                b = n3 % n2;
            } while (n3 - b + (n2 - 1) < 0);
        }
        return n + b;
    }
    
    public static final class a extends c implements Serializable
    {
        private a() {
        }
        
        @Override
        public int b(final int n) {
            return c.a().b(n);
        }
        
        @Override
        public byte[] c(final int n) {
            return c.a().c(n);
        }
        
        @Override
        public byte[] d(final byte[] array) {
            v.j((Object)array, "array");
            return c.a().d(array);
        }
        
        @Override
        public int e() {
            return c.a().e();
        }
        
        @Override
        public int f(final int n) {
            return c.a().f(n);
        }
        
        @Override
        public int g(final int n, final int n2) {
            return c.a().g(n, n2);
        }
    }
}
