package b9;

import kotlin.jvm.internal.v;

public abstract class d
{
    public static final String a(final Object o, final Object o2) {
        v.j(o, "from");
        v.j(o2, "until");
        final StringBuilder sb = new StringBuilder();
        sb.append("Random range is empty: [");
        sb.append(o);
        sb.append(", ");
        sb.append(o2);
        sb.append(").");
        return sb.toString();
    }
    
    public static final void b(final int n, final int n2) {
        if (n2 > n) {
            return;
        }
        throw new IllegalArgumentException(a(n, n2).toString());
    }
    
    public static final int c(final int n) {
        return 31 - Integer.numberOfLeadingZeros(n);
    }
    
    public static final int d(final int n, final int n2) {
        return n >>> 32 - n2 & -n2 >> 31;
    }
}
