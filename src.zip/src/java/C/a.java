package c;

import com.syncleoiot.core.domain.scope.AppRegionPreferences;
import com.syncleoiot.core.infrastructure.scope.ScopeRepositoryImpl;
import java.util.Iterator;
import kotlin.coroutines.jvm.internal.d;

public final class a extends d
{
    public Iterator A;
    public Object B;
    public final ScopeRepositoryImpl C;
    public int H;
    public ScopeRepositoryImpl y;
    public AppRegionPreferences z;
    
    public a(final ScopeRepositoryImpl c, final P8.d d) {
        this.C = c;
        super(d);
    }
    
    public final Object invokeSuspend(final Object b) {
        this.B = b;
        this.H |= Integer.MIN_VALUE;
        return this.C.refreshAppRegionConfig((P8.d)this);
    }
}
