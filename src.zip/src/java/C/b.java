package C;

import S.s0;
import S.i;
import S.D;
import S.j;
import K8.x;
import i9.M;
import P8.d;
import S.a;
import X8.p;
import kotlin.coroutines.jvm.internal.l;

public final class b extends l implements p
{
    public final float A;
    public int y;
    public final a z;
    
    public b(final a z, final float a, final d d) {
        this.z = z;
        this.A = a;
        super(2, d);
    }
    
    public final d create(final Object o, final d d) {
        return (d)new b(this.z, this.A, d);
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final M m = (M)o;
        return new b(this.z, this.A, (d)o2).invokeSuspend(K8.M.a);
    }
    
    public final Object invokeSuspend(final Object o) {
        final Object f = Q8.b.f();
        final int y = this.y;
        if (y != 0) {
            if (y != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            x.b(o);
        }
        else {
            x.b(o);
            final a z = this.z;
            final Float d = kotlin.coroutines.jvm.internal.b.d(this.A);
            final s0 l = j.l(0, 0, (D)null, 6, (Object)null);
            this.y = 1;
            if (a.f(z, (Object)d, (i)l, (Object)null, (X8.l)null, (d)this, 12, (Object)null) == f) {
                return f;
            }
        }
        return K8.M.a;
    }
}
