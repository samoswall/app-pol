package C;

import java.util.Iterator;
import i9.O;
import P8.g;
import i9.i;
import S.a;
import L8.t;
import K8.x;
import Q8.b;
import K8.M;
import P8.d;
import java.util.List;
import X8.p;
import kotlin.coroutines.jvm.internal.l;

public final class e extends l implements p
{
    public final List A;
    public Object y;
    public final List z;
    
    public e(final List z, final List a, final d d) {
        this.z = z;
        this.A = a;
        super(2, d);
    }
    
    public final d create(final Object y, final d d) {
        final e e = new e(this.z, this.A, d);
        e.y = y;
        return (d)e;
    }
    
    public final Object invoke(final Object o, final Object o2) {
        return ((e)this.create(o, (d)o2)).invokeSuspend(M.a);
    }
    
    public final Object invokeSuspend(final Object o) {
        b.f();
        x.b(o);
        final i9.M m = (i9.M)this.y;
        final List z = this.z;
        final List a = this.A;
        final Iterator iterator = ((Iterable)z).iterator();
        int n = 0;
        while (iterator.hasNext()) {
            final Object next = iterator.next();
            if (n < 0) {
                t.w();
            }
            final a a2 = (a)next;
            final Float n2 = (Float)t.n0(a, n);
            if (n2 != null) {
                i.d(m, (g)null, (O)null, (p)new C.d(a2, n2, null), 3, (Object)null);
            }
            ++n;
        }
        return M.a;
    }
}
