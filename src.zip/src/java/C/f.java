package C;

import i9.O;
import P8.g;
import i9.i;
import K8.x;
import Q8.b;
import P8.d;
import i9.M;
import java.util.List;
import X8.p;
import kotlin.coroutines.jvm.internal.l;

public final class f extends l implements p
{
    public final List A;
    public final List B;
    public final boolean y;
    public final M z;
    
    public f(final boolean y, final M z, final List a, final List b, final d d) {
        this.y = y;
        this.z = z;
        this.A = a;
        this.B = b;
        super(2, d);
    }
    
    public final d create(final Object o, final d d) {
        return (d)new f(this.y, this.z, this.A, this.B, d);
    }
    
    public final Object invoke(final Object o, final Object o2) {
        return ((f)this.create(o, (d)o2)).invokeSuspend(K8.M.a);
    }
    
    public final Object invokeSuspend(final Object o) {
        b.f();
        x.b(o);
        if (!this.y) {
            i.d(this.z, (g)null, (O)null, (p)new c(this.A, this.B, null), 3, (Object)null);
        }
        else {
            i.d(this.z, (g)null, (O)null, (p)new e(this.A, this.B, null), 3, (Object)null);
        }
        return K8.M.a;
    }
}
