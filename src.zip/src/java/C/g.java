package C;

import K8.M;
import com.syncleoiot.core.widgets.circleSlider.DonutSliderKt;
import L8.t;
import java.util.List;
import com.syncleoiot.core.widgets.circleSlider.DonutModel;
import v0.t0;
import X8.l;
import kotlin.jvm.internal.w;

public final class g extends w implements l
{
    public final t0 H;
    public final t0 L;
    public final DonutModel M;
    public final t0 Q;
    public final l W;
    
    public g(final t0 h, final t0 l, final DonutModel m, final t0 q, final l w) {
        this.H = h;
        this.L = l;
        this.M = m;
        this.Q = q;
        this.W = w;
        super(1);
    }
    
    public final Object invoke(final Object o) {
        final long v = ((O0.g)o).v();
        final m m = (m)t.m0((List)this.H.getValue());
        if (m != null) {
            this.L.setValue(O0.g.d(v));
            final float access$getRadian-3MmeM6k = DonutSliderKt.access$getRadian-3MmeM6k(((O0.g)this.L.getValue()).v(), DonutSliderKt.access$getDiameterPx(this.M));
            final double n = this.M.getMaxUseAngle() / 57.29577951308232 / this.M.getCountSection();
            float n3;
            final float n2 = n3 = access$getRadian-3MmeM6k - (float)(m.d / 57.29577951308232);
            if (n2 < 0.0f) {
                n3 = n2 + 6.2831855f;
            }
            float n4 = n3;
            if (O0.g.m(v) - DonutSliderKt.access$getDiameterPx(this.M) / 2 < 0.0f) {
                n4 = n3;
                if (n3 > 6.283185307179586) {
                    n4 = n3 - 6.2831855f;
                }
            }
            this.Q.setValue((int)(n4 / n));
            final Integer n5 = (Integer)this.Q.getValue();
            if (n5 != null) {
                final DonutModel i = this.M;
                final t0 q = this.Q;
                final l w = this.W;
                final int intValue = ((Number)n5).intValue();
                if (intValue > i.getCountSection() - 1) {
                    q.setValue(i.getCountSection() - 1);
                    w.invoke((Object)(i.getCountSection() - 1));
                }
                else {
                    w.invoke((Object)intValue);
                }
            }
        }
        return K8.M.a;
    }
}
