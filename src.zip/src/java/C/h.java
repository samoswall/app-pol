package C;

import K8.M;
import L8.t;
import java.util.List;
import X8.p;
import v0.t0;
import X8.a;
import kotlin.jvm.internal.w;

public final class h extends w implements a
{
    public final t0 H;
    public final t0 L;
    public final p M;
    
    public h(final t0 h, final t0 l, final p m) {
        this.H = h;
        this.L = l;
        this.M = m;
        super(0);
    }
    
    public final Object invoke() {
        final Integer n = (Integer)this.H.getValue();
        if (n != null) {
            final t0 h = this.H;
            final t0 l = this.L;
            final p m = this.M;
            final int intValue = ((Number)n).intValue();
            h.setValue(null);
            final m i = (m)t.n0((List)l.getValue(), intValue);
            if (i != null) {
                m.invoke((Object)intValue, (Object)(i.a / i.e));
            }
        }
        return K8.M.a;
    }
}
