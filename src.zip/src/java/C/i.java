package C;

import K8.M;
import kotlin.jvm.internal.v;
import O0.g;
import a1.y;
import v0.t0;
import X8.p;
import kotlin.jvm.internal.w;

public final class i extends w implements p
{
    public final t0 H;
    
    public i(final t0 h) {
        this.H = h;
        super(2);
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final y y = (y)o;
        final long v = ((g)o2).v();
        kotlin.jvm.internal.v.j((Object)y, "change");
        final t0 h = this.H;
        h.setValue(g.d(g.r(((g)h.getValue()).v(), v)));
        return M.a;
    }
}
