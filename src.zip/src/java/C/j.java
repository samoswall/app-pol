package C;

import X8.a;
import a1.H;
import K8.x;
import Q8.b;
import K8.M;
import P8.d;
import com.syncleoiot.core.widgets.circleSlider.DonutModel;
import v0.t0;
import X8.p;
import kotlin.coroutines.jvm.internal.l;

public final class j extends l implements p
{
    public final t0 A;
    public final t0 B;
    public final DonutModel C;
    public final t0 H;
    public final X8.l L;
    public final p M;
    public int y;
    public Object z;
    
    public j(final t0 a, final t0 b, final DonutModel c, final t0 h, final X8.l l, final p m, final d d) {
        this.A = a;
        this.B = b;
        this.C = c;
        this.H = h;
        this.L = l;
        this.M = m;
        super(2, d);
    }
    
    public final d create(final Object z, final d d) {
        final j j = new j(this.A, this.B, this.C, this.H, this.L, this.M, d);
        j.z = z;
        return (d)j;
    }
    
    public final Object invoke(final Object o, final Object o2) {
        return ((j)this.create(o, (d)o2)).invokeSuspend(K8.M.a);
    }
    
    public final Object invokeSuspend(final Object o) {
        final Object f = b.f();
        final int y = this.y;
        if (y != 0) {
            if (y != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            x.b(o);
        }
        else {
            x.b(o);
            final H h = (H)this.z;
            final g g = new g(this.A, this.B, this.C, this.H, this.L);
            final h h2 = new h(this.H, this.A, this.M);
            final i i = new i(this.B);
            this.y = 1;
            if (V.j.f(h, (X8.l)g, (a)h2, (a)null, (p)i, (d)this, 4, (Object)null) == f) {
                return f;
            }
        }
        return K8.M.a;
    }
}
