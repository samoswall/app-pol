package C;

import java.util.Map;
import com.syncleoiot.core.data.model.LayoutSegment;
import A1.d;
import android.graphics.Canvas;
import java.util.Iterator;
import com.syncleoiot.core.data.model.RawArcPoint;
import P0.c;
import com.syncleoiot.core.R$color;
import android.graphics.Paint$Align;
import android.graphics.Paint;
import java.util.Map$Entry;
import com.syncleoiot.core.data.model.LimitKt;
import P0.K;
import com.syncleoiot.core.utils.DeviceUtils;
import com.syncleoiot.core.ext.NumberExtKt;
import com.syncleoiot.core.data.model.ColorParams;
import P0.j0;
import P0.y0;
import O0.n;
import O0.h;
import com.syncleoiot.core.data.model.Limit;
import com.syncleoiot.core.data.model.DeviceLayoutItem;
import P0.J;
import R0.j;
import R0.f;
import K8.M;
import com.syncleoiot.core.widgets.circleSlider.DonutSliderKt;
import L8.t;
import O0.g;
import kotlin.jvm.internal.v;
import android.content.Context;
import X8.p;
import com.syncleoiot.core.widgets.circleSlider.DonutModel;
import java.util.List;
import v0.t0;
import X8.l;
import kotlin.jvm.internal.w;

public final class k extends w implements l
{
    public final t0 H;
    public final t0 L;
    public final t0 M;
    public final t0 Q;
    public final List W;
    public final List X;
    public final DonutModel Y;
    public final t0 Z;
    public final List a0;
    public final List b0;
    public final p c0;
    public final Context d0;
    public final Integer e0;
    public final Integer f0;
    
    public k(final t0 h, final t0 l, final t0 m, final t0 q, final List w, final List x, final DonutModel y, final t0 z, final List a0, final List b0, final p c0, final Context d0, final Integer e0, final Integer f0) {
        this.H = h;
        this.L = l;
        this.M = m;
        this.Q = q;
        this.W = w;
        this.X = x;
        this.Y = y;
        this.Z = z;
        this.a0 = a0;
        this.b0 = b0;
        this.c0 = c0;
        this.d0 = d0;
        this.e0 = e0;
        this.f0 = f0;
        super(1);
    }
    
    public final Object invoke(Object next) {
        next = next;
        v.j(next, "$this$Canvas");
        if (!g.j(((g)this.H.getValue()).v(), ((g)this.L.getValue()).v())) {
            final Integer n = (Integer)this.M.getValue();
            if (n != null) {
                final List b0 = this.b0;
                final t0 q = this.Q;
                final t0 h = this.H;
                final DonutModel y = this.Y;
                final p c0 = this.c0;
                final t0 l = this.L;
                final int intValue = ((Number)n).intValue();
                if (v.e(t.n0(b0, intValue), (Object)Boolean.TRUE)) {
                    q.setValue(DonutSliderKt.access$changeListSectionModel-38CYSgM((List)q.getValue(), intValue, ((g)h.getValue()).v(), y, c0));
                    l.setValue(h.getValue());
                }
                final M a = K8.M.a;
            }
        }
        final Iterator iterator = ((List)this.Q.getValue()).iterator();
        int n2 = 0;
    Label_0715_Outer:
        while (true) {
            final boolean hasNext = iterator.hasNext();
            final int n3 = 2;
            if (!hasNext) {
                final Iterator iterator2 = ((List)this.Q.getValue()).iterator();
                int n4 = 0;
                while (iterator2.hasNext()) {
                    final m m = (m)iterator2.next();
                    Label_2197: {
                        if (!v.e(t.n0(this.a0, n4), (Object)Boolean.FALSE)) {
                            final double n5 = DonutSliderKt.access$getBias(DonutSliderKt.access$getIndicatorRadiusPx(this.Y), ((d)next).X0(this.Y.getDiameter-D9Ej5fM())) + 0.0f;
                            final float a2 = m.a;
                            final double n6 = a2;
                            long n7;
                            if (n6 < n5) {
                                n7 = DonutSliderKt.access$setRadian((f)next, (float)((m.d + n5) / 57.29577951308232), DonutSliderKt.access$getIndicatorRadiusPx(this.Y), DonutSliderKt.access$getArcHalfOffset(this.Y));
                            }
                            else {
                                final float e = m.e;
                                if (n6 > e - n5) {
                                    n7 = DonutSliderKt.access$setRadian((f)next, (float)((m.d + e - n5) / 57.29577951308232), DonutSliderKt.access$getIndicatorRadiusPx(this.Y), DonutSliderKt.access$getArcHalfOffset(this.Y));
                                }
                                else {
                                    n7 = DonutSliderKt.access$setRadian((f)next, (float)((m.d + a2) / 57.29577951308232), DonutSliderKt.access$getIndicatorRadiusPx(this.Y), DonutSliderKt.access$getArcHalfOffset(this.Y));
                                }
                            }
                            final float i = g.m(n7);
                            final float n8 = g.n(n7);
                            final Integer e2 = this.e0;
                            final DonutModel y2 = this.Y;
                            final Integer f0 = this.f0;
                            ((f)next).a1().d().e(i, n8);
                            while (true) {
                                if (e2 == null) {
                                    break Label_1976;
                                }
                                Label_1979: {
                                    break Label_1979;
                                    Label_2057: {
                                        break Label_2057;
                                        try {
                                            if (e2 == n4) {
                                                Label_2114: {
                                                    while (true) {
                                                        try {
                                                            final long selectedBackground-0d7_KjU = y2.getDonutColor().getSelectedBackground-0d7_KjU();
                                                            final float access$getIndicatorRadiusPx = DonutSliderKt.access$getIndicatorRadiusPx(y2);
                                                            final float n9 = (float)n3;
                                                            final j a3 = j.a;
                                                            try {
                                                                f.o1((f)next, selectedBackground-0d7_KjU, n9 * access$getIndicatorRadiusPx, 0L, 0.0f, (R0.g)a3, (J)null, 0, 108, (Object)null);
                                                                break Label_2114;
                                                            }
                                                            finally {}
                                                        }
                                                        finally {
                                                            continue;
                                                        }
                                                        break;
                                                    }
                                                    if (f0 != null) {
                                                        if (f0 == n4) {
                                                            f.o1((f)next, y2.getDonutColor().getFocusedBackground-0d7_KjU(), n3 * DonutSliderKt.access$getIndicatorRadiusPx(y2), 0L, 0.0f, (R0.g)j.a, (J)null, 0, 108, (Object)null);
                                                        }
                                                    }
                                                }
                                                f.o1((f)next, y2.getDonutColor().getIndicatorColor-0d7_KjU(), DonutSliderKt.access$getIndicatorRadiusPx(y2), 0L, 0.0f, (R0.g)j.a, (J)null, 0, 108, (Object)null);
                                                ((f)next).a1().d().e(-i, -n8);
                                                break Label_2197;
                                            }
                                            continue;
                                        }
                                        finally {}
                                    }
                                }
                                break;
                            }
                            ((f)next).a1().d().e(-i, -n8);
                        }
                    }
                    ++n4;
                }
                return K8.M.a;
            }
            final m j = (m)iterator.next();
            final DeviceLayoutItem deviceLayoutItem = (DeviceLayoutItem)t.n0(this.W, n2);
            Label_1676: {
                if (deviceLayoutItem != null) {
                    final Limit limit = (Limit)t.n0(this.X, n2);
                    final long disableDonut-0d7_KjU = this.Y.getDonutColor().getDisableDonut-0d7_KjU();
                    final float d = j.d;
                    final float floatValue = ((Number)this.Z.getValue()).floatValue();
                    final long r = g.r(g.b.c(), h.a(DonutSliderKt.access$getArcHalfOffset(this.Y) + DonutSliderKt.access$getIndicatorRadiusPx(this.Y), DonutSliderKt.access$getArcHalfOffset(this.Y) + (DonutSliderKt.access$getIndicatorRadiusPx(this.Y) + (DonutSliderKt.access$getVerticalCenter((f)next) - DonutSliderKt.access$getHorizontalCenter((f)next)))));
                    final float access$getHorizontalCenter = DonutSliderKt.access$getHorizontalCenter((f)next);
                    final float n10 = 2;
                    final long a4 = n.a(access$getHorizontalCenter * n10 - DonutSliderKt.access$getIndicatorRadiusPx(this.Y) * n10 - DonutSliderKt.access$getArcOffset(this.Y), DonutSliderKt.access$getHorizontalCenter((f)next) * n10 - DonutSliderKt.access$getIndicatorRadiusPx(this.Y) * n10 - DonutSliderKt.access$getArcOffset(this.Y));
                    final R0.k k = new R0.k(DonutSliderKt.access$getIndicatorRadiusPx(this.Y) * n10, 0.0f, y0.a.a(), 0, (j0)null, 26, (kotlin.jvm.internal.m)null);
                    final Object o = next;
                    f.d1((f)next, disableDonut-0d7_KjU, d, floatValue, false, r, a4, 0.0f, (R0.g)k, (J)null, 0, 832, (Object)null);
                    final float a5 = j.a;
                    if (a5 < 0.0f) {
                        j.a = a5 + 360;
                    }
                    final float b2 = j.b;
                    if (b2 < 0.0f) {
                        j.b = b2 + 360;
                    }
                    final double n11 = j.b / j.e;
                    final Limit limit2 = (Limit)t.n0(this.X, n2);
                    double max;
                    if (limit2 != null) {
                        max = limit2.getMax();
                    }
                    else {
                        max = 0.0;
                    }
                    final double n12 = n11 * max;
                    final List colors = deviceLayoutItem.getColors();
                    final String s = null;
                Label_0715:
                    while (true) {
                        Label_0718: {
                            if (colors != null) {
                                final Iterator iterator3 = ((Iterable)colors).iterator();
                                while (true) {
                                    while (iterator3.hasNext()) {
                                        next = iterator3.next();
                                        final ColorParams colorParams = (ColorParams)next;
                                        if (colorParams.getMax() >= NumberExtKt.round(n12, 5) && colorParams.getMin() <= NumberExtKt.round(n12, 5)) {
                                            final ColorParams colorParams2 = (ColorParams)next;
                                            if (colorParams2 != null) {
                                                final long n13 = K.b(DeviceUtils.INSTANCE.getColorParamsResource(colorParams2.getColor(), this.d0));
                                                break Label_0715;
                                            }
                                            break Label_0718;
                                        }
                                    }
                                    next = null;
                                    continue Label_0715_Outer;
                                }
                            }
                            break Label_0718;
                            final float d2 = j.d;
                            final float b3 = j.b;
                            final long r2 = g.r(g.b.c(), h.a(DonutSliderKt.access$getArcHalfOffset(this.Y) + DonutSliderKt.access$getIndicatorRadiusPx(this.Y), DonutSliderKt.access$getArcHalfOffset(this.Y) + (DonutSliderKt.access$getIndicatorRadiusPx(this.Y) + (DonutSliderKt.access$getVerticalCenter((f)o) - DonutSliderKt.access$getHorizontalCenter((f)o)))));
                            final long a6 = n.a(DonutSliderKt.access$getHorizontalCenter((f)o) * n10 - DonutSliderKt.access$getIndicatorRadiusPx(this.Y) * n10 - DonutSliderKt.access$getArcOffset(this.Y), DonutSliderKt.access$getHorizontalCenter((f)o) * n10 - DonutSliderKt.access$getIndicatorRadiusPx(this.Y) * n10 - DonutSliderKt.access$getArcOffset(this.Y));
                            final R0.k k2 = new R0.k(DonutSliderKt.access$getIndicatorRadiusPx(this.Y) * n10, 0.0f, y0.a.a(), 0, (j0)null, 26, (kotlin.jvm.internal.m)null);
                            final m m2 = j;
                            long n13 = 0L;
                            f.d1((f)o, n13, d2, b3, false, r2, a6, 0.0f, (R0.g)k2, (J)null, 0, 832, (Object)null);
                            Limit limit3 = null;
                            Label_1174: {
                                if (limit != null) {
                                    final List segments = deviceLayoutItem.getSegments();
                                    if (segments != null) {
                                        final Context d3 = this.d0;
                                        final DonutModel y3 = this.Y;
                                        for (final Object o2 : segments) {
                                            final float convertValueToProgress = LimitKt.getConvertValueToProgress(limit, ((LayoutSegment)o2).getMin());
                                            f.d1((f)o, K.b(DeviceUtils.INSTANCE.getColorParamsResource(((LayoutSegment)o2).getColor(), d3)), m2.e * convertValueToProgress + m2.d, m2.e * (LimitKt.getConvertValueToProgress(limit, ((LayoutSegment)o2).getMax()) - convertValueToProgress), false, g.r(g.b.c(), h.a(0.0f, DonutSliderKt.access$getVerticalCenter((f)o) - DonutSliderKt.access$getHorizontalCenter((f)o))), n.a(DonutSliderKt.access$getHorizontalCenter((f)o) * n10, DonutSliderKt.access$getHorizontalCenter((f)o) * n10), 0.0f, (R0.g)new R0.k(DonutSliderKt.access$getSegmentsWidthPx(y3), 0.0f, y0.a.a(), 0, (j0)null, 26, (kotlin.jvm.internal.m)null), (J)null, 0, 832, (Object)null);
                                        }
                                        final M a7 = K8.M.a;
                                        limit3 = limit;
                                        break Label_1174;
                                    }
                                }
                                limit3 = limit;
                            }
                            if (this.Y.getShowPoints() && limit3 != null && limit3.isEnabled()) {
                                Object textAlign = deviceLayoutItem.getPoints();
                                if (textAlign == null) {
                                    final List defaultPoints = this.Y.getDefaultPoints();
                                    textAlign = s;
                                    if (defaultPoints != null) {
                                        textAlign = t.n0(defaultPoints, n2);
                                    }
                                }
                                if (textAlign != null) {
                                    final DonutModel y4 = this.Y;
                                    final Context d4 = this.d0;
                                    for (final Map$Entry map$Entry : ((Map)textAlign).entrySet()) {
                                        final float n14 = m2.d + (float)(1 / (limit3.getMax() - limit3.getMin()) * (((Number)map$Entry.getKey()).doubleValue() - limit3.getMin()) * m2.e);
                                        final long access$setRadianText = DonutSliderKt.access$setRadianText((f)o, (float)(n14 / 57.29577951308232), ((d)o).X0(y4.getPointsTextOffset-D9Ej5fM()) + DonutSliderKt.access$getIndicatorRadiusPx(y4));
                                        float n15 = n14;
                                        if (n14 > 360.0f) {
                                            n15 = n14 - 360.0f;
                                        }
                                        final float m3 = g.m(access$setRadianText);
                                        final float n16 = g.n(access$setRadianText);
                                        ((f)o).a1().d().e(m3, n16);
                                        Label_1637: {
                                            Object o2 = null;
                                            Label_1499: {
                                                try {
                                                    o2 = new Paint();
                                                    if (n15 >= -90.0f) {
                                                        if (n15 <= 90.0f) {
                                                            textAlign = Paint$Align.LEFT;
                                                            break Label_1499;
                                                        }
                                                    }
                                                }
                                                finally {
                                                    break Label_1637;
                                                }
                                                textAlign = Paint$Align.RIGHT;
                                            }
                                            ((Paint)o2).setTextAlign((Paint$Align)textAlign);
                                            ((Paint)o2).setTextSize(((d)o).D1(y4.getPointsTextSize-XSAIIZE()));
                                            ((Paint)o2).setColor(d4.getColor(R$color.colorWhite));
                                            final Canvas d5 = c.d(((f)o).a1().g());
                                            if ((textAlign = ((RawArcPoint)map$Entry.getValue()).getLabel()) == null) {
                                                textAlign = "";
                                            }
                                            d5.drawText((String)textAlign, g.m(((f)o).u1()), g.n(((f)o).u1()), (Paint)o2);
                                            ((f)o).a1().d().e(-m3, -n16);
                                            continue Label_0715_Outer;
                                        }
                                        ((f)o).a1().d().e(-m3, -n16);
                                    }
                                    next = o;
                                    final M a8 = K8.M.a;
                                    break Label_1676;
                                }
                            }
                            next = o;
                            break Label_1676;
                        }
                        final long n13 = this.Y.getDonutColor().getEnableDonut-0d7_KjU();
                        continue Label_0715;
                    }
                }
            }
            ++n2;
        }
    }
}
