package C;

import K8.M;
import com.syncleoiot.core.widgets.circleSlider.DonutSliderKt;
import v0.P0;
import v0.m;
import java.util.List;
import com.syncleoiot.core.widgets.circleSlider.DonutModel;
import androidx.compose.ui.e;
import X8.p;
import kotlin.jvm.internal.w;

public final class l extends w implements p
{
    public final e H;
    public final DonutModel L;
    public final List M;
    public final List Q;
    public final boolean W;
    public final List X;
    public final List Y;
    public final List Z;
    public final List a0;
    public final float b0;
    public final Integer c0;
    public final Integer d0;
    public final p e0;
    public final X8.l f0;
    public final p g0;
    public final int h0;
    public final int i0;
    public final int j0;
    
    public l(final e h, final DonutModel l, final List m, final List q, final boolean w, final List x, final List y, final List z, final List a0, final float b0, final Integer c0, final Integer d0, final p e0, final X8.l f0, final p g0, final int h2, final int i0, final int j0) {
        this.H = h;
        this.L = l;
        this.M = m;
        this.Q = q;
        this.W = w;
        this.X = x;
        this.Y = y;
        this.Z = z;
        this.a0 = a0;
        this.b0 = b0;
        this.c0 = c0;
        this.d0 = d0;
        this.e0 = e0;
        this.f0 = f0;
        this.g0 = g0;
        this.h0 = h2;
        this.i0 = i0;
        this.j0 = j0;
        super(2);
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final m m = (m)o;
        ((Number)o2).intValue();
        DonutSliderKt.DonutSlider(this.H, this.L, this.M, this.Q, this.W, this.X, this.Y, this.Z, this.a0, this.b0, this.c0, this.d0, this.e0, this.f0, this.g0, m, P0.a(this.h0 | 0x1), P0.a(this.i0), this.j0);
        return K8.M.a;
    }
}
