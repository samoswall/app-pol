package C;

import O0.g;
import O0.h;

public final class m
{
    public float a;
    public float b;
    public long c;
    public final float d;
    public final float e;
    
    public m(final float a, final float b, final float d, final float e) {
        final long a2 = h.a(0.0f, 0.0f);
        this.a = a;
        this.b = b;
        this.c = a2;
        this.d = d;
        this.e = e;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof m)) {
            return false;
        }
        final m m = (m)o;
        return Float.compare(this.a, m.a) == 0 && Float.compare(this.b, m.b) == 0 && g.j(this.c, m.c) && Float.compare(this.d, m.d) == 0 && Float.compare(this.e, m.e) == 0;
    }
    
    @Override
    public final int hashCode() {
        return Float.hashCode(this.e) + (Float.hashCode(this.d) + (g.o(this.c) + (Float.hashCode(this.b) + Float.hashCode(this.a) * 31) * 31) * 31) * 31;
    }
    
    @Override
    public final String toString() {
        final float a = this.a;
        final float b = this.b;
        final String t = g.t(this.c);
        final float d = this.d;
        final float e = this.e;
        final StringBuilder sb = new StringBuilder();
        sb.append("SectionModel(circleProgress=");
        sb.append(a);
        sb.append(", arcProgress=");
        sb.append(b);
        sb.append(", offsetSphere=");
        sb.append(t);
        sb.append(", startAngle=");
        sb.append(d);
        sb.append(", sweepAngle=");
        sb.append(e);
        sb.append(")");
        return sb.toString();
    }
}
