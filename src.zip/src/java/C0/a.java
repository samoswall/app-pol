package c0;

import P8.d;
import A1.y;
import d9.n;
import java.util.concurrent.CancellationException;
import Z0.e;
import O0.g;
import V.q;

final class a implements Z0.a
{
    private final C a;
    private final q b;
    
    public a(final C a, final q b) {
        this.a = a;
        this.b = b;
    }
    
    private final float b(final long n) {
        float n2;
        if (this.b == q.Horizontal) {
            n2 = g.m(n);
        }
        else {
            n2 = g.n(n);
        }
        return n2;
    }
    
    public long A1(final long n, final long n2, final int n3) {
        if (e.e(n3, e.a.b()) && this.b(n2) != 0.0f) {
            throw new CancellationException("Scroll cancelled");
        }
        return g.b.c();
    }
    
    public long O0(long n, final int n2) {
        if (e.e(n2, e.a.c()) && Math.abs(this.a.w()) > 1.0E-6) {
            final float n3 = this.a.w() * this.a.G();
            float n4 = (this.a.C().getPageSize() + this.a.C().k()) * -Math.signum(this.a.w()) + n3;
            float n5 = n3;
            if (this.a.w() > 0.0f) {
                n4 = (n5 = n3);
            }
            final q b = this.b;
            final q horizontal = q.Horizontal;
            float n6;
            if (b == horizontal) {
                n6 = g.m(n);
            }
            else {
                n6 = g.n(n);
            }
            float n7 = -this.a.f(-n.n(n6, n5, n4));
            float m;
            if (this.b == horizontal) {
                m = n7;
            }
            else {
                m = g.m(n);
            }
            if (this.b != q.Vertical) {
                n7 = g.n(n);
            }
            n = g.f(n, m, n7);
        }
        else {
            n = g.b.c();
        }
        return n;
    }
    
    public final long a(long n, final q q) {
        if (q == q.Vertical) {
            n = y.e(n, 0.0f, 0.0f, 2, (Object)null);
        }
        else {
            n = y.e(n, 0.0f, 0.0f, 1, (Object)null);
        }
        return n;
    }
    
    public Object o0(final long n, final long n2, final d d) {
        return y.b(this.a(n2, this.b));
    }
}
