package c0;

import v0.u1;
import v0.v1;
import X8.l;
import X8.p;
import F0.a;
import kotlin.jvm.internal.m;
import v0.t0;
import F0.j;

final class b extends C
{
    public static final c L;
    private static final j M;
    private t0 K;
    
    static {
        L = new c(null);
        M = a.a((p)b$a.H, (l)b$b.H);
    }
    
    public b(final int n, final float n2, final X8.a a) {
        super(n, n2);
        this.K = v1.i((Object)a, (u1)null, 2, (Object)null);
    }
    
    public static final /* synthetic */ j l0() {
        return b.M;
    }
    
    @Override
    public int F() {
        return ((Number)((X8.a)this.K.getValue()).invoke()).intValue();
    }
    
    public final t0 m0() {
        return this.K;
    }
    
    public static final class c
    {
        private c() {
        }
        
        public final j a() {
            return b.l0();
        }
    }
}
