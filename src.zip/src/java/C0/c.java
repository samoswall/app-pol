package c0;

import kotlin.jvm.internal.G;
import b0.K;
import v0.G1;
import v0.v1;
import i9.N;
import java.util.List;
import a1.o;
import K8.x;
import a1.H;
import v0.b1;
import b0.F;
import v0.m$a;
import K8.M;
import v0.P0;
import V.n;
import V.y;
import T.V;
import x0.b;
import androidx.compose.ui.platform.f0;
import androidx.compose.foundation.lazy.layout.f;
import v0.v;
import V.d;
import v0.B;
import v0.Q;
import kotlin.jvm.internal.w;
import v0.p;
import A1.h;
import v0.m;
import X8.r;
import W.k;
import I0.c$c;
import I0.c$b;
import X8.l;
import Z0.a;
import V.q;
import Y.A;
import androidx.compose.ui.e;

public abstract class c
{
    public static final void a(final e e, final C c, final A a, final boolean b, final q q, final V.C c2, final boolean b2, int d, float i, final g g, final a a2, final l l, final I0.c$b c$b, final I0.c$c c$c, final k k, final r r, final m m, final int n, final int n2, final int n3) {
        final m v = m.v(538371694);
        int n4;
        if ((n3 & 0x1) != 0x0) {
            n4 = (n | 0x6);
        }
        else if ((n & 0x6) == 0x0) {
            int n5;
            if (v.Y((Object)e)) {
                n5 = 4;
            }
            else {
                n5 = 2;
            }
            n4 = (n5 | n);
        }
        else {
            n4 = n;
        }
        int n6;
        if ((n3 & 0x2) != 0x0) {
            n6 = (n4 | 0x30);
        }
        else {
            n6 = n4;
            if ((n & 0x30) == 0x0) {
                int n7;
                if (v.Y((Object)c)) {
                    n7 = 32;
                }
                else {
                    n7 = 16;
                }
                n6 = (n4 | n7);
            }
        }
        final int n8 = 128;
        int n11 = 0;
        Label_0199: {
            int n9;
            if ((n3 & 0x4) != 0x0) {
                n9 = (n6 | 0x180);
            }
            else {
                n9 = n6;
                if ((n & 0x180) == 0x0) {
                    int n10;
                    if (v.Y((Object)a)) {
                        n10 = 256;
                    }
                    else {
                        n10 = 128;
                    }
                    n11 = (n6 | n10);
                    break Label_0199;
                }
            }
            n11 = n9;
        }
        final int n12 = 1024;
        int n15 = 0;
        Label_0271: {
            int n13;
            if ((n3 & 0x8) != 0x0) {
                n13 = (n11 | 0xC00);
            }
            else {
                n13 = n11;
                if ((n & 0xC00) == 0x0) {
                    int n14;
                    if (v.d(b)) {
                        n14 = 2048;
                    }
                    else {
                        n14 = 1024;
                    }
                    n15 = (n11 | n14);
                    break Label_0271;
                }
            }
            n15 = n13;
        }
        final int n16 = 8192;
        int n17;
        if ((n3 & 0x10) != 0x0) {
            n17 = (n15 | 0x6000);
        }
        else {
            n17 = n15;
            if ((n & 0x6000) == 0x0) {
                int n18;
                if (v.Y((Object)q)) {
                    n18 = 16384;
                }
                else {
                    n18 = 8192;
                }
                n17 = (n15 | n18);
            }
        }
        int n19;
        if ((n3 & 0x20) != 0x0) {
            n19 = (n17 | 0x30000);
        }
        else {
            n19 = n17;
            if ((n & 0x30000) == 0x0) {
                int n20;
                if (v.Y((Object)c2)) {
                    n20 = 131072;
                }
                else {
                    n20 = 65536;
                }
                n19 = (n17 | n20);
            }
        }
        int n22 = 0;
        Label_0460: {
            int n21;
            if ((n3 & 0x40) != 0x0) {
                n21 = 1572864;
            }
            else {
                n22 = n19;
                if ((0x180000 & n) != 0x0) {
                    break Label_0460;
                }
                if (v.d(b2)) {
                    n21 = 1048576;
                }
                else {
                    n21 = 524288;
                }
            }
            n22 = (n19 | n21);
        }
        final int n23 = n3 & 0x80;
        int n24;
        if (n23 != 0) {
            n24 = (n22 | 0xC00000);
        }
        else {
            n24 = n22;
            if ((n & 0xC00000) == 0x0) {
                int n25;
                if (v.j(d)) {
                    n25 = 8388608;
                }
                else {
                    n25 = 4194304;
                }
                n24 = (n22 | n25);
            }
        }
        int n26 = d;
        final int n27 = n3 & 0x100;
        if (n27 != 0) {
            d = (n24 | 0x6000000);
        }
        else {
            d = n24;
            if ((n & 0x6000000) == 0x0) {
                if (v.h(i)) {
                    d = 67108864;
                }
                else {
                    d = 33554432;
                }
                d |= n24;
            }
        }
        int n30 = 0;
        Label_0659: {
            int n28;
            if ((n3 & 0x200) != 0x0) {
                n28 = (d | 0x30000000);
            }
            else {
                n28 = d;
                if ((0x30000000 & n) == 0x0) {
                    int n29;
                    if (v.Y((Object)g)) {
                        n29 = 536870912;
                    }
                    else {
                        n29 = 268435456;
                    }
                    n30 = (d | n29);
                    break Label_0659;
                }
            }
            n30 = n28;
        }
        if ((n3 & 0x400) != 0x0) {
            d = (n2 | 0x6);
        }
        else if ((n2 & 0x6) == 0x0) {
            if (v.m((Object)a2)) {
                d = 4;
            }
            else {
                d = 2;
            }
            d |= n2;
        }
        else {
            d = n2;
        }
        Label_0786: {
            int n31;
            if ((n3 & 0x800) != 0x0) {
                n31 = (d | 0x30);
            }
            else {
                n31 = d;
                if ((n2 & 0x30) == 0x0) {
                    int n32;
                    if (v.m((Object)l)) {
                        n32 = 32;
                    }
                    else {
                        n32 = 16;
                    }
                    d |= n32;
                    break Label_0786;
                }
            }
            d = n31;
        }
        Label_0851: {
            int n33;
            if ((n3 & 0x1000) != 0x0) {
                n33 = (d | 0x180);
            }
            else {
                n33 = d;
                if ((n2 & 0x180) == 0x0) {
                    int n34 = n8;
                    if (v.Y((Object)c$b)) {
                        n34 = 256;
                    }
                    d |= n34;
                    break Label_0851;
                }
            }
            d = n33;
        }
        Label_0916: {
            int n35;
            if ((n3 & 0x2000) != 0x0) {
                n35 = (d | 0xC00);
            }
            else {
                n35 = d;
                if ((n2 & 0xC00) == 0x0) {
                    int n36 = n12;
                    if (v.Y((Object)c$c)) {
                        n36 = 2048;
                    }
                    d |= n36;
                    break Label_0916;
                }
            }
            d = n35;
        }
        int n37;
        if ((n3 & 0x4000) != 0x0) {
            n37 = (d | 0x6000);
        }
        else {
            n37 = d;
            if ((n2 & 0x6000) == 0x0) {
                int n38 = n16;
                if (v.Y((Object)k)) {
                    n38 = 16384;
                }
                n37 = (d | n38);
            }
        }
        if ((n3 & 0x8000) != 0x0) {
            d = (n37 | 0x30000);
        }
        else {
            d = n37;
            if ((n2 & 0x30000) == 0x0) {
                if (v.m((Object)r)) {
                    d = 131072;
                }
                else {
                    d = 65536;
                }
                d |= n37;
            }
        }
        if ((n30 & 0x12492493) == 0x12492492 && (0x12493 & d) == 0x12492 && v.y()) {
            v.G();
            d = n26;
        }
        else {
            if (n23 != 0) {
                n26 = 0;
            }
            if (n27 != 0) {
                i = h.i((float)0);
            }
            if (p.J()) {
                p.S(538371694, n30, d, "androidx.compose.foundation.pager.Pager (LazyLayoutPager.kt:101)");
            }
            if (n26 < 0) {
                final StringBuilder sb = new StringBuilder();
                sb.append("beyondViewportPageCount should be greater than or equal to 0, you selected ");
                sb.append(n26);
                throw new IllegalArgumentException(sb.toString().toString());
            }
            final int n39 = n30 & 0x70;
            final boolean b3 = n39 == 32;
            final Object g2 = v.g();
            Object o;
            if (b3 || (o = g2) == m.a.a()) {
                o = new X8.a(c) {
                    final C H;
                    
                    public final Integer invoke() {
                        return this.H.F();
                    }
                };
                v.P(o);
            }
            final X8.a a3 = (X8.a)o;
            final int n40 = n30 >> 3;
            final int n41 = n40 & 0xE;
            final int n42 = d >> 12;
            final X8.a c3 = c(c, r, l, a3, v, n41 | (n42 & 0x70) | (d << 3 & 0x380));
            final Object g3 = v.g();
            final m$a a4 = m.a;
            B b4;
            if ((b4 = (B)g3) == a4.a()) {
                b4 = new B(Q.k((P8.g)P8.h.a, v));
                v.P((Object)b4);
            }
            final i9.M a5 = b4.a();
            final boolean b5 = n39 == 32;
            final Object g4 = v.g();
            Object o2;
            if (b5 || (o2 = g4) == a4.a()) {
                o2 = new X8.a(c) {
                    final C H;
                    
                    public final Integer invoke() {
                        return this.H.F();
                    }
                };
                v.P(o2);
            }
            final X8.a a6 = (X8.a)o2;
            final int n43 = n30 >> 6;
            d <<= 18;
            final X8.p a7 = t.a(c3, c, a, b, q, n26, i, g, c$b, c$c, k, a5, a6, v, (0xFFF0 & n30) | (n43 & 0x70000) | (0x380000 & n43) | (0x1C00000 & n43) | (0xE000000 & d) | (d & 0x70000000), n42 & 0xE);
            final q vertical = q.Vertical;
            final F a8 = z.a(c, q == vertical, v, n41);
            if (n39 == 32) {
                d = 1;
            }
            else {
                d = 0;
            }
            final boolean b6 = (n30 & 0x70000) == 0x20000;
            Object g5 = v.g();
            if ((d | (b6 ? 1 : 0)) != 0x0 || g5 == a4.a()) {
                g5 = new E(c2, c);
                v.P(g5);
            }
            final E e2 = (E)g5;
            final d d2 = (d)v.p((v)V.e.a());
            if (n39 == 32) {
                d = 1;
            }
            else {
                d = 0;
            }
            final boolean y = v.Y((Object)d2);
            final Object g6 = v.g();
            j j;
            if ((d | (y ? 1 : 0)) != 0x0 || (j = (j)g6) == a4.a()) {
                j = new j(c, d2);
                v.P((Object)j);
            }
            final j j2 = j;
            final e e3 = m.e(f.c(e.f((e)c.P()).f((e)c.t()), c3, a8, q, b2, b, v, (n40 & 0x1C00) | (0xE000 & n43) | (n30 << 6 & 0x70000)), c, q == vertical, a5, b2);
            final b0.m a9 = c0.h.a(c, n26, v, (n30 >> 18 & 0x70) | n41);
            final b0.j u = c.u();
            final A1.t t = (A1.t)v.p((v)f0.k());
            d = b.d;
            final int n44 = n30 << 3;
            b0.w.a(c3, androidx.compose.ui.input.nestedscroll.a.b(b(V.a(b0.l.b(e3, a9, u, b, t, q, b2, v, d << 6 | (n30 & 0x1C00) | (n44 & 0x70000) | (n30 & 0x380000)), (y)c, q, b2, b, (n)e2, c.A(), (d)j2, v, (n43 & 0x380) | n39 | (n30 >> 9 & 0x1C00) | (n44 & 0xE000), 0), c), a2, (Z0.b)null, 2, (Object)null), c.M(), a7, v, 0, 0);
            if (p.J()) {
                p.R();
            }
            d = n26;
        }
        final b1 c4 = v.C();
        if (c4 != null) {
            c4.a((X8.p)new X8.p(e, c, a, b, q, c2, b2, d, i, g, a2, l, c$b, c$c, k, r, n, n2, n3) {
                final e H;
                final C L;
                final A M;
                final boolean Q;
                final q W;
                final V.C X;
                final boolean Y;
                final int Z;
                final float a0;
                final g b0;
                final a c0;
                final l d0;
                final I0.c$b e0;
                final I0.c$c f0;
                final k g0;
                final r h0;
                final int i0;
                final int j0;
                final int k0;
                
                public final void a(final m m, final int n) {
                    c.a(this.H, this.L, this.M, this.Q, this.W, this.X, this.Y, this.Z, this.a0, this.b0, this.c0, this.d0, this.e0, this.f0, this.g0, this.h0, m, P0.a(this.i0 | 0x1), P0.a(this.j0), this.k0);
                }
            });
        }
    }
    
    private static final e b(final e e, final C c) {
        return e.f(a1.Q.c((e)e.a, c, (X8.p)new X8.p(c, null) {
            final C A;
            int y;
            private Object z;
            
            public final P8.d create(final Object z, final P8.d d) {
                final X8.p p2 = (X8.p)new X8.p(this.A, d) {
                    final C A;
                    int y;
                    private Object z;
                };
                p2.z = z;
                return (P8.d)p2;
            }
            
            public final Object f(final H h, final P8.d d) {
                return ((c$d)this.create(h, d)).invokeSuspend(M.a);
            }
            
            public final Object invokeSuspend(final Object o) {
                final Object f = Q8.b.f();
                final int y = this.y;
                if (y != 0) {
                    if (y != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    x.b(o);
                }
                else {
                    x.b(o);
                    final X8.p p = (X8.p)new X8.p((H)this.z, this.A, null) {
                        final C A;
                        int y;
                        final H z;
                        
                        public final P8.d create(final Object o, final P8.d d) {
                            return (P8.d)new X8.p(this.z, this.A, d) {
                                final C A;
                                int y;
                                final H z;
                            };
                        }
                        
                        public final Object invoke(final i9.M m, final P8.d d) {
                            return ((c$d$a)this.create(m, d)).invokeSuspend(M.a);
                        }
                        
                        public final Object invokeSuspend(final Object o) {
                            final Object f = Q8.b.f();
                            final int y = this.y;
                            if (y != 0) {
                                if (y != 1) {
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                x.b(o);
                            }
                            else {
                                x.b(o);
                                final H z = this.z;
                                final X8.p p = (X8.p)new X8.p(this.A, null) {
                                    int A;
                                    private Object B;
                                    final C C;
                                    Object y;
                                    Object z;
                                    
                                    public final P8.d create(final Object b, final P8.d d) {
                                        final X8.p p2 = (X8.p)new X8.p(this.C, d) {
                                            int A;
                                            private Object B;
                                            final C C;
                                            Object y;
                                            Object z;
                                        };
                                        p2.B = b;
                                        return (P8.d)p2;
                                    }
                                    
                                    public final Object f(final a1.b b, final P8.d d) {
                                        return ((c$d$a$a)this.create(b, d)).invokeSuspend(M.a);
                                    }
                                    
                                    public final Object invokeSuspend(Object d) {
                                        final Object f = Q8.b.f();
                                        final int a = this.A;
                                    Label_0166:
                                        while (true) {
                                            a1.y y = null;
                                            Label_0225: {
                                                a1.b b2;
                                                if (a != 0) {
                                                    if (a != 1) {
                                                        if (a == 2) {
                                                            y = (a1.y)this.z;
                                                            final a1.y y2 = (a1.y)this.y;
                                                            final a1.b b = (a1.b)this.B;
                                                            x.b(d);
                                                            break Label_0225;
                                                        }
                                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                                    }
                                                    else {
                                                        b2 = (a1.b)this.B;
                                                        x.b(d);
                                                    }
                                                }
                                                else {
                                                    x.b(d);
                                                    b2 = (a1.b)this.B;
                                                    final o initial = o.Initial;
                                                    this.B = b2;
                                                    this.A = 1;
                                                    if ((d = V.B.d(b2, false, initial, (P8.d)this)) == f) {
                                                        return f;
                                                    }
                                                }
                                                final a1.y y3 = (a1.y)d;
                                                this.C.h0(O0.g.b.c());
                                                final a1.y y4 = null;
                                                final a1.b b = b2;
                                                final a1.y y2 = y3;
                                                final a1.y z = y4;
                                                if (z != null) {
                                                    this.C.h0(O0.g.q(z.h(), y2.h()));
                                                    return M.a;
                                                }
                                                final o initial2 = o.Initial;
                                                this.B = b;
                                                this.y = y2;
                                                this.z = z;
                                                this.A = 2;
                                                final Object k1 = b.K1(initial2, (P8.d)this);
                                                y = z;
                                                if ((d = k1) == f) {
                                                    return f;
                                                }
                                            }
                                            final a1.m m = (a1.m)d;
                                            final List c = m.c();
                                            for (int size = c.size(), i = 0; i < size; ++i) {
                                                if (!a1.n.c((a1.y)c.get(i))) {
                                                    final a1.y z = y;
                                                    continue Label_0166;
                                                }
                                            }
                                            final a1.y z = (a1.y)m.c().get(0);
                                            continue Label_0166;
                                        }
                                    }
                                };
                                this.y = 1;
                                if (V.o.c(z, (X8.p)p, (P8.d)this) == f) {
                                    return f;
                                }
                            }
                            return M.a;
                        }
                    };
                    this.y = 1;
                    if (N.f((X8.p)p, (P8.d)this) == f) {
                        return f;
                    }
                }
                return M.a;
            }
        }));
    }
    
    private static final X8.a c(final C c, final r r, final l l, final X8.a a, final m m, final int n) {
        if (p.J()) {
            p.S(-1372505274, n, -1, "androidx.compose.foundation.pager.rememberPagerItemProviderLambda (LazyLayoutPager.kt:258)");
        }
        final G1 n2 = v1.n((Object)r, m, n >> 3 & 0xE);
        final G1 n3 = v1.n((Object)l, m, n >> 6 & 0xE);
        boolean b = false;
        final boolean b2 = (((n & 0xE) ^ 0x6) > 4 && m.Y((Object)c)) || (n & 0x6) == 0x4;
        final boolean y = m.Y((Object)n2);
        final boolean y2 = m.Y((Object)n3);
        if ((((n & 0x1C00) ^ 0xC00) > 2048 && m.Y((Object)a)) || (n & 0xC00) == 0x800) {
            b = true;
        }
        final Object g = m.g();
        Object o;
        if ((b2 | y | y2 | b) || (o = g) == m.a.a()) {
            o = new G(v1.e(v1.m(), (X8.a)new X8.a(v1.e(v1.m(), (X8.a)new X8.a(n2, n3, a) {
                final G1 H;
                final G1 L;
                final X8.a M;
                
                public final c0.p a() {
                    return new c0.p((r)this.H.getValue(), (l)this.L.getValue(), ((Number)this.M.invoke()).intValue());
                }
            }), c) {
                final G1 H;
                final C L;
                
                public final c0.r a() {
                    final c0.p p = (c0.p)this.H.getValue();
                    return new c0.r(this.L, p, (androidx.compose.foundation.lazy.layout.c)new K(this.L.E(), p));
                }
            }));
            m.P(o);
        }
        final e9.k k = (e9.k)o;
        if (p.J()) {
            p.R();
        }
        return (X8.a)k;
    }
}
