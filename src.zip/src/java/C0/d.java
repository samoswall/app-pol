package c0;

import K8.M;
import Q8.b;
import A1.r;
import V.q;
import b0.F;

public abstract class d
{
    public static final F a(final C c, final boolean b) {
        return (F)new F(c, b) {
            final C a;
            final boolean b;
            
            public int a() {
                int n;
                if (this.a.C().f() == q.Vertical) {
                    n = r.f(this.a.C().a());
                }
                else {
                    n = r.g(this.a.C().a());
                }
                return n;
            }
            
            public float b() {
                return (float)y.a(this.a);
            }
            
            public Object c(final int n, final P8.d d) {
                final Object z = C.Z(this.a, n, 0.0f, d, 2, null);
                if (z == Q8.b.f()) {
                    return z;
                }
                return M.a;
            }
            
            public int d() {
                return this.a.C().g() + this.a.C().d();
            }
            
            public float e() {
                return (float)D.g(this.a.C(), this.a.F());
            }
            
            public l1.b f() {
                l1.b b;
                if (this.b) {
                    b = new l1.b(this.a.F(), 1);
                }
                else {
                    b = new l1.b(1, this.a.F());
                }
                return b;
            }
        };
    }
}
