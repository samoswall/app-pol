package c0;

import X8.l;
import A1.n;
import e1.U$a;
import A1.o;
import kotlin.jvm.internal.m;
import e1.U;
import V.q;
import A1.t;
import I0.c$c;
import I0.c$b;
import java.util.List;

public final class e implements f
{
    private final int a;
    private final int b;
    private final List c;
    private final long d;
    private final Object e;
    private final c$b f;
    private final c$c g;
    private final t h;
    private final boolean i;
    private final boolean j;
    private final int k;
    private final int[] l;
    private int m;
    private int n;
    
    private e(int max, int i, final List c, final long d, final Object e, final q q, final c$b f, final c$c g, final t h, final boolean j) {
        this.a = max;
        this.b = i;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = j;
        final q vertical = q.Vertical;
        i = 0;
        this.j = (q == vertical);
        final int size = c.size();
        max = 0;
        while (i < size) {
            final U u = (U)c.get(i);
            int n;
            if (!this.j) {
                n = u.J0();
            }
            else {
                n = u.S0();
            }
            max = Math.max(max, n);
            ++i;
        }
        this.k = max;
        this.l = new int[this.c.size() * 2];
        this.n = Integer.MIN_VALUE;
    }
    
    private final int e(final U u) {
        int n;
        if (this.j) {
            n = u.J0();
        }
        else {
            n = u.S0();
        }
        return n;
    }
    
    private final long f(int n) {
        final int[] l = this.l;
        n *= 2;
        return o.a(l[n], l[n + 1]);
    }
    
    public final void a(final int n) {
        this.m = this.b() + n;
        for (int length = this.l.length, i = 0; i < length; ++i) {
            final boolean j = this.j;
            if ((j && i % 2 == 1) || (!j && i % 2 == 0)) {
                final int[] l = this.l;
                l[i] += n;
            }
        }
    }
    
    @Override
    public int b() {
        return this.m;
    }
    
    public final int c() {
        return this.k;
    }
    
    public Object d() {
        return this.e;
    }
    
    public final int g() {
        return this.b;
    }
    
    @Override
    public int getIndex() {
        return this.a;
    }
    
    public final void h(final U$a u$a) {
        if (this.n != Integer.MIN_VALUE) {
            for (int size = this.c.size(), i = 0; i < size; ++i) {
                final U u = (U)this.c.get(i);
                long n2;
                final long n = n2 = this.f(i);
                if (this.i) {
                    int j;
                    if (this.j) {
                        j = A1.n.j(n);
                    }
                    else {
                        j = this.n - A1.n.j(n) - this.e(u);
                    }
                    int k;
                    if (this.j) {
                        k = this.n - A1.n.k(n) - this.e(u);
                    }
                    else {
                        k = A1.n.k(n);
                    }
                    n2 = o.a(j, k);
                }
                final long n3 = A1.n.n(n2, this.d);
                if (this.j) {
                    U$a.y(u$a, u, n3, 0.0f, (l)null, 6, (Object)null);
                }
                else {
                    U$a.s(u$a, u, n3, 0.0f, (l)null, 6, (Object)null);
                }
            }
            return;
        }
        throw new IllegalArgumentException("position() should be called first");
    }
    
    public final void i(int m, final int n, final int n2) {
        this.m = m;
        int n3;
        if (this.j) {
            n3 = n2;
        }
        else {
            n3 = n;
        }
        this.n = n3;
        final List c = this.c;
        for (int size = c.size(), i = 0; i < size; ++i) {
            final U u = (U)c.get(i);
            final int n4 = i * 2;
            int n5;
            if (this.j) {
                final int[] l = this.l;
                final c$b f = this.f;
                if (f == null) {
                    throw new IllegalArgumentException("null horizontalAlignment");
                }
                l[n4] = f.a(u.S0(), n, this.h);
                this.l[n4 + 1] = m;
                n5 = u.J0();
            }
            else {
                final int[] j = this.l;
                j[n4] = m;
                final c$c g = this.g;
                if (g == null) {
                    throw new IllegalArgumentException("null verticalAlignment");
                }
                j[n4 + 1] = g.a(u.J0(), n2);
                n5 = u.S0();
            }
            m += n5;
        }
    }
}
