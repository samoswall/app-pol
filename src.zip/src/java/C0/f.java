package c0;

public interface f
{
    int b();
    
    int getIndex();
}
