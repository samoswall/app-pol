package c0;

import A1.d;

public interface g
{
    int a(final d p0, final int p1, final int p2);
    
    public static final class a implements g
    {
        public static final a a;
        
        static {
            a = new a();
        }
        
        private a() {
        }
        
        @Override
        public int a(final d d, final int n, final int n2) {
            return n;
        }
    }
}
