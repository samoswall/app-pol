package c0;

import v0.p;
import v0.m;

public abstract class h
{
    public static final b0.m a(final C c, final int n, final m m, final int n2) {
        if (p.J()) {
            p.S(373558254, n2, -1, "androidx.compose.foundation.pager.rememberPagerBeyondBoundsState (PagerBeyondBoundsModifier.kt:25)");
        }
        boolean b = false;
        final boolean b2 = (((n2 & 0xE) ^ 0x6) > 4 && m.Y((Object)c)) || (n2 & 0x6) == 0x4;
        if ((((n2 & 0x70) ^ 0x30) > 32 && m.j(n)) || (n2 & 0x30) == 0x20) {
            b = true;
        }
        final Object g = m.g();
        i i;
        if ((b2 | b) || (i = (i)g) == m.a.a()) {
            i = new i(c, n);
            m.P((Object)i);
        }
        final i j = i;
        if (p.J()) {
            p.R();
        }
        return (b0.m)j;
    }
}
