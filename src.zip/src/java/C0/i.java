package c0;

import java.util.Collection;
import e1.W;
import L8.t;
import b0.m;

public final class i implements m
{
    private final C a;
    private final int b;
    
    public i(final C a, final int b) {
        this.a = a;
        this.b = b;
    }
    
    public int a() {
        return this.a.F();
    }
    
    public int b() {
        return Math.min(this.a() - 1, ((f)t.v0(this.a.C().j())).getIndex() + this.b);
    }
    
    public void c() {
        final W o = this.a.O();
        if (o != null) {
            o.k();
        }
    }
    
    public boolean d() {
        return ((Collection)this.a.C().j()).isEmpty() ^ true;
    }
    
    public int e() {
        return Math.max(0, this.a.y() - this.b);
    }
}
