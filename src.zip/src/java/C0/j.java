package c0;

import d9.n;
import S.i;
import V.d;

final class j implements d
{
    private final C b;
    private final d c;
    private final i d;
    
    public j(final C b, final d c) {
        this.b = b;
        this.c = c;
        this.d = c.b();
    }
    
    private final float c(final float n) {
        float n2 = this.b.z() * (float)(-1);
        float n3;
        while (true) {
            n3 = n2;
            if (n <= 0.0f) {
                break;
            }
            n3 = n2;
            if (n2 >= n) {
                break;
            }
            n2 += this.b.H();
        }
        while (n < 0.0f && n3 > n) {
            n3 -= this.b.H();
        }
        return n3;
    }
    
    public float a(float n, float a, final float n2) {
        a = this.c.a(n, a, n2);
        n = 0.0f;
        if (a == 0.0f) {
            if (this.b.z() != 0) {
                a = (n = this.b.z() * -1.0f);
                if (this.b.B()) {
                    n = a + this.b.H();
                }
                n = n.n(n, -n2, n2);
            }
        }
        else {
            n = this.c(a);
        }
        return n;
    }
    
    public i b() {
        return this.d;
    }
}
