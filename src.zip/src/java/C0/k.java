package c0;

import Z0.a;
import W.g;
import kotlin.jvm.internal.w;
import X8.q;
import A1.t;
import v0.v;
import androidx.compose.ui.platform.f0;
import A1.d;
import v0.p;
import S.j;
import S.J0;
import kotlin.jvm.internal.u;
import v0.m;
import S.i;
import S.z;

public final class k
{
    public static final k a;
    
    static {
        a = new k();
    }
    
    private k() {
    }
    
    public final V.C a(final C c, A a, z b, i j, float n, final m m, final int n2, int n3) {
        final int n4 = 1;
        if ((n3 & 0x2) != 0x0) {
            a = A.a.a(1);
        }
        if ((n3 & 0x4) != 0x0) {
            b = R.z.b(m, 0);
        }
        if ((n3 & 0x8) != 0x0) {
            j = (i)j.j(0.0f, 400.0f, (Object)J0.b(u.a), 1, (Object)null);
        }
        if ((n3 & 0x10) != 0x0) {
            n = 0.5f;
        }
        if (p.J()) {
            p.S(1559769181, n2, -1, "androidx.compose.foundation.pager.PagerDefaults.flingBehavior (Pager.kt:301)");
        }
        if (0.0f <= n && n <= 1.0f) {
            final d d = (d)m.p((v)f0.e());
            final t t = (t)m.p((v)f0.k());
            if ((((n2 & 0xE) ^ 0x6) > 4 && m.Y((Object)c)) || (n2 & 0x6) == 0x4) {
                n3 = 1;
            }
            else {
                n3 = 0;
            }
            final boolean y = m.Y((Object)b);
            final boolean y2 = m.Y((Object)j);
            int n5 = 0;
            Label_0242: {
                if (((n2 & 0x70) ^ 0x30) > 32) {
                    n5 = n4;
                    if (m.Y((Object)a)) {
                        break Label_0242;
                    }
                }
                if ((n2 & 0x30) == 0x20) {
                    n5 = n4;
                }
                else {
                    n5 = 0;
                }
            }
            final boolean y3 = m.Y((Object)d);
            final boolean y4 = m.Y((Object)t);
            final Object g = m.g();
            V.C o;
            if (((y3 ? 1 : 0) | (n3 | (y ? 1 : 0) | (y2 ? 1 : 0) | n5) | (y4 ? 1 : 0)) != 0x0 || (o = (V.C)g) == m.a.a()) {
                o = W.i.o(W.g.a(c, a, (q)new q(c, t, n) {
                    final C H;
                    final t L;
                    final float M;
                    
                    public final Float a(final float n, final float n2, final float n3) {
                        return W.g.d(this.H, this.L, this.M, n, n2, n3);
                    }
                }), b, j);
                m.P((Object)o);
            }
            final V.C c2 = o;
            if (p.J()) {
                p.R();
            }
            return c2;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("snapPositionalThreshold should be a number between 0 and 1. You've specified ");
        sb.append(n);
        throw new IllegalArgumentException(sb.toString().toString());
    }
    
    public final a b(final C c, final V.q q, final m m, final int n) {
        if (p.J()) {
            p.S(877583120, n, -1, "androidx.compose.foundation.pager.PagerDefaults.pageNestedScrollConnection (Pager.kt:350)");
        }
        boolean b = false;
        final boolean b2 = (((n & 0xE) ^ 0x6) > 4 && m.Y((Object)c)) || (n & 0x6) == 0x4;
        if ((((n & 0x70) ^ 0x30) > 32 && m.Y((Object)q)) || (n & 0x30) == 0x20) {
            b = true;
        }
        final Object g = m.g();
        c0.a a;
        if ((b2 | b) || (a = (c0.a)g) == m.a.a()) {
            a = new c0.a(c, q);
            m.P((Object)a);
        }
        final c0.a a2 = a;
        if (p.J()) {
            p.R();
        }
        return (a)a2;
    }
}
