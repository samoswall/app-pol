package c0;

import X8.r;
import b0.o$a;

public final class l implements o$a
{
    private final X8.l a;
    private final r b;
    
    public l(final X8.l a, final r b) {
        this.a = a;
        this.b = b;
    }
    
    public final r a() {
        return this.b;
    }
    
    public X8.l getKey() {
        return this.a;
    }
}
