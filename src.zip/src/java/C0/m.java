package c0;

import i9.O;
import K8.x;
import P8.d;
import l1.n;
import l1.u;
import Z8.b;
import v0.b1;
import I0.c$b;
import K8.M;
import v0.P0;
import kotlin.jvm.internal.w;
import W.k$b;
import V.q;
import S.i;
import S.z;
import I0.c;
import androidx.compose.foundation.layout.p;
import A1.h;
import X8.r;
import W.k;
import Z0.a;
import X8.l;
import I0.c$c;
import Y.A;
import androidx.compose.ui.e;

public abstract class m
{
    public static final void a(final C c, e a, A a2, g a3, int n, float i, c$c j, final V.C c2, boolean b, boolean b2, l l, a b3, k k, final r r, final v0.m m, final int n2, final int n3, final int n4) {
        final v0.m v = m.v(1870896258);
        int n5;
        if ((n4 & 0x1) != 0x0) {
            n5 = (n2 | 0x6);
        }
        else if ((n2 & 0x6) == 0x0) {
            int n6;
            if (v.Y((Object)c)) {
                n6 = 4;
            }
            else {
                n6 = 2;
            }
            n5 = (n6 | n2);
        }
        else {
            n5 = n2;
        }
        final int n7 = n4 & 0x2;
        int n10 = 0;
        Label_0136: {
            int n8;
            if (n7 != 0) {
                n8 = (n5 | 0x30);
            }
            else {
                n8 = n5;
                if ((n2 & 0x30) == 0x0) {
                    int n9;
                    if (v.Y((Object)a)) {
                        n9 = 32;
                    }
                    else {
                        n9 = 16;
                    }
                    n10 = (n5 | n9);
                    break Label_0136;
                }
            }
            n10 = n8;
        }
        final int n11 = n4 & 0x4;
        int n14 = 0;
        Label_0206: {
            int n12;
            if (n11 != 0) {
                n12 = (n10 | 0x180);
            }
            else {
                n12 = n10;
                if ((n2 & 0x180) == 0x0) {
                    int n13;
                    if (v.Y((Object)a2)) {
                        n13 = 256;
                    }
                    else {
                        n13 = 128;
                    }
                    n14 = (n10 | n13);
                    break Label_0206;
                }
            }
            n14 = n12;
        }
        final int n15 = n4 & 0x8;
        final int n16 = 1024;
        int n19 = 0;
        Label_0282: {
            int n17;
            if (n15 != 0) {
                n17 = (n14 | 0xC00);
            }
            else {
                n17 = n14;
                if ((n2 & 0xC00) == 0x0) {
                    int n18;
                    if (v.Y((Object)a3)) {
                        n18 = 2048;
                    }
                    else {
                        n18 = 1024;
                    }
                    n19 = (n14 | n18);
                    break Label_0282;
                }
            }
            n19 = n17;
        }
        final int n20 = n4 & 0x10;
        int n21;
        if (n20 != 0) {
            n21 = (n19 | 0x6000);
        }
        else {
            n21 = n19;
            if ((n2 & 0x6000) == 0x0) {
                int n22;
                if (v.j(n)) {
                    n22 = 16384;
                }
                else {
                    n22 = 8192;
                }
                n21 = (n19 | n22);
            }
        }
        final int n23 = n4 & 0x20;
        int n24;
        if (n23 != 0) {
            n24 = (n21 | 0x30000);
        }
        else {
            n24 = n21;
            if ((n2 & 0x30000) == 0x0) {
                int n25;
                if (v.h(i)) {
                    n25 = 131072;
                }
                else {
                    n25 = 65536;
                }
                n24 = (n21 | n25);
            }
        }
        final int n26 = n4 & 0x40;
        int n27;
        if (n26 != 0) {
            n27 = (n24 | 0x180000);
        }
        else {
            n27 = n24;
            if ((n2 & 0x180000) == 0x0) {
                int n28;
                if (v.Y((Object)j)) {
                    n28 = 1048576;
                }
                else {
                    n28 = 524288;
                }
                n27 = (n24 | n28);
            }
        }
        if ((n2 & 0xC00000) == 0x0) {
            int n29;
            if ((n4 & 0x80) == 0x0 && v.Y((Object)c2)) {
                n29 = 8388608;
            }
            else {
                n29 = 4194304;
            }
            n27 |= n29;
        }
        final int n30 = n4 & 0x100;
        int n31;
        if (n30 != 0) {
            n31 = (n27 | 0x6000000);
        }
        else {
            n31 = n27;
            if ((n2 & 0x6000000) == 0x0) {
                int n32;
                if (v.d(b)) {
                    n32 = 67108864;
                }
                else {
                    n32 = 33554432;
                }
                n31 = (n27 | n32);
            }
        }
        final int n33 = n4 & 0x200;
        if (n33 != 0) {
            n31 |= 0x30000000;
        }
        else if ((n2 & 0x30000000) == 0x0) {
            int n34;
            if (v.d(b2)) {
                n34 = 536870912;
            }
            else {
                n34 = 268435456;
            }
            n31 |= n34;
        }
        final int n35 = n4 & 0x400;
        int n36;
        if (n35 != 0) {
            n36 = (n3 | 0x6);
        }
        else if ((n3 & 0x6) == 0x0) {
            int n37;
            if (v.m((Object)l)) {
                n37 = 4;
            }
            else {
                n37 = 2;
            }
            n36 = (n3 | n37);
        }
        else {
            n36 = n3;
        }
        if ((n3 & 0x30) == 0x0) {
            int n38;
            if ((n4 & 0x800) == 0x0 && v.m((Object)b3)) {
                n38 = 32;
            }
            else {
                n38 = 16;
            }
            n36 |= n38;
        }
        final int n39 = n36;
        final int n40 = n4 & 0x1000;
        int n41;
        if (n40 != 0) {
            n41 = (n39 | 0x180);
        }
        else {
            n41 = n39;
            if ((n3 & 0x180) == 0x0) {
                int n42;
                if (v.Y((Object)k)) {
                    n42 = 256;
                }
                else {
                    n42 = 128;
                }
                n41 = (n39 | n42);
            }
        }
        int n45 = 0;
        Label_0917: {
            int n43;
            if ((n4 & 0x2000) != 0x0) {
                n43 = (n41 | 0xC00);
            }
            else {
                n43 = n41;
                if ((n3 & 0xC00) == 0x0) {
                    int n44 = n16;
                    if (v.m((Object)r)) {
                        n44 = 2048;
                    }
                    n45 = (n41 | n44);
                    break Label_0917;
                }
            }
            n45 = n43;
        }
        a a4;
        c$c c$c;
        V.C c3;
        if ((n31 & 0x12492493) == 0x12492492 && (n45 & 0x493) == 0x492 && v.y()) {
            v.G();
            a4 = b3;
            c$c = j;
            c3 = c2;
        }
        else {
            v.u();
            int n47;
            int n48;
            l l2;
            V.C c4;
            a a6;
            Object a7;
            if ((n2 & 0x1) != 0x0 && !v.M()) {
                v.G();
                int n46 = n31;
                if ((n4 & 0x80) != 0x0) {
                    n46 = (n31 & 0xFE3FFFFF);
                }
                n47 = n45;
                if ((n4 & 0x800) != 0x0) {
                    n47 = (n45 & 0xFFFFFF8F);
                }
                final a a5 = b3;
                final k k2 = k;
                n48 = n46;
                l2 = l;
                c4 = c2;
                a6 = a5;
                a7 = k2;
            }
            else {
                if (n7 != 0) {
                    a = (e)e.a;
                }
                if (n11 != 0) {
                    a2 = p.a(h.i((float)0));
                }
                if (n15 != 0) {
                    a3 = g.a.a;
                }
                if (n20 != 0) {
                    n = 0;
                }
                if (n23 != 0) {
                    i = h.i((float)0);
                }
                if (n26 != 0) {
                    j = c.a.i();
                }
                V.C a8;
                if ((n4 & 0x80) != 0x0) {
                    a8 = k.a.a(c, null, null, null, 0.0f, v, (n31 & 0xE) | 0x30000, 30);
                    n31 &= 0xFE3FFFFF;
                }
                else {
                    a8 = c2;
                }
                final boolean b4 = false;
                if (n30 != 0) {
                    b = true;
                }
                if (n33 != 0) {
                    b2 = b4;
                }
                if (n35 != 0) {
                    l = null;
                }
                if ((n4 & 0x800) != 0x0) {
                    b3 = k.a.b(c, q.Horizontal, v, (n31 & 0xE) | 0x1B0);
                    n45 &= 0xFFFFFF8F;
                }
                if (n40 != 0) {
                    a7 = k$b.a;
                }
                else {
                    a7 = k;
                }
                a6 = b3;
                final int n49 = n31;
                l2 = l;
                n47 = n45;
                n48 = n49;
                c4 = a8;
            }
            v.W();
            if (v0.p.J()) {
                v0.p.S(1870896258, n48, n47, "androidx.compose.foundation.pager.HorizontalPager (Pager.kt:124)");
            }
            final q horizontal = q.Horizontal;
            final c$b g = c.a.g();
            final int n50 = n48 >> 6;
            final int n51 = n48 << 9;
            final int n52 = n47 << 6;
            c.a(a, c, a2, b2, horizontal, c4, b, n, i, a3, a6, l2, g, j, (k)a7, r, v, (n48 >> 3 & 0xE) | 0x6000 | (n48 << 3 & 0x70) | (n48 & 0x380) | (n48 >> 18 & 0x1C00) | (0x70000 & n50) | (n50 & 0x380000) | (0x1C00000 & n51) | (n51 & 0xE000000) | (n48 << 18 & 0x70000000), (n48 >> 9 & 0x1C00) | ((n47 >> 3 & 0xE) | 0x180 | (n47 << 3 & 0x70)) | (0xE000 & n52) | (n52 & 0x70000), 0);
            if (v0.p.J()) {
                v0.p.R();
            }
            c$c = j;
            c3 = c4;
            l = l2;
            b3 = a6;
            k = (k)a7;
            a4 = b3;
        }
        final b1 c5 = v.C();
        if (c5 != null) {
            c5.a((X8.p)new X8.p(c, a, a2, a3, n, i, c$c, c3, b, b2, l, a4, k, r, n2, n3, n4) {
                final C H;
                final e L;
                final A M;
                final g Q;
                final int W;
                final float X;
                final c$c Y;
                final V.C Z;
                final boolean a0;
                final boolean b0;
                final l c0;
                final a d0;
                final k e0;
                final r f0;
                final int g0;
                final int h0;
                final int i0;
                
                public final void a(final v0.m m, final int n) {
                    m.a(this.H, this.L, this.M, this.Q, this.W, this.X, this.Y, this.Z, this.a0, this.b0, this.c0, this.d0, this.e0, this.f0, m, P0.a(this.g0 | 0x1), P0.a(this.h0), this.i0);
                }
            });
        }
    }
    
    public static final int d(final k k, final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final float n7, final int n8) {
        return b.e(k.a(n, n2, n4, n5, n6, n8) - n7 * (n2 + n3));
    }
    
    public static final e e(e e, final C c, final boolean b, final i9.M m, final boolean b2) {
        if (b2) {
            e = e.f(n.d((e)e.a, false, (l)new l(b, c, m) {
                final boolean H;
                final C L;
                final i9.M M;
                
                public final void a(final l1.w w) {
                    if (this.H) {
                        u.J(w, (String)null, (X8.a)new X8.a(this.L, this.M) {
                            final C H;
                            final i9.M L;
                            
                            public final Boolean a() {
                                return f(this.H, this.L);
                            }
                        }, 1, (Object)null);
                        u.D(w, (String)null, (X8.a)new X8.a(this.L, this.M) {
                            final C H;
                            final i9.M L;
                            
                            public final Boolean a() {
                                return g(this.H, this.L);
                            }
                        }, 1, (Object)null);
                    }
                    else {
                        u.F(w, (String)null, (X8.a)new X8.a(this.L, this.M) {
                            final C H;
                            final i9.M L;
                            
                            public final Boolean a() {
                                return f(this.H, this.L);
                            }
                        }, 1, (Object)null);
                        u.H(w, (String)null, (X8.a)new X8.a(this.L, this.M) {
                            final C H;
                            final i9.M L;
                            
                            public final Boolean a() {
                                return g(this.H, this.L);
                            }
                        }, 1, (Object)null);
                    }
                }
            }, 1, (Object)null));
        }
        else {
            e = e.f((e)e.a);
        }
        return e;
    }
    
    private static final boolean f(final C c, final i9.M m) {
        boolean b;
        if (c.c()) {
            i9.i.d(m, (P8.g)null, (O)null, (X8.p)new X8.p(c, null) {
                int y;
                final C z;
                
                public final d create(final Object o, final d d) {
                    return (d)new X8.p(this.z, d) {
                        int y;
                        final C z;
                    };
                }
                
                public final Object invoke(final i9.M m, final d d) {
                    return ((m$c)this.create(m, d)).invokeSuspend(M.a);
                }
                
                public final Object invokeSuspend(final Object o) {
                    final Object f = Q8.b.f();
                    final int y = this.y;
                    if (y != 0) {
                        if (y != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        x.b(o);
                    }
                    else {
                        x.b(o);
                        final C z = this.z;
                        this.y = 1;
                        if (D.f(z, (d)this) == f) {
                            return f;
                        }
                    }
                    return M.a;
                }
            }, 3, (Object)null);
            b = true;
        }
        else {
            b = false;
        }
        return b;
    }
    
    private static final boolean g(final C c, final i9.M m) {
        boolean b;
        if (c.d()) {
            i9.i.d(m, (P8.g)null, (O)null, (X8.p)new X8.p(c, null) {
                int y;
                final C z;
                
                public final d create(final Object o, final d d) {
                    return (d)new X8.p(this.z, d) {
                        int y;
                        final C z;
                    };
                }
                
                public final Object invoke(final i9.M m, final d d) {
                    return ((m$d)this.create(m, d)).invokeSuspend(M.a);
                }
                
                public final Object invokeSuspend(final Object o) {
                    final Object f = Q8.b.f();
                    final int y = this.y;
                    if (y != 0) {
                        if (y != 1) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        x.b(o);
                    }
                    else {
                        x.b(o);
                        final C z = this.z;
                        this.y = 1;
                        if (D.e(z, (d)this) == f) {
                            return f;
                        }
                    }
                    return M.a;
                }
            }, 3, (Object)null);
            b = true;
        }
        else {
            b = false;
        }
        return b;
    }
}
