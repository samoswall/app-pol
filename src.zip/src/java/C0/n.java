package c0;

import W.k;
import java.util.List;
import V.q;

public interface n
{
    long a();
    
    int d();
    
    int e();
    
    q f();
    
    int g();
    
    int getPageSize();
    
    int h();
    
    boolean i();
    
    List j();
    
    int k();
    
    int l();
    
    k m();
}
