package c0;

import A1.r;
import V.q;

public abstract class o
{
    public static final int a(final n n) {
        int n2;
        if (n.f() == q.Vertical) {
            n2 = r.f(n.a());
        }
        else {
            n2 = r.g(n.a());
        }
        return n2;
    }
}
