package c0;

import b0.J;
import b0.d;
import X8.l;
import X8.r;
import b0.o;

final class p extends o
{
    private final r a;
    private final l b;
    private final int c;
    private final d d;
    
    public p(final r a, final l b, final int c) {
        this.a = a;
        this.b = b;
        this.c = c;
        final J d = new J();
        d.c(c, new c0.l(b, a));
        this.d = d;
    }
    
    public d j() {
        return this.d;
    }
}
