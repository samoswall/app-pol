package c0;

import java.util.List;
import V.v;
import L8.t;
import K8.M;
import Q8.b;
import T.G;
import V.y;
import P8.d;
import X8.p;
import b0.h;

public abstract class q
{
    public static final h a(final C c) {
        return (h)new h(c) {
            final C a;
            
            private final int h() {
                return this.a.G() + this.a.I();
            }
            
            public int a() {
                return this.a.F();
            }
            
            public Object b(final p p2, final d d) {
                final Object a = y.a((y)this.a, (G)null, p2, d, 1, (Object)null);
                if (a == b.f()) {
                    return a;
                }
                return M.a;
            }
            
            public int c() {
                return ((f)t.v0(this.a.C().j())).getIndex();
            }
            
            public int d() {
                return this.a.z();
            }
            
            public void e(final v v, final int n, final int n2) {
                this.a.i0(n, n2 / (float)this.a.H(), true);
            }
            
            public float f(final int n) {
                final List j = this.a.C().j();
                while (true) {
                    for (int size = j.size(), i = 0; i < size; ++i) {
                        final Object value = j.get(i);
                        if (((f)value).getIndex() == n) {
                            final f f = (f)value;
                            float n2;
                            if (f == null) {
                                n2 = (n - this.a.v()) * (float)this.h() - this.a.w() * this.a.H();
                            }
                            else {
                                n2 = (float)f.b();
                            }
                            return n2;
                        }
                    }
                    final Object value = null;
                    continue;
                }
            }
            
            public int g() {
                return this.a.y();
            }
        };
    }
}
