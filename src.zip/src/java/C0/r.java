package c0;

import v0.b1;
import v0.P0;
import b0.D;
import K8.M;
import b0.d;
import v0.p;
import v0.m;
import kotlin.jvm.internal.v;
import androidx.compose.foundation.lazy.layout.c;
import b0.o;
import b0.t;

public final class r implements t
{
    private final C a;
    private final o b;
    private final c c;
    private final w d;
    
    public r(final C a, final o b, final c c) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = w.a;
    }
    
    public static final /* synthetic */ o j(final r r) {
        return r.b;
    }
    
    public static final /* synthetic */ w k(final r r) {
        return r.d;
    }
    
    public int a() {
        return this.b.k();
    }
    
    public Object b(final int n) {
        Object o;
        if ((o = this.c.b(n)) == null) {
            o = this.b.l(n);
        }
        return o;
    }
    
    public int d(final Object o) {
        return this.c.d(o);
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o instanceof r && v.e((Object)this.b, (Object)((r)o).b));
    }
    
    public void h(final int n, final Object o, m v, final int n2) {
        v = v.v(-1201380429);
        int n4;
        if ((n2 & 0x6) == 0x0) {
            int n3;
            if (v.j(n)) {
                n3 = 4;
            }
            else {
                n3 = 2;
            }
            n4 = (n3 | n2);
        }
        else {
            n4 = n2;
        }
        int n5 = n4;
        if ((n2 & 0x30) == 0x0) {
            int n6;
            if (v.m(o)) {
                n6 = 32;
            }
            else {
                n6 = 16;
            }
            n5 = (n4 | n6);
        }
        int n7 = n5;
        if ((n2 & 0x180) == 0x0) {
            int n8;
            if (v.Y((Object)this)) {
                n8 = 256;
            }
            else {
                n8 = 128;
            }
            n7 = (n5 | n8);
        }
        if ((n7 & 0x93) == 0x92 && v.y()) {
            v.G();
        }
        else {
            if (p.J()) {
                p.S(-1201380429, n7, -1, "androidx.compose.foundation.pager.PagerLazyLayoutItemProvider.Item (LazyLayoutPager.kt:206)");
            }
            D.a(o, n, this.a.J(), (X8.p)D0.c.e(1142237095, true, (Object)new X8.p(this, n) {
                final r H;
                final int L;
                
                public final void a(final m m, int l) {
                    if ((l & 0x3) == 0x2 && m.y()) {
                        m.G();
                    }
                    else {
                        if (p.J()) {
                            p.S(1142237095, l, -1, "androidx.compose.foundation.pager.PagerLazyLayoutItemProvider.Item.<anonymous> (LazyLayoutPager.kt:208)");
                        }
                        final o j = r.j(this.H);
                        l = this.L;
                        final r h = this.H;
                        final d.a value = j.j().get(l);
                        ((l)value.c()).a().invoke((Object)r.k(h), (Object)(l - value.b()), (Object)m, (Object)0);
                        if (p.J()) {
                            p.R();
                        }
                    }
                }
            }, v, 54), v, (n7 >> 3 & 0xE) | 0xC00 | (n7 << 3 & 0x70));
            if (p.J()) {
                p.R();
            }
        }
        final b1 c = v.C();
        if (c != null) {
            c.a((X8.p)new X8.p(this, n, o, n2) {
                final r H;
                final int L;
                final Object M;
                final int Q;
                
                public final void a(final m m, final int n) {
                    this.H.h(this.L, this.M, m, P0.a(this.Q | 0x1));
                }
            });
        }
    }
    
    @Override
    public int hashCode() {
        return this.b.hashCode();
    }
}
