package c0;

import java.util.Collection;
import L8.f;
import Y.b$e;
import Y.b$m;
import e1.U$a;
import kotlin.jvm.internal.v;
import kotlin.jvm.internal.w;
import A1.c;
import A1.b;
import e1.G;
import i9.M;
import v0.t0;
import kotlin.jvm.internal.m;
import Y.b$f;
import d9.h;
import d9.n;
import Y.b$a;
import java.util.ArrayList;
import A1.d;
import W.l;
import W.k;
import java.util.List;
import A1.t;
import I0.c$c;
import I0.c$b;
import V.q;
import b0.x;

public abstract class s
{
    private static final e b(final int n, final List list, final int n2, final int n3, final int n4, final k k, final int n5) {
        e e;
        if (list.isEmpty()) {
            e = null;
        }
        else {
            Object value = list.get(0);
            final e e2 = (e)value;
            float n6 = -Math.abs(l.a(n, n2, n3, n4, e2.b(), e2.getIndex(), k, n5));
            final int p7 = L8.t.p(list);
            int n7 = 1;
            e = (e)value;
            if (1 <= p7) {
                while (true) {
                    final Object value2 = list.get(n7);
                    final e e3 = (e)value2;
                    final float n8 = -Math.abs(l.a(n, n2, n3, n4, e3.b(), e3.getIndex(), k, n5));
                    float n9 = n6;
                    if (Float.compare(n6, n8) < 0) {
                        value = value2;
                        n9 = n8;
                    }
                    e = (e)value;
                    if (n7 == p7) {
                        break;
                    }
                    ++n7;
                    n6 = n9;
                }
            }
        }
        return e;
    }
    
    private static final List c(final x x, final List list, final List list2, final List list3, final int n, final int n2, int i, int j, int n3, final q q, final boolean b, final d d, int n4, int s) {
        final int n5 = s + n4;
        int n6;
        if (q == q.Vertical) {
            n6 = n2;
        }
        else {
            n6 = n;
        }
        j = Math.min(n6, j);
        final int n7 = 0;
        if (i < j) {
            i = 1;
        }
        else {
            i = 0;
        }
        if (i != 0 && n3 != 0) {
            final StringBuilder sb = new StringBuilder();
            sb.append("non-zero pagesScrollOffset=");
            sb.append(n3);
            throw new IllegalStateException(sb.toString().toString());
        }
        final ArrayList list4 = new ArrayList(list.size() + list2.size() + list3.size());
        if (i != 0) {
            if (!list2.isEmpty() || !list3.isEmpty()) {
                throw new IllegalArgumentException("No extra pages");
            }
            final int size = list.size();
            final int[] array = new int[size];
            for (i = 0; i < size; ++i) {
                array[i] = s;
            }
            final int[] array2 = new int[size];
            for (i = 0; i < size; ++i) {
                array2[i] = 0;
            }
            final b$f d2 = b$a.a.d(x.v(n4));
            if (q == q.Vertical) {
                ((b$m)d2).b(d, n6, array, array2);
            }
            else {
                ((b$e)d2).c(d, n6, array, t.Ltr, array2);
            }
            Object o = L8.l.g0(array2);
            if (b) {
                o = n.u((h)o);
            }
            j = ((h)o).q();
            s = ((h)o).s();
            n4 = ((h)o).u();
            if (n4 <= 0 || (i = j) > s) {
                if (n4 >= 0 || s > j) {
                    return (List)list4;
                }
                i = j;
            }
            while (true) {
                n3 = array2[i];
                final e e = (e)list.get(d(i, b, size));
                j = n3;
                if (b) {
                    j = n6 - n3 - e.g();
                }
                e.i(j, n, n2);
                list4.add((Object)e);
                if (i == s) {
                    break;
                }
                i += n4;
            }
        }
        else {
            n4 = list2.size();
            i = n3;
            e e2;
            for (j = 0; j < n4; ++j) {
                e2 = (e)list2.get(j);
                i -= n5;
                e2.i(i, n, n2);
                list4.add((Object)e2);
            }
            e e3;
            for (j = list.size(), i = 0; i < j; ++i) {
                e3 = (e)list.get(i);
                e3.i(n3, n, n2);
                list4.add((Object)e3);
                n3 += n5;
            }
            e e4;
            for (j = list3.size(), i = n7; i < j; ++i) {
                e4 = (e)list3.get(i);
                e4.i(n3, n, n2);
                list4.add((Object)e4);
                n3 += n5;
            }
        }
        return (List)list4;
    }
    
    private static final int d(int n, final boolean b, final int n2) {
        if (b) {
            n = n2 - n - 1;
        }
        return n;
    }
    
    private static final List e(int i, final int n, int min, List n2, final X8.l l) {
        min = Math.min(min + i, n - 1);
        ++i;
        List list = null;
        final List list2 = null;
        if (i <= min) {
            List list3 = list2;
            while (true) {
                Object o = list3;
                if (list3 == null) {
                    o = new ArrayList();
                }
                ((List)o).add(l.invoke((Object)i));
                list = (List)o;
                if (i == min) {
                    break;
                }
                ++i;
                list3 = (List)o;
            }
        }
        final int size = n2.size();
        i = 0;
        List list4 = list;
        while (i < size) {
            final int intValue = ((Number)n2.get(i)).intValue();
            Object o2 = list4;
            if (min + 1 <= intValue) {
                o2 = list4;
                if (intValue < n) {
                    if ((o2 = list4) == null) {
                        o2 = new ArrayList();
                    }
                    ((List)o2).add(l.invoke((Object)intValue));
                }
            }
            ++i;
            list4 = (List)o2;
        }
        if ((n2 = list4) == null) {
            n2 = L8.t.n();
        }
        return n2;
    }
    
    private static final List f(int i, int max, List n, final X8.l l) {
        final int n2 = 0;
        max = Math.max(0, i - max);
        --i;
        List list = null;
        final List list2 = null;
        if (max <= i) {
            List list3 = list2;
            while (true) {
                Object o = list3;
                if (list3 == null) {
                    o = new ArrayList();
                }
                ((List)o).add(l.invoke((Object)i));
                list = (List)o;
                if (i == max) {
                    break;
                }
                --i;
                list3 = (List)o;
            }
        }
        final int size = n.size();
        List list4 = list;
        int intValue;
        Object o2;
        for (i = n2; i < size; ++i, list4 = (List)o2) {
            intValue = ((Number)n.get(i)).intValue();
            o2 = list4;
            if (intValue < max) {
                if ((o2 = list4) == null) {
                    o2 = new ArrayList();
                }
                ((List)o2).add(l.invoke((Object)intValue));
            }
        }
        if ((n = list4) == null) {
            n = L8.t.n();
        }
        return n;
    }
    
    private static final e g(final x x, final int n, final long n2, final r r, final long n3, final q q, final c$b c$b, final c$c c$c, final t t, final boolean b, final int n4) {
        return new e(n, n4, x.E0(n, n2), n3, r.b(n), q, c$b, c$c, t, b, null);
    }
    
    public static final u h(final x x, final int n, final r r, final int n2, int b, final int n3, final int n4, int n5, int i, final long n6, final q q, final c$c c$c, final c$b c$b, final boolean b2, final long n7, final int n8, final int n9, List e, final k k, final t0 t0, final M m, final X8.q q2) {
        if (b < 0) {
            throw new IllegalArgumentException("negative beforeContentPadding");
        }
        if (n3 < 0) {
            throw new IllegalArgumentException("negative afterContentPadding");
        }
        final int n10 = 0;
        final int f = n.f(n8 + n4, 0);
        if (n <= 0) {
            return new u(L8.t.n(), n8, n4, n3, q, -b, n2 + n3, false, n9, null, null, 0.0f, 0, false, k, (G)q2.invoke((Object)b.n(n6), (Object)b.m(n6), (Object)s$b.H), false, null, null, m, 393216, null);
        }
        final q vertical = q.Vertical;
        int l;
        if (q == vertical) {
            l = b.l(n6);
        }
        else {
            l = n8;
        }
        int j;
        if (q != vertical) {
            j = b.k(n6);
        }
        else {
            j = n8;
        }
        final long b3 = c.b(0, l, 0, j, 5, (Object)null);
        int n11;
        for (n11 = i, i = n5; i > 0 && n11 > 0; --i, n11 -= f) {}
        int n12 = n11 * -1;
        if ((n5 = i) >= n) {
            n5 = n - 1;
            n12 = 0;
        }
        final L8.k k2 = new L8.k();
        final int n13 = -b;
        if (n4 < 0) {
            i = n4;
        }
        else {
            i = 0;
        }
        final int n14 = i + n13;
        final int n15 = n12 + n14;
        int n16 = 0;
        i = n10;
        int n17;
        for (n17 = n15; n17 < 0 && n5 > 0; n17 += f) {
            --n5;
            final e g = g(x, n5, b3, r, n7, q, c$b, c$c, x.getLayoutDirection(), b2, n8);
            k2.add(i, (Object)g);
            n16 = Math.max(n16, g.c());
        }
        final int n18 = f;
        int n19;
        if (n17 < n14) {
            n19 = n14;
        }
        else {
            n19 = n17;
        }
        final int n20 = n19 - n14;
        final int n21 = n2 + n3;
        final int f2 = n.f(n21, i);
        final int n22 = -n20;
        final int n23 = i = i;
        int n24 = n5;
        int n25 = n23;
        int n26 = n22;
        while (n25 < ((f)k2).size()) {
            if (n26 >= f2) {
                ((f)k2).remove(n25);
                i = 1;
            }
            else {
                ++n24;
                n26 += n18;
                ++n25;
            }
        }
        final int n27 = n5;
        n5 = n20;
        boolean b4 = i != 0;
        i = n24;
        int n28 = n26;
        int n29 = n5;
        n5 = n18;
        int n30 = i;
        final int n31 = n21;
        i = n27;
        while (n30 < n && (n28 < f2 || n28 <= 0 || k2.isEmpty())) {
            final e g2 = g(x, n30, b3, r, n7, q, c$b, c$c, x.getLayoutDirection(), b2, n8);
            final int n32 = n - 1;
            int n33;
            if (n30 == n32) {
                n33 = n8;
            }
            else {
                n33 = n5;
            }
            n28 += n33;
            if (n28 <= n14 && n30 != n32) {
                n29 -= n5;
                i = n30 + 1;
                b4 = true;
            }
            else {
                n16 = Math.max(n16, g2.c());
                k2.add((Object)g2);
            }
            ++n30;
        }
        int n40;
        int n41;
        if (n28 < n2) {
            final int n34 = n2 - n28;
            final int n35 = n34 + n28;
            final int n36 = i;
            int n37;
            e g3;
            for (n37 = n29 - n34, i = n5, n5 = n36; n37 < b && n5 > 0; n37 += i) {
                --n5;
                g3 = g(x, n5, b3, r, n7, q, c$b, c$c, x.getLayoutDirection(), b2, n8);
                k2.add(0, (Object)g3);
                n16 = Math.max(n16, g3.c());
            }
            if (n37 < 0) {
                final int n38 = n35 + n37;
                final int n39 = 0;
                n40 = n5;
                n5 = n38;
                n41 = i;
                i = n39;
            }
            else {
                final int n42 = n37;
                final int n43 = n35;
                n40 = n5;
                n5 = n43;
                n41 = i;
                i = n42;
            }
        }
        else {
            n41 = n5;
            n5 = n28;
            n40 = i;
            i = n29;
        }
        if (i >= 0) {
            final int n44 = -i;
            e e2 = (e)k2.first();
            int n45;
            if (b <= 0 && n4 >= 0) {
                n45 = i;
            }
            else {
                for (int size = ((f)k2).size(), n46 = 0; n46 < size && i != 0 && n41 <= i && n46 != L8.t.p((List)k2); i -= n41, ++n46, e2 = (e)k2.get(n46)) {}
                n45 = i;
            }
            final List f3 = f(n40, n9, e, (X8.l)new X8.l(x, b3, r, n7, q, c$b, c$c, b2, n8) {
                final x H;
                final long L;
                final r M;
                final long Q;
                final q W;
                final c$b X;
                final c$c Y;
                final boolean Z;
                final int a0;
                
                public final e a(final int n) {
                    final x h = this.H;
                    return g(h, n, this.L, this.M, this.Q, this.W, this.X, this.Y, h.getLayoutDirection(), this.Z, this.a0);
                }
            });
            final int size2 = f3.size();
            i = n16;
            for (int n47 = 0; n47 < size2; ++n47) {
                i = Math.max(i, ((e)f3.get(n47)).c());
            }
            e = e(((e)k2.last()).getIndex(), n, n9, e, (X8.l)new X8.l(x, b3, r, n7, q, c$b, c$c, b2, n8) {
                final x H;
                final long L;
                final r M;
                final long Q;
                final q W;
                final c$b X;
                final c$c Y;
                final boolean Z;
                final int a0;
                
                public final e a(final int n) {
                    final x h = this.H;
                    return g(h, n, this.L, this.M, this.Q, this.W, this.X, this.Y, h.getLayoutDirection(), this.Z, this.a0);
                }
            });
            for (int size3 = e.size(), n48 = 0; n48 < size3; ++n48) {
                i = Math.max(i, ((e)e.get(n48)).c());
            }
            final boolean b5 = v.e((Object)e2, k2.first()) && f3.isEmpty() && e.isEmpty();
            final q vertical2 = q.Vertical;
            int n49;
            if (q == vertical2) {
                n49 = i;
            }
            else {
                n49 = n5;
            }
            final int i2 = c.i(n6, n49);
            if (q == vertical2) {
                i = n5;
            }
            final int h = c.h(n6, i);
            final List c = c(x, (List)k2, f3, e, i2, h, n5, n2, n44, q, b2, (d)x, n4, n8);
            Object o;
            if (b5) {
                o = c;
            }
            else {
                o = new ArrayList(c.size());
                int size4;
                Object value;
                e e3;
                for (size4 = c.size(), i = 0; i < size4; ++i) {
                    value = c.get(i);
                    e3 = (e)value;
                    if (e3.getIndex() >= ((e)k2.first()).getIndex() && e3.getIndex() <= ((e)k2.last()).getIndex()) {
                        ((Collection)o).add(value);
                    }
                }
            }
            Object n50;
            if (f3.isEmpty()) {
                n50 = L8.t.n();
            }
            else {
                final ArrayList list = new ArrayList(c.size());
                final int size5 = c.size();
                i = 0;
                while (true) {
                    n50 = list;
                    if (i >= size5) {
                        break;
                    }
                    final Object value2 = c.get(i);
                    if (((e)value2).getIndex() < ((e)k2.first()).getIndex()) {
                        ((Collection)list).add(value2);
                    }
                    ++i;
                }
            }
            Object n51;
            if (e.isEmpty()) {
                n51 = L8.t.n();
            }
            else {
                final ArrayList list2 = new ArrayList(c.size());
                final int size6 = c.size();
                i = 0;
                while (true) {
                    n51 = list2;
                    if (i >= size6) {
                        break;
                    }
                    final Object value3 = c.get(i);
                    if (((e)value3).getIndex() > ((e)k2.last()).getIndex()) {
                        ((Collection)list2).add(value3);
                    }
                    ++i;
                }
            }
            if (q == q.Vertical) {
                i = h;
            }
            else {
                i = i2;
            }
            final e b6 = b(i, (List)o, b, n3, n41, k, n);
            if (b6 != null) {
                i = b6.getIndex();
            }
            else {
                i = 0;
            }
            i = k.a(n2, n8, b, n3, i, n);
            if (b6 != null) {
                b = b6.b();
            }
            else {
                b = 0;
            }
            float n52;
            if (n41 == 0) {
                n52 = 0.0f;
            }
            else {
                n52 = n.n((i - b) / (float)n41, -0.5f, 0.5f);
            }
            return new u((List)o, n8, n4, n3, q, n13, n31, b2, n9, e2, b6, n52, n45, n30 < n || n5 > n2, k, (G)q2.invoke((Object)i2, (Object)h, (Object)new X8.l(c, t0) {
                final List H;
                final t0 L;
                
                public final void a(final U$a u$a) {
                    final List h = this.H;
                    for (int size = h.size(), i = 0; i < size; ++i) {
                        ((e)h.get(i)).h(u$a);
                    }
                    b0.M.a(this.L);
                }
            }), b4, (List)n50, (List)n51, m);
        }
        throw new IllegalArgumentException("invalid currentFirstPageScrollOffset");
    }
}
