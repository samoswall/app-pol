package c0;

import G0.k$a;
import v0.t0;
import java.util.List;
import L8.P;
import e1.G;
import X8.l;
import d9.n;
import A1.o;
import A1.b;
import A1.d;
import A1.c;
import T.j;
import b0.x;
import kotlin.jvm.internal.w;
import X8.p;
import v0.m;
import i9.M;
import W.k;
import I0.c$c;
import I0.c$b;
import V.q;
import Y.A;
import X8.a;

public abstract class t
{
    public static final p a(final a a, final C c, final A a2, final boolean b, final q q, final int n, final float n2, final g g, final c$b c$b, final c$c c$c, final k k, final M m, final a a3, final m i, int n3, int n4) {
        if (v0.p.J()) {
            v0.p.S(1391419623, n3, n4, "androidx.compose.foundation.pager.rememberPagerMeasurePolicy (PagerMeasurePolicy.kt:56)");
        }
        final boolean b2 = (((n3 & 0x70) ^ 0x30) > 32 && i.Y((Object)c)) || (n3 & 0x30) == 0x20;
        final boolean b3 = (((n3 & 0x380) ^ 0x180) > 256 && i.Y((Object)a2)) || (n3 & 0x180) == 0x100;
        final boolean b4 = (((n3 & 0x1C00) ^ 0xC00) > 2048 && i.d(b)) || (n3 & 0xC00) == 0x800;
        final boolean b5 = (((0xE000 & n3) ^ 0x6000) > 16384 && i.Y((Object)q)) || (n3 & 0x6000) == 0x4000;
        final boolean b6 = (((0xE000000 & n3) ^ 0x6000000) > 67108864 && i.Y((Object)c$b)) || (n3 & 0x6000000) == 0x4000000;
        final boolean b7 = (((0x70000000 & n3) ^ 0x30000000) > 536870912 && i.Y((Object)c$c)) || (n3 & 0x30000000) == 0x20000000;
        final boolean b8 = (((0x380000 & n3) ^ 0x180000) > 1048576 && i.h(n2)) || (0x180000 & n3) == 0x100000;
        final boolean b9 = (((0x1C00000 & n3) ^ 0xC00000) > 8388608 && i.Y((Object)g)) || (0xC00000 & n3) == 0x800000;
        final boolean b10 = (((n4 & 0xE) ^ 0x6) > 4 && i.Y((Object)k)) || (n4 & 0x6) == 0x4;
        if ((((n4 & 0x380) ^ 0x180) > 256 && i.Y((Object)a3)) || (n4 & 0x180) == 0x100) {
            n4 = 1;
        }
        else {
            n4 = 0;
        }
        if ((((0x70000 & n3) ^ 0x30000) > 131072 && i.j(n)) || (n3 & 0x30000) == 0x20000) {
            n3 = 1;
        }
        else {
            n3 = 0;
        }
        final boolean y = i.Y((Object)m);
        final Object g2 = i.g();
        Object o;
        if ((n4 | ((b2 | b3 | b4 | b5 | b6 | b7 | b8 | b9 | b10) ? 1 : 0) | n3 | (y ? 1 : 0)) != 0x0 || (o = g2) == m.a.a()) {
            o = new p(c, q, a2, b, n2, g, a, a3, c$c, c$b, n, k, m) {
                final C H;
                final q L;
                final A M;
                final boolean Q;
                final float W;
                final g X;
                final a Y;
                final a Z;
                final c$c a0;
                final c$b b0;
                final int c0;
                final k d0;
                final M e0;
                
                public final u a(final x x, final long n) {
                    b0.M.a(this.H.D());
                    final q l = this.L;
                    final q vertical = q.Vertical;
                    final boolean b = l == vertical;
                    q horizontal;
                    if (b) {
                        horizontal = vertical;
                    }
                    else {
                        horizontal = q.Horizontal;
                    }
                    j.a(n, horizontal);
                    int n2;
                    if (b) {
                        n2 = ((d)x).p1(this.M.c(x.getLayoutDirection()));
                    }
                    else {
                        n2 = ((d)x).p1(androidx.compose.foundation.layout.p.g(this.M, x.getLayoutDirection()));
                    }
                    int n3;
                    if (b) {
                        n3 = ((d)x).p1(this.M.b(x.getLayoutDirection()));
                    }
                    else {
                        n3 = ((d)x).p1(androidx.compose.foundation.layout.p.f(this.M, x.getLayoutDirection()));
                    }
                    final int p2 = ((d)x).p1(this.M.d());
                    final int p3 = ((d)x).p1(this.M.a());
                    final int n4 = p2 + p3;
                    final int n5 = n2 + n3;
                    int n6;
                    if (b) {
                        n6 = n4;
                    }
                    else {
                        n6 = n5;
                    }
                    if (b && !this.Q) {
                        n3 = p2;
                    }
                    else if (b && this.Q) {
                        n3 = p3;
                    }
                    else if (!b && !this.Q) {
                        n3 = n2;
                    }
                    final int n7 = n6 - n3;
                    final long o = c.o(n, -n5, -n4);
                    this.H.c0((d)x);
                    final int p4 = ((d)x).p1(this.W);
                    int n8;
                    if (b) {
                        n8 = A1.b.k(n) - n4;
                    }
                    else {
                        n8 = A1.b.l(n) - n5;
                    }
                    long n10;
                    if (this.Q && n8 <= 0) {
                        if (!b) {
                            n2 += n8;
                        }
                        int n9 = p2;
                        if (b) {
                            n9 = p2 + n8;
                        }
                        n10 = A1.o.a(n2, n9);
                    }
                    else {
                        n10 = A1.o.a(n2, p2);
                    }
                    final int f = n.f(this.X.a((d)x, n8, p4), 0);
                    final C h = this.H;
                    int i;
                    if (this.L == vertical) {
                        i = A1.b.l(o);
                    }
                    else {
                        i = f;
                    }
                    int k;
                    if (this.L != vertical) {
                        k = A1.b.k(o);
                    }
                    else {
                        k = f;
                    }
                    h.d0(c.b(0, i, 0, k, 5, (Object)null));
                    final r r = (r)this.Y.invoke();
                    Object o2 = G0.k.e;
                    final C h2 = this.H;
                    final k d0 = this.d0;
                    final G0.k d2 = ((k$a)o2).d();
                    Object o3;
                    if (d2 != null) {
                        o3 = d2.h();
                    }
                    else {
                        o3 = null;
                    }
                    final G0.k f2 = ((k$a)o2).f(d2);
                    try {
                        final int u = h2.U(r, h2.v());
                        final int d3 = m.d(d0, n8, f, p4, n3, n7, h2.v(), h2.w(), h2.F());
                        final K8.M a = K8.M.a;
                        ((k$a)o2).m(d2, f2, (l)o3);
                        o3 = b0.n.a((b0.t)r, this.H.J(), this.H.u());
                        final int intValue = ((Number)this.Z.invoke()).intValue();
                        o2 = this.H.K();
                        final u h3 = s.h(x, intValue, r, n8, n3, n7, p4, u, d3, o, this.L, this.a0, this.b0, this.Q, n10, f, this.c0, (List)o3, this.d0, (t0)o2, this.e0, (X8.q)new X8.q(x, n, n5, n4) {
                            final x H;
                            final long L;
                            final int M;
                            final int Q;
                            
                            public final G a(final int n, final int n2, final l l) {
                                return this.H.c1(c.i(this.L, n + this.M), c.h(this.L, n2 + this.Q), P.j(), l);
                            }
                        });
                        C.p(this.H, h3, false, 2, null);
                        return h3;
                    }
                    finally {
                        ((k$a)o2).m(d2, f2, (l)o3);
                    }
                }
            };
            i.P(o);
        }
        final p p16 = (p)o;
        if (v0.p.J()) {
            v0.p.R();
        }
        return p16;
    }
}
