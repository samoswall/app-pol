package c0;

import X8.l;
import java.util.Map;
import A1.s;
import L8.t;
import kotlin.jvm.internal.m;
import i9.M;
import W.k;
import V.q;
import java.util.List;
import e1.G;

public final class u implements n, G
{
    private final List a;
    private final int b;
    private final int c;
    private final int d;
    private final q e;
    private final int f;
    private final int g;
    private final boolean h;
    private final int i;
    private final e j;
    private final e k;
    private float l;
    private int m;
    private boolean n;
    private final k o;
    private final boolean p;
    private final List q;
    private final List r;
    private final M s;
    private final G t;
    
    public u(final List a, final int b, final int c, final int d, final q e, final int f, final int g, final boolean h, final int i, final e j, final e k, final float l, final int m, final boolean n, final k o, final G t, final boolean p20, final List q, final List r, final M s) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = i;
        this.j = j;
        this.k = k;
        this.l = l;
        this.m = m;
        this.n = n;
        this.o = o;
        this.p = p20;
        this.q = q;
        this.r = r;
        this.s = s;
        this.t = t;
    }
    
    @Override
    public long a() {
        return A1.s.a(this.c(), this.b());
    }
    
    public int b() {
        return this.t.b();
    }
    
    public int c() {
        return this.t.c();
    }
    
    @Override
    public int d() {
        return this.d;
    }
    
    @Override
    public int e() {
        return this.g;
    }
    
    @Override
    public q f() {
        return this.e;
    }
    
    @Override
    public int g() {
        return -this.h();
    }
    
    @Override
    public int getPageSize() {
        return this.b;
    }
    
    @Override
    public int h() {
        return this.f;
    }
    
    @Override
    public boolean i() {
        return this.h;
    }
    
    @Override
    public List j() {
        return this.a;
    }
    
    @Override
    public int k() {
        return this.c;
    }
    
    @Override
    public int l() {
        return this.i;
    }
    
    @Override
    public k m() {
        return this.o;
    }
    
    public final boolean n() {
        final e j = this.j;
        boolean b = false;
        int index;
        if (j != null) {
            index = j.getIndex();
        }
        else {
            index = 0;
        }
        if (index != 0 || this.m != 0) {
            b = true;
        }
        return b;
    }
    
    public final boolean o() {
        return this.n;
    }
    
    public final e p() {
        return this.k;
    }
    
    public Map q() {
        return this.t.q();
    }
    
    public void r() {
        this.t.r();
    }
    
    public l s() {
        return this.t.s();
    }
    
    public final float t() {
        return this.l;
    }
    
    public final e u() {
        return this.j;
    }
    
    public final int v() {
        return this.m;
    }
    
    public final boolean w(final int n) {
        final int n2 = this.getPageSize() + this.k();
        final boolean p = this.p;
        final boolean b = false;
        final int n3 = 0;
        boolean b2 = b;
        if (!p) {
            b2 = b;
            if (!this.j().isEmpty()) {
                b2 = b;
                if (this.j != null) {
                    final int n4 = this.m - n;
                    b2 = b;
                    if (n4 >= 0) {
                        b2 = b;
                        if (n4 < n2) {
                            float n5;
                            if (n2 != 0) {
                                n5 = n / (float)n2;
                            }
                            else {
                                n5 = 0.0f;
                            }
                            final float n6 = this.l - n5;
                            b2 = b;
                            if (this.k != null) {
                                b2 = b;
                                if (n6 < 0.5f) {
                                    if (n6 <= -0.5f) {
                                        b2 = b;
                                    }
                                    else {
                                        final e e = (e)L8.t.k0(this.j());
                                        final e e2 = (e)L8.t.v0(this.j());
                                        if (n < 0) {
                                            b2 = b;
                                            if (Math.min(e.b() + n2 - this.h(), e2.b() + n2 - this.e()) <= -n) {
                                                return b2;
                                            }
                                        }
                                        else {
                                            b2 = b;
                                            if (Math.min(this.h() - e.b(), this.e() - e2.b()) <= n) {
                                                return b2;
                                            }
                                        }
                                        this.l -= n5;
                                        this.m -= n;
                                        final List j = this.j();
                                        for (int size = j.size(), i = 0; i < size; ++i) {
                                            ((e)j.get(i)).a(n);
                                        }
                                        final List q = this.q;
                                        for (int size2 = q.size(), k = 0; k < size2; ++k) {
                                            ((e)q.get(k)).a(n);
                                        }
                                        final List r = this.r;
                                        for (int size3 = r.size(), l = n3; l < size3; ++l) {
                                            ((e)r.get(l)).a(n);
                                        }
                                        final boolean n7 = this.n;
                                        final boolean b3 = b2 = true;
                                        if (!n7) {
                                            b2 = b3;
                                            if (n > 0) {
                                                this.n = true;
                                                b2 = b3;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return b2;
    }
}
