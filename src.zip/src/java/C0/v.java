package c0;

public interface v
{
}
