package c0;

public final class w implements v
{
    public static final w a;
    
    static {
        a = new w();
    }
    
    private w() {
    }
}
