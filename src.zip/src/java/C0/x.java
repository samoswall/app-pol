package c0;

import v0.S;
import v0.Y;
import java.util.Collection;
import b0.t;
import b0.u;
import v0.G0;
import v0.l1;
import b0.B;
import v0.p0;
import v0.q0;

public final class x
{
    private final C a;
    private final q0 b;
    private final p0 c;
    private boolean d;
    private Object e;
    private final B f;
    
    public x(final int n, final float n2, final C a) {
        this.a = a;
        this.b = l1.a(n);
        this.c = G0.a(n2);
        this.f = new B(n, 30, 100);
    }
    
    private final void g(final int n) {
        this.b.l(n);
    }
    
    private final void h(final float n) {
        this.c.k(n);
    }
    
    private final void i(final int n, final float n2) {
        this.g(n);
        this.f.j(n);
        this.h(n2);
    }
    
    public final void a(final int n) {
        float n2;
        if (this.a.H() == 0) {
            n2 = 0.0f;
        }
        else {
            n2 = n / (float)this.a.H();
        }
        this.h(this.c() + n2);
    }
    
    public final int b() {
        return ((Y)this.b).g();
    }
    
    public final float c() {
        return ((S)this.c).e();
    }
    
    public final B d() {
        return this.f;
    }
    
    public final int e(final r r, final int n) {
        final int a = u.a((t)r, this.e, n);
        if (n != a) {
            this.g(a);
            this.f.j(n);
        }
        return a;
    }
    
    public final void f(final int n, final float n2) {
        this.i(n, n2);
        this.e = null;
    }
    
    public final void j(final float n) {
        this.h(n);
    }
    
    public final void k(final c0.u u) {
        final e p = u.p();
        Object d;
        if (p != null) {
            d = p.d();
        }
        else {
            d = null;
        }
        this.e = d;
        if (this.d || !((Collection)u.j()).isEmpty()) {
            this.d = true;
            final e p2 = u.p();
            int index;
            if (p2 != null) {
                index = p2.getIndex();
            }
            else {
                index = 0;
            }
            this.i(index, u.t());
        }
    }
}
