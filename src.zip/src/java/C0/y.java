package c0;

import Z8.b;

public abstract class y
{
    public static final long a(final C c) {
        return c.v() * (long)c.H() + b.g(c.w() * c.H());
    }
}
