package c0;

import v0.p;
import b0.F;
import v0.m;

public abstract class z
{
    public static final F a(final C c, final boolean b, final m m, final int n) {
        if (p.J()) {
            p.S(-786344289, n, -1, "androidx.compose.foundation.pager.rememberPagerSemanticState (PagerSemantics.kt:26)");
        }
        boolean b2 = false;
        final boolean b3 = (((n & 0xE) ^ 0x6) > 4 && m.Y((Object)c)) || (n & 0x6) == 0x4;
        if ((((n & 0x70) ^ 0x30) > 32 && m.d(b)) || (n & 0x30) == 0x20) {
            b2 = true;
        }
        final Object g = m.g();
        F a;
        if ((b3 | b2) || (a = (F)g) == m.a.a()) {
            a = d.a(c, b);
            m.P((Object)a);
        }
        final F f = a;
        if (p.J()) {
            p.R();
        }
        return f;
    }
}
