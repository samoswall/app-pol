package c1;

import g1.j;

public interface a extends j
{
    boolean j0(final b p0);
    
    boolean s1(final b p0);
}
