package c1;

public final class b
{
    private final float a;
    private final float b;
    private final long c;
    private final int d;
    
    public b(final float a, final float b, final long c, final int d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o instanceof b) {
            final b b = (b)o;
            if (b.a == this.a && b.b == this.b && b.c == this.c && b.d == this.d) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return ((Float.hashCode(this.a) * 31 + Float.hashCode(this.b)) * 31 + Long.hashCode(this.c)) * 31 + Integer.hashCode(this.d);
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("RotaryScrollEvent(verticalScrollPixels=");
        sb.append(this.a);
        sb.append(",horizontalScrollPixels=");
        sb.append(this.b);
        sb.append(",uptimeMillis=");
        sb.append(this.c);
        sb.append(",deviceId=");
        sb.append(this.d);
        sb.append(')');
        return sb.toString();
    }
}
