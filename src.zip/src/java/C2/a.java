package c2;

import b2.d;
import b2.e;

public final class a implements e
{
    @Override
    public Object a(final d d, final P8.d d2) {
        throw d;
    }
}
