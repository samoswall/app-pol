package c2;

import b2.d;
import kotlin.jvm.internal.v;
import X8.l;
import b2.e;

public final class b implements e
{
    private final l a;
    
    public b(final l a) {
        v.j((Object)a, "produceNewData");
        this.a = a;
    }
    
    @Override
    public Object a(final d d, final P8.d d2) {
        return this.a.invoke((Object)d);
    }
}
