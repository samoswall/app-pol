package c3;

import android.view.View;

public interface a
{
    View getRoot();
}
