package c3;

import android.view.ViewGroup;
import android.view.View;

public abstract class b
{
    public static View a(View viewById, final int n) {
        if (!(viewById instanceof ViewGroup)) {
            return null;
        }
        final ViewGroup viewGroup = (ViewGroup)viewById;
        for (int childCount = viewGroup.getChildCount(), i = 0; i < childCount; ++i) {
            viewById = viewGroup.getChildAt(i).findViewById(n);
            if (viewById != null) {
                return viewById;
            }
        }
        return null;
    }
}
