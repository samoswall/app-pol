package C3;

import android.graphics.Bitmap;
import java.util.Iterator;
import java.util.Map$Entry;
import L8.P;
import java.util.LinkedHashMap;
import kotlin.jvm.internal.v;
import android.os.Parcel;
import kotlin.jvm.internal.m;
import java.util.Map;
import android.os.Parcelable$Creator;
import android.os.Parcelable;
import I3.j;
import android.content.Context;

public interface c
{
    void a(final int p0);
    
    c b(final b p0);
    
    void c(final b p0, final c p1);
    
    public static final class a
    {
        private final Context a;
        private double b;
        private int c;
        private boolean d;
        private boolean e;
        
        public a(final Context a) {
            this.a = a;
            this.b = j.e(a);
            this.d = true;
            this.e = true;
        }
        
        public final c a() {
            i i;
            if (this.e) {
                i = new g();
            }
            else {
                i = new b();
            }
            h h;
            if (this.d) {
                final double b = this.b;
                int n;
                if (b > 0.0) {
                    n = j.c(this.a, b);
                }
                else {
                    n = this.c;
                }
                if (n > 0) {
                    h = new f(n, i);
                }
                else {
                    h = new C3.a(i);
                }
            }
            else {
                h = new C3.a(i);
            }
            return new e(h, i);
        }
    }
    
    public static final class b implements Parcelable
    {
        @Deprecated
        public static final Parcelable$Creator<b> CREATOR;
        private static final b c;
        private final String a;
        private final Map b;
        
        static {
            c = new b(null);
            CREATOR = (Parcelable$Creator)new Parcelable$Creator() {
                public b a(final Parcel parcel) {
                    final String string = parcel.readString();
                    v.g((Object)string);
                    final int int1 = parcel.readInt();
                    final LinkedHashMap linkedHashMap = new LinkedHashMap(int1);
                    for (int i = 0; i < int1; ++i) {
                        final String string2 = parcel.readString();
                        v.g((Object)string2);
                        final String string3 = parcel.readString();
                        v.g((Object)string3);
                        ((Map)linkedHashMap).put((Object)string2, (Object)string3);
                    }
                    return new b(string, (Map)linkedHashMap);
                }
                
                public b[] b(final int n) {
                    return new b[n];
                }
            };
        }
        
        public b(final String a, final Map b) {
            this.a = a;
            this.b = b;
        }
        
        public final b a(final String s, final Map map) {
            return new b(s, map);
        }
        
        public int describeContents() {
            return 0;
        }
        
        public final Map e() {
            return this.b;
        }
        
        @Override
        public boolean equals(final Object o) {
            boolean b = true;
            if (this == o) {
                return true;
            }
            if (o instanceof b) {
                final String a = this.a;
                final b b2 = (b)o;
                if (v.e((Object)a, (Object)b2.a) && v.e((Object)this.b, (Object)b2.b)) {
                    return b;
                }
            }
            b = false;
            return b;
        }
        
        @Override
        public int hashCode() {
            return this.a.hashCode() * 31 + this.b.hashCode();
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append("Key(key=");
            sb.append(this.a);
            sb.append(", extras=");
            sb.append((Object)this.b);
            sb.append(')');
            return sb.toString();
        }
        
        public void writeToParcel(final Parcel parcel, final int n) {
            parcel.writeString(this.a);
            parcel.writeInt(this.b.size());
            for (final Map$Entry map$Entry : this.b.entrySet()) {
                final String s = (String)map$Entry.getKey();
                final String s2 = (String)map$Entry.getValue();
                parcel.writeString(s);
                parcel.writeString(s2);
            }
        }
        
        private static final class b
        {
        }
    }
    
    public static final class c
    {
        private final Bitmap a;
        private final Map b;
        
        public c(final Bitmap a, final Map b) {
            this.a = a;
            this.b = b;
        }
        
        public final Bitmap a() {
            return this.a;
        }
        
        public final Map b() {
            return this.b;
        }
        
        @Override
        public boolean equals(final Object o) {
            boolean b = true;
            if (this == o) {
                return true;
            }
            if (o instanceof c) {
                final Bitmap a = this.a;
                final c c = (c)o;
                if (v.e((Object)a, (Object)c.a) && v.e((Object)this.b, (Object)c.b)) {
                    return b;
                }
            }
            b = false;
            return b;
        }
        
        @Override
        public int hashCode() {
            return this.a.hashCode() * 31 + this.b.hashCode();
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append("Value(bitmap=");
            sb.append((Object)this.a);
            sb.append(", extras=");
            sb.append((Object)this.b);
            sb.append(')');
            return sb.toString();
        }
    }
}
