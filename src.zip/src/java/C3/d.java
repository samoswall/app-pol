package C3;

import android.graphics.Bitmap;
import java.util.LinkedHashMap;
import z3.a$b;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.BitmapDrawable;
import E3.o;
import z3.b$a;
import java.util.List;
import java.util.Collection;
import L8.P;
import java.util.Map;
import E3.k;
import I3.a;
import I3.j;
import I3.i;
import w3.f;
import kotlin.jvm.internal.v;
import F3.b;
import F3.h;
import E3.g;
import I3.p;
import kotlin.jvm.internal.m;
import E3.n;
import u3.e;

public final class d
{
    public static final a c;
    private final e a;
    private final n b;
    
    static {
        c = new a(null);
    }
    
    public d(final e a, final n b, final p p3) {
        this.a = a;
        this.b = b;
    }
    
    private final String b(final c.c c) {
        final Object value = c.b().get((Object)"coil#disk_cache_key");
        String s;
        if (value instanceof String) {
            s = (String)value;
        }
        else {
            s = null;
        }
        return s;
    }
    
    private final boolean d(final c.c c) {
        final Object value = c.b().get((Object)"coil#is_sampled");
        Boolean b;
        if (value instanceof Boolean) {
            b = (Boolean)value;
        }
        else {
            b = null;
        }
        return b != null && b;
    }
    
    private final boolean e(final g g, final c.b b, final c.c c, final h h, final F3.g g2) {
        final boolean d = this.d(c);
        if (b.a(h)) {
            return !d;
        }
        final String s = (String)b.e().get((Object)"coil#transformation_size");
        if (s != null) {
            return v.e((Object)s, (Object)h.toString());
        }
        final int width = c.a().getWidth();
        final int height = c.a().getHeight();
        final F3.c b2 = h.b();
        final boolean b3 = b2 instanceof F3.c.a;
        int a = Integer.MAX_VALUE;
        int a2;
        if (b3) {
            a2 = ((F3.c.a)b2).a;
        }
        else {
            a2 = Integer.MAX_VALUE;
        }
        final F3.c a3 = h.a();
        if (a3 instanceof F3.c.a) {
            a = ((F3.c.a)a3).a;
        }
        final double c2 = f.c(width, height, a2, a, g2);
        final boolean a4 = i.a(g);
        if (a4) {
            final double i = d9.n.i(c2, 1.0);
            if (Math.abs(a2 - width * i) <= 1.0 || Math.abs(a - i * height) <= 1.0) {
                return true;
            }
        }
        else if ((j.r(a2) || Math.abs(a2 - width) <= 1) && (j.r(a) || Math.abs(a - height) <= 1)) {
            return true;
        }
        if (c2 != 1.0 && !a4) {
            return false;
        }
        if (c2 > 1.0 && d) {
            return false;
        }
        return true;
    }
    
    public final c.c a(final g g, final c.b b, final h h, final F3.g g2) {
        final boolean readEnabled = g.C().getReadEnabled();
        final c.c c = null;
        if (!readEnabled) {
            return null;
        }
        final c c2 = this.a.c();
        Object b2;
        if (c2 != null) {
            b2 = c2.b(b);
        }
        else {
            b2 = null;
        }
        c.c c3 = c;
        if (b2 != null) {
            c3 = c;
            if (this.c(g, b, (c.c)b2, h, g2)) {
                c3 = (c.c)b2;
            }
        }
        return c3;
    }
    
    public final boolean c(final g g, final c.b b, final c.c c, final h h, final F3.g g2) {
        return this.b.c(g, I3.a.c(c.a())) && this.e(g, b, c, h, g2);
    }
    
    public final c.b f(final g g, final Object o, final k k, final u3.c c) {
        final c.b b = g.B();
        if (b != null) {
            return b;
        }
        c.k(g, o);
        final String f = this.a.getComponents().f(o, k);
        c.i(g, f);
        if (f == null) {
            return null;
        }
        final List o2 = g.O();
        final Map g2 = g.E().g();
        if (o2.isEmpty() && g2.isEmpty()) {
            return new c.b(f, null, 2, null);
        }
        final Map x = P.x(g2);
        if (!((Collection)o2).isEmpty()) {
            final List o3 = g.O();
            if (o3.size() > 0) {
                androidx.appcompat.app.v.a(o3.get(0));
                final StringBuilder sb = new StringBuilder();
                sb.append("coil#transformation_");
                sb.append(0);
                throw null;
            }
            x.put((Object)"coil#transformation_size", (Object)k.n().toString());
        }
        return new c.b(f, x);
    }
    
    public final o g(final b$a b$a, final g g, final c.b b, final c.c c) {
        return new o((Drawable)new BitmapDrawable(g.l().getResources(), c.a()), g, w3.d.MEMORY_CACHE, b, this.b(c), this.d(c), j.s(b$a));
    }
    
    public final boolean h(final c.b b, final g g, final a$b a$b) {
        if (!g.C().getWriteEnabled()) {
            return false;
        }
        final c c = this.a.c();
        if (c != null) {
            if (b != null) {
                final Drawable e = a$b.e();
                BitmapDrawable bitmapDrawable;
                if (e instanceof BitmapDrawable) {
                    bitmapDrawable = (BitmapDrawable)e;
                }
                else {
                    bitmapDrawable = null;
                }
                if (bitmapDrawable != null) {
                    final Bitmap bitmap = bitmapDrawable.getBitmap();
                    if (bitmap != null) {
                        final LinkedHashMap linkedHashMap = new LinkedHashMap();
                        ((Map)linkedHashMap).put((Object)"coil#is_sampled", (Object)a$b.f());
                        final String d = a$b.d();
                        if (d != null) {
                            ((Map)linkedHashMap).put((Object)"coil#disk_cache_key", (Object)d);
                        }
                        c.c(b, new c.c(bitmap, (Map)linkedHashMap));
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public static final class a
    {
        private a() {
        }
    }
}
