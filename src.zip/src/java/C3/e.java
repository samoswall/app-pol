package C3;

public final class e implements c
{
    private final h a;
    private final i b;
    
    public e(final h a, final i b) {
        this.a = a;
        this.b = b;
    }
    
    @Override
    public void a(final int n) {
        this.a.a(n);
        this.b.a(n);
    }
    
    @Override
    public c b(final b b) {
        c c;
        if ((c = this.a.b(b)) == null) {
            c = this.b.b(b);
        }
        return c;
    }
    
    @Override
    public void c(final b b, final c c) {
        this.a.c(b.d(b, null, I3.c.b(b.e()), 1, null), c.a(), I3.c.b(c.b()));
    }
}
