package C3;

import I3.a;
import java.util.Map;
import android.graphics.Bitmap;
import androidx.collection.u;

public final class f implements h
{
    private final i a;
    private final f$b b;
    
    public f(final int n, final i a) {
        this.a = a;
        this.b = new u(n, this) {
            final f a;
            
            protected void b(final boolean b, final c.b b2, final a a, final a a2) {
                f.d(this.a).c(b2, a.a(), a.b(), a.c());
            }
            
            protected int c(final c.b b, final a a) {
                return a.c();
            }
        };
    }
    
    public static final /* synthetic */ i d(final f f) {
        return f.a;
    }
    
    @Override
    public void a(final int n) {
        if (n >= 40) {
            this.e();
        }
        else if (10 <= n && n < 20) {
            this.b.trimToSize(this.g() / 2);
        }
    }
    
    @Override
    public c.c b(final c.b b) {
        final a a = (a)this.b.get((Object)b);
        Object o;
        if (a != null) {
            o = new c.c(a.a(), a.b());
        }
        else {
            o = null;
        }
        return (c.c)o;
    }
    
    @Override
    public void c(final c.b b, final Bitmap bitmap, final Map map) {
        final int a = I3.a.a(bitmap);
        if (a <= this.f()) {
            this.b.put((Object)b, (Object)new a(bitmap, map, a));
        }
        else {
            this.b.remove((Object)b);
            this.a.c(b, bitmap, map, a);
        }
    }
    
    public void e() {
        this.b.evictAll();
    }
    
    public int f() {
        return this.b.maxSize();
    }
    
    public int g() {
        return this.b.size();
    }
    
    private static final class a
    {
        private final Bitmap a;
        private final Map b;
        private final int c;
        
        public a(final Bitmap a, final Map b, final int c) {
            this.a = a;
            this.b = b;
            this.c = c;
        }
        
        public final Bitmap a() {
            return this.a;
        }
        
        public final Map b() {
            return this.b;
        }
        
        public final int c() {
            return this.c;
        }
    }
}
