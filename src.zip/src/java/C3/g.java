package C3;

import java.util.Collection;
import java.lang.ref.Reference;
import java.util.Iterator;
import java.util.List;
import L8.t;
import java.lang.ref.WeakReference;
import java.util.Map;
import android.graphics.Bitmap;
import java.util.ArrayList;
import kotlin.jvm.internal.m;
import java.util.LinkedHashMap;

public final class g implements i
{
    public static final a c;
    private final LinkedHashMap a;
    private int b;
    
    static {
        c = new a(null);
    }
    
    public g() {
        this.a = new LinkedHashMap();
    }
    
    private final void e() {
        if (this.b++ >= 10) {
            this.d();
        }
    }
    
    @Override
    public void a(final int n) {
        monitorenter(this);
        if (n >= 10 && n != 20) {
            try {
                this.d();
            }
            finally {
                monitorexit(this);
            }
        }
        monitorexit(this);
    }
    
    @Override
    public c.c b(final c.b b) {
        monitorenter(this);
    Label_0117_Outer:
        while (true) {
        Label_0104_Outer:
            while (true) {
                while (true) {
                    Label_0102: {
                        try {
                            final ArrayList list = (ArrayList)this.a.get((Object)b);
                            final c.c c = null;
                            if (list == null) {
                                monitorexit(this);
                                return null;
                            }
                            final int size = ((List)list).size();
                            final int n = 0;
                            Object o = c;
                            if (n >= size) {
                                break Label_0117;
                            }
                            final b b2 = (b)((List)list).get(n);
                            final Bitmap bitmap = (Bitmap)((Reference)b2.a()).get();
                            if (bitmap != null) {
                                o = new c.c(bitmap, b2.b());
                                break Label_0104;
                            }
                            break Label_0102;
                        }
                        finally {
                            monitorexit(this);
                            this.e();
                            monitorexit(this);
                            final Object o;
                            return (c.c)o;
                            Label_0111: {
                                int n = 0;
                                ++n;
                            }
                            continue Label_0117_Outer;
                            iftrue(Label_0111:)(o == null);
                            continue Label_0104_Outer;
                            o = null;
                            continue;
                        }
                    }
                    break;
                }
                break;
            }
            break;
        }
    }
    
    @Override
    public void c(final c.b b, final Bitmap bitmap, final Map map, final int n) {
        monitorenter(this);
        Label_0058: {
            try {
                final LinkedHashMap a = this.a;
                Object value;
                if ((value = ((Map)a).get((Object)b)) == null) {
                    value = new ArrayList();
                    ((Map)a).put((Object)b, value);
                }
                break Label_0058;
            }
            finally {
                monitorexit(this);
            Label_0191_Outer:
                while (true) {
                    int n2 = 0;
                    int size = 0;
                    iftrue(Label_0182:)(n2 >= size);
                    ArrayList list = null;
                    final b b2 = (b)list.get(n2);
                    iftrue(Label_0176:)(n < b2.d());
                    while (true) {
                        final b b3;
                        final int identityHashCode;
                        Block_6: {
                            break Block_6;
                            Label_0182: {
                                ((Collection)list).add((Object)b3);
                            }
                            break Label_0191;
                            final Object value;
                            list = (ArrayList)value;
                            identityHashCode = System.identityHashCode((Object)bitmap);
                            b3 = new b(identityHashCode, new WeakReference((Object)bitmap), map, n);
                            size = list.size();
                            n2 = 0;
                            continue Label_0191_Outer;
                        }
                        iftrue(Label_0165:)(b2.c() != identityHashCode || ((Reference)b2.a()).get() != bitmap);
                        list.set(n2, (Object)b3);
                        this.e();
                        monitorexit(this);
                        return;
                        Label_0165: {
                            list.add(n2, (Object)b3);
                        }
                        continue;
                    }
                    Label_0176: {
                        ++n2;
                    }
                    continue Label_0191_Outer;
                }
            }
        }
    }
    
    public final void d() {
        this.b = 0;
        final Iterator iterator = this.a.values().iterator();
        while (iterator.hasNext()) {
            final ArrayList list = (ArrayList)iterator.next();
            if (((Collection)list).size() <= 1) {
                final b b = (b)t.m0((List)list);
                Bitmap bitmap = null;
                Label_0095: {
                    if (b != null) {
                        final WeakReference a = b.a();
                        if (a != null) {
                            bitmap = (Bitmap)((Reference)a).get();
                            break Label_0095;
                        }
                    }
                    bitmap = null;
                }
                if (bitmap != null) {
                    continue;
                }
                iterator.remove();
            }
            else {
                final int size = ((List)list).size();
                int i = 0;
                int n = 0;
                while (i < size) {
                    final int n2 = i - n;
                    int n3 = n;
                    if (((Reference)((b)((List)list).get(n2)).a()).get() == null) {
                        ((List)list).remove(n2);
                        n3 = n + 1;
                    }
                    ++i;
                    n = n3;
                }
                if (!list.isEmpty()) {
                    continue;
                }
                iterator.remove();
            }
        }
    }
    
    public static final class a
    {
        private a() {
        }
    }
    
    public static final class b
    {
        private final int a;
        private final WeakReference b;
        private final Map c;
        private final int d;
        
        public b(final int a, final WeakReference b, final Map c, final int d) {
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
        }
        
        public final WeakReference a() {
            return this.b;
        }
        
        public final Map b() {
            return this.c;
        }
        
        public final int c() {
            return this.a;
        }
        
        public final int d() {
            return this.d;
        }
    }
}
