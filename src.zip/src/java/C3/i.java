package C3;

import java.util.Map;
import android.graphics.Bitmap;

public interface i
{
    void a(final int p0);
    
    c.c b(final c.b p0);
    
    void c(final c.b p0, final Bitmap p1, final Map p2, final int p3);
}
