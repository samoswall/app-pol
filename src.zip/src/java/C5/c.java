package c5;

import android.util.Base64;

public abstract class c
{
    public static byte[] a(final String s) {
        if (s == null) {
            return null;
        }
        return Base64.decode(s, 10);
    }
    
    public static byte[] b(final String s) {
        if (s == null) {
            return null;
        }
        return Base64.decode(s, 11);
    }
    
    public static String c(final byte[] array) {
        if (array == null) {
            return null;
        }
        return Base64.encodeToString(array, 0);
    }
    
    public static String d(final byte[] array) {
        if (array == null) {
            return null;
        }
        return Base64.encodeToString(array, 10);
    }
    
    public static String e(final byte[] array) {
        if (array == null) {
            return null;
        }
        return Base64.encodeToString(array, 11);
    }
}
