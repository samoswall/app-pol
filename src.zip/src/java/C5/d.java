package c5;

public interface d
{
    long a();
    
    long b();
    
    long c();
}
