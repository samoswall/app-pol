package c5;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public abstract class e
{
    public static List a(final Object o) {
        return Collections.singletonList(o);
    }
    
    public static List b(final Object... array) {
        final int length = array.length;
        if (length == 0) {
            return Collections.emptyList();
        }
        if (length != 1) {
            return Collections.unmodifiableList(Arrays.asList(array));
        }
        return Collections.singletonList(array[0]);
    }
}
