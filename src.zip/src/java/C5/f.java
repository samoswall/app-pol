package c5;

import android.util.Log;
import com.google.android.gms.common.internal.r;
import android.content.Context;

public abstract class f
{
    private static final String[] a;
    
    static {
        a = new String[] { "android.", "com.android.", "dalvik.", "java.", "javax." };
    }
    
    public static boolean a(final Context context, final Throwable t) {
        try {
            r.l((Object)context);
            r.l((Object)t);
        }
        catch (final Exception ex) {
            Log.e("CrashUtils", "Error adding exception to DropBox!", (Throwable)ex);
        }
        return false;
    }
}
