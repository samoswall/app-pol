package c5;

import android.os.SystemClock;

public class g implements d
{
    private static final g a;
    
    static {
        a = new g();
    }
    
    private g() {
    }
    
    public static d d() {
        return g.a;
    }
    
    @Override
    public final long a() {
        return System.currentTimeMillis();
    }
    
    @Override
    public final long b() {
        return System.nanoTime();
    }
    
    @Override
    public final long c() {
        return SystemClock.elapsedRealtime();
    }
}
