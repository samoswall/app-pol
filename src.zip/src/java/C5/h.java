package c5;

import android.os.Build;
import W4.j;
import android.content.pm.PackageManager;
import android.content.Context;

public abstract class h
{
    private static Boolean a;
    private static Boolean b;
    private static Boolean c;
    private static Boolean d;
    
    public static boolean a(final Context context) {
        final PackageManager packageManager = context.getPackageManager();
        if (h.d == null) {
            final boolean h = m.h();
            boolean b = false;
            if (h) {
                b = b;
                if (packageManager.hasSystemFeature("android.hardware.type.automotive")) {
                    b = true;
                }
            }
            c5.h.d = b;
        }
        return h.d;
    }
    
    public static boolean b() {
        final int a = j.a;
        return "user".equals((Object)Build.TYPE);
    }
    
    public static boolean c(final Context context) {
        return g(context.getPackageManager());
    }
    
    public static boolean d(final Context context) {
        return (c(context) && !m.g()) || (e(context) && (!m.h() || m.k()));
    }
    
    public static boolean e(final Context context) {
        if (h.b == null) {
            final boolean f = m.f();
            boolean b = false;
            if (f) {
                b = b;
                if (context.getPackageManager().hasSystemFeature("cn.google")) {
                    b = true;
                }
            }
            h.b = b;
        }
        return h.b;
    }
    
    public static boolean f(final Context context) {
        if (h.c == null) {
            final boolean hasSystemFeature = context.getPackageManager().hasSystemFeature("android.hardware.type.iot");
            boolean b = true;
            if (!hasSystemFeature) {
                b = (context.getPackageManager().hasSystemFeature("android.hardware.type.embedded") && b);
            }
            h.c = b;
        }
        return h.c;
    }
    
    public static boolean g(final PackageManager packageManager) {
        if (h.a == null) {
            final boolean e = m.e();
            boolean b = false;
            if (e) {
                b = b;
                if (packageManager.hasSystemFeature("android.hardware.type.watch")) {
                    b = true;
                }
            }
            h.a = b;
        }
        return h.a;
    }
}
