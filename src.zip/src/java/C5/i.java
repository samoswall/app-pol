package c5;

public abstract class i
{
    private static final char[] a;
    private static final char[] b;
    
    static {
        a = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
        b = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
    }
    
    public static String a(final byte[] array) {
        final int length = array.length;
        final char[] array2 = new char[length + length];
        int i = 0;
        int n = 0;
        while (i < array.length) {
            final byte b = array[i];
            final char[] b2 = c5.i.b;
            array2[n] = b2[(b & 0xFF) >>> 4];
            array2[n + 1] = b2[b & 0xF];
            n += 2;
            ++i;
        }
        return new String(array2);
    }
    
    public static String b(final byte[] array) {
        return c(array, false);
    }
    
    public static String c(final byte[] array, final boolean b) {
        final int length = array.length;
        final StringBuilder sb = new StringBuilder(length + length);
        for (int n = 0; n < length && (!b || n != length - 1 || (array[n] & 0xFF) != 0x0); ++n) {
            final char[] a = i.a;
            sb.append(a[(array[n] & 0xF0) >>> 4]);
            sb.append(a[array[n] & 0xF]);
        }
        return sb.toString();
    }
}
