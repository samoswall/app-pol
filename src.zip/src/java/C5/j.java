package c5;

import java.io.IOException;
import java.io.Closeable;

public abstract class j
{
    public static void a(final Closeable closeable) {
        if (closeable == null) {
            return;
        }
        try {
            closeable.close();
        }
        catch (final IOException ex) {}
    }
}
