package c5;

import java.util.Iterator;
import java.util.HashMap;

public abstract class l
{
    public static void a(final StringBuilder sb, final HashMap hashMap) {
        sb.append("{");
        final Iterator iterator = hashMap.keySet().iterator();
        int n = 1;
        while (iterator.hasNext()) {
            final String s = (String)iterator.next();
            if (n == 0) {
                sb.append(",");
            }
            final String s2 = (String)hashMap.get((Object)s);
            sb.append("\"");
            sb.append(s);
            sb.append("\":");
            if (s2 == null) {
                sb.append("null");
            }
            else {
                sb.append("\"");
                sb.append(s2);
                sb.append("\"");
            }
            n = 0;
        }
        sb.append("}");
    }
}
