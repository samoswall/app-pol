package c5;

import android.os.Build$VERSION;

public abstract class m
{
    public static boolean a() {
        return true;
    }
    
    public static boolean b() {
        return true;
    }
    
    public static boolean c() {
        return true;
    }
    
    public static boolean d() {
        return true;
    }
    
    public static boolean e() {
        return true;
    }
    
    public static boolean f() {
        return true;
    }
    
    public static boolean g() {
        return true;
    }
    
    public static boolean h() {
        return true;
    }
    
    public static boolean i() {
        return true;
    }
    
    public static boolean j() {
        return true;
    }
    
    public static boolean k() {
        return Build$VERSION.SDK_INT >= 30;
    }
    
    public static boolean l() {
        return Build$VERSION.SDK_INT >= 31;
    }
}
