package c5;

import android.app.Application;

public abstract class n
{
    private static String a;
    
    public static String a() {
        if (n.a == null) {
            n.a = Application.getProcessName();
        }
        return n.a;
    }
}
