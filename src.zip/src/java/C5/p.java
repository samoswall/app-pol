package c5;

import e5.c;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager$NameNotFoundException;
import android.util.Log;
import W4.k;
import android.content.Context;

public abstract class p
{
    public static boolean a(final Context context, final int n) {
        if (b(context, n, "com.google.android.gms")) {
            final PackageManager packageManager = context.getPackageManager();
            try {
                return k.a(context).b(packageManager.getPackageInfo("com.google.android.gms", 64));
            }
            catch (final PackageManager$NameNotFoundException ex) {
                if (Log.isLoggable("UidVerifier", 3)) {
                    Log.d("UidVerifier", "Package manager can't find google play services package, defaulting to false");
                }
            }
        }
        return false;
    }
    
    public static boolean b(final Context context, final int n, final String s) {
        return c.a(context).g(n, s);
    }
}
