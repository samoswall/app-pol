package c5;

import androidx.core.content.a;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager$NameNotFoundException;
import e5.c;
import android.content.Context;
import android.util.Log;
import android.os.WorkSource;
import java.lang.reflect.Method;

public abstract class q
{
    private static final int a;
    private static final Method b;
    private static final Method c;
    private static final Method d;
    private static final Method e;
    private static final Method f;
    private static final Method g;
    private static final Method h;
    private static final Method i;
    private static Boolean j;
    
    static {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: putstatic       c5/q.a:I
        //     6: ldc             Landroid/os/WorkSource;.class
        //     8: ldc             "add"
        //    10: iconst_1       
        //    11: anewarray       Ljava/lang/Class;
        //    14: dup            
        //    15: iconst_0       
        //    16: getstatic       java/lang/Integer.TYPE:Ljava/lang/Class;
        //    19: aastore        
        //    20: invokevirtual   java/lang/Class.getMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
        //    23: astore_0       
        //    24: goto            30
        //    27: astore_0       
        //    28: aconst_null    
        //    29: astore_0       
        //    30: aload_0        
        //    31: putstatic       c5/q.b:Ljava/lang/reflect/Method;
        //    34: invokestatic    c5/m.c:()Z
        //    37: ifeq            66
        //    40: ldc             Landroid/os/WorkSource;.class
        //    42: ldc             "add"
        //    44: iconst_2       
        //    45: anewarray       Ljava/lang/Class;
        //    48: dup            
        //    49: iconst_0       
        //    50: getstatic       java/lang/Integer.TYPE:Ljava/lang/Class;
        //    53: aastore        
        //    54: dup            
        //    55: iconst_1       
        //    56: ldc             Ljava/lang/String;.class
        //    58: aastore        
        //    59: invokevirtual   java/lang/Class.getMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
        //    62: astore_0       
        //    63: goto            68
        //    66: aconst_null    
        //    67: astore_0       
        //    68: aload_0        
        //    69: putstatic       c5/q.c:Ljava/lang/reflect/Method;
        //    72: ldc             Landroid/os/WorkSource;.class
        //    74: ldc             "size"
        //    76: iconst_0       
        //    77: anewarray       Ljava/lang/Class;
        //    80: invokevirtual   java/lang/Class.getMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
        //    83: astore_0       
        //    84: goto            90
        //    87: astore_0       
        //    88: aconst_null    
        //    89: astore_0       
        //    90: aload_0        
        //    91: putstatic       c5/q.d:Ljava/lang/reflect/Method;
        //    94: ldc             Landroid/os/WorkSource;.class
        //    96: ldc             "get"
        //    98: iconst_1       
        //    99: anewarray       Ljava/lang/Class;
        //   102: dup            
        //   103: iconst_0       
        //   104: getstatic       java/lang/Integer.TYPE:Ljava/lang/Class;
        //   107: aastore        
        //   108: invokevirtual   java/lang/Class.getMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
        //   111: astore_0       
        //   112: goto            118
        //   115: astore_0       
        //   116: aconst_null    
        //   117: astore_0       
        //   118: aload_0        
        //   119: putstatic       c5/q.e:Ljava/lang/reflect/Method;
        //   122: invokestatic    c5/m.c:()Z
        //   125: ifeq            149
        //   128: ldc             Landroid/os/WorkSource;.class
        //   130: ldc             "getName"
        //   132: iconst_1       
        //   133: anewarray       Ljava/lang/Class;
        //   136: dup            
        //   137: iconst_0       
        //   138: getstatic       java/lang/Integer.TYPE:Ljava/lang/Class;
        //   141: aastore        
        //   142: invokevirtual   java/lang/Class.getMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
        //   145: astore_0       
        //   146: goto            151
        //   149: aconst_null    
        //   150: astore_0       
        //   151: aload_0        
        //   152: putstatic       c5/q.f:Ljava/lang/reflect/Method;
        //   155: invokestatic    c5/m.i:()Z
        //   158: ifeq            186
        //   161: ldc             Landroid/os/WorkSource;.class
        //   163: ldc             "createWorkChain"
        //   165: iconst_0       
        //   166: anewarray       Ljava/lang/Class;
        //   169: invokevirtual   java/lang/Class.getMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
        //   172: astore_0       
        //   173: goto            188
        //   176: astore_0       
        //   177: ldc             "WorkSourceUtil"
        //   179: ldc             "Missing WorkChain API createWorkChain"
        //   181: aload_0        
        //   182: invokestatic    android/util/Log.w:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
        //   185: pop            
        //   186: aconst_null    
        //   187: astore_0       
        //   188: aload_0        
        //   189: putstatic       c5/q.g:Ljava/lang/reflect/Method;
        //   192: invokestatic    c5/m.i:()Z
        //   195: ifeq            237
        //   198: ldc             "android.os.WorkSource$WorkChain"
        //   200: invokestatic    java/lang/Class.forName:(Ljava/lang/String;)Ljava/lang/Class;
        //   203: ldc             "addNode"
        //   205: iconst_2       
        //   206: anewarray       Ljava/lang/Class;
        //   209: dup            
        //   210: iconst_0       
        //   211: getstatic       java/lang/Integer.TYPE:Ljava/lang/Class;
        //   214: aastore        
        //   215: dup            
        //   216: iconst_1       
        //   217: ldc             Ljava/lang/String;.class
        //   219: aastore        
        //   220: invokevirtual   java/lang/Class.getMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
        //   223: astore_0       
        //   224: goto            239
        //   227: astore_0       
        //   228: ldc             "WorkSourceUtil"
        //   230: ldc             "Missing WorkChain class"
        //   232: aload_0        
        //   233: invokestatic    android/util/Log.w:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
        //   236: pop            
        //   237: aconst_null    
        //   238: astore_0       
        //   239: aload_0        
        //   240: putstatic       c5/q.h:Ljava/lang/reflect/Method;
        //   243: invokestatic    c5/m.i:()Z
        //   246: ifeq            269
        //   249: ldc             Landroid/os/WorkSource;.class
        //   251: ldc             "isEmpty"
        //   253: iconst_0       
        //   254: anewarray       Ljava/lang/Class;
        //   257: invokevirtual   java/lang/Class.getMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
        //   260: astore_0       
        //   261: aload_0        
        //   262: iconst_1       
        //   263: invokevirtual   java/lang/reflect/AccessibleObject.setAccessible:(Z)V
        //   266: goto            271
        //   269: aconst_null    
        //   270: astore_0       
        //   271: aload_0        
        //   272: putstatic       c5/q.i:Ljava/lang/reflect/Method;
        //   275: aconst_null    
        //   276: putstatic       c5/q.j:Ljava/lang/Boolean;
        //   279: return         
        //   280: astore_0       
        //   281: goto            66
        //   284: astore_0       
        //   285: goto            149
        //   288: astore_0       
        //   289: goto            269
        //   292: astore_1       
        //   293: goto            271
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  6      24     27     30     Ljava/lang/Exception;
        //  40     63     280    284    Ljava/lang/Exception;
        //  72     84     87     90     Ljava/lang/Exception;
        //  94     112    115    118    Ljava/lang/Exception;
        //  128    146    284    288    Ljava/lang/Exception;
        //  161    173    176    186    Ljava/lang/Exception;
        //  198    224    227    237    Ljava/lang/Exception;
        //  249    261    288    292    Ljava/lang/Exception;
        //  261    266    292    296    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 158 out of bounds for length 158
        //     at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:266)
        //     at java.util.Objects.checkIndex(Objects.java:359)
        //     at java.util.ArrayList.get(ArrayList.java:434)
        //     at w5.a.o(SourceFile:31)
        //     at w5.a.j(SourceFile:218)
        //     at a6.j.j(SourceFile:23)
        //     at a6.j.i(SourceFile:28)
        //     at a6.i.n(SourceFile:7)
        //     at a6.i.m(SourceFile:174)
        //     at a6.i.c(SourceFile:67)
        //     at a6.i.r(SourceFile:328)
        //     at a6.i.s(SourceFile:17)
        //     at a6.i.q(SourceFile:29)
        //     at a6.i.b(SourceFile:33)
        //     at y5.d.e(SourceFile:6)
        //     at y5.d.b(SourceFile:1)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(SourceFile:306)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:131)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
        //     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
        //     at e7.a.run(SourceFile:1)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        //     at java.lang.Thread.run(Thread.java:1012)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void a(final WorkSource workSource, final int n, final String s) {
        final Method c = q.c;
        if (c != null) {
            String s2;
            if ((s2 = s) == null) {
                s2 = "";
            }
            try {
                c.invoke((Object)workSource, new Object[] { n, s2 });
                return;
            }
            catch (final Exception ex) {
                Log.wtf("WorkSourceUtil", "Unable to assign blame through WorkSource", (Throwable)ex);
                return;
            }
        }
        final Method b = q.b;
        if (b != null) {
            try {
                b.invoke((Object)workSource, new Object[] { n });
            }
            catch (final Exception ex2) {
                Log.wtf("WorkSourceUtil", "Unable to assign blame through WorkSource", (Throwable)ex2);
            }
        }
    }
    
    public static WorkSource b(final Context context, final String s) {
        if (context != null && context.getPackageManager() != null && s != null) {
            try {
                final ApplicationInfo c = e5.c.a(context).c(s, 0);
                if (c == null) {
                    Log.e("WorkSourceUtil", "Could not get applicationInfo from package: ".concat(s));
                    return null;
                }
                final int uid = c.uid;
                final WorkSource workSource = new WorkSource();
                a(workSource, uid, s);
                return workSource;
            }
            catch (final PackageManager$NameNotFoundException ex) {
                Log.e("WorkSourceUtil", "Could not find package: ".concat(s));
            }
        }
        return null;
    }
    
    public static boolean c(final Context context) {
        final Class<q> clazz;
        monitorenter(clazz = q.class);
        Label_0026: {
            try {
                final Boolean j = q.j;
                if (j != null) {
                    final boolean booleanValue = j;
                    monitorexit(clazz);
                    return booleanValue;
                }
                break Label_0026;
            }
            finally {
                monitorexit(clazz);
                while (true) {
                    monitorexit(clazz);
                    return false;
                    final boolean b = false;
                    iftrue(Label_0036:)(context != null);
                    continue;
                }
                Label_0036: {
                    iftrue(Label_0047:)(androidx.core.content.a.checkSelfPermission(context, "android.permission.UPDATE_DEVICE_STATS") != 0);
                }
                final boolean b = true;
                Label_0047:
                q.j = b;
                monitorexit(clazz);
                return b;
            }
        }
    }
}
