package c5;

public abstract class r
{
    public static int a(final int n) {
        if (n == -1) {
            return -1;
        }
        return n / 1000;
    }
}
