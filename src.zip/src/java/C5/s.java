package c5;

import android.os.Looper;

public abstract class s
{
    public static boolean a() {
        return Looper.getMainLooper() == Looper.myLooper();
    }
}
