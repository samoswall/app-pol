package c6;

public interface a
{
    byte[] a(final byte[] p0, final int p1);
}
