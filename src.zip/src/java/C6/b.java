package C6;

public final class b extends RuntimeException
{
    public b(final String s) {
        super(s);
    }
    
    public b(final String s, final Exception ex) {
        super(s, (Throwable)ex);
    }
}
