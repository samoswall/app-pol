package C6;

import java.util.HashMap;
import java.lang.annotation.Annotation;
import java.util.Collections;
import java.util.Map;

public final class c
{
    private final String a;
    private final Map b;
    
    private c(final String a, final Map b) {
        this.a = a;
        this.b = b;
    }
    
    public static b a(final String s) {
        return new b(s);
    }
    
    public static c d(final String s) {
        return new c(s, Collections.emptyMap());
    }
    
    public String b() {
        return this.a;
    }
    
    public Annotation c(final Class clazz) {
        return (Annotation)this.b.get((Object)clazz);
    }
    
    @Override
    public boolean equals(final Object o) {
        boolean b = true;
        if (this == o) {
            return true;
        }
        if (!(o instanceof c)) {
            return false;
        }
        final c c = (c)o;
        if (!this.a.equals((Object)c.a) || !this.b.equals((Object)c.b)) {
            b = false;
        }
        return b;
    }
    
    @Override
    public int hashCode() {
        return this.a.hashCode() * 31 + this.b.hashCode();
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("FieldDescriptor{name=");
        sb.append(this.a);
        sb.append(", properties=");
        sb.append((Object)this.b.values());
        sb.append("}");
        return sb.toString();
    }
    
    public static final class b
    {
        private final String a;
        private Map b;
        
        b(final String a) {
            this.b = null;
            this.a = a;
        }
        
        public c a() {
            final String a = this.a;
            Map map;
            if (this.b == null) {
                map = Collections.emptyMap();
            }
            else {
                map = Collections.unmodifiableMap((Map)new HashMap(this.b));
            }
            return new c(a, map, null);
        }
        
        public b b(final Annotation annotation) {
            if (this.b == null) {
                this.b = (Map)new HashMap();
            }
            this.b.put((Object)annotation.annotationType(), (Object)annotation);
            return this;
        }
    }
}
