package C6;

public interface d
{
}
