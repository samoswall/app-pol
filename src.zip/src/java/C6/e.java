package C6;

public interface e
{
    e a(final c p0, final Object p1);
    
    e b(final c p0, final double p1);
    
    e d(final c p0, final long p1);
    
    e e(final c p0, final int p1);
    
    e g(final c p0, final boolean p1);
}
