package C6;

public interface g
{
    g c(final String p0);
    
    g f(final boolean p0);
}
