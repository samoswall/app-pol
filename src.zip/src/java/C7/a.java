package c7;

import f7.b;

public final class a
{
    private boolean a;
    private int b;
    private int c;
    private int d;
    private b e;
    
    public b a() {
        return this.e;
    }
    
    public void b(final int d) {
        this.d = d;
    }
    
    public void c(final boolean a) {
        this.a = a;
    }
    
    public void d(final int c) {
        this.c = c;
    }
    
    public void e(final b e) {
        this.e = e;
    }
    
    public void f(final int b) {
        this.b = b;
    }
}
