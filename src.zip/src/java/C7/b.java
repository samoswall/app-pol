package c7;

import f7.a;

final class b extends g
{
    private final short c;
    private final short d;
    
    b(final g g, final int n, final int n2) {
        super(g);
        this.c = (short)n;
        this.d = (short)n2;
    }
    
    public void c(final a a, final byte[] array) {
        short n = 0;
        while (true) {
            final short d = this.d;
            if (n >= d) {
                break;
            }
            if (n == 0 || (n == 31 && d <= 62)) {
                a.c(31, 5);
                final short d2 = this.d;
                if (d2 > 62) {
                    a.c(d2 - 31, 16);
                }
                else if (n == 0) {
                    a.c(Math.min((int)d2, 31), 5);
                }
                else {
                    a.c(d2 - 31, 5);
                }
            }
            a.c((int)array[this.c + n], 8);
            ++n;
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("<");
        sb.append((int)this.c);
        sb.append("::");
        sb.append(this.c + this.d - 1);
        sb.append('>');
        return sb.toString();
    }
}
