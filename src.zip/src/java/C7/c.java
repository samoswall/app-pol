package c7;

import f7.b;
import f7.a;

public abstract class c
{
    private static final int[] a;
    
    static {
        a = new int[] { 4, 6, 6, 8, 8, 8, 8, 8, 8, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12 };
    }
    
    private static int[] a(final a a, final int n, int i) {
        final int[] array = new int[i];
        int n2;
        int j;
        int n3;
        int n4;
        for (n2 = a.l() / n, i = 0; i < n2; ++i) {
            j = 0;
            n3 = 0;
            while (j < n) {
                if (a.h(i * n + j)) {
                    n4 = 1 << n - j - 1;
                }
                else {
                    n4 = 0;
                }
                n3 |= n4;
                ++j;
            }
            array[i] = n3;
        }
        return array;
    }
    
    private static void b(final b b, int n, final int n2) {
        for (int i = 0; i < n2; i += 2) {
            int n4;
            final int n3 = n4 = n - i;
            while (true) {
                final int n5 = n + i;
                if (n4 > n5) {
                    break;
                }
                b.n(n4, n3);
                b.n(n4, n5);
                b.n(n3, n4);
                b.n(n5, n4);
                ++n4;
            }
        }
        final int n6 = n - n2;
        b.n(n6, n6);
        final int n7 = n6 + 1;
        b.n(n7, n6);
        b.n(n6, n7);
        n += n2;
        b.n(n, n6);
        b.n(n, n7);
        b.n(n, n - 1);
    }
    
    private static void c(final b b, final boolean b2, int i, final a a) {
        final int n = i / 2;
        i = 0;
        final int n2 = 0;
        if (b2) {
            int n3;
            for (i = n2; i < 7; ++i) {
                n3 = n - 3 + i;
                if (a.h(i)) {
                    b.n(n3, n - 5);
                }
                if (a.h(i + 7)) {
                    b.n(n + 5, n3);
                }
                if (a.h(20 - i)) {
                    b.n(n3, n + 5);
                }
                if (a.h(27 - i)) {
                    b.n(n - 5, n3);
                }
            }
            return;
        }
        while (i < 10) {
            final int n4 = n - 5 + i + i / 5;
            if (a.h(i)) {
                b.n(n4, n - 7);
            }
            if (a.h(i + 10)) {
                b.n(n + 7, n4);
            }
            if (a.h(29 - i)) {
                b.n(n4, n + 7);
            }
            if (a.h(39 - i)) {
                b.n(n - 7, n4);
            }
            ++i;
        }
    }
    
    public static c7.a d(final byte[] array, int i, int n) {
        final a a = new d(array).a();
        i = a.l() * i / 100;
        final int n2 = 11;
        final int n3 = i + 11;
        final int l = a.l();
        int n4 = 32;
        final int n5 = 1;
        i = 1;
        a h = null;
        boolean b2 = false;
        int n10 = 0;
        int n11 = 0;
        int n12 = 0;
        Label_0399: {
            if (n == 0) {
                h = null;
                int j = 0;
                int n6 = 0;
                while (j <= 32) {
                    final boolean b = j <= 3 && i;
                    int n7;
                    if (b) {
                        n7 = j + 1;
                    }
                    else {
                        n7 = j;
                    }
                    final int k = i(n7, b);
                    a a2 = h;
                    int n8 = n6;
                    Label_0376: {
                        if (l + n3 <= k) {
                            if (h == null || (n = n6) != c.a[n7]) {
                                n = c.a[n7];
                                h = h(a, n);
                            }
                            if (b) {
                                a2 = h;
                                n8 = n;
                                if (h.l() > n << 6) {
                                    break Label_0376;
                                }
                            }
                            if (h.l() + n3 <= k - k % n) {
                                b2 = b;
                                final int n9 = n7;
                                n10 = k;
                                n11 = n;
                                n = n9;
                                n12 = i;
                                break Label_0399;
                            }
                            n8 = n;
                            a2 = h;
                        }
                    }
                    ++j;
                    h = a2;
                    n6 = n8;
                }
                throw new IllegalArgumentException("Data too large for an Aztec code");
            }
            if (n < 0) {
                i = 1;
            }
            else {
                i = 0;
            }
            final int abs = Math.abs(n);
            if (i != 0) {
                n4 = 4;
            }
            if (abs > n4) {
                throw new IllegalArgumentException(String.format("Illegal value %s for layers", new Object[] { n }));
            }
            final int m = i(abs, (boolean)(i != 0));
            final int n13 = c.a[abs];
            final a h2 = h(a, n13);
            if (h2.l() + n3 > m - m % n13) {
                throw new IllegalArgumentException("Data to large for user specified layer");
            }
            h = h2;
            b2 = (i != 0);
            n10 = m;
            n12 = n5;
            n = abs;
            n11 = n13;
            if (i != 0) {
                if (h2.l() > n13 << 6) {
                    throw new IllegalArgumentException("Data to large for user specified layer");
                }
                h = h2;
                b2 = (i != 0);
                n10 = m;
                n12 = n5;
                n = abs;
                n11 = n13;
            }
        }
        final a e = e(h, n10, n11);
        final int n14 = h.l() / n11;
        final a f = f(b2, n, n14);
        if (b2) {
            i = n2;
        }
        else {
            i = 14;
        }
        final int n15 = i + (n << 2);
        final int[] array2 = new int[n15];
        if (b2) {
            for (i = 0; i < n15; ++i) {
                array2[i] = i;
            }
            i = n15;
        }
        else {
            final int n16 = n15 / 2;
            final int n17 = n15 + 1 + (n16 - 1) / 15 * 2;
            final int n18 = n17 / 2;
            int n19 = 0;
            while (true) {
                i = n17;
                if (n19 >= n16) {
                    break;
                }
                i = n19 / 15 + n19;
                array2[n16 - n19 - n12] = n18 - i - 1;
                array2[n16 + n19] = i + n18 + n12;
                ++n19;
            }
        }
        final b b3 = new b(i);
        int n20 = 0;
        int n21 = 0;
        while (n20 < n) {
            int n22;
            if (b2) {
                n22 = 9;
            }
            else {
                n22 = 12;
            }
            final int n23 = (n - n20 << 2) + n22;
            for (int n24 = 0; n24 < n23; ++n24) {
                final int n25 = n24 << 1;
                for (int n26 = 0; n26 < 2; ++n26) {
                    if (e.h(n21 + n25 + n26)) {
                        final int n27 = n20 << 1;
                        b3.n(array2[n27 + n26], array2[n27 + n24]);
                    }
                    if (e.h((n23 << 1) + n21 + n25 + n26)) {
                        final int n28 = n20 << 1;
                        b3.n(array2[n28 + n24], array2[n15 - 1 - n28 - n26]);
                    }
                    if (e.h((n23 << 2) + n21 + n25 + n26)) {
                        final int n29 = n15 - 1 - (n20 << 1);
                        b3.n(array2[n29 - n26], array2[n29 - n24]);
                    }
                    if (e.h(n23 * 6 + n21 + n25 + n26)) {
                        final int n30 = n20 << 1;
                        b3.n(array2[n15 - 1 - n30 - n24], array2[n30 + n26]);
                    }
                }
            }
            n21 += n23 << 3;
            ++n20;
        }
        c(b3, b2, i, f);
        if (b2) {
            b(b3, i / 2, 5);
        }
        else {
            final int n31 = i / 2;
            b(b3, n31, 7);
            for (int n32 = 0, n33 = 0; n33 < n15 / 2 - 1; n33 += 15, n32 += 16) {
                for (int n34 = n31 & 0x1; n34 < i; n34 += 2) {
                    final int n35 = n31 - n32;
                    b3.n(n35, n34);
                    final int n36 = n31 + n32;
                    b3.n(n36, n34);
                    b3.n(n34, n35);
                    b3.n(n34, n36);
                }
            }
        }
        final c7.a a3 = new c7.a();
        a3.c(b2);
        a3.f(i);
        a3.d(n);
        a3.b(n14);
        a3.e(b3);
        return a3;
    }
    
    private static a e(final a a, int i, final int n) {
        final int n2 = a.l() / n;
        final h7.d d = new h7.d(g(n));
        final int n3 = i / n;
        final int[] a2 = a(a, n, n3);
        d.b(a2, n3 - n2);
        final a a3 = new a();
        final int n4 = 0;
        a3.c(0, i % n);
        int length;
        for (length = a2.length, i = n4; i < length; ++i) {
            a3.c(a2[i], n);
        }
        return a3;
    }
    
    static a f(final boolean b, final int n, final int n2) {
        final a a = new a();
        a a2;
        if (b) {
            a.c(n - 1, 2);
            a.c(n2 - 1, 6);
            a2 = e(a, 28, 4);
        }
        else {
            a.c(n - 1, 5);
            a.c(n2 - 1, 11);
            a2 = e(a, 40, 4);
        }
        return a2;
    }
    
    private static h7.a g(final int n) {
        if (n == 4) {
            return h7.a.k;
        }
        if (n == 6) {
            return h7.a.j;
        }
        if (n == 8) {
            return h7.a.n;
        }
        if (n == 10) {
            return h7.a.i;
        }
        if (n == 12) {
            return h7.a.h;
        }
        throw new IllegalArgumentException("Unsupported word size ".concat(String.valueOf(n)));
    }
    
    static a h(final a a, final int n) {
        final a a2 = new a();
        final int l = a.l();
        final int n2 = (1 << n) - 2;
        for (int i = 0; i < l; i += n) {
            int j = 0;
            int n3 = 0;
            while (j < n) {
                final int n4 = i + j;
                int n5 = 0;
                Label_0078: {
                    if (n4 < l) {
                        n5 = n3;
                        if (!a.h(n4)) {
                            break Label_0078;
                        }
                    }
                    n5 = (n3 | 1 << n - 1 - j);
                }
                ++j;
                n3 = n5;
            }
            final int n6 = n3 & n2;
            if (n6 == n2) {
                a2.c(n6, n);
            }
            else {
                if (n6 != 0) {
                    a2.c(n3, n);
                    continue;
                }
                a2.c(n3 | 0x1, n);
            }
            --i;
        }
        return a2;
    }
    
    private static int i(final int n, final boolean b) {
        int n2;
        if (b) {
            n2 = 88;
        }
        else {
            n2 = 112;
        }
        return (n2 + (n << 4)) * n;
    }
}
