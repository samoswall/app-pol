package c7;

import f7.a;

final class e extends g
{
    private final short c;
    private final short d;
    
    e(final g g, final int n, final int n2) {
        super(g);
        this.c = (short)n;
        this.d = (short)n2;
    }
    
    @Override
    void c(final a a, final byte[] array) {
        a.c((int)this.c, (int)this.d);
    }
    
    @Override
    public String toString() {
        final short c = this.c;
        final short d = this.d;
        final StringBuilder sb = new StringBuilder("<");
        sb.append(Integer.toBinaryString(1 << this.d | ((c & (1 << d) - 1) | 1 << d)).substring(1));
        sb.append('>');
        return sb.toString();
    }
}
