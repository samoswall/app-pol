package c7;

import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;
import f7.a;

final class f
{
    static final f e;
    private final int a;
    private final g b;
    private final int c;
    private final int d;
    
    static {
        e = new f(g.b, 0, 0, 0);
    }
    
    private f(final g b, final int a, final int c, final int d) {
        this.b = b;
        this.a = a;
        this.c = c;
        this.d = d;
    }
    
    private static int b(final f f) {
        final int c = f.c;
        if (c > 62) {
            return 21;
        }
        if (c > 31) {
            return 20;
        }
        if (c > 0) {
            return 10;
        }
        return 0;
    }
    
    f a(final int n) {
        final g b = this.b;
        final int a = this.a;
        final int d = this.d;
        g a2 = null;
        int n2 = 0;
        int n3 = 0;
        Label_0075: {
            if (a != 4) {
                a2 = b;
                n2 = a;
                n3 = d;
                if (a != 2) {
                    break Label_0075;
                }
            }
            final int n4 = c7.d.c[a][0];
            final int n5 = n4 >> 16;
            a2 = b.a(0xFFFF & n4, n5);
            n3 = d + n5;
            n2 = 0;
        }
        final int c = this.c;
        int n6;
        if (c != 0 && c != 31) {
            if (c == 62) {
                n6 = 9;
            }
            else {
                n6 = 8;
            }
        }
        else {
            n6 = 18;
        }
        f c2;
        final f f = c2 = new f(a2, n2, c + 1, n3 + n6);
        if (f.c == 2078) {
            c2 = f.c(n + 1);
        }
        return c2;
    }
    
    f c(final int n) {
        final int c = this.c;
        if (c == 0) {
            return this;
        }
        return new f(this.b.b(n - c, c), this.a, 0, this.d);
    }
    
    int d() {
        return this.c;
    }
    
    int e() {
        return this.d;
    }
    
    int f() {
        return this.a;
    }
    
    boolean g(final f f) {
        final int n = this.d + (c7.d.c[this.a][f.a] >> 16);
        final int c = this.c;
        final int c2 = f.c;
        int n2;
        if (c < c2) {
            n2 = n + (b(f) - b(this));
        }
        else {
            n2 = n;
            if (c > c2) {
                n2 = n;
                if (c2 > 0) {
                    n2 = n + 10;
                }
            }
        }
        return n2 <= f.d;
    }
    
    f h(final int n, final int n2) {
        final int d = this.d;
        final g b = this.b;
        final int a = this.a;
        int n3 = d;
        g a2 = b;
        if (n != a) {
            final int n4 = c7.d.c[a][n];
            final int n5 = n4 >> 16;
            a2 = b.a(0xFFFF & n4, n5);
            n3 = d + n5;
        }
        int n6;
        if (n == 2) {
            n6 = 4;
        }
        else {
            n6 = 5;
        }
        return new f(a2.a(n2, n6), n, 0, n3 + n6);
    }
    
    f i(final int n, final int n2) {
        final g b = this.b;
        final int a = this.a;
        int n3;
        if (a == 2) {
            n3 = 4;
        }
        else {
            n3 = 5;
        }
        return new f(b.a(c7.d.e[a][n], n3).a(n2, 5), this.a, 0, this.d + n3 + 5);
    }
    
    a j(final byte[] array) {
        final LinkedList list = new LinkedList();
        for (g g = this.c(array.length).b; g != null; g = g.d()) {
            ((Deque)list).addFirst((Object)g);
        }
        final a a = new a();
        final Iterator iterator = ((Deque)list).iterator();
        while (iterator.hasNext()) {
            ((g)iterator.next()).c(a, array);
        }
        return a;
    }
    
    @Override
    public String toString() {
        return String.format("%s bits=%d bytes=%d", new Object[] { c7.d.b[this.a], this.d, this.c });
    }
}
