package c7;

import f7.a;

abstract class g
{
    static final g b;
    private final g a;
    
    static {
        b = new e(null, 0, 0);
    }
    
    g(final g a) {
        this.a = a;
    }
    
    final g a(final int n, final int n2) {
        return new e(this, n, n2);
    }
    
    final g b(final int n, final int n2) {
        return new b(this, n, n2);
    }
    
    abstract void c(final a p0, final byte[] p1);
    
    final g d() {
        return this.a;
    }
}
