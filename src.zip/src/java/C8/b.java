package C8;

import java.util.concurrent.Executor;
import K8.M;
import java.util.List;
import kotlin.jvm.internal.v;
import com.syncleoiot.core.application.configurator.ConfiguratorViewModel;
import X8.l;
import kotlin.jvm.internal.w;

public final class b extends w implements l
{
    public final ConfiguratorViewModel H;
    
    public b(final ConfiguratorViewModel h) {
        this.H = h;
        super(1);
    }
    
    public static final void c(final ConfiguratorViewModel configuratorViewModel) {
        v.j((Object)configuratorViewModel, "this$0");
        ConfiguratorViewModel.access$handleConfiguratorDiscovery(configuratorViewModel);
    }
    
    public final void a() {
        if (ConfiguratorViewModel.access$isResumed$p(this.H)) {
            ((Executor)ConfiguratorViewModel.access$getExecutor$p(this.H)).execute((Runnable)new a(this.H));
        }
    }
}
