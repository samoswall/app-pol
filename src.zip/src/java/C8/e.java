package C8;

import K8.M;
import com.syncleoiot.tools.logwriter.Log;
import kotlin.jvm.internal.v;
import android.nfc.Tag;
import com.syncleoiot.core.application.configurator.ConfiguratorViewModel;
import X8.l;
import kotlin.jvm.internal.w;

public final class e extends w implements l
{
    public final ConfiguratorViewModel H;
    
    public e(final ConfiguratorViewModel h) {
        this.H = h;
        super(1);
    }
    
    public final Object invoke(final Object o) {
        final Tag tag = (Tag)o;
        v.j((Object)tag, "tag");
        if (ConfiguratorViewModel.access$writeNfcConfig(this.H, tag)) {
            ConfiguratorViewModel.access$handleWifiConfigWritten(this.H);
        }
        else {
            Log.e(ConfiguratorViewModel.access$getTAG$cp(), "NFC show error");
        }
        return M.a;
    }
}
