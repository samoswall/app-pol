package C8;

import com.syncleoiot.core.data.db.entity.ConfiguredWifi;
import com.syncleoiot.core.data.sp.AppPreferences;
import K8.x;
import Q8.b;
import i9.M;
import P8.d;
import android.content.Context;
import com.syncleoiot.core.application.configurator.ConfiguratorViewModel;
import X8.p;
import kotlin.coroutines.jvm.internal.l;

public final class f extends l implements p
{
    public final ConfiguratorViewModel y;
    public final Context z;
    
    public f(final ConfiguratorViewModel y, final Context z, final d d) {
        this.y = y;
        this.z = z;
        super(2, d);
    }
    
    public final d create(final Object o, final d d) {
        return (d)new f(this.y, this.z, d);
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final M m = (M)o;
        return new f(this.y, this.z, (d)o2).invokeSuspend(K8.M.a);
    }
    
    public final Object invokeSuspend(final Object o) {
        b.f();
        x.b(o);
        final String configureSsid = this.y.getConfigureSsid();
        if (configureSsid == null) {
            return K8.M.a;
        }
        final String sendPassword = this.y.getSendPassword();
        if (sendPassword == null) {
            return K8.M.a;
        }
        AppPreferences.INSTANCE.setLastConfiguredWifi(this.z, configureSsid);
        ConfiguratorViewModel.access$getAppDatabase$p(this.y).configuredWifiDao().insert(new ConfiguredWifi(configureSsid, sendPassword));
        return K8.M.a;
    }
}
