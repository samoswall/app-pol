package C8;

import K8.M;
import kotlin.jvm.internal.v;
import android.nfc.Tag;
import com.syncleoiot.core.application.configurator.ConfiguratorViewModel;
import X8.l;
import kotlin.jvm.internal.w;

public final class g extends w implements l
{
    public final ConfiguratorViewModel H;
    
    public g(final ConfiguratorViewModel h) {
        this.H = h;
        super(1);
    }
    
    public final Object invoke(final Object o) {
        final Tag tag = (Tag)o;
        v.j((Object)tag, "it");
        ConfiguratorViewModel.access$getNfcEventHandler$p(this.H).invoke(tag);
        return M.a;
    }
}
