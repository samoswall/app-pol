package c9;

import kotlin.jvm.internal.v;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public final class a extends b9.a
{
    @Override
    public int g(final int n, final int n2) {
        return ThreadLocalRandom.current().nextInt(n, n2);
    }
    
    @Override
    public Random h() {
        final ThreadLocalRandom current = ThreadLocalRandom.current();
        v.i((Object)current, "current(...)");
        return (Random)current;
    }
}
