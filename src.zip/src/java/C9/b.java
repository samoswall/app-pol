package C9;

import java.nio.ByteBuffer;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;

class b extends ByteArrayOutputStream
{
    final f a;
    final i b;
    
    b(final f a) {
        this.a = a;
        this.b = null;
    }
    
    b(final i b) {
        this.a = null;
        this.b = b;
    }
    
    OutputStream d() {
        final f a = this.a;
        if (a != null) {
            return a.f();
        }
        final i b = this.b;
        if (b != null) {
            return b.j();
        }
        return null;
    }
    
    public void flush() {
        synchronized (this) {
            final ByteBuffer wrap = ByteBuffer.wrap(this.toByteArray());
            this.reset();
            monitorexit(this);
            this.d().write(new d((byte)2, true, wrap.array()).d());
            this.d().flush();
        }
    }
}
