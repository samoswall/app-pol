package C9;

public class c extends Exception
{
}
