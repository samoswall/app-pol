package C9;

import java.util.Random;
import java.security.SecureRandom;
import java.nio.ByteBuffer;
import java.io.IOException;
import java.io.InputStream;

public class d
{
    private byte a;
    private boolean b;
    private byte[] c;
    private boolean d;
    
    public d(final byte a, final boolean b, final byte[] array) {
        this.d = false;
        this.a = a;
        this.b = b;
        if (array != null) {
            this.c = array.clone();
        }
    }
    
    public d(final InputStream inputStream) {
        final int n = 0;
        this.d = false;
        this.h((byte)inputStream.read());
        final byte a = this.a;
        int n2 = 8;
        boolean b = true;
        if (a == 2) {
            final byte b2 = (byte)inputStream.read();
            if ((b2 & 0x80) == 0x0) {
                b = false;
            }
            int n3 = (byte)(b2 & 0x7F);
            if (n3 != 127) {
                if (n3 == 126) {
                    n2 = 2;
                }
                else {
                    n2 = 0;
                }
            }
            int n4 = n2;
            if (n2 > 0) {
                n3 = 0;
                n4 = n2;
            }
            while (--n4 >= 0) {
                n3 |= ((byte)inputStream.read() & 0xFF) << n4 * 8;
            }
            byte[] array;
            if (b) {
                array = new byte[4];
                inputStream.read(array, 0, 4);
            }
            else {
                array = null;
            }
            this.c = new byte[n3];
            int read;
            for (int i = 0, n5 = n3; i != n3; i += read, n5 -= read) {
                read = inputStream.read(this.c, i, n5);
            }
            if (b) {
                int n6 = n;
                while (true) {
                    final byte[] c = this.c;
                    if (n6 >= c.length) {
                        break;
                    }
                    c[n6] ^= array[n6 % 4];
                    ++n6;
                }
            }
            return;
        }
        if (a == 8) {
            this.d = true;
            return;
        }
        final byte a2 = this.a;
        final StringBuilder sb = new StringBuilder();
        sb.append("Invalid Frame: Opcode: ");
        sb.append((int)a2);
        throw new IOException(sb.toString());
    }
    
    public static void a(final ByteBuffer byteBuffer, final byte b, final boolean b2) {
        byte b3;
        if (b2) {
            b3 = (byte)128;
        }
        else {
            b3 = 0;
        }
        byteBuffer.put((byte)((b & 0xF) | b3));
    }
    
    private static void b(final ByteBuffer byteBuffer, final int n, final boolean b) {
        if (n >= 0) {
            int n2;
            if (b) {
                n2 = -128;
            }
            else {
                n2 = 0;
            }
            if (n > 65535) {
                byteBuffer.put((byte)(n2 | 0x7F));
                byteBuffer.put((byte)0);
                byteBuffer.put((byte)0);
                byteBuffer.put((byte)0);
                byteBuffer.put((byte)0);
                byteBuffer.put((byte)(n >> 24 & 0xFF));
                byteBuffer.put((byte)(n >> 16 & 0xFF));
                byteBuffer.put((byte)(n >> 8 & 0xFF));
                byteBuffer.put((byte)(n & 0xFF));
            }
            else if (n >= 126) {
                byteBuffer.put((byte)(n2 | 0x7E));
                byteBuffer.put((byte)(n >> 8));
                byteBuffer.put((byte)(n & 0xFF));
            }
            else {
                byteBuffer.put((byte)(n | n2));
            }
            return;
        }
        throw new IllegalArgumentException("Length cannot be negative");
    }
    
    public static void c(final ByteBuffer byteBuffer, final int n, final byte[] array) {
        if (array != null) {
            b(byteBuffer, n, true);
            byteBuffer.put(array);
        }
        else {
            b(byteBuffer, n, false);
        }
    }
    
    public static byte[] e() {
        final SecureRandom secureRandom = new SecureRandom();
        return new byte[] { (byte)((Random)secureRandom).nextInt(255), (byte)((Random)secureRandom).nextInt(255), (byte)((Random)secureRandom).nextInt(255), (byte)((Random)secureRandom).nextInt(255) };
    }
    
    private void h(final byte b) {
        this.b = ((b & 0x80) != 0x0);
        this.a = (byte)(b & 0xF);
    }
    
    public byte[] d() {
        final byte[] c = this.c;
        final int length = c.length;
        int n = length + 6;
        if (c.length > 65535) {
            n = length + 14;
        }
        else if (c.length >= 126) {
            n = length + 8;
        }
        final ByteBuffer allocate = ByteBuffer.allocate(n);
        a(allocate, this.a, this.b);
        final byte[] e = e();
        c(allocate, this.c.length, e);
        int n2 = 0;
        while (true) {
            final byte[] c2 = this.c;
            if (n2 >= c2.length) {
                break;
            }
            allocate.put(c2[n2] ^= e[n2 % 4]);
            ++n2;
        }
        allocate.flip();
        return allocate.array();
    }
    
    public byte[] f() {
        return this.c;
    }
    
    public boolean g() {
        return this.d;
    }
}
