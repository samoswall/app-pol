package C9;

import java.util.UUID;
import java.security.MessageDigest;
import java.util.Iterator;
import java.io.PrintWriter;
import java.net.URISyntaxException;
import java.net.URI;
import java.security.NoSuchAlgorithmException;
import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.Properties;
import java.io.OutputStream;
import java.io.InputStream;

public class e
{
    InputStream a;
    OutputStream b;
    String c;
    String d;
    int e;
    Properties f;
    
    public e(final InputStream a, final OutputStream b, final String c, final String d, final int e, final Properties f) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    
    private Map b(final ArrayList list) {
        final HashMap hashMap = new HashMap();
        for (int i = 1; i < list.size(); ++i) {
            final String[] split = ((String)list.get(i)).split(":");
            ((Map)hashMap).put((Object)split[0].toLowerCase(), (Object)split[1]);
        }
        return (Map)hashMap;
    }
    
    private void c(final String s) {
        final BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(this.a));
        final ArrayList list = new ArrayList();
        String s2 = bufferedReader.readLine();
        if (s2 == null) {
            throw new IOException("WebSocket Response header: Invalid response from Server, It may not support WebSockets.");
        }
        while (!s2.equals((Object)"")) {
            list.add((Object)s2);
            s2 = bufferedReader.readLine();
        }
        final Map b = this.b(list);
        final String s3 = (String)b.get((Object)"connection");
        if (s3 == null || s3.equalsIgnoreCase("upgrade")) {
            throw new IOException("WebSocket Response header: Incorrect connection header");
        }
        final String s4 = (String)b.get((Object)"upgrade");
        if (s4 == null || !s4.toLowerCase().contains((CharSequence)"websocket")) {
            throw new IOException("WebSocket Response header: Incorrect upgrade.");
        }
        if (b.get((Object)"sec-websocket-protocol") == null) {
            throw new IOException("WebSocket Response header: empty sec-websocket-protocol");
        }
        if (b.containsKey((Object)"sec-websocket-accept")) {
            try {
                this.f(s, (String)b.get((Object)"sec-websocket-accept"));
                return;
            }
            catch (final NoSuchAlgorithmException ex) {}
            catch (final c c) {
                throw new IOException("WebSocket Response header: Incorrect Sec-WebSocket-Key");
            }
            final NoSuchAlgorithmException ex;
            throw new IOException(((Throwable)ex).getMessage());
        }
        throw new IOException("WebSocket Response header: Missing Sec-WebSocket-Accept");
    }
    
    private void d(String userInfo) {
        final String s = "/mqtt";
        URI uri;
        String s2;
        try {
            uri = new URI(this.c);
            s2 = s;
            if (uri.getRawPath() != null) {
                s2 = s;
                if (!uri.getRawPath().isEmpty()) {
                    final String s3 = s2 = uri.getRawPath();
                    if (uri.getRawQuery() != null) {
                        s2 = s3;
                        if (!uri.getRawQuery().isEmpty()) {
                            final String rawQuery = uri.getRawQuery();
                            final StringBuilder sb = new StringBuilder();
                            sb.append(s3);
                            sb.append("?");
                            sb.append(rawQuery);
                            s2 = sb.toString();
                        }
                    }
                }
            }
        }
        catch (final URISyntaxException ex) {
            throw new IllegalStateException(ex.getMessage());
        }
        final PrintWriter printWriter = new PrintWriter(this.b);
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("GET ");
        sb2.append(s2);
        sb2.append(" HTTP/1.1\r\n");
        printWriter.print(sb2.toString());
        final int e = this.e;
        if (e != 80) {
            final String d = this.d;
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("Host: ");
            sb3.append(d);
            sb3.append(":");
            sb3.append(e);
            sb3.append("\r\n");
            printWriter.print(sb3.toString());
        }
        else {
            final String d2 = this.d;
            final StringBuilder sb4 = new StringBuilder();
            sb4.append("Host: ");
            sb4.append(d2);
            sb4.append("\r\n");
            printWriter.print(sb4.toString());
        }
        printWriter.print("Upgrade: websocket\r\n");
        printWriter.print("Connection: Upgrade\r\n");
        final StringBuilder sb5 = new StringBuilder();
        sb5.append("Sec-WebSocket-Key: ");
        sb5.append(userInfo);
        sb5.append("\r\n");
        printWriter.print(sb5.toString());
        printWriter.print("Sec-WebSocket-Protocol: mqtt\r\n");
        printWriter.print("Sec-WebSocket-Version: 13\r\n");
        final Properties f = this.f;
        if (f != null) {
            final Iterator iterator = f.keySet().iterator();
            while (iterator.hasNext()) {
                userInfo = (String)iterator.next();
                final String property = this.f.getProperty(userInfo);
                final StringBuilder sb6 = new StringBuilder();
                sb6.append(userInfo);
                sb6.append(": ");
                sb6.append(property);
                sb6.append("\r\n");
                printWriter.print(sb6.toString());
            }
        }
        userInfo = uri.getUserInfo();
        if (userInfo != null) {
            final String a = C9.a.a(userInfo);
            final StringBuilder sb7 = new StringBuilder();
            sb7.append("Authorization: Basic ");
            sb7.append(a);
            sb7.append("\r\n");
            printWriter.print(sb7.toString());
        }
        printWriter.print("\r\n");
        printWriter.flush();
    }
    
    private byte[] e(final String s) {
        return MessageDigest.getInstance("SHA1").digest(s.getBytes());
    }
    
    private void f(final String s, final String s2) {
        final StringBuilder sb = new StringBuilder();
        sb.append(s);
        sb.append("258EAFA5-E914-47DA-95CA-C5AB0DC85B11");
        if (C9.a.b(this.e(sb.toString())).trim().equals((Object)s2.trim())) {
            return;
        }
        throw new c();
    }
    
    public void a() {
        final byte[] array = new byte[16];
        System.arraycopy((Object)UUID.randomUUID().toString().getBytes(), 0, (Object)array, 0, 16);
        final String b = C9.a.b(array);
        this.d(b);
        this.c(b);
    }
}
