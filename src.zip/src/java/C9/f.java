package C9;

import java.io.InputStream;
import java.io.OutputStream;
import org.eclipse.paho.client.mqttv3.logging.b;
import javax.net.SocketFactory;
import java.io.ByteArrayOutputStream;
import java.io.PipedInputStream;
import java.util.Properties;
import org.eclipse.paho.client.mqttv3.logging.a;
import A9.q;

public class f extends q
{
    private static final String p = "C9.f";
    private a h;
    private String i;
    private String j;
    private int k;
    private Properties l;
    private PipedInputStream m;
    private h n;
    private ByteArrayOutputStream o;
    
    public f(final SocketFactory socketFactory, final String i, final String j, final int k, final String resourceName, final Properties l) {
        super(socketFactory, j, k, resourceName);
        this.h = org.eclipse.paho.client.mqttv3.logging.b.a("org.eclipse.paho.client.mqttv3.internal.nls.logcat", f.p);
        this.o = new C9.b(this);
        this.i = i;
        this.j = j;
        this.k = k;
        this.l = l;
        this.m = new PipedInputStream();
        this.h.setResourceName(resourceName);
    }
    
    @Override
    public String a() {
        final String j = this.j;
        final int k = this.k;
        final StringBuilder sb = new StringBuilder();
        sb.append("ws://");
        sb.append(j);
        sb.append(":");
        sb.append(k);
        return sb.toString();
    }
    
    @Override
    public OutputStream b() {
        return (OutputStream)this.o;
    }
    
    @Override
    public InputStream c() {
        return (InputStream)this.m;
    }
    
    InputStream e() {
        return super.c();
    }
    
    OutputStream f() {
        return super.b();
    }
    
    @Override
    public void start() {
        super.start();
        new e(this.e(), this.f(), this.i, this.j, this.k, this.l).a();
        (this.n = new h(this.e(), this.m)).b("webSocketReceiver");
    }
    
    @Override
    public void stop() {
        this.f().write(new d((byte)8, true, "1000".getBytes()).d());
        this.f().flush();
        final h n = this.n;
        if (n != null) {
            n.c();
        }
        super.stop();
    }
}
