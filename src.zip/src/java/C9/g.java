package C9;

import A9.h;
import javax.net.ssl.SSLSocketFactory;
import javax.net.SocketFactory;
import A9.k;
import org.eclipse.paho.client.mqttv3.i;
import java.net.URI;
import java.util.Collections;
import java.util.Collection;
import java.util.HashSet;
import java.util.Arrays;
import java.util.Set;
import F9.a;

public class g implements a
{
    @Override
    public Set a() {
        return Collections.unmodifiableSet((Set)new HashSet((Collection)Arrays.asList((Object[])new String[] { "ws" })));
    }
    
    @Override
    public k b(final URI uri, final i i, final String s) {
        final String host = uri.getHost();
        int port;
        if ((port = uri.getPort()) == -1) {
            port = 80;
        }
        SocketFactory socketFactory = i.l();
        if (socketFactory == null) {
            socketFactory = SocketFactory.getDefault();
        }
        else if (socketFactory instanceof SSLSocketFactory) {
            throw h.a(32105);
        }
        final f f = new f(socketFactory, uri.toString(), host, port, s, i.b());
        f.d(i.a());
        return f;
    }
    
    @Override
    public void c(final URI uri) {
    }
}
