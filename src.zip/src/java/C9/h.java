package C9;

import java.net.SocketTimeoutException;
import java.io.IOException;
import org.eclipse.paho.client.mqttv3.logging.b;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.InputStream;
import org.eclipse.paho.client.mqttv3.logging.a;

public class h implements Runnable
{
    private static final String i = "C9.h";
    private a a;
    private boolean b;
    private boolean c;
    private final Object d;
    private InputStream e;
    private Thread f;
    private volatile boolean g;
    private PipedOutputStream h;
    
    public h(final InputStream e, final PipedInputStream pipedInputStream) {
        this.a = org.eclipse.paho.client.mqttv3.logging.b.a("org.eclipse.paho.client.mqttv3.internal.nls.logcat", C9.h.i);
        this.b = false;
        this.c = false;
        this.d = new Object();
        this.f = null;
        this.e = e;
        pipedInputStream.connect(this.h = new PipedOutputStream());
    }
    
    private void a() {
        try {
            this.h.close();
        }
        catch (final IOException ex) {}
    }
    
    public void b(final String s) {
        this.a.fine(C9.h.i, "start", "855");
        final Object d;
        monitorenter(d = this.d);
        Label_0064: {
            try {
                if (!this.b) {
                    this.b = true;
                    (this.f = new Thread((Runnable)this, s)).start();
                }
                break Label_0064;
            }
            finally {
                monitorexit(d);
                monitorexit(d);
            }
        }
    }
    
    public void c() {
        boolean b = true;
        this.c = true;
        final Object d;
        monitorenter(d = this.d);
        Label_0061: {
            try {
                this.a.fine(C9.h.i, "stop", "850");
                if (this.b) {
                    this.b = false;
                    this.g = false;
                    this.a();
                    break Label_0061;
                }
                break Label_0061;
            }
            finally {
                while (true) {
                    while (true) {
                        Label_0118: {
                            break Label_0118;
                            try {
                                final Thread f;
                                f.join();
                                Label_0096: {
                                    this.f = null;
                                }
                                this.a.fine(C9.h.i, "stop", "851");
                                return;
                                monitorexit(d);
                            }
                            catch (final InterruptedException ex) {}
                        }
                        final Thread f = this.f;
                        iftrue(Label_0096:)(f == null);
                        continue;
                    }
                    b = false;
                    monitorexit(d);
                    iftrue(Label_0096:)(!b || Thread.currentThread().equals(this.f));
                    continue;
                }
            }
        }
    }
    
    public void run() {
        while (this.b && this.e != null) {
            try {
                this.a.fine(C9.h.i, "run", "852");
                this.g = (this.e.available() > 0);
                final d d = new d(this.e);
                if (!d.g()) {
                    for (int i = 0; i < d.f().length; ++i) {
                        this.h.write((int)d.f()[i]);
                    }
                    this.h.flush();
                }
                else if (!this.c) {
                    throw new IOException("Server sent a WebSocket Frame with the Stop OpCode");
                }
                this.g = false;
            }
            catch (final IOException ex) {
                this.c();
            }
            catch (final SocketTimeoutException ex2) {}
        }
        goto Label_0146;
    }
}
