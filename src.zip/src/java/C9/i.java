package C9;

import java.io.InputStream;
import java.io.OutputStream;
import org.eclipse.paho.client.mqttv3.logging.b;
import javax.net.ssl.SSLSocketFactory;
import java.io.ByteArrayOutputStream;
import java.util.Properties;
import java.io.PipedInputStream;
import org.eclipse.paho.client.mqttv3.logging.a;
import A9.n;

public class i extends n
{
    private static final String x = "C9.i";
    private a p;
    private PipedInputStream q;
    private h r;
    private String s;
    private String t;
    private int u;
    private Properties v;
    private ByteArrayOutputStream w;
    
    public i(final SSLSocketFactory sslSocketFactory, final String s, final String t, final int u, final String resourceName, final Properties v) {
        super(sslSocketFactory, t, u, resourceName);
        this.p = org.eclipse.paho.client.mqttv3.logging.b.a("org.eclipse.paho.client.mqttv3.internal.nls.logcat", i.x);
        this.w = new C9.b(this);
        this.s = s;
        this.t = t;
        this.u = u;
        this.v = v;
        this.q = new PipedInputStream();
        this.p.setResourceName(resourceName);
    }
    
    @Override
    public String a() {
        final String t = this.t;
        final int u = this.u;
        final StringBuilder sb = new StringBuilder();
        sb.append("wss://");
        sb.append(t);
        sb.append(":");
        sb.append(u);
        return sb.toString();
    }
    
    @Override
    public OutputStream b() {
        return (OutputStream)this.w;
    }
    
    @Override
    public InputStream c() {
        return (InputStream)this.q;
    }
    
    InputStream i() {
        return super.c();
    }
    
    OutputStream j() {
        return super.b();
    }
    
    @Override
    public void start() {
        super.start();
        new e(super.c(), super.b(), this.s, this.t, this.u, this.v).a();
        (this.r = new h(this.i(), this.q)).b("WssSocketReceiver");
    }
    
    @Override
    public void stop() {
        this.j().write(new d((byte)8, true, "1000".getBytes()).d());
        this.j().flush();
        final h r = this.r;
        if (r != null) {
            r.c();
        }
        super.stop();
    }
}
