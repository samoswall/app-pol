package C9;

import java.util.Properties;
import A9.h;
import javax.net.ssl.SSLSocketFactory;
import A9.k;
import org.eclipse.paho.client.mqttv3.i;
import java.net.URI;
import java.util.Collections;
import java.util.Collection;
import java.util.HashSet;
import java.util.Arrays;
import java.util.Set;
import F9.a;

public class j implements a
{
    @Override
    public Set a() {
        return Collections.unmodifiableSet((Set)new HashSet((Collection)Arrays.asList((Object[])new String[] { "wss" })));
    }
    
    @Override
    public k b(final URI uri, final i i, final String s) {
        final String host = uri.getHost();
        int port;
        if ((port = uri.getPort()) == -1) {
            port = 443;
        }
        Object o = i.l();
        B9.a a;
        if (o == null) {
            a = new B9.a();
            final Properties j = i.j();
            if (j != null) {
                a.t(j, null);
            }
            o = a.c(null);
        }
        else {
            if (!(o instanceof SSLSocketFactory)) {
                throw h.a(32105);
            }
            a = null;
        }
        final C9.i k = new C9.i((SSLSocketFactory)o, uri.toString(), host, port, s, i.b());
        k.h(i.a());
        k.g(i.i());
        k.f(i.r());
        if (a != null) {
            final String[] e = a.e(null);
            if (e != null) {
                k.e(e);
            }
        }
        return k;
    }
    
    @Override
    public void c(final URI uri) {
    }
}
