package a4;

import java.util.Iterator;
import java.util.Collection;
import java.util.Map;
import java.util.Collections;
import java.util.WeakHashMap;
import java.util.Set;

class a implements l
{
    private final Set a;
    private boolean b;
    private boolean c;
    
    a() {
        this.a = Collections.newSetFromMap((Map)new WeakHashMap());
    }
    
    @Override
    public void a(final m m) {
        this.a.remove((Object)m);
    }
    
    @Override
    public void b(final m m) {
        this.a.add((Object)m);
        if (this.c) {
            m.onDestroy();
        }
        else if (this.b) {
            m.onStart();
        }
        else {
            m.onStop();
        }
    }
    
    void c() {
        this.c = true;
        final Iterator iterator = g4.l.j((Collection)this.a).iterator();
        while (iterator.hasNext()) {
            ((m)iterator.next()).onDestroy();
        }
    }
    
    void d() {
        this.b = true;
        final Iterator iterator = g4.l.j((Collection)this.a).iterator();
        while (iterator.hasNext()) {
            ((m)iterator.next()).onStart();
        }
    }
    
    void e() {
        this.b = false;
        final Iterator iterator = g4.l.j((Collection)this.a).iterator();
        while (iterator.hasNext()) {
            ((m)iterator.next()).onStop();
        }
    }
}
