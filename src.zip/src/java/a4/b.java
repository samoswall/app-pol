package a4;

class b implements l
{
    @Override
    public void a(final m m) {
    }
    
    @Override
    public void b(final m m) {
        m.onStart();
    }
}
