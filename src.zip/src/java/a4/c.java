package a4;

public interface c extends m
{
    public interface a
    {
        void a(final boolean p0);
    }
}
