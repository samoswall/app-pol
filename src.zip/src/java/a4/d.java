package a4;

import android.content.Context;

public interface d
{
    c a(final Context p0, final c.a p1);
}
