package a4;

import android.content.Context;

final class e implements c
{
    private final Context a;
    final a b;
    
    e(final Context context, final a b) {
        this.a = context.getApplicationContext();
        this.b = b;
    }
    
    private void a() {
        s.a(this.a).d(this.b);
    }
    
    private void b() {
        s.a(this.a).e(this.b);
    }
    
    public void onDestroy() {
    }
    
    public void onStart() {
        this.a();
    }
    
    public void onStop() {
        this.b();
    }
}
