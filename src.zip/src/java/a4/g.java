package a4;

import android.app.Activity;

final class g implements k
{
    @Override
    public void a(final Activity activity) {
    }
}
