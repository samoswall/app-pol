package a4;

import java.util.Collections;
import java.util.Set;

final class h implements q
{
    @Override
    public Set a() {
        return Collections.emptySet();
    }
}
