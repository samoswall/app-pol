package a4;

import android.app.Activity;

final class j implements k
{
    @Override
    public void a(final Activity activity) {
    }
}
