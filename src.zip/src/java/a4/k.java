package a4;

import android.app.Activity;

interface k
{
    void a(final Activity p0);
}
