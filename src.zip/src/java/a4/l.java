package a4;

public interface l
{
    void a(final m p0);
    
    void b(final m p0);
}
