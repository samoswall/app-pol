package a4;

public interface m
{
    void onDestroy();
    
    void onStart();
    
    void onStop();
}
