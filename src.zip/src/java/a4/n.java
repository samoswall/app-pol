package a4;

class n implements c
{
    public void onDestroy() {
    }
    
    public void onStart() {
    }
    
    public void onStop() {
    }
}
