package a4;

import android.util.Log;
import java.util.Iterator;
import java.util.Collections;
import android.content.Context;
import com.bumptech.glide.b;
import android.app.Activity;
import java.util.HashSet;
import com.bumptech.glide.j;
import java.util.Set;
import android.app.Fragment;

public class o extends Fragment
{
    private final a4.a a;
    private final q b;
    private final Set c;
    private j d;
    private o e;
    private Fragment f;
    
    public o() {
        this(new a4.a());
    }
    
    o(final a4.a a) {
        this.b = new a();
        this.c = (Set)new HashSet();
        this.a = a;
    }
    
    private void a(final o o) {
        this.c.add((Object)o);
    }
    
    private Fragment d() {
        Fragment fragment = this.getParentFragment();
        if (fragment == null) {
            fragment = this.f;
        }
        return fragment;
    }
    
    private boolean g(Fragment parentFragment) {
        final Fragment parentFragment2 = this.getParentFragment();
        while (true) {
            final Fragment parentFragment3 = parentFragment.getParentFragment();
            if (parentFragment3 == null) {
                return false;
            }
            if (parentFragment3.equals((Object)parentFragment2)) {
                return true;
            }
            parentFragment = parentFragment.getParentFragment();
        }
    }
    
    private void h(final Activity activity) {
        this.l();
        final o i = com.bumptech.glide.b.c((Context)activity).k().i(activity);
        this.e = i;
        if (!this.equals(i)) {
            this.e.a(this);
        }
    }
    
    private void i(final o o) {
        this.c.remove((Object)o);
    }
    
    private void l() {
        final o e = this.e;
        if (e != null) {
            e.i(this);
            this.e = null;
        }
    }
    
    Set b() {
        if (this.equals(this.e)) {
            return Collections.unmodifiableSet(this.c);
        }
        if (this.e != null) {
            final HashSet set = new HashSet();
            for (final o o : this.e.b()) {
                if (this.g(o.getParentFragment())) {
                    ((Set)set).add((Object)o);
                }
            }
            return Collections.unmodifiableSet((Set)set);
        }
        return Collections.emptySet();
    }
    
    a4.a c() {
        return this.a;
    }
    
    public j e() {
        return this.d;
    }
    
    public q f() {
        return this.b;
    }
    
    void j(final Fragment f) {
        this.f = f;
        if (f != null && f.getActivity() != null) {
            this.h(f.getActivity());
        }
    }
    
    public void k(final j d) {
        this.d = d;
    }
    
    public void onAttach(final Activity activity) {
        super.onAttach(activity);
        try {
            this.h(activity);
        }
        catch (final IllegalStateException ex) {
            if (Log.isLoggable("RMFragment", 5)) {
                Log.w("RMFragment", "Unable to register fragment with root", (Throwable)ex);
            }
        }
    }
    
    public void onDestroy() {
        super.onDestroy();
        this.a.c();
        this.l();
    }
    
    public void onDetach() {
        super.onDetach();
        this.l();
    }
    
    public void onStart() {
        super.onStart();
        this.a.d();
    }
    
    public void onStop() {
        super.onStop();
        this.a.e();
    }
    
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("{parent=");
        sb.append((Object)this.d());
        sb.append("}");
        return sb.toString();
    }
    
    private class a implements q
    {
        final o a;
        
        a(final o a) {
            this.a = a;
        }
        
        @Override
        public Set a() {
            final Set b = this.a.b();
            final HashSet set = new HashSet(b.size());
            for (final o o : b) {
                if (o.e() != null) {
                    ((Set)set).add((Object)o.e());
                }
            }
            return (Set)set;
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append(super.toString());
            sb.append("{fragment=");
            sb.append((Object)this.a);
            sb.append("}");
            return sb.toString();
        }
    }
}
