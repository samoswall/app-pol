package a4;

import android.os.Message;
import android.app.Application;
import androidx.fragment.app.v;
import androidx.fragment.app.S;
import android.app.FragmentTransaction;
import android.util.Log;
import androidx.fragment.app.J;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.ContextWrapper;
import com.bumptech.glide.c$e;
import U3.n;
import android.app.Activity;
import android.os.Looper;
import java.util.HashMap;
import com.bumptech.glide.e;
import android.content.Context;
import com.bumptech.glide.b;
import android.os.Bundle;
import androidx.collection.a;
import android.os.Handler;
import java.util.Map;
import com.bumptech.glide.j;
import android.os.Handler$Callback;

public class p implements Handler$Callback
{
    private static final b j;
    private volatile j a;
    final Map b;
    final Map c;
    private final Handler d;
    private final b e;
    private final a f;
    private final a g;
    private final Bundle h;
    private final k i;
    
    static {
        j = (b)new b() {
            @Override
            public j a(final com.bumptech.glide.b b, final l l, final q q, final Context context) {
                return new j(b, l, q, context);
            }
        };
    }
    
    public p(b j, final e e) {
        this.b = (Map)new HashMap();
        this.c = (Map)new HashMap();
        this.f = new a();
        this.g = new a();
        this.h = new Bundle();
        if (j == null) {
            j = p.j;
        }
        this.e = j;
        this.d = new Handler(Looper.getMainLooper(), (Handler$Callback)this);
        this.i = b(e);
    }
    
    private static void a(final Activity activity) {
        if (!activity.isDestroyed()) {
            return;
        }
        throw new IllegalArgumentException("You cannot start a load for a destroyed activity");
    }
    
    private static k b(final e e) {
        if (n.h && n.g) {
            k k;
            if (e.a((Class)c$e.class)) {
                k = new i();
            }
            else {
                k = new a4.j();
            }
            return k;
        }
        return new g();
    }
    
    private static Activity c(final Context context) {
        if (context instanceof Activity) {
            return (Activity)context;
        }
        if (context instanceof ContextWrapper) {
            return c(((ContextWrapper)context).getBaseContext());
        }
        return null;
    }
    
    private j d(final Context context, final FragmentManager fragmentManager, final Fragment fragment, final boolean b) {
        final o j = this.j(fragmentManager, fragment);
        j i;
        if ((i = j.e()) == null) {
            i = this.e.a(b.c(context), j.c(), j.f(), context);
            if (b) {
                i.onStart();
            }
            j.k(i);
        }
        return i;
    }
    
    private j h(final Context context) {
        if (this.a == null) {
            monitorenter(this);
            Label_0077: {
                try {
                    if (this.a == null) {
                        this.a = this.e.a(com.bumptech.glide.b.c(context.getApplicationContext()), new a4.b(), new h(), context.getApplicationContext());
                    }
                    break Label_0077;
                }
                finally {
                    monitorexit(this);
                    monitorexit(this);
                }
            }
        }
        return this.a;
    }
    
    private o j(final FragmentManager fragmentManager, final Fragment fragment) {
        o o;
        if ((o = (o)this.b.get((Object)fragmentManager)) == null && (o = (o)fragmentManager.findFragmentByTag("com.bumptech.glide.manager")) == null) {
            o = new o();
            o.j(fragment);
            this.b.put((Object)fragmentManager, (Object)o);
            fragmentManager.beginTransaction().add((Fragment)o, "com.bumptech.glide.manager").commitAllowingStateLoss();
            this.d.obtainMessage(1, (Object)fragmentManager).sendToTarget();
        }
        return o;
    }
    
    private t l(final J j, final androidx.fragment.app.q q) {
        t t;
        if ((t = (t)this.c.get((Object)j)) == null && (t = (t)j.j0("com.bumptech.glide.manager")) == null) {
            t = new t();
            t.L1(q);
            this.c.put((Object)j, (Object)t);
            j.o().d((androidx.fragment.app.q)t, "com.bumptech.glide.manager").g();
            this.d.obtainMessage(2, (Object)j).sendToTarget();
        }
        return t;
    }
    
    private static boolean m(final Context context) {
        final Activity c = c(context);
        return c == null || !c.isFinishing();
    }
    
    private j n(final Context context, final J j, final androidx.fragment.app.q q, final boolean b) {
        final t l = this.l(j, q);
        j i;
        if ((i = l.F1()) == null) {
            i = this.e.a(b.c(context), l.D1(), l.G1(), context);
            if (b) {
                i.onStart();
            }
            l.M1(i);
        }
        return i;
    }
    
    private boolean o(final FragmentManager fragmentManager, final boolean b) {
        final o o = (o)this.b.get((Object)fragmentManager);
        final o o2 = (o)fragmentManager.findFragmentByTag("com.bumptech.glide.manager");
        if (o2 == o) {
            return true;
        }
        if (o2 != null && o2.e() != null) {
            final StringBuilder sb = new StringBuilder();
            sb.append("We've added two fragments with requests! Old: ");
            sb.append((Object)o2);
            sb.append(" New: ");
            sb.append((Object)o);
            throw new IllegalStateException(sb.toString());
        }
        if (!b && !fragmentManager.isDestroyed()) {
            final FragmentTransaction add = fragmentManager.beginTransaction().add((Fragment)o, "com.bumptech.glide.manager");
            if (o2 != null) {
                add.remove((Fragment)o2);
            }
            add.commitAllowingStateLoss();
            this.d.obtainMessage(1, 1, 0, (Object)fragmentManager).sendToTarget();
            if (Log.isLoggable("RMRetriever", 3)) {
                Log.d("RMRetriever", "We failed to add our Fragment the first time around, trying again...");
            }
            return false;
        }
        if (Log.isLoggable("RMRetriever", 5)) {
            if (fragmentManager.isDestroyed()) {
                Log.w("RMRetriever", "Parent was destroyed before our Fragment could be added");
            }
            else {
                Log.w("RMRetriever", "Tried adding Fragment twice and failed twice, giving up!");
            }
        }
        o.c().c();
        return true;
    }
    
    private boolean p(final J j, final boolean b) {
        final t t = (t)this.c.get((Object)j);
        final t t2 = (t)j.j0("com.bumptech.glide.manager");
        if (t2 == t) {
            return true;
        }
        if (t2 != null && t2.F1() != null) {
            final StringBuilder sb = new StringBuilder();
            sb.append("We've added two fragments with requests! Old: ");
            sb.append((Object)t2);
            sb.append(" New: ");
            sb.append((Object)t);
            throw new IllegalStateException(sb.toString());
        }
        if (!b && !j.I0()) {
            final S d = j.o().d((androidx.fragment.app.q)t, "com.bumptech.glide.manager");
            if (t2 != null) {
                d.l((androidx.fragment.app.q)t2);
            }
            d.i();
            this.d.obtainMessage(2, 1, 0, (Object)j).sendToTarget();
            if (Log.isLoggable("RMRetriever", 3)) {
                Log.d("RMRetriever", "We failed to add our Fragment the first time around, trying again...");
            }
            return false;
        }
        if (j.I0()) {
            if (Log.isLoggable("RMRetriever", 5)) {
                Log.w("RMRetriever", "Parent was destroyed before our Fragment could be added, all requests for the destroyed parent are cancelled");
            }
        }
        else if (Log.isLoggable("RMRetriever", 6)) {
            Log.e("RMRetriever", "ERROR: Tried adding Fragment twice and failed twice, giving up and cancelling all associated requests! This probably means you're starting loads in a unit test with an Activity that you haven't created and never create. If you're using Robolectric, create the Activity as part of your test setup");
        }
        t.D1().c();
        return true;
    }
    
    public j e(final Activity activity) {
        if (g4.l.q()) {
            return this.f(((Context)activity).getApplicationContext());
        }
        if (activity instanceof v) {
            return this.g((v)activity);
        }
        a(activity);
        this.i.a(activity);
        return this.d((Context)activity, activity.getFragmentManager(), null, m((Context)activity));
    }
    
    public j f(final Context context) {
        if (context != null) {
            if (g4.l.r() && !(context instanceof Application)) {
                if (context instanceof v) {
                    return this.g((v)context);
                }
                if (context instanceof Activity) {
                    return this.e((Activity)context);
                }
                if (context instanceof ContextWrapper) {
                    final ContextWrapper contextWrapper = (ContextWrapper)context;
                    if (contextWrapper.getBaseContext().getApplicationContext() != null) {
                        return this.f(contextWrapper.getBaseContext());
                    }
                }
            }
            return this.h(context);
        }
        throw new IllegalArgumentException("You cannot start a load on a null Context");
    }
    
    public j g(final v v) {
        if (g4.l.q()) {
            return this.f(((Context)v).getApplicationContext());
        }
        a((Activity)v);
        this.i.a((Activity)v);
        return this.n((Context)v, v.getSupportFragmentManager(), null, m((Context)v));
    }
    
    public boolean handleMessage(final Message message) {
        final int arg1 = message.arg1;
        boolean b = true;
        final boolean b2 = false;
        final boolean b3 = arg1 == 1;
        final int what = message.what;
        Object o = null;
        Object o2 = null;
        boolean b4 = false;
        Label_0129: {
            Label_0122: {
                if (what != 1) {
                    if (what != 2) {
                        b = false;
                        o2 = null;
                        b4 = b2;
                        break Label_0129;
                    }
                    o2 = message.obj;
                    if (!this.p((J)o2, b3)) {
                        break Label_0122;
                    }
                    o = this.c.remove(o2);
                }
                else {
                    o2 = message.obj;
                    if (!this.o((FragmentManager)o2, b3)) {
                        break Label_0122;
                    }
                    o = this.b.remove(o2);
                }
                b4 = true;
                break Label_0129;
            }
            o2 = null;
            b4 = true;
            b = false;
        }
        if (Log.isLoggable("RMRetriever", 5) && b && o == null) {
            final StringBuilder sb = new StringBuilder();
            sb.append("Failed to remove expected request manager fragment, manager: ");
            sb.append(o2);
            Log.w("RMRetriever", sb.toString());
        }
        return b4;
    }
    
    o i(final Activity activity) {
        return this.j(activity.getFragmentManager(), null);
    }
    
    t k(final J j) {
        return this.l(j, null);
    }
    
    public interface b
    {
        j a(final com.bumptech.glide.b p0, final l p1, final q p2, final Context p3);
    }
}
