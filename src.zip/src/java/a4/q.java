package a4;

import java.util.Set;

public interface q
{
    Set a();
}
