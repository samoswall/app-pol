package a4;

import android.util.Log;
import java.util.Iterator;
import java.util.Collection;
import g4.l;
import com.bumptech.glide.request.d;
import java.util.HashSet;
import java.util.Map;
import java.util.Collections;
import java.util.WeakHashMap;
import java.util.Set;

public class r
{
    private final Set a;
    private final Set b;
    private boolean c;
    
    public r() {
        this.a = Collections.newSetFromMap((Map)new WeakHashMap());
        this.b = (Set)new HashSet();
    }
    
    public boolean a(final d d) {
        final boolean b = true;
        if (d == null) {
            return true;
        }
        final boolean remove = this.a.remove((Object)d);
        boolean b2 = b;
        if (!this.b.remove((Object)d)) {
            b2 = (remove && b);
        }
        if (b2) {
            d.clear();
        }
        return b2;
    }
    
    public void b() {
        final Iterator iterator = l.j((Collection)this.a).iterator();
        while (iterator.hasNext()) {
            this.a((d)iterator.next());
        }
        this.b.clear();
    }
    
    public void c() {
        this.c = true;
        for (final d d : l.j((Collection)this.a)) {
            if (d.isRunning() || d.j()) {
                d.clear();
                this.b.add((Object)d);
            }
        }
    }
    
    public void d() {
        this.c = true;
        for (final d d : l.j((Collection)this.a)) {
            if (d.isRunning()) {
                d.e();
                this.b.add((Object)d);
            }
        }
    }
    
    public void e() {
        for (final d d : l.j((Collection)this.a)) {
            if (!d.j() && !d.g()) {
                d.clear();
                if (!this.c) {
                    d.i();
                }
                else {
                    this.b.add((Object)d);
                }
            }
        }
    }
    
    public void f() {
        this.c = false;
        for (final d d : l.j((Collection)this.a)) {
            if (!d.j() && !d.isRunning()) {
                d.i();
            }
        }
        this.b.clear();
    }
    
    public void g(final d d) {
        this.a.add((Object)d);
        if (!this.c) {
            d.i();
        }
        else {
            d.clear();
            if (Log.isLoggable("RequestTracker", 2)) {
                Log.v("RequestTracker", "Paused, delaying request");
            }
            this.b.add((Object)d);
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("{numRequests=");
        sb.append(this.a.size());
        sb.append(", isPaused=");
        sb.append(this.c);
        sb.append("}");
        return sb.toString();
    }
}
