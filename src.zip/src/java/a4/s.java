package a4;

import java.util.List;
import android.util.Log;
import android.net.Network;
import g4.l;
import android.net.ConnectivityManager$NetworkCallback;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import android.net.ConnectivityManager;
import g4.f;
import java.util.HashSet;
import android.content.Context;
import java.util.Set;

final class s
{
    private static volatile s d;
    private final c a;
    final Set b;
    private boolean c;
    
    private s(final Context context) {
        this.b = (Set)new HashSet();
        this.a = (c)new d(f.a((f.b)new f.b(this, context) {
            final Context a;
            final s b;
            
            public ConnectivityManager a() {
                return (ConnectivityManager)this.a.getSystemService("connectivity");
            }
        }), new a4.c.a(this) {
            final s a;
            
            @Override
            public void a(final boolean b) {
                final s a = this.a;
                synchronized (a) {
                    final ArrayList list = new ArrayList((Collection)this.a.b);
                    monitorexit(a);
                    final Iterator iterator = ((List)list).iterator();
                    while (iterator.hasNext()) {
                        ((a)iterator.next()).a(b);
                    }
                }
            }
        });
    }
    
    static s a(final Context context) {
        if (s.d == null) {
            final Class<s> clazz;
            monitorenter(clazz = s.class);
            Label_0040: {
                try {
                    if (s.d == null) {
                        s.d = new s(context.getApplicationContext());
                    }
                    break Label_0040;
                }
                finally {
                    monitorexit(clazz);
                    monitorexit(clazz);
                }
            }
        }
        return s.d;
    }
    
    private void b() {
        if (!this.c) {
            if (!this.b.isEmpty()) {
                this.c = this.a.b();
            }
        }
    }
    
    private void c() {
        if (this.c) {
            if (this.b.isEmpty()) {
                this.a.a();
                this.c = false;
            }
        }
    }
    
    void d(final a4.c.a a) {
        synchronized (this) {
            this.b.add((Object)a);
            this.b();
        }
    }
    
    void e(final a4.c.a a) {
        synchronized (this) {
            this.b.remove((Object)a);
            this.c();
        }
    }
    
    private interface c
    {
        void a();
        
        boolean b();
    }
    
    private static final class d implements c
    {
        boolean a;
        final a4.c.a b;
        private final f.b c;
        private final ConnectivityManager$NetworkCallback d;
        
        d(final f.b c, final a4.c.a b) {
            this.d = new ConnectivityManager$NetworkCallback() {
                final d a;
                
                private void b(final boolean b) {
                    l.u((Runnable)new Runnable(this, b) {
                        final boolean a;
                        final s$d$a b;
                        
                        public void run() {
                            this.b.a(this.a);
                        }
                    });
                }
                
                void a(final boolean a) {
                    l.b();
                    final d a2 = this.a;
                    final boolean a3 = a2.a;
                    a2.a = a;
                    if (a3 != a) {
                        a2.b.a(a);
                    }
                }
                
                public void onAvailable(final Network network) {
                    this.b(true);
                }
                
                public void onLost(final Network network) {
                    this.b(false);
                }
            };
            this.c = c;
            this.b = b;
        }
        
        @Override
        public void a() {
            ((ConnectivityManager)this.c.get()).unregisterNetworkCallback(this.d);
        }
        
        @Override
        public boolean b() {
            this.a = (((ConnectivityManager)this.c.get()).getActiveNetwork() != null);
            try {
                ((ConnectivityManager)this.c.get()).registerDefaultNetworkCallback(this.d);
                return true;
            }
            catch (final RuntimeException ex) {
                if (Log.isLoggable("ConnectivityMonitor", 5)) {
                    Log.w("ConnectivityMonitor", "Failed to register callback", (Throwable)ex);
                }
                return false;
            }
        }
    }
}
