package a4;

import android.util.Log;
import java.util.Iterator;
import java.util.Collections;
import com.bumptech.glide.b;
import android.content.Context;
import androidx.fragment.app.J;
import java.util.HashSet;
import com.bumptech.glide.j;
import java.util.Set;
import androidx.fragment.app.q;

public class t extends q
{
    private final a4.a u0;
    private final a4.q v0;
    private final Set w0;
    private t x0;
    private j y0;
    private q z0;
    
    public t() {
        this(new a4.a());
    }
    
    public t(final a4.a u0) {
        this.v0 = new a();
        this.w0 = (Set)new HashSet();
        this.u0 = u0;
    }
    
    private void B1(final t t) {
        this.w0.add((Object)t);
    }
    
    private q E1() {
        q q = this.C();
        if (q == null) {
            q = this.z0;
        }
        return q;
    }
    
    private static J H1(q c) {
        while (c.C() != null) {
            c = c.C();
        }
        return c.x();
    }
    
    private boolean I1(q c) {
        final q e1 = this.E1();
        while (true) {
            final q c2 = c.C();
            if (c2 == null) {
                return false;
            }
            if (c2.equals((Object)e1)) {
                return true;
            }
            c = c.C();
        }
    }
    
    private void J1(final Context context, final J j) {
        this.N1();
        final t k = b.c(context).k().k(j);
        this.x0 = k;
        if (!this.equals((Object)k)) {
            this.x0.B1(this);
        }
    }
    
    private void K1(final t t) {
        this.w0.remove((Object)t);
    }
    
    private void N1() {
        final t x0 = this.x0;
        if (x0 != null) {
            x0.K1(this);
            this.x0 = null;
        }
    }
    
    Set C1() {
        final t x0 = this.x0;
        if (x0 == null) {
            return Collections.emptySet();
        }
        if (this.equals((Object)x0)) {
            return Collections.unmodifiableSet(this.w0);
        }
        final HashSet set = new HashSet();
        for (final t t : this.x0.C1()) {
            if (this.I1(t.E1())) {
                ((Set)set).add((Object)t);
            }
        }
        return Collections.unmodifiableSet((Set)set);
    }
    
    a4.a D1() {
        return this.u0;
    }
    
    public j F1() {
        return this.y0;
    }
    
    public a4.q G1() {
        return this.v0;
    }
    
    public void I0() {
        super.I0();
        this.u0.d();
    }
    
    public void J0() {
        super.J0();
        this.u0.e();
    }
    
    void L1(final q z0) {
        this.z0 = z0;
        if (z0 != null) {
            if (z0.p() != null) {
                final J h1 = H1(z0);
                if (h1 == null) {
                    return;
                }
                this.J1(z0.p(), h1);
            }
        }
    }
    
    public void M1(final j y0) {
        this.y0 = y0;
    }
    
    public void i0(final Context context) {
        super.i0(context);
        final J h1 = H1(this);
        if (h1 == null) {
            if (Log.isLoggable("SupportRMFragment", 5)) {
                Log.w("SupportRMFragment", "Unable to register fragment with root, ancestor detached");
            }
            return;
        }
        try {
            this.J1(this.p(), h1);
        }
        catch (final IllegalStateException ex) {
            if (Log.isLoggable("SupportRMFragment", 5)) {
                Log.w("SupportRMFragment", "Unable to register fragment with root", (Throwable)ex);
            }
        }
    }
    
    public void q0() {
        super.q0();
        this.u0.c();
        this.N1();
    }
    
    public void t0() {
        super.t0();
        this.z0 = null;
        this.N1();
    }
    
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("{parent=");
        sb.append((Object)this.E1());
        sb.append("}");
        return sb.toString();
    }
    
    private class a implements q
    {
        final t a;
        
        a(final t a) {
            this.a = a;
        }
        
        @Override
        public Set a() {
            final Set c1 = this.a.C1();
            final HashSet set = new HashSet(c1.size());
            for (final t t : c1) {
                if (t.F1() != null) {
                    ((Set)set).add((Object)t.F1());
                }
            }
            return (Set)set;
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append(super.toString());
            sb.append("{fragment=");
            sb.append((Object)this.a);
            sb.append("}");
            return sb.toString();
        }
    }
}
