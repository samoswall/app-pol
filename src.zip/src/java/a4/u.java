package a4;

import java.util.Iterator;
import d4.d;
import java.util.Collection;
import g4.l;
import java.util.List;
import java.util.Map;
import java.util.Collections;
import java.util.WeakHashMap;
import java.util.Set;

public final class u implements m
{
    private final Set a;
    
    public u() {
        this.a = Collections.newSetFromMap((Map)new WeakHashMap());
    }
    
    public void a() {
        this.a.clear();
    }
    
    public List b() {
        return l.j((Collection)this.a);
    }
    
    public void c(final d d) {
        this.a.add((Object)d);
    }
    
    public void d(final d d) {
        this.a.remove((Object)d);
    }
    
    public void onDestroy() {
        final Iterator iterator = l.j((Collection)this.a).iterator();
        while (iterator.hasNext()) {
            ((m)iterator.next()).onDestroy();
        }
    }
    
    public void onStart() {
        final Iterator iterator = l.j((Collection)this.a).iterator();
        while (iterator.hasNext()) {
            ((m)iterator.next()).onStart();
        }
    }
    
    public void onStop() {
        final Iterator iterator = l.j((Collection)this.a).iterator();
        while (iterator.hasNext()) {
            ((m)iterator.next()).onStop();
        }
    }
}
