package A4;

import android.content.Context;
import I4.d;
import java.io.Closeable;

abstract class v implements Closeable
{
    public void close() {
        ((Closeable)this.d()).close();
    }
    
    abstract d d();
    
    abstract u e();
    
    interface a
    {
        v a();
        
        a b(final Context p0);
    }
}
