package b4;

import android.content.Context;

public abstract class a extends c
{
    public void b(final Context context, final com.bumptech.glide.c c) {
    }
    
    public boolean c() {
        return true;
    }
}
