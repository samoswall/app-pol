package b4;

public interface b
{
}
