package b4;

import com.bumptech.glide.h;
import com.bumptech.glide.b;
import android.content.Context;

public abstract class c
{
    public void a(final Context context, final b b, final h h) {
    }
}
