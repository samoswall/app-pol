package b4;

import android.os.BaseBundle;
import java.util.Iterator;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager$NameNotFoundException;
import java.util.ArrayList;
import android.util.Log;
import java.util.List;
import java.lang.reflect.InvocationTargetException;
import android.content.Context;

public final class d
{
    private final Context a;
    
    public d(final Context a) {
        this.a = a;
    }
    
    private static b b(final String className) {
        try {
            final Class<?> forName = Class.forName(className);
            Object instance = null;
            Label_0071: {
                Label_0069: {
                    Label_0064: {
                        Label_0056: {
                            Label_0048: {
                                try {
                                    instance = forName.getDeclaredConstructor((Class<?>[])new Class[0]).newInstance(new Object[0]);
                                    break Label_0071;
                                }
                                catch (final InvocationTargetException ex) {}
                                catch (final NoSuchMethodException ex2) {
                                    break Label_0048;
                                }
                                catch (final IllegalAccessException ex3) {
                                    break Label_0056;
                                }
                                catch (final InstantiationException ex4) {
                                    break Label_0064;
                                }
                                final InvocationTargetException ex;
                                c(forName, (Exception)ex);
                                break Label_0069;
                            }
                            final NoSuchMethodException ex2;
                            c(forName, (Exception)ex2);
                            break Label_0069;
                        }
                        final IllegalAccessException ex3;
                        c(forName, (Exception)ex3);
                        break Label_0069;
                    }
                    final InstantiationException ex4;
                    c(forName, (Exception)ex4);
                }
                instance = null;
            }
            final StringBuilder sb = new StringBuilder();
            sb.append("Expected instanceof GlideModule, but found: ");
            sb.append(instance);
            throw new RuntimeException(sb.toString());
        }
        catch (final ClassNotFoundException ex5) {
            throw new IllegalArgumentException("Unable to find GlideModule implementation", (Throwable)ex5);
        }
    }
    
    private static void c(final Class clazz, final Exception ex) {
        final StringBuilder sb = new StringBuilder();
        sb.append("Unable to instantiate GlideModule implementation for ");
        sb.append((Object)clazz);
        throw new RuntimeException(sb.toString(), (Throwable)ex);
    }
    
    public List a() {
        if (Log.isLoggable("ManifestParser", 3)) {
            Log.d("ManifestParser", "Loading Glide modules");
        }
        final ArrayList list = new ArrayList();
        ApplicationInfo applicationInfo = null;
        Label_0079: {
            try {
                applicationInfo = this.a.getPackageManager().getApplicationInfo(this.a.getPackageName(), 128);
                if (applicationInfo.metaData != null) {
                    break Label_0079;
                }
                if (Log.isLoggable("ManifestParser", 3)) {
                    Log.d("ManifestParser", "Got null app info metadata");
                }
            }
            catch (final PackageManager$NameNotFoundException ex) {
                throw new RuntimeException("Unable to find metadata to parse GlideModules", (Throwable)ex);
            }
            return (List)list;
        }
        if (Log.isLoggable("ManifestParser", 2)) {
            final StringBuilder sb = new StringBuilder();
            sb.append("Got app info metadata: ");
            sb.append((Object)applicationInfo.metaData);
            Log.v("ManifestParser", sb.toString());
        }
        for (final String s : ((BaseBundle)applicationInfo.metaData).keySet()) {
            if ("GlideModule".equals(((BaseBundle)applicationInfo.metaData).get(s))) {
                b(s);
                ((List)list).add((Object)null);
                if (!Log.isLoggable("ManifestParser", 3)) {
                    continue;
                }
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("Loaded Glide module: ");
                sb2.append(s);
                Log.d("ManifestParser", sb2.toString());
            }
        }
        if (Log.isLoggable("ManifestParser", 3)) {
            Log.d("ManifestParser", "Finished loading Glide modules");
        }
        return (List)list;
    }
}
