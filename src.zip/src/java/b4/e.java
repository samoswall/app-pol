package B4;

public interface e
{
    m f(final String p0);
}
