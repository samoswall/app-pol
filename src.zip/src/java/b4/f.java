package B4;

public abstract class f
{
    public static a a() {
        return (a)new B4.a.b();
    }
    
    public abstract Iterable b();
    
    public abstract byte[] c();
    
    public abstract static class a
    {
        public abstract f a();
        
        public abstract a b(final Iterable p0);
        
        public abstract a c(final byte[] p0);
    }
}
