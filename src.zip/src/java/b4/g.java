package B4;

public abstract class g
{
    public static g a() {
        return new b(a.FATAL_ERROR, -1L);
    }
    
    public static g d() {
        return new b(a.INVALID_PAYLOAD, -1L);
    }
    
    public static g e(final long n) {
        return new b(a.OK, n);
    }
    
    public static g f() {
        return new b(a.TRANSIENT_ERROR, -1L);
    }
    
    public abstract long b();
    
    public abstract a c();
    
    public enum a
    {
        private static final a[] $VALUES;
        
        FATAL_ERROR, 
        INVALID_PAYLOAD, 
        OK, 
        TRANSIENT_ERROR;
    }
}
