package B4;

import K4.a;
import android.content.Context;

public abstract class h
{
    public static h a(final Context context, final a a, final a a2, final String s) {
        return new c(context, a, a2, s);
    }
    
    public abstract Context b();
    
    public abstract String c();
    
    public abstract a d();
    
    public abstract a e();
}
