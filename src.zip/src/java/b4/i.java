package B4;

import K4.a;
import android.content.Context;

class i
{
    private final Context a;
    private final a b;
    private final a c;
    
    i(final Context a, final a b, final a c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    h a(final String s) {
        return h.a(this.a, this.b, this.c, s);
    }
}
