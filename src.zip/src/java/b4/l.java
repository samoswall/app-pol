package B4;

import android.content.Context;
import I8.a;
import C4.b;

public final class l implements b
{
    private final a a;
    private final a b;
    
    public l(final a a, final a b) {
        this.a = a;
        this.b = b;
    }
    
    public static l a(final a a, final a a2) {
        return new l(a, a2);
    }
    
    public static k c(final Context context, final Object o) {
        return new k(context, (i)o);
    }
    
    public k b() {
        return c((Context)this.a.get(), this.b.get());
    }
}
