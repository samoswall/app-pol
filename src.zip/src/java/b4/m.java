package B4;

import A4.i;

public interface m
{
    g a(final f p0);
    
    i b(final i p0);
}
