package c4;

import java.util.Iterator;
import L3.d;
import java.util.ArrayList;
import java.util.List;

public class a
{
    private final List a;
    
    public a() {
        this.a = (List)new ArrayList();
    }
    
    public void a(final Class clazz, final d d) {
        synchronized (this) {
            this.a.add((Object)new a(clazz, d));
        }
    }
    
    public d b(final Class clazz) {
        monitorenter(this);
        Label_0056: {
            try {
                Block_4: {
                    for (final a a : this.a) {
                        if (a.a(clazz)) {
                            break Block_4;
                        }
                    }
                    break Label_0056;
                }
                final a a;
                final d b = a.b;
                monitorexit(this);
                return b;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
                return null;
            }
        }
    }
    
    private static final class a
    {
        private final Class a;
        final d b;
        
        a(final Class a, final d b) {
            this.a = a;
            this.b = b;
        }
        
        boolean a(final Class cls) {
            return this.a.isAssignableFrom(cls);
        }
    }
}
