package c4;

import com.bumptech.glide.load.ImageHeaderParser;
import java.util.ArrayList;
import java.util.List;

public final class b
{
    private final List a;
    
    public b() {
        this.a = (List)new ArrayList();
    }
    
    public void a(final ImageHeaderParser imageHeaderParser) {
        synchronized (this) {
            this.a.add((Object)imageHeaderParser);
        }
    }
    
    public List b() {
        synchronized (this) {
            return this.a;
        }
    }
}
