package c4;

import androidx.collection.U;
import g4.j;
import Q1.d;
import Z3.e;
import N3.i;
import Z3.g;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicReference;
import androidx.collection.a;
import N3.t;

public class c
{
    private static final t c;
    private final a a;
    private final AtomicReference b;
    
    static {
        c = new t((Class)Object.class, (Class)Object.class, (Class)Object.class, Collections.singletonList((Object)new i((Class)Object.class, (Class)Object.class, (Class)Object.class, Collections.emptyList(), (e)new g(), (d)null)), (d)null);
    }
    
    public c() {
        this.a = new a();
        this.b = new AtomicReference();
    }
    
    private j b(final Class clazz, final Class clazz2, final Class clazz3) {
        j j;
        if ((j = (j)this.b.getAndSet((Object)null)) == null) {
            j = new j();
        }
        j.a(clazz, clazz2, clazz3);
        return j;
    }
    
    public t a(final Class clazz, final Class clazz2, final Class clazz3) {
        final j b = this.b(clazz, clazz2, clazz3);
        final a a = this.a;
        synchronized (a) {
            final t t = (t)this.a.get((Object)b);
            monitorexit(a);
            this.b.set((Object)b);
            return t;
        }
    }
    
    public boolean c(final t obj) {
        return c4.c.c.equals(obj);
    }
    
    public void d(final Class clazz, final Class clazz2, final Class clazz3, t c) {
        final a a = this.a;
        synchronized (a) {
            final a a2 = this.a;
            final j j = new j(clazz, clazz2, clazz3);
            if (c == null) {
                c = c.c;
            }
            ((U)a2).put((Object)j, (Object)c);
        }
    }
}
