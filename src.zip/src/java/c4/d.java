package c4;

import androidx.collection.U;
import g4.j;
import java.util.List;
import androidx.collection.a;
import java.util.concurrent.atomic.AtomicReference;

public class d
{
    private final AtomicReference a;
    private final a b;
    
    public d() {
        this.a = new AtomicReference();
        this.b = new a();
    }
    
    public List a(final Class clazz, final Class clazz2, final Class clazz3) {
        final j j = (j)this.a.getAndSet((Object)null);
        j i;
        if (j == null) {
            i = new j(clazz, clazz2, clazz3);
        }
        else {
            j.a(clazz, clazz2, clazz3);
            i = j;
        }
        final a b = this.b;
        synchronized (b) {
            final List list = (List)this.b.get((Object)i);
            monitorexit(b);
            this.a.set((Object)i);
            return list;
        }
    }
    
    public void b(final Class clazz, final Class clazz2, final Class clazz3, final List list) {
        final a b = this.b;
        synchronized (b) {
            ((U)this.b).put((Object)new j(clazz, clazz2, clazz3), (Object)list);
        }
    }
}
