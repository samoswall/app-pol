package c4;

import java.util.Collection;
import java.util.Iterator;
import L3.j;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;

public class e
{
    private final List a;
    private final Map b;
    
    public e() {
        this.a = (List)new ArrayList();
        this.b = (Map)new HashMap();
    }
    
    private List c(final String s) {
        monitorenter(this);
        Label_0036: {
            try {
                if (!this.a.contains((Object)s)) {
                    this.a.add((Object)s);
                }
                break Label_0036;
            }
            finally {
                monitorexit(this);
                while (true) {
                    monitorexit(this);
                    Object o = null;
                    return (List)o;
                    iftrue(Label_0076:)((o = this.b.get((Object)s)) != null);
                    o = new ArrayList();
                    this.b.put((Object)s, o);
                    continue;
                }
            }
        }
    }
    
    public void a(final String s, final j j, final Class clazz, final Class clazz2) {
        synchronized (this) {
            this.c(s).add((Object)new a(clazz, clazz2, j));
        }
    }
    
    public List b(final Class clazz, final Class clazz2) {
        monitorenter(this);
        Label_0130: {
            try {
                final ArrayList list = new ArrayList();
                final Iterator iterator = this.a.iterator();
                while (iterator.hasNext()) {
                    final List list2 = (List)this.b.get((Object)iterator.next());
                    if (list2 == null) {
                        continue;
                    }
                    for (final a a : list2) {
                        if (a.a(clazz, clazz2)) {
                            ((List)list).add((Object)a.c);
                        }
                    }
                }
                break Label_0130;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
                final ArrayList list;
                return (List)list;
            }
        }
    }
    
    public List d(final Class clazz, final Class clazz2) {
        monitorenter(this);
        Label_0145: {
            try {
                final ArrayList list = new ArrayList();
                final Iterator iterator = this.a.iterator();
                while (iterator.hasNext()) {
                    final List list2 = (List)this.b.get((Object)iterator.next());
                    if (list2 == null) {
                        continue;
                    }
                    for (final a a : list2) {
                        if (a.a(clazz, clazz2) && !((List)list).contains((Object)a.b)) {
                            ((List)list).add((Object)a.b);
                        }
                    }
                }
                break Label_0145;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
                final ArrayList list;
                return (List)list;
            }
        }
    }
    
    public void e(final List list) {
        monitorenter(this);
        Label_0073: {
            try {
                final ArrayList list2 = new ArrayList((Collection)this.a);
                this.a.clear();
                final Iterator iterator = list.iterator();
                while (iterator.hasNext()) {
                    this.a.add((Object)iterator.next());
                }
                break Label_0073;
            }
            finally {
                monitorexit(this);
                while (true) {
                    final Iterator iterator2;
                    final String s = (String)iterator2.next();
                    iftrue(Label_0080:)(list.contains((Object)s));
                    Label_0080: {
                        Block_6: {
                            break Block_6;
                            Label_0123: {
                                monitorexit(this);
                            }
                            return;
                            final ArrayList list2;
                            iterator2 = ((List)list2).iterator();
                            break Label_0080;
                        }
                        this.a.add((Object)s);
                    }
                    iftrue(Label_0123:)(!iterator2.hasNext());
                    continue;
                }
            }
        }
    }
    
    private static class a
    {
        private final Class a;
        final Class b;
        final j c;
        
        public a(final Class a, final Class b, final j c) {
            this.a = a;
            this.b = b;
            this.c = c;
        }
        
        public boolean a(final Class cls, final Class clazz) {
            return this.a.isAssignableFrom(cls) && clazz.isAssignableFrom(this.b);
        }
    }
}
