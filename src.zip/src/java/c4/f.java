package c4;

import L3.k;
import java.util.ArrayList;
import java.util.List;

public class f
{
    private final List a;
    
    public f() {
        this.a = (List)new ArrayList();
    }
    
    public void a(final Class clazz, final k k) {
        synchronized (this) {
            this.a.add((Object)new a(clazz, k));
        }
    }
    
    public k b(final Class clazz) {
        monitorenter(this);
        while (true) {
            Label_0061: {
                try {
                    final int size = this.a.size();
                    final int n = 0;
                    if (n >= size) {
                        break Label_0061;
                    }
                    final a a = (a)this.a.get(n);
                    if (a.a(clazz)) {
                        final k b = a.b;
                        monitorexit(this);
                        return b;
                    }
                    break Label_0061;
                }
                finally {
                    monitorexit(this);
                    int n = 0;
                    ++n;
                    continue;
                    monitorexit(this);
                    return null;
                }
            }
            break;
        }
    }
    
    private static final class a
    {
        private final Class a;
        final k b;
        
        a(final Class a, final k b) {
            this.a = a;
            this.b = b;
        }
        
        boolean a(final Class cls) {
            return this.a.isAssignableFrom(cls);
        }
    }
}
