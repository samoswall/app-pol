package com.auth0.android.jwt;

import com.google.gson.GsonBuilder;
import com.google.gson.Gson;
import java.lang.reflect.Type;
import com.google.gson.reflect.TypeToken;
import java.nio.charset.Charset;
import android.util.Base64;
import android.os.Parcel;
import java.util.Map;
import android.os.Parcelable$Creator;
import android.os.Parcelable;

public class JWT implements Parcelable
{
    public static final Parcelable$Creator<JWT> CREATOR;
    private final String a;
    private Map b;
    private e c;
    private String d;
    
    static {
        CREATOR = (Parcelable$Creator)new Parcelable$Creator() {
            public JWT a(final Parcel parcel) {
                return new JWT(parcel.readString());
            }
            
            public JWT[] b(final int n) {
                return new JWT[n];
            }
        };
    }
    
    public JWT(final String a) {
        this.d(a);
        this.a = a;
    }
    
    private String a(String s) {
        try {
            s = new String(Base64.decode(s, 11), Charset.defaultCharset());
            return s;
        }
        catch (final IllegalArgumentException ex) {
            throw new d("Received bytes didn't correspond to a valid Base64 encoded string.", (Throwable)ex);
        }
    }
    
    private void d(final String s) {
        final String[] h = this.h(s);
        this.b = (Map)this.g(this.a(h[0]), new TypeToken<Map<String, String>>(this) {
            final JWT d;
        }.getType());
        this.c = (e)this.g(this.a(h[1]), (Type)e.class);
        this.d = h[2];
    }
    
    static Gson f() {
        return new GsonBuilder().registerTypeAdapter((Type)e.class, (Object)new JWTDeserializer()).create();
    }
    
    private Object g(final String s, final Type type) {
        try {
            return f().fromJson(s, type);
        }
        catch (final Exception ex) {
            throw new d("The token's payload had an invalid JSON format.", (Throwable)ex);
        }
    }
    
    private String[] h(final String s) {
        String[] split;
        final String[] array = split = s.split("\\.");
        if (array.length == 2) {
            split = array;
            if (s.endsWith(".")) {
                split = new String[] { array[0], array[1], "" };
            }
        }
        if (split.length == 3) {
            return split;
        }
        throw new d(String.format("The token was expected to have 3 parts, but got %s.", new Object[] { split.length }));
    }
    
    public int describeContents() {
        return 0;
    }
    
    public Map e() {
        return this.c.h;
    }
    
    @Override
    public String toString() {
        return this.a;
    }
    
    public void writeToParcel(final Parcel parcel, final int n) {
        parcel.writeString(this.a);
    }
}
