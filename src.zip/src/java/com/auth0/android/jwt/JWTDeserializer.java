package com.auth0.android.jwt;

import java.util.Iterator;
import java.util.Map;
import java.util.Map$Entry;
import java.util.HashMap;
import com.google.gson.JsonDeserializationContext;
import java.lang.reflect.Type;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Date;
import com.google.gson.JsonObject;
import com.google.gson.JsonDeserializer;

class JWTDeserializer implements JsonDeserializer<e>
{
    private Date b(final JsonObject jsonObject, final String s) {
        if (!jsonObject.has(s)) {
            return null;
        }
        return new Date(jsonObject.get(s).getAsLong() * 1000L);
    }
    
    private String c(final JsonObject jsonObject, final String s) {
        if (!jsonObject.has(s)) {
            return null;
        }
        return jsonObject.get(s).getAsString();
    }
    
    private List d(final JsonObject jsonObject, final String s) {
        Object o = Collections.emptyList();
        if (jsonObject.has(s)) {
            final JsonElement value = jsonObject.get(s);
            if (value.isJsonArray()) {
                final JsonArray asJsonArray = value.getAsJsonArray();
                o = new ArrayList(asJsonArray.size());
                for (int i = 0; i < asJsonArray.size(); ++i) {
                    ((List)o).add((Object)asJsonArray.get(i).getAsString());
                }
            }
            else {
                o = Collections.singletonList((Object)value.getAsString());
            }
        }
        return (List)o;
    }
    
    public e a(final JsonElement jsonElement, final Type type, final JsonDeserializationContext jsonDeserializationContext) {
        if (!jsonElement.isJsonNull() && jsonElement.isJsonObject()) {
            final JsonObject asJsonObject = jsonElement.getAsJsonObject();
            final String c = this.c(asJsonObject, "iss");
            final String c2 = this.c(asJsonObject, "sub");
            final Date b = this.b(asJsonObject, "exp");
            final Date b2 = this.b(asJsonObject, "nbf");
            final Date b3 = this.b(asJsonObject, "iat");
            final String c3 = this.c(asJsonObject, "jti");
            final List d = this.d(asJsonObject, "aud");
            final HashMap hashMap = new HashMap();
            for (final Map$Entry map$Entry : asJsonObject.entrySet()) {
                ((Map)hashMap).put(map$Entry.getKey(), (Object)new c((JsonElement)map$Entry.getValue()));
            }
            return new e(c, c2, b, b2, b3, c3, d, (Map)hashMap);
        }
        throw new d("The token's payload had an invalid JSON format.");
    }
}
