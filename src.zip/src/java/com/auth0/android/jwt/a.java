package com.auth0.android.jwt;

abstract class a implements b
{
}
