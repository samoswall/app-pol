package com.auth0.android.jwt;

import java.util.List;

public interface b
{
    List a(final Class p0);
    
    String b();
    
    Boolean c();
}
