package com.auth0.android.jwt;

import com.google.gson.JsonArray;
import com.google.gson.JsonSyntaxException;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.JsonElement;

class c extends a
{
    private final JsonElement a;
    
    c(final JsonElement a) {
        this.a = a;
    }
    
    @Override
    public List a(final Class clazz) {
        ArrayList list;
        try {
            if (!this.a.isJsonArray() || this.a.isJsonNull()) {
                return (List)new ArrayList();
            }
            final Gson gson = new Gson();
            final JsonArray asJsonArray = this.a.getAsJsonArray();
            list = new ArrayList();
            for (int i = 0; i < asJsonArray.size(); ++i) {
                ((List)list).add(gson.fromJson(asJsonArray.get(i), clazz));
            }
        }
        catch (final JsonSyntaxException ex) {
            throw new d("Failed to decode claim as list", (Throwable)ex);
        }
        return (List)list;
    }
    
    @Override
    public String b() {
        if (!this.a.isJsonPrimitive()) {
            return null;
        }
        return this.a.getAsString();
    }
    
    @Override
    public Boolean c() {
        if (!this.a.isJsonPrimitive()) {
            return null;
        }
        return this.a.getAsBoolean();
    }
}
