package com.auth0.android.jwt;

public class d extends RuntimeException
{
    d(final String s) {
        super(s);
    }
    
    d(final String s, final Throwable t) {
        super(s, t);
    }
}
