package com.auth0.android.jwt;

import java.util.Collections;
import java.util.Map;
import java.util.List;
import java.util.Date;

class e
{
    final String a;
    final String b;
    final Date c;
    final Date d;
    final Date e;
    final String f;
    final List g;
    final Map h;
    
    e(final String a, final String b, final Date c, final Date d, final Date e, final String f, final List g, final Map map) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = Collections.unmodifiableMap(map);
    }
}
