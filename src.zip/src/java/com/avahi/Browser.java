package com.avahi;

import java.net.InetAddress;
import java.io.IOException;
import android.net.wifi.WifiManager;
import android.content.Context;
import android.net.wifi.WifiManager$MulticastLock;
import androidx.annotation.Keep;

@Keep
public final class Browser extends Resolver
{
    private static final String TAG = "Avahi";
    private WifiManager$MulticastLock multicastLock;
    
    static {
        System.loadLibrary("avahi");
    }
    
    public Browser(final Context context) throws IOException {
        super(_setup());
        if (super._native != 0L) {
            final WifiManager$MulticastLock multicastLock = ((WifiManager)context.getSystemService("wifi")).createMulticastLock("Avahi");
            this.multicastLock = multicastLock;
            if (!multicastLock.isHeld()) {
                multicastLock.setReferenceCounted(true);
                multicastLock.acquire();
            }
            return;
        }
        throw new IOException();
    }
    
    @Keep
    private native void _close();
    
    @Keep
    private static native long _setup();
    
    @Keep
    public native Resolver browse(final String p0, final String p1, final BrowseCallback p2);
    
    @Override
    public void close() {
        final WifiManager$MulticastLock multicastLock = this.multicastLock;
        if (multicastLock != null && multicastLock.isHeld()) {
            this.multicastLock.release();
        }
        this.multicastLock = null;
        this._close();
    }
    
    @Keep
    public native Resolver resolve(final Service p0, final ServiceResolveCallback p1);
    
    @Keep
    public native Resolver resolve(final String p0, final AddressType p1, final AddressResolveCallback p2);
    
    @Keep
    public interface AddressResolveCallback
    {
        void onAddressFailed(final String p0, final AddressType p1, final int p2);
        
        void onAddressResolved(final String p0, final InetAddress p1);
    }
    
    @Keep
    public enum AddressType
    {
        private static final AddressType[] $VALUES;
        
        V4, 
        V6;
        
        private static /* synthetic */ AddressType[] $values() {
            return new AddressType[] { AddressType.V4, AddressType.V6 };
        }
        
        static {
            $VALUES = $values();
        }
    }
    
    @Keep
    private static final class AvahiAddressResolver extends Resolver
    {
        private AvahiAddressResolver(final long n) {
            super(n);
        }
        
        @Override
        public native void close();
    }
    
    @Keep
    private static final class AvahiBrowseResolver extends Resolver
    {
        private AvahiBrowseResolver(final long n) {
            super(n);
        }
        
        @Override
        public native void close();
    }
    
    @Keep
    private static final class AvahiServiceResolver extends Resolver
    {
        private AvahiServiceResolver(final long n) {
            super(n);
        }
        
        @Override
        public native void close();
    }
    
    @Keep
    public interface BrowseCallback
    {
        void onAllForNow(final String p0, final String p1);
        
        void onBrowseFailed(final String p0, final String p1, final int p2);
        
        void onCacheExhausted(final String p0, final String p1);
        
        void onServiceFound(final Service p0);
        
        void onServiceLost(final Service p0);
    }
    
    @Keep
    public static class Service
    {
        final String domain;
        final String name;
        final String type;
        
        Service(final String name, final String type, final String domain) {
            this.name = name;
            this.type = type;
            this.domain = domain;
        }
        
        public String getDomain() {
            return this.domain;
        }
        
        public String getName() {
            return this.name;
        }
        
        public String getType() {
            return this.type;
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append("Service{name='");
            sb.append(this.name);
            sb.append('\'');
            sb.append(", type='");
            sb.append(this.type);
            sb.append('\'');
            sb.append(", domain='");
            sb.append(this.domain);
            sb.append('\'');
            sb.append('}');
            return sb.toString();
        }
    }
    
    @Keep
    public interface ServiceResolveCallback
    {
        void onServiceFailed(final Service p0, final int p1);
        
        void onServiceResolved(final Service p0, final String p1, final int p2, final byte[][] p3);
    }
}
