package com.avahi;

public abstract class Resolver
{
    final long _native;
    
    Resolver(final long native1) {
        this._native = native1;
    }
    
    public abstract void close();
    
    @Override
    protected void finalize() {
        this.close();
    }
}
