package com.github.mikephil.charting.charts;

import android.view.View$OnTouchListener;
import android.view.MotionEvent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint$Style;
import q4.e;
import s4.g;
import j4.h$a;
import j4.h;
import android.util.Log;
import j4.i$a;
import android.view.View;
import android.content.Context;
import android.graphics.Matrix;
import android.graphics.RectF;
import s4.f;
import r4.j;
import j4.i;
import android.graphics.Paint;
import s4.c;

public abstract class a extends b implements n4.a
{
    protected float[] A0;
    protected c B0;
    protected c C0;
    protected float[] D0;
    protected int M;
    protected boolean Q;
    protected boolean W;
    protected boolean a0;
    protected boolean b0;
    private boolean c0;
    private boolean d0;
    private boolean e0;
    private boolean f0;
    protected Paint g0;
    protected Paint h0;
    protected boolean i0;
    protected boolean j0;
    protected boolean k0;
    protected float l0;
    protected boolean m0;
    protected i n0;
    protected i o0;
    protected j p0;
    protected j q0;
    protected f r0;
    protected f s0;
    protected r4.i t0;
    private long u0;
    private long v0;
    private RectF w0;
    protected Matrix x0;
    protected Matrix y0;
    private boolean z0;
    
    public a(final Context context) {
        super(context);
        this.M = 100;
        this.Q = false;
        this.W = false;
        this.a0 = true;
        this.b0 = true;
        this.c0 = true;
        this.d0 = true;
        this.e0 = true;
        this.f0 = true;
        this.i0 = false;
        this.j0 = false;
        this.k0 = false;
        this.l0 = 15.0f;
        this.m0 = false;
        this.u0 = 0L;
        this.v0 = 0L;
        this.w0 = new RectF();
        this.x0 = new Matrix();
        this.y0 = new Matrix();
        this.z0 = false;
        this.A0 = new float[2];
        this.B0 = s4.c.b(0.0, 0.0);
        this.C0 = s4.c.b(0.0, 0.0);
        this.D0 = new float[2];
    }
    
    public void A() {
        final Matrix y0 = this.y0;
        super.s.l(y0);
        super.s.K(y0, (View)this, false);
        this.c();
        ((View)this).postInvalidate();
    }
    
    public i B(final i$a i$a) {
        if (i$a == i$a.LEFT) {
            return this.n0;
        }
        return this.o0;
    }
    
    public o4.a C(final float n, final float n2) {
        final m4.b h = this.h(n, n2);
        if (h != null) {
            return (o4.a)((k4.h)super.b).e(h.c());
        }
        return null;
    }
    
    public boolean D() {
        return super.s.u();
    }
    
    public boolean E() {
        return this.n0.c0() || this.o0.c0();
    }
    
    public boolean F() {
        return this.k0;
    }
    
    public boolean G() {
        return this.a0;
    }
    
    public boolean H() {
        return this.c0 || this.d0;
    }
    
    public boolean I() {
        return this.c0;
    }
    
    public boolean J() {
        return this.d0;
    }
    
    public boolean K() {
        return super.s.v();
    }
    
    public boolean L() {
        return this.b0;
    }
    
    public boolean M(final i$a i$a) {
        return this.B(i$a).c0();
    }
    
    public boolean N() {
        return this.W;
    }
    
    public boolean O() {
        return this.e0;
    }
    
    public boolean P() {
        return this.f0;
    }
    
    public void Q(final float n) {
        this.b((Runnable)p4.a.b(super.s, n, 0.0f, this.a(i$a.LEFT), (View)this));
    }
    
    protected void R() {
        this.s0.i(this.o0.c0());
        this.r0.i(this.n0.c0());
    }
    
    protected void S() {
        if (super.a) {
            final StringBuilder sb = new StringBuilder();
            sb.append("Preparing Value-Px Matrix, xmin: ");
            sb.append(((j4.a)super.i).H);
            sb.append(", xmax: ");
            sb.append(((j4.a)super.i).G);
            sb.append(", xdelta: ");
            sb.append(((j4.a)super.i).I);
            Log.i("MPAndroidChart", sb.toString());
        }
        final f s0 = this.s0;
        final h i = super.i;
        final float h = ((j4.a)i).H;
        final float j = ((j4.a)i).I;
        final i o0 = this.o0;
        s0.j(h, j, ((j4.a)o0).I, ((j4.a)o0).H);
        final f r0 = this.r0;
        final h k = super.i;
        final float h2 = ((j4.a)k).H;
        final float l = ((j4.a)k).I;
        final i n0 = this.n0;
        r0.j(h2, l, ((j4.a)n0).I, ((j4.a)n0).H);
    }
    
    public void T(final float n, final float n2, final float n3, final float n4) {
        super.s.R(n, n2, n3, -n4, this.x0);
        super.s.K(this.x0, (View)this, false);
        this.c();
        ((View)this).postInvalidate();
    }
    
    @Override
    public f a(final i$a i$a) {
        if (i$a == i$a.LEFT) {
            return this.r0;
        }
        return this.s0;
    }
    
    public void c() {
        if (!this.z0) {
            this.y(this.w0);
            final RectF w0 = this.w0;
            final float n = w0.left + 0.0f;
            final float n2 = w0.top + 0.0f;
            final float n3 = w0.right + 0.0f;
            final float n4 = w0.bottom + 0.0f;
            float n5 = n;
            if (this.n0.d0()) {
                n5 = n + this.n0.U(((r4.a)this.p0).c());
            }
            float n6 = n3;
            if (this.o0.d0()) {
                n6 = n3 + this.o0.U(((r4.a)this.q0).c());
            }
            float n7 = n4;
            float n8 = n2;
            Label_0248: {
                if (((j4.b)super.i).f()) {
                    n7 = n4;
                    n8 = n2;
                    if (((j4.a)super.i).B()) {
                        final h i = super.i;
                        final float n9 = i.M + ((j4.b)i).e();
                        if (super.i.R() == h$a.BOTTOM) {
                            n7 = n4 + n9;
                            n8 = n2;
                        }
                        else {
                            if (super.i.R() == h$a.TOP) {
                                n7 = n4;
                            }
                            else {
                                n7 = n4;
                                n8 = n2;
                                if (super.i.R() != h$a.BOTH_SIDED) {
                                    break Label_0248;
                                }
                                n7 = n4 + n9;
                            }
                            n8 = n2 + n9;
                        }
                    }
                }
            }
            final float n10 = n8 + this.getExtraTopOffset();
            final float n11 = n6 + this.getExtraRightOffset();
            final float n12 = n7 + this.getExtraBottomOffset();
            final float n13 = n5 + this.getExtraLeftOffset();
            final float e = s4.g.e(this.l0);
            super.s.L(Math.max(e, n13), Math.max(e, n10), Math.max(e, n11), Math.max(e, n12));
            if (super.a) {
                final StringBuilder sb = new StringBuilder();
                sb.append("offsetLeft: ");
                sb.append(n13);
                sb.append(", offsetTop: ");
                sb.append(n10);
                sb.append(", offsetRight: ");
                sb.append(n11);
                sb.append(", offsetBottom: ");
                sb.append(n12);
                Log.i("MPAndroidChart", sb.toString());
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("Content: ");
                sb2.append(super.s.p().toString());
                Log.i("MPAndroidChart", sb2.toString());
            }
        }
        this.R();
        this.S();
    }
    
    public void computeScroll() {
        final q4.b n = super.n;
        if (n instanceof q4.a) {
            ((q4.a)n).f();
        }
    }
    
    public i getAxisLeft() {
        return this.n0;
    }
    
    public i getAxisRight() {
        return this.o0;
    }
    
    public e getDrawListener() {
        return null;
    }
    
    @Override
    public float getHighestVisibleX() {
        this.a(i$a.LEFT).e(super.s.i(), super.s.f(), this.C0);
        return (float)Math.min((double)((j4.a)super.i).G, this.C0.c);
    }
    
    @Override
    public float getLowestVisibleX() {
        this.a(i$a.LEFT).e(super.s.h(), super.s.f(), this.B0);
        return (float)Math.max((double)((j4.a)super.i).H, this.B0.c);
    }
    
    @Override
    public int getMaxVisibleCount() {
        return this.M;
    }
    
    public float getMinOffset() {
        return this.l0;
    }
    
    public j getRendererLeftYAxis() {
        return this.p0;
    }
    
    public j getRendererRightYAxis() {
        return this.q0;
    }
    
    public r4.i getRendererXAxis() {
        return this.t0;
    }
    
    public float getScaleX() {
        final s4.h s = super.s;
        if (s == null) {
            return 1.0f;
        }
        return s.r();
    }
    
    public float getScaleY() {
        final s4.h s = super.s;
        if (s == null) {
            return 1.0f;
        }
        return s.s();
    }
    
    public float getVisibleXRange() {
        return Math.abs(this.getHighestVisibleX() - this.getLowestVisibleX());
    }
    
    @Override
    public float getYChartMax() {
        return Math.max(((j4.a)this.n0).G, ((j4.a)this.o0).G);
    }
    
    @Override
    public float getYChartMin() {
        return Math.min(((j4.a)this.n0).H, ((j4.a)this.o0).H);
    }
    
    @Override
    protected void n() {
        super.n();
        this.n0 = new i(i$a.LEFT);
        this.o0 = new i(i$a.RIGHT);
        this.r0 = new f(super.s);
        this.s0 = new f(super.s);
        this.p0 = new j(super.s, this.n0, this.r0);
        this.q0 = new j(super.s, this.o0, this.s0);
        this.t0 = new r4.i(super.s, super.i, this.r0);
        this.setHighlighter(new m4.a((n4.a)this));
        super.n = (q4.b)new q4.a(this, super.s.q(), 3.0f);
        (this.g0 = new Paint()).setStyle(Paint$Style.FILL);
        this.g0.setColor(Color.rgb(240, 240, 240));
        (this.h0 = new Paint()).setStyle(Paint$Style.STROKE);
        this.h0.setColor(-16777216);
        this.h0.setStrokeWidth(s4.g.e(1.0f));
    }
    
    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        if (super.b == null) {
            return;
        }
        final long currentTimeMillis = System.currentTimeMillis();
        this.z(canvas);
        if (this.Q) {
            this.w();
        }
        if (((j4.b)this.n0).f()) {
            final j p = this.p0;
            final i n0 = this.n0;
            ((r4.a)p).a(((j4.a)n0).H, ((j4.a)n0).G, n0.c0());
        }
        if (((j4.b)this.o0).f()) {
            final j q0 = this.q0;
            final i o0 = this.o0;
            ((r4.a)q0).a(((j4.a)o0).H, ((j4.a)o0).G, o0.c0());
        }
        if (((j4.b)super.i).f()) {
            final r4.i t0 = this.t0;
            final h i = super.i;
            t0.a(((j4.a)i).H, ((j4.a)i).G, false);
        }
        this.t0.j(canvas);
        this.p0.j(canvas);
        this.q0.j(canvas);
        if (((j4.a)super.i).z()) {
            this.t0.k(canvas);
        }
        if (((j4.a)this.n0).z()) {
            this.p0.k(canvas);
        }
        if (((j4.a)this.o0).z()) {
            this.q0.k(canvas);
        }
        if (((j4.b)super.i).f() && ((j4.a)super.i).C()) {
            this.t0.l(canvas);
        }
        if (((j4.b)this.n0).f() && ((j4.a)this.n0).C()) {
            this.p0.l(canvas);
        }
        if (((j4.b)this.o0).f() && ((j4.a)this.o0).C()) {
            this.q0.l(canvas);
        }
        final int save = canvas.save();
        canvas.clipRect(super.s.p());
        super.q.b(canvas);
        if (!((j4.a)super.i).z()) {
            this.t0.k(canvas);
        }
        if (!((j4.a)this.n0).z()) {
            this.p0.k(canvas);
        }
        if (!((j4.a)this.o0).z()) {
            this.q0.k(canvas);
        }
        if (this.v()) {
            super.q.d(canvas, super.z);
        }
        canvas.restoreToCount(save);
        super.q.c(canvas);
        if (((j4.b)super.i).f() && !((j4.a)super.i).C()) {
            this.t0.l(canvas);
        }
        if (((j4.b)this.n0).f() && !((j4.a)this.n0).C()) {
            this.p0.l(canvas);
        }
        if (((j4.b)this.o0).f() && !((j4.a)this.o0).C()) {
            this.q0.l(canvas);
        }
        this.t0.i(canvas);
        this.p0.i(canvas);
        this.q0.i(canvas);
        if (this.F()) {
            final int save2 = canvas.save();
            canvas.clipRect(super.s.p());
            super.q.e(canvas);
            canvas.restoreToCount(save2);
        }
        else {
            super.q.e(canvas);
        }
        super.p.d(canvas);
        this.e(canvas);
        this.f(canvas);
        if (super.a) {
            final long n2 = System.currentTimeMillis() - currentTimeMillis;
            final long u0 = this.u0 + n2;
            this.u0 = u0;
            final long v0 = this.v0 + 1L;
            this.v0 = v0;
            final long n3 = u0 / v0;
            final StringBuilder sb = new StringBuilder();
            sb.append("Drawtime: ");
            sb.append(n2);
            sb.append(" ms, average: ");
            sb.append(n3);
            sb.append(" ms, cycles: ");
            sb.append(this.v0);
            Log.i("MPAndroidChart", sb.toString());
        }
    }
    
    @Override
    protected void onSizeChanged(final int n, final int n2, final int n3, final int n4) {
        final float[] d0 = this.D0;
        d0[0] = (d0[1] = 0.0f);
        if (this.m0) {
            d0[0] = super.s.h();
            this.D0[1] = super.s.j();
            this.a(i$a.LEFT).g(this.D0);
        }
        super.onSizeChanged(n, n2, n3, n4);
        if (this.m0) {
            this.a(i$a.LEFT).h(this.D0);
            super.s.e(this.D0, (View)this);
        }
        else {
            final s4.h s = super.s;
            s.K(s.q(), (View)this, true);
        }
    }
    
    public boolean onTouchEvent(final MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        final q4.b n = super.n;
        return n != null && super.b != null && super.j && ((View$OnTouchListener)n).onTouch((View)this, motionEvent);
    }
    
    @Override
    public void s() {
        if (super.b == null) {
            if (super.a) {
                Log.i("MPAndroidChart", "Preparing... DATA NOT SET.");
            }
            return;
        }
        if (super.a) {
            Log.i("MPAndroidChart", "Preparing...");
        }
        final r4.c q = super.q;
        if (q != null) {
            q.f();
        }
        this.x();
        final j p0 = this.p0;
        final i n0 = this.n0;
        ((r4.a)p0).a(((j4.a)n0).H, ((j4.a)n0).G, n0.c0());
        final j q2 = this.q0;
        final i o0 = this.o0;
        ((r4.a)q2).a(((j4.a)o0).H, ((j4.a)o0).G, o0.c0());
        final r4.i t0 = this.t0;
        final h i = super.i;
        t0.a(((j4.a)i).H, ((j4.a)i).G, false);
        if (super.l != null) {
            super.p.a(super.b);
        }
        this.c();
    }
    
    public void setAutoScaleMinMaxEnabled(final boolean q) {
        this.Q = q;
    }
    
    public void setBorderColor(final int color) {
        this.h0.setColor(color);
    }
    
    public void setBorderWidth(final float n) {
        this.h0.setStrokeWidth(s4.g.e(n));
    }
    
    public void setClipValuesToContent(final boolean k0) {
        this.k0 = k0;
    }
    
    public void setDoubleTapToZoomEnabled(final boolean a0) {
        this.a0 = a0;
    }
    
    public void setDragEnabled(final boolean b) {
        this.c0 = b;
        this.d0 = b;
    }
    
    public void setDragOffsetX(final float n) {
        super.s.N(n);
    }
    
    public void setDragOffsetY(final float n) {
        super.s.O(n);
    }
    
    public void setDragXEnabled(final boolean c0) {
        this.c0 = c0;
    }
    
    public void setDragYEnabled(final boolean d0) {
        this.d0 = d0;
    }
    
    public void setDrawBorders(final boolean j0) {
        this.j0 = j0;
    }
    
    public void setDrawGridBackground(final boolean i0) {
        this.i0 = i0;
    }
    
    public void setGridBackgroundColor(final int color) {
        this.g0.setColor(color);
    }
    
    public void setHighlightPerDragEnabled(final boolean b0) {
        this.b0 = b0;
    }
    
    public void setKeepPositionOnRotation(final boolean m0) {
        this.m0 = m0;
    }
    
    public void setMaxVisibleValueCount(final int m) {
        this.M = m;
    }
    
    public void setMinOffset(final float l0) {
        this.l0 = l0;
    }
    
    public void setOnDrawListener(final e e) {
    }
    
    public void setPinchZoom(final boolean w) {
        this.W = w;
    }
    
    public void setRendererLeftYAxis(final j p) {
        this.p0 = p;
    }
    
    public void setRendererRightYAxis(final j q0) {
        this.q0 = q0;
    }
    
    public void setScaleEnabled(final boolean b) {
        this.e0 = b;
        this.f0 = b;
    }
    
    public void setScaleXEnabled(final boolean e0) {
        this.e0 = e0;
    }
    
    public void setScaleYEnabled(final boolean f0) {
        this.f0 = f0;
    }
    
    public void setVisibleXRangeMaximum(float n) {
        n = ((j4.a)super.i).I / n;
        super.s.Q(n);
    }
    
    public void setVisibleXRangeMinimum(float n) {
        n = ((j4.a)super.i).I / n;
        super.s.P(n);
    }
    
    public void setXAxisRenderer(final r4.i t0) {
        this.t0 = t0;
    }
    
    protected void w() {
        ((k4.h)super.b).d(this.getLowestVisibleX(), this.getHighestVisibleX());
        ((j4.a)super.i).j(((k4.h)super.b).p(), ((k4.h)super.b).o());
        if (((j4.b)this.n0).f()) {
            final i n0 = this.n0;
            final k4.b b = (k4.b)super.b;
            final i$a left = i$a.LEFT;
            n0.j(((k4.h)b).t(left), ((k4.h)super.b).r(left));
        }
        if (((j4.b)this.o0).f()) {
            final i o0 = this.o0;
            final k4.b b2 = (k4.b)super.b;
            final i$a right = i$a.RIGHT;
            o0.j(((k4.h)b2).t(right), ((k4.h)super.b).r(right));
        }
        this.c();
    }
    
    protected void x() {
        ((j4.a)super.i).j(((k4.h)super.b).p(), ((k4.h)super.b).o());
        final i n0 = this.n0;
        final k4.b b = (k4.b)super.b;
        final i$a left = i$a.LEFT;
        n0.j(((k4.h)b).t(left), ((k4.h)super.b).r(left));
        final i o0 = this.o0;
        final k4.b b2 = (k4.b)super.b;
        final i$a right = i$a.RIGHT;
        o0.j(((k4.h)b2).t(right), ((k4.h)super.b).r(right));
    }
    
    protected void y(final RectF rectF) {
        rectF.left = 0.0f;
        rectF.right = 0.0f;
        rectF.top = 0.0f;
        rectF.bottom = 0.0f;
        final j4.e l = super.l;
        if (l != null && ((j4.b)l).f() && !super.l.E()) {
            final int n = a$a.c[((Enum)super.l.z()).ordinal()];
            if (n != 1) {
                if (n == 2) {
                    final int n2 = a$a.a[((Enum)super.l.B()).ordinal()];
                    if (n2 != 1) {
                        if (n2 == 2) {
                            rectF.bottom += Math.min(super.l.y, super.s.m() * super.l.w()) + ((j4.b)super.l).e();
                        }
                    }
                    else {
                        rectF.top += Math.min(super.l.y, super.s.m() * super.l.w()) + ((j4.b)super.l).e();
                    }
                }
            }
            else {
                final int n3 = a$a.b[((Enum)super.l.v()).ordinal()];
                if (n3 != 1) {
                    if (n3 != 2) {
                        if (n3 == 3) {
                            final int n4 = a$a.a[((Enum)super.l.B()).ordinal()];
                            if (n4 != 1) {
                                if (n4 == 2) {
                                    rectF.bottom += Math.min(super.l.y, super.s.m() * super.l.w()) + ((j4.b)super.l).e();
                                }
                            }
                            else {
                                rectF.top += Math.min(super.l.y, super.s.m() * super.l.w()) + ((j4.b)super.l).e();
                            }
                        }
                    }
                    else {
                        rectF.right += Math.min(super.l.x, super.s.n() * super.l.w()) + ((j4.b)super.l).d();
                    }
                }
                else {
                    rectF.left += Math.min(super.l.x, super.s.n() * super.l.w()) + ((j4.b)super.l).d();
                }
            }
        }
    }
    
    protected void z(final Canvas canvas) {
        if (this.i0) {
            canvas.drawRect(super.s.p(), this.g0);
        }
        if (this.j0) {
            canvas.drawRect(super.s.p(), this.h0);
        }
    }
}
