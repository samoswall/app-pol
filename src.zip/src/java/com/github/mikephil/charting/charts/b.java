package com.github.mikephil.charting.charts;

import android.graphics.Typeface;
import java.util.Iterator;
import android.text.TextUtils;
import android.graphics.Paint$Align;
import android.graphics.Color;
import s4.g;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator$AnimatorUpdateListener;
import android.util.Log;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.Bitmap$Config;
import android.graphics.Bitmap;
import k4.j;
import android.graphics.Canvas;
import android.view.ViewParent;
import android.graphics.drawable.Drawable$Callback;
import android.view.View;
import android.content.Context;
import i4.a;
import j4.e;
import android.graphics.Paint;
import l4.c;
import k4.h;
import java.util.ArrayList;
import j4.d;
import android.view.ViewGroup;

public abstract class b extends ViewGroup implements n4.b
{
    protected float A;
    protected boolean B;
    protected d C;
    protected ArrayList H;
    private boolean L;
    protected boolean a;
    protected h b;
    protected boolean c;
    private boolean d;
    private float e;
    protected c f;
    protected Paint g;
    protected Paint h;
    protected j4.h i;
    protected boolean j;
    protected j4.c k;
    protected e l;
    protected q4.d m;
    protected q4.b n;
    private String o;
    protected r4.d p;
    protected r4.c q;
    protected m4.c r;
    protected s4.h s;
    protected a t;
    private float u;
    private float v;
    private float w;
    private float x;
    private boolean y;
    protected m4.b[] z;
    
    public b(final Context context) {
        super(context);
        this.a = false;
        this.b = null;
        this.c = true;
        this.d = true;
        this.e = 0.9f;
        this.f = new c(0);
        this.j = true;
        this.o = "No chart data available.";
        this.s = new s4.h();
        this.u = 0.0f;
        this.v = 0.0f;
        this.w = 0.0f;
        this.x = 0.0f;
        this.y = false;
        this.A = 0.0f;
        this.B = true;
        this.H = new ArrayList();
        this.L = false;
        this.n();
    }
    
    private void u(final View view) {
        if (view.getBackground() != null) {
            view.getBackground().setCallback((Drawable$Callback)null);
        }
        if (view instanceof ViewGroup) {
            int n = 0;
            ViewGroup viewGroup;
            while (true) {
                viewGroup = (ViewGroup)view;
                if (n >= viewGroup.getChildCount()) {
                    break;
                }
                this.u(viewGroup.getChildAt(n));
                ++n;
            }
            viewGroup.removeAllViews();
        }
    }
    
    public void b(final Runnable runnable) {
        if (this.s.t()) {
            ((View)this).post(runnable);
        }
        else {
            this.H.add((Object)runnable);
        }
    }
    
    protected abstract void c();
    
    public void d() {
        final ViewParent parent = ((View)this).getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(true);
        }
    }
    
    protected void e(final Canvas canvas) {
        final j4.c k = this.k;
        if (k != null && ((j4.b)k).f()) {
            final s4.d j = this.k.j();
            this.g.setTypeface(((j4.b)this.k).c());
            this.g.setTextSize(((j4.b)this.k).b());
            this.g.setColor(((j4.b)this.k).a());
            this.g.setTextAlign(this.k.l());
            float c;
            float d;
            if (j == null) {
                c = ((View)this).getWidth() - this.s.I() - ((j4.b)this.k).d();
                d = ((View)this).getHeight() - this.s.G() - ((j4.b)this.k).e();
            }
            else {
                c = j.c;
                d = j.d;
            }
            canvas.drawText(this.k.k(), c, d, this.g);
        }
    }
    
    protected void f(final Canvas canvas) {
        if (this.C != null && this.p()) {
            if (this.v()) {
                int n = 0;
                while (true) {
                    final m4.b[] z = this.z;
                    if (n >= z.length) {
                        break;
                    }
                    final m4.b b = z[n];
                    final o4.b e = this.b.e(b.c());
                    final j k = this.b.k(this.z[n]);
                    final int f = e.f(k);
                    if (k != null) {
                        if (f <= e.Q() * this.t.a()) {
                            final float[] i = this.i(b);
                            if (this.s.y(i[0], i[1])) {
                                this.C.refreshContent(k, b);
                                this.C.draw(canvas, i[0], i[1]);
                            }
                        }
                    }
                    ++n;
                }
            }
        }
    }
    
    public void g() {
        final ViewParent parent = ((View)this).getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(false);
        }
    }
    
    public a getAnimator() {
        return this.t;
    }
    
    public s4.d getCenter() {
        return s4.d.c(((View)this).getWidth() / 2.0f, ((View)this).getHeight() / 2.0f);
    }
    
    public s4.d getCenterOfView() {
        return this.getCenter();
    }
    
    public s4.d getCenterOffsets() {
        return this.s.o();
    }
    
    public Bitmap getChartBitmap() {
        final Bitmap bitmap = Bitmap.createBitmap(((View)this).getWidth(), ((View)this).getHeight(), Bitmap$Config.RGB_565);
        final Canvas canvas = new Canvas(bitmap);
        final Drawable background = ((View)this).getBackground();
        if (background != null) {
            background.draw(canvas);
        }
        else {
            canvas.drawColor(-1);
        }
        ((View)this).draw(canvas);
        return bitmap;
    }
    
    public RectF getContentRect() {
        return this.s.p();
    }
    
    public h getData() {
        return this.b;
    }
    
    public l4.e getDefaultValueFormatter() {
        return (l4.e)this.f;
    }
    
    public j4.c getDescription() {
        return this.k;
    }
    
    public float getDragDecelerationFrictionCoef() {
        return this.e;
    }
    
    public float getExtraBottomOffset() {
        return this.w;
    }
    
    public float getExtraLeftOffset() {
        return this.x;
    }
    
    public float getExtraRightOffset() {
        return this.v;
    }
    
    public float getExtraTopOffset() {
        return this.u;
    }
    
    public m4.b[] getHighlighted() {
        return this.z;
    }
    
    public m4.c getHighlighter() {
        return this.r;
    }
    
    public ArrayList<Runnable> getJobs() {
        return (ArrayList<Runnable>)this.H;
    }
    
    public e getLegend() {
        return this.l;
    }
    
    public r4.d getLegendRenderer() {
        return this.p;
    }
    
    public d getMarker() {
        return this.C;
    }
    
    @Deprecated
    public d getMarkerView() {
        return this.getMarker();
    }
    
    public float getMaxHighlightDistance() {
        return this.A;
    }
    
    public q4.c getOnChartGestureListener() {
        return null;
    }
    
    public q4.b getOnTouchListener() {
        return this.n;
    }
    
    public r4.c getRenderer() {
        return this.q;
    }
    
    public s4.h getViewPortHandler() {
        return this.s;
    }
    
    public j4.h getXAxis() {
        return this.i;
    }
    
    public float getXChartMax() {
        return ((j4.a)this.i).G;
    }
    
    public float getXChartMin() {
        return ((j4.a)this.i).H;
    }
    
    public float getXRange() {
        return ((j4.a)this.i).I;
    }
    
    public float getYMax() {
        return this.b.q();
    }
    
    public float getYMin() {
        return this.b.s();
    }
    
    public m4.b h(final float n, final float n2) {
        if (this.b == null) {
            Log.e("MPAndroidChart", "Can't select by touch. No data set.");
            return null;
        }
        return this.getHighlighter().a(n, n2);
    }
    
    protected float[] i(final m4.b b) {
        return new float[] { b.d(), b.e() };
    }
    
    public void j(final float n, final float n2, final int n3, final boolean b) {
        if (n3 >= 0 && n3 < this.b.g()) {
            this.l(new m4.b(n, n2, n3), b);
        }
        else {
            this.l(null, b);
        }
    }
    
    public void k(final float n, final int n2, final boolean b) {
        this.j(n, Float.NaN, n2, b);
    }
    
    public void l(m4.b b, final boolean b2) {
        j k = null;
        if (b == null) {
            this.z = null;
        }
        else {
            if (this.a) {
                final StringBuilder sb = new StringBuilder();
                sb.append("Highlighted: ");
                sb.append(b.toString());
                Log.i("MPAndroidChart", sb.toString());
            }
            k = this.b.k(b);
            if (k == null) {
                this.z = null;
                b = null;
            }
            else {
                this.z = new m4.b[] { b };
            }
        }
        this.setLastHighlighted(this.z);
        if (b2 && this.m != null) {
            if (!this.v()) {
                this.m.onNothingSelected();
            }
            else {
                this.m.onValueSelected(k, b);
            }
        }
        ((View)this).invalidate();
    }
    
    public void m(final m4.b[] z) {
        this.setLastHighlighted(this.z = z);
        ((View)this).invalidate();
    }
    
    protected void n() {
        ((View)this).setWillNotDraw(false);
        this.t = new a((ValueAnimator$AnimatorUpdateListener)new ValueAnimator$AnimatorUpdateListener(this) {
            final b a;
            
            public void onAnimationUpdate(final ValueAnimator valueAnimator) {
                ((View)this.a).postInvalidate();
            }
        });
        s4.g.t(((View)this).getContext());
        this.A = s4.g.e(500.0f);
        this.k = new j4.c();
        final e l = new e();
        this.l = l;
        this.p = new r4.d(this.s, l);
        this.i = new j4.h();
        this.g = new Paint(1);
        (this.h = new Paint(1)).setColor(Color.rgb(247, 189, 51));
        this.h.setTextAlign(Paint$Align.CENTER);
        this.h.setTextSize(s4.g.e(12.0f));
        if (this.a) {
            Log.i("", "Chart.init()");
        }
    }
    
    public boolean o() {
        return this.d;
    }
    
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.L) {
            this.u((View)this);
        }
    }
    
    protected void onDraw(final Canvas canvas) {
        if (this.b == null) {
            if (!TextUtils.isEmpty((CharSequence)this.o)) {
                final s4.d center = this.getCenter();
                canvas.drawText(this.o, center.c, center.d, this.h);
            }
            return;
        }
        if (!this.y) {
            this.c();
            this.y = true;
        }
    }
    
    protected void onLayout(final boolean b, final int n, final int n2, final int n3, final int n4) {
        for (int i = 0; i < this.getChildCount(); ++i) {
            this.getChildAt(i).layout(n, n2, n3, n4);
        }
    }
    
    protected void onMeasure(final int n, final int n2) {
        super.onMeasure(n, n2);
        final int n3 = (int)s4.g.e(50.0f);
        ((View)this).setMeasuredDimension(Math.max(((View)this).getSuggestedMinimumWidth(), View.resolveSize(n3, n)), Math.max(((View)this).getSuggestedMinimumHeight(), View.resolveSize(n3, n2)));
    }
    
    protected void onSizeChanged(final int n, final int n2, final int n3, final int n4) {
        if (this.a) {
            Log.i("MPAndroidChart", "OnSizeChanged()");
        }
        if (n > 0 && n2 > 0 && n < 10000 && n2 < 10000) {
            if (this.a) {
                final StringBuilder sb = new StringBuilder();
                sb.append("Setting chart dimens, width: ");
                sb.append(n);
                sb.append(", height: ");
                sb.append(n2);
                Log.i("MPAndroidChart", sb.toString());
            }
            this.s.M((float)n, (float)n2);
        }
        else if (this.a) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("*Avoiding* setting chart dimens! width: ");
            sb2.append(n);
            sb2.append(", height: ");
            sb2.append(n2);
            Log.w("MPAndroidChart", sb2.toString());
        }
        this.s();
        final Iterator iterator = this.H.iterator();
        while (iterator.hasNext()) {
            ((View)this).post((Runnable)iterator.next());
        }
        this.H.clear();
        super.onSizeChanged(n, n2, n3, n4);
    }
    
    public boolean p() {
        return this.B;
    }
    
    public boolean q() {
        return this.c;
    }
    
    public boolean r() {
        return this.a;
    }
    
    public abstract void s();
    
    public void setData(final h b) {
        this.b = b;
        this.y = false;
        if (b == null) {
            return;
        }
        this.t(b.s(), b.q());
        for (final o4.b b2 : this.b.i()) {
            if (b2.E() || b2.v() == this.f) {
                b2.C((l4.e)this.f);
            }
        }
        this.s();
        if (this.a) {
            Log.i("MPAndroidChart", "Data is set.");
        }
    }
    
    public void setDescription(final j4.c k) {
        this.k = k;
    }
    
    public void setDragDecelerationEnabled(final boolean d) {
        this.d = d;
    }
    
    public void setDragDecelerationFrictionCoef(float e) {
        float n = e;
        if (e < 0.0f) {
            n = 0.0f;
        }
        e = n;
        if (n >= 1.0f) {
            e = 0.999f;
        }
        this.e = e;
    }
    
    @Deprecated
    public void setDrawMarkerViews(final boolean drawMarkers) {
        this.setDrawMarkers(drawMarkers);
    }
    
    public void setDrawMarkers(final boolean b) {
        this.B = b;
    }
    
    public void setExtraBottomOffset(final float n) {
        this.w = s4.g.e(n);
    }
    
    public void setExtraLeftOffset(final float n) {
        this.x = s4.g.e(n);
    }
    
    public void setExtraRightOffset(final float n) {
        this.v = s4.g.e(n);
    }
    
    public void setExtraTopOffset(final float n) {
        this.u = s4.g.e(n);
    }
    
    public void setHardwareAccelerationEnabled(final boolean b) {
        if (b) {
            ((View)this).setLayerType(2, (Paint)null);
        }
        else {
            ((View)this).setLayerType(1, (Paint)null);
        }
    }
    
    public void setHighlightPerTapEnabled(final boolean c) {
        this.c = c;
    }
    
    public void setHighlighter(final m4.a r) {
        this.r = (m4.c)r;
    }
    
    protected void setLastHighlighted(final m4.b[] array) {
        if (array != null && array.length > 0) {
            final m4.b b = array[0];
            if (b != null) {
                this.n.d(b);
                return;
            }
        }
        this.n.d((m4.b)null);
    }
    
    public void setLogEnabled(final boolean a) {
        this.a = a;
    }
    
    public void setMarker(final d c) {
        this.C = c;
    }
    
    @Deprecated
    public void setMarkerView(final d marker) {
        this.setMarker(marker);
    }
    
    public void setMaxHighlightDistance(final float n) {
        this.A = s4.g.e(n);
    }
    
    public void setNoDataText(final String o) {
        this.o = o;
    }
    
    public void setNoDataTextColor(final int color) {
        this.h.setColor(color);
    }
    
    public void setNoDataTextTypeface(final Typeface typeface) {
        this.h.setTypeface(typeface);
    }
    
    public void setOnChartGestureListener(final q4.c c) {
    }
    
    public void setOnChartValueSelectedListener(final q4.d m) {
        this.m = m;
    }
    
    public void setOnTouchListener(final q4.b n) {
        this.n = n;
    }
    
    public void setRenderer(final r4.c q) {
        if (q != null) {
            this.q = q;
        }
    }
    
    public void setTouchEnabled(final boolean j) {
        this.j = j;
    }
    
    public void setUnbindEnabled(final boolean l) {
        this.L = l;
    }
    
    protected void t(float n, final float n2) {
        final h b = this.b;
        if (b != null && b.j() >= 2) {
            n = Math.abs(n2 - n);
        }
        else {
            n = Math.max(Math.abs(n), Math.abs(n2));
        }
        this.f.a(s4.g.i(n));
    }
    
    public boolean v() {
        final m4.b[] z = this.z;
        boolean b2;
        final boolean b = b2 = false;
        if (z != null) {
            b2 = b;
            if (z.length > 0) {
                b2 = (z[0] != null || b);
            }
        }
        return b2;
    }
}
