package com.github.mikephil.charting.charts;

import r4.e;
import k4.k;
import android.content.Context;

public class c extends a implements n4.c
{
    public c(final Context context) {
        super(context);
    }
    
    @Override
    public k getLineData() {
        return (k)super.b;
    }
    
    @Override
    protected void n() {
        super.n();
        super.q = (r4.c)new e((n4.c)this, super.t, super.s);
    }
    
    @Override
    protected void onDetachedFromWindow() {
        final r4.c q = super.q;
        if (q != null && q instanceof e) {
            ((e)q).w();
        }
        super.onDetachedFromWindow();
    }
}
