package com.google.crypto.tink.config.internal;

abstract class a
{
    public static boolean a() {
        return false;
    }
}
