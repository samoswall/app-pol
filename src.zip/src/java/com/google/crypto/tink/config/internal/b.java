package com.google.crypto.tink.config.internal;

import org.conscrypt.Conscrypt;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;

public abstract class b
{
    private static final Logger a;
    private static final AtomicBoolean b;
    
    static {
        a = Logger.getLogger(b.class.getName());
        b = new AtomicBoolean(false);
    }
    
    static Boolean a() {
        try {
            final int a = Conscrypt.a;
            return (Boolean)Conscrypt.class.getMethod("isBoringSslFIPSBuild", (Class<?>[])new Class[0]).invoke((Object)null, new Object[0]);
        }
        catch (final Exception ex) {
            com.google.crypto.tink.config.internal.b.a.info("Conscrypt is not available or does not support checking for FIPS build.");
            return Boolean.FALSE;
        }
    }
    
    public static boolean b() {
        return a();
    }
    
    public static boolean c() {
        return com.google.crypto.tink.config.internal.a.a() || com.google.crypto.tink.config.internal.b.b.get();
    }
    
    public enum b
    {
        private static final b[] $VALUES;
        
        ALGORITHM_NOT_FIPS {
            @Override
            public boolean isCompatible() {
                return com.google.crypto.tink.config.internal.b.c() ^ true;
            }
        }, 
        ALGORITHM_REQUIRES_BORINGCRYPTO {
            @Override
            public boolean isCompatible() {
                return !com.google.crypto.tink.config.internal.b.c() || com.google.crypto.tink.config.internal.b.b();
            }
        };
        
        public abstract boolean isCompatible();
    }
}
