package com.google.crypto.tink.internal;

import java.util.Collection;
import java.util.Deque;
import java.math.BigDecimal;
import com.google.gson.stream.JsonWriter;
import java.util.ArrayDeque;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import java.io.IOException;
import com.google.gson.JsonNull;
import com.google.gson.JsonPrimitive;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.JsonElement;
import com.google.gson.TypeAdapter;

public abstract class JsonParser
{
    private static final JsonElementTypeAdapter a;
    
    static {
        a = new JsonElementTypeAdapter();
    }
    
    public static boolean a(final String s) {
        final int length = s.length();
        int i = 0;
        while (i != length) {
            final char char1 = s.charAt(i);
            final int n = i + 1;
            if (Character.isSurrogate(char1)) {
                if (Character.isLowSurrogate(char1) || n == length || !Character.isLowSurrogate(s.charAt(n))) {
                    return false;
                }
                i += 2;
            }
            else {
                i = n;
            }
        }
        return true;
    }
    
    private static final class JsonElementTypeAdapter extends TypeAdapter<JsonElement>
    {
        private JsonElement a(final JsonReader jsonReader, final JsonToken jsonToken) {
            final int n = JsonParser$a.a[((Enum)jsonToken).ordinal()];
            if (n != 3) {
                if (n == 4) {
                    return (JsonElement)new JsonPrimitive((Number)new b(jsonReader.nextString()));
                }
                if (n == 5) {
                    return (JsonElement)new JsonPrimitive(Boolean.valueOf(jsonReader.nextBoolean()));
                }
                if (n == 6) {
                    jsonReader.nextNull();
                    return (JsonElement)JsonNull.INSTANCE;
                }
                final StringBuilder sb = new StringBuilder();
                sb.append("Unexpected token: ");
                sb.append((Object)jsonToken);
                throw new IllegalStateException(sb.toString());
            }
            else {
                final String nextString = jsonReader.nextString();
                if (JsonParser.a(nextString)) {
                    return (JsonElement)new JsonPrimitive(nextString);
                }
                throw new IOException("illegal characters in string");
            }
        }
        
        private JsonElement b(final JsonReader jsonReader, final JsonToken jsonToken) {
            final int n = JsonParser$a.a[((Enum)jsonToken).ordinal()];
            if (n == 1) {
                jsonReader.beginArray();
                return (JsonElement)new JsonArray();
            }
            if (n != 2) {
                return null;
            }
            jsonReader.beginObject();
            return (JsonElement)new JsonObject();
        }
        
        public JsonElement read(final JsonReader jsonReader) {
            final JsonToken peek = jsonReader.peek();
            JsonElement b = this.b(jsonReader, peek);
            if (b == null) {
                return this.a(jsonReader, peek);
            }
            final ArrayDeque arrayDeque = new ArrayDeque();
            while (true) {
                if (jsonReader.hasNext()) {
                    String nextName;
                    if (b instanceof JsonObject) {
                        nextName = jsonReader.nextName();
                        if (!JsonParser.a(nextName)) {
                            throw new IOException("illegal characters in string");
                        }
                    }
                    else {
                        nextName = null;
                    }
                    final JsonToken peek2 = jsonReader.peek();
                    final JsonElement b2 = this.b(jsonReader, peek2);
                    final boolean b3 = b2 != null;
                    JsonElement a = b2;
                    if (b2 == null) {
                        a = this.a(jsonReader, peek2);
                    }
                    if (b instanceof JsonArray) {
                        ((JsonArray)b).add(a);
                    }
                    else {
                        final JsonObject jsonObject = (JsonObject)b;
                        if (jsonObject.has(nextName)) {
                            final StringBuilder sb = new StringBuilder();
                            sb.append("duplicate key: ");
                            sb.append(nextName);
                            throw new IOException(sb.toString());
                        }
                        jsonObject.add(nextName, a);
                    }
                    if (!b3) {
                        continue;
                    }
                    ((Deque)arrayDeque).addLast((Object)b);
                    if (((Deque)arrayDeque).size() > 100) {
                        throw new IOException("too many recursions");
                    }
                    b = a;
                }
                else {
                    if (b instanceof JsonArray) {
                        jsonReader.endArray();
                    }
                    else {
                        jsonReader.endObject();
                    }
                    if (((Collection)arrayDeque).isEmpty()) {
                        return b;
                    }
                    b = (JsonElement)((Deque)arrayDeque).removeLast();
                }
            }
        }
        
        public void write(final JsonWriter jsonWriter, final JsonElement jsonElement) {
            throw new UnsupportedOperationException("write is not supported");
        }
    }
    
    private static final class b extends Number
    {
        private final String a;
        
        public b(final String a) {
            this.a = a;
        }
        
        public double doubleValue() {
            return Double.parseDouble(this.a);
        }
        
        public boolean equals(final Object o) {
            return this == o || (o instanceof b && this.a.equals((Object)((b)o).a));
        }
        
        public float floatValue() {
            return Float.parseFloat(this.a);
        }
        
        public int hashCode() {
            return this.a.hashCode();
        }
        
        public int intValue() {
            try {
                return Integer.parseInt(this.a);
            }
            catch (final NumberFormatException ex) {
                try {
                    return (int)Long.parseLong(this.a);
                }
                catch (final NumberFormatException ex2) {
                    return new BigDecimal(this.a).intValue();
                }
            }
        }
        
        public long longValue() {
            try {
                return Long.parseLong(this.a);
            }
            catch (final NumberFormatException ex) {
                return new BigDecimal(this.a).longValue();
            }
        }
        
        public String toString() {
            return this.a;
        }
    }
}
