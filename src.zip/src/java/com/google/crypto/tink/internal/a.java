package com.google.crypto.tink.internal;

import android.os.Build$VERSION;

abstract class a
{
    public static Integer a() {
        return Build$VERSION.SDK_INT;
    }
}
