package com.google.crypto.tink.internal;

import S5.g;
import S5.x;
import f6.a;

public abstract class b
{
    private final a a;
    private final Class b;
    
    private b(final a a, final Class b) {
        this.a = a;
        this.b = b;
    }
    
    public static b a(final b$b b$b, final a a, final Class clazz) {
        return new b(a, clazz, b$b) {
            final b$b c;
            
            @Override
            public g d(final q q, final x x) {
                return this.c.a(q, x);
            }
        };
    }
    
    public final a b() {
        return this.a;
    }
    
    public final Class c() {
        return this.b;
    }
    
    public abstract g d(final q p0, final x p1);
}
