package com.google.crypto.tink.internal;

public abstract class c
{
    private final Class a;
    private final Class b;
    
    private c(final Class a, final Class b) {
        this.a = a;
        this.b = b;
    }
    
    public static c a(final c$b c$b, final Class clazz, final Class clazz2) {
        return new c(clazz, clazz2, c$b) {
            final c$b c;
        };
    }
    
    public Class b() {
        return this.a;
    }
    
    public Class c() {
        return this.b;
    }
}
