package com.google.crypto.tink.internal;

import java.util.Set;
import com.google.crypto.tink.shaded.protobuf.h;
import d6.y$c;
import com.google.crypto.tink.shaded.protobuf.O;
import com.google.crypto.tink.config.internal.b$b;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public abstract class d
{
    private final Class a;
    private final Map b;
    private final Class c;
    
    protected d(final Class a, final m... array) {
        this.a = a;
        final HashMap hashMap = new HashMap();
        for (final m m : array) {
            if (((Map)hashMap).containsKey((Object)m.b())) {
                final StringBuilder sb = new StringBuilder();
                sb.append("KeyTypeManager constructed with duplicate factories for primitive ");
                sb.append(m.b().getCanonicalName());
                throw new IllegalArgumentException(sb.toString());
            }
            ((Map)hashMap).put((Object)m.b(), (Object)m);
        }
        if (array.length > 0) {
            this.c = array[0].b();
        }
        else {
            this.c = Void.class;
        }
        this.b = Collections.unmodifiableMap((Map)hashMap);
    }
    
    public b$b a() {
        return b$b.ALGORITHM_NOT_FIPS;
    }
    
    public final Class b() {
        return this.c;
    }
    
    public final Class c() {
        return this.a;
    }
    
    public abstract String d();
    
    public final Object e(final O o, final Class clazz) {
        final m m = (m)this.b.get((Object)clazz);
        if (m != null) {
            return m.a(o);
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("Requested primitive class ");
        sb.append(clazz.getCanonicalName());
        sb.append(" not supported.");
        throw new IllegalArgumentException(sb.toString());
    }
    
    public abstract a f();
    
    public abstract y$c g();
    
    public abstract O h(final h p0);
    
    public final Set i() {
        return this.b.keySet();
    }
    
    public abstract void j(final O p0);
    
    public abstract static class a
    {
        private final Class a;
        
        public a(final Class a) {
            this.a = a;
        }
        
        public abstract O a(final O p0);
        
        public final Class b() {
            return this.a;
        }
        
        public Map c() {
            return Collections.emptyMap();
        }
        
        public abstract O d(final h p0);
        
        public abstract void e(final O p0);
    }
}
