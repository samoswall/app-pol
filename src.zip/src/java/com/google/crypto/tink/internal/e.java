package com.google.crypto.tink.internal;

import S5.x;
import S5.g;

public final class e extends g
{
    private final o a;
    
    public e(final o a, final x x) {
        a(a, x);
        this.a = a;
    }
    
    private static void a(final o o, final x x) {
        final int n = e$a.b[((Enum)o.d()).ordinal()];
        if (n == 1 || n == 2) {
            x.b(x);
        }
    }
}
