package com.google.crypto.tink.internal;

import S5.k;
import d6.z;
import java.util.Iterator;
import java.security.GeneralSecurityException;
import S5.u$c;
import java.util.List;
import b6.c;
import S5.u;
import b6.b;

public abstract class f
{
    public static final b6.b.a a;
    
    static {
        a = new b();
    }
    
    public static c a(final u u) {
        final c.b a = c.a();
        a.d(u.d());
        final Iterator iterator = u.c().iterator();
        while (iterator.hasNext()) {
            for (final u$c u$c : (List)iterator.next()) {
                a.a(c(u$c.h()), u$c.d(), b(u$c.e()), ((Enum)u$c.f()).name());
            }
        }
        if (u.e() != null) {
            a.e(u.e().d());
        }
        try {
            return a.b();
        }
        catch (final GeneralSecurityException ex) {
            throw new IllegalStateException((Throwable)ex);
        }
    }
    
    private static String b(final String s) {
        if (!s.startsWith("type.googleapis.com/google.crypto.")) {
            return s;
        }
        return s.substring(34);
    }
    
    private static k c(final z z) {
        final int n = f$a.a[((Enum)z).ordinal()];
        if (n == 1) {
            return k.b;
        }
        if (n == 2) {
            return k.c;
        }
        if (n == 3) {
            return k.d;
        }
        throw new IllegalStateException("Unknown key status");
    }
    
    private static class b implements a
    {
        @Override
        public void a() {
        }
        
        @Override
        public void b(final int n, final long n2) {
        }
    }
}
