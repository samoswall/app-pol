package com.google.crypto.tink.internal;

import b6.c;
import b6.b;
import java.util.concurrent.atomic.AtomicReference;

public final class g
{
    private static final g b;
    private static final b c;
    private final AtomicReference a;
    
    static {
        b = new g();
        c = new b();
    }
    
    public g() {
        this.a = new AtomicReference();
    }
    
    public static g b() {
        return g.b;
    }
    
    public b6.b a() {
        b6.b c;
        if ((c = (b6.b)this.a.get()) == null) {
            c = g.c;
        }
        return c;
    }
    
    private static class b implements b6.b
    {
        @Override
        public a a(final c c, final String s, final String s2) {
            return f.a;
        }
    }
}
