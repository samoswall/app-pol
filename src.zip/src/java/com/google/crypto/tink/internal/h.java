package com.google.crypto.tink.internal;

import S5.u;
import S5.v;
import S5.g;
import java.util.concurrent.atomic.AtomicReference;

public final class h
{
    private static h b;
    private final AtomicReference a;
    
    static {
        h.b = new h();
    }
    
    h() {
        this.a = new AtomicReference((Object)new n.b().c());
    }
    
    public static h c() {
        return h.b;
    }
    
    public Class a(final Class clazz) {
        return ((n)this.a.get()).c(clazz);
    }
    
    public Object b(final g g, final Class clazz) {
        return ((n)this.a.get()).d(g, clazz);
    }
    
    public void d(final l l) {
        synchronized (this) {
            this.a.set((Object)new n.b((n)this.a.get()).d(l).c());
        }
    }
    
    public void e(final v v) {
        synchronized (this) {
            this.a.set((Object)new n.b((n)this.a.get()).e(v).c());
        }
    }
    
    public Object f(final u u, final Class clazz) {
        return ((n)this.a.get()).e(u, clazz);
    }
}
