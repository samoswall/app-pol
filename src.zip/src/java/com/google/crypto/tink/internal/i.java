package com.google.crypto.tink.internal;

import java.security.GeneralSecurityException;
import S5.g;
import S5.x;
import java.util.concurrent.atomic.AtomicReference;

public final class i
{
    private static final i b;
    private final AtomicReference a;
    
    static {
        b = new i();
    }
    
    public i() {
        this.a = new AtomicReference((Object)new r.b().e());
    }
    
    public static i a() {
        return i.b;
    }
    
    public boolean b(final q q) {
        return ((r)this.a.get()).e(q);
    }
    
    public g c(final q q, final x x) {
        return ((r)this.a.get()).f(q, x);
    }
    
    public g d(final o o, final x x) {
        if (x != null) {
            if (!this.b(o)) {
                try {
                    return new e(o, x);
                }
                catch (final GeneralSecurityException ex) {
                    throw new s("Creating a LegacyProtoKey failed", (Throwable)ex);
                }
            }
            return this.c(o, x);
        }
        throw new NullPointerException("access cannot be null");
    }
    
    public void e(final b b) {
        synchronized (this) {
            this.a.set((Object)new r.b((r)this.a.get()).f(b).e());
        }
    }
    
    public void f(final c c) {
        synchronized (this) {
            this.a.set((Object)new r.b((r)this.a.get()).g(c).e());
        }
    }
    
    public void g(final j j) {
        synchronized (this) {
            this.a.set((Object)new r.b((r)this.a.get()).h(j).e());
        }
    }
    
    public void h(final k k) {
        synchronized (this) {
            this.a.set((Object)new r.b((r)this.a.get()).i(k).e());
        }
    }
}
