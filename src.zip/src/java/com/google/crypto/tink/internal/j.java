package com.google.crypto.tink.internal;

import f6.a;

public abstract class j
{
    private final a a;
    private final Class b;
    
    private j(final a a, final Class b) {
        this.a = a;
        this.b = b;
    }
    
    public static j a(final j$b j$b, final a a, final Class clazz) {
        return new j(a, clazz, j$b) {
            final j$b c;
        };
    }
    
    public final a b() {
        return this.a;
    }
    
    public final Class c() {
        return this.b;
    }
}
