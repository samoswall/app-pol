package com.google.crypto.tink.internal;

public abstract class k
{
    private final Class a;
    private final Class b;
    
    private k(final Class a, final Class b) {
        this.a = a;
        this.b = b;
    }
    
    public static k a(final k$b k$b, final Class clazz, final Class clazz2) {
        return new k(clazz, clazz2, k$b) {
            final k$b c;
        };
    }
    
    public Class b() {
        return this.a;
    }
    
    public Class c() {
        return this.b;
    }
}
