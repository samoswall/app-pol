package com.google.crypto.tink.internal;

import S5.g;

public abstract class l
{
    private final Class a;
    private final Class b;
    
    private l(final Class a, final Class b) {
        this.a = a;
        this.b = b;
    }
    
    public static l b(final b b, final Class clazz, final Class clazz2) {
        return new l(clazz, clazz2, b) {
            final b c;
            
            @Override
            public Object a(final g g) {
                return this.c.a(g);
            }
        };
    }
    
    public abstract Object a(final g p0);
    
    public Class c() {
        return this.a;
    }
    
    public Class d() {
        return this.b;
    }
    
    public interface b
    {
        Object a(final g p0);
    }
}
