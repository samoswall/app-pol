package com.google.crypto.tink.internal;

import com.google.crypto.tink.shaded.protobuf.O;

public abstract class m
{
    private final Class a;
    
    public m(final Class a) {
        this.a = a;
    }
    
    public abstract Object a(final O p0);
    
    final Class b() {
        return this.a;
    }
}
