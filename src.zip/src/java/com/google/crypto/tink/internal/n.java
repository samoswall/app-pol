package com.google.crypto.tink.internal;

import java.util.Objects;
import S5.u;
import S5.g;
import java.security.GeneralSecurityException;
import S5.v;
import java.util.HashMap;
import java.util.Map;

public class n
{
    private final Map a;
    private final Map b;
    
    private n(final b b) {
        this.a = (Map)new HashMap(b.a);
        this.b = (Map)new HashMap(b.b);
    }
    
    public Class c(final Class clazz) {
        if (this.b.containsKey((Object)clazz)) {
            return ((v)this.b.get((Object)clazz)).a();
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("No input primitive class for ");
        sb.append((Object)clazz);
        sb.append(" available");
        throw new GeneralSecurityException(sb.toString());
    }
    
    public Object d(final g g, final Class clazz) {
        final c c = new c((Class)g.getClass(), clazz);
        if (this.a.containsKey((Object)c)) {
            return ((l)this.a.get((Object)c)).a(g);
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("No PrimitiveConstructor for ");
        sb.append((Object)c);
        sb.append(" available");
        throw new GeneralSecurityException(sb.toString());
    }
    
    public Object e(final u u, final Class clazz) {
        if (!this.b.containsKey((Object)clazz)) {
            final StringBuilder sb = new StringBuilder();
            sb.append("No wrapper found for ");
            sb.append((Object)clazz);
            throw new GeneralSecurityException(sb.toString());
        }
        final v v = (v)this.b.get((Object)clazz);
        if (u.g().equals(v.a()) && v.a().equals(u.g())) {
            return v.c(u);
        }
        throw new GeneralSecurityException("Input primitive type of the wrapper doesn't match the type of primitives in the provided PrimitiveSet");
    }
    
    public static final class b
    {
        private final Map a;
        private final Map b;
        
        public b() {
            this.a = (Map)new HashMap();
            this.b = (Map)new HashMap();
        }
        
        public b(final n n) {
            this.a = (Map)new HashMap(n.a);
            this.b = (Map)new HashMap(n.b);
        }
        
        n c() {
            return new n(this, null);
        }
        
        public b d(final l obj) {
            if (obj != null) {
                final c c = new c(obj.c(), obj.d());
                if (this.a.containsKey((Object)c)) {
                    final l obj2 = (l)this.a.get((Object)c);
                    if (!obj2.equals(obj) || !obj.equals(obj2)) {
                        final StringBuilder sb = new StringBuilder();
                        sb.append("Attempt to register non-equal PrimitiveConstructor object for already existing object of type: ");
                        sb.append((Object)c);
                        throw new GeneralSecurityException(sb.toString());
                    }
                }
                else {
                    this.a.put((Object)c, (Object)obj);
                }
                return this;
            }
            throw new NullPointerException("primitive constructor must be non-null");
        }
        
        public b e(final v obj) {
            if (obj != null) {
                final Class b = obj.b();
                if (this.b.containsKey((Object)b)) {
                    final v obj2 = (v)this.b.get((Object)b);
                    if (!obj2.equals(obj) || !obj.equals(obj2)) {
                        final StringBuilder sb = new StringBuilder();
                        sb.append("Attempt to register non-equal PrimitiveWrapper object or input class object for already existing object of type");
                        sb.append((Object)b);
                        throw new GeneralSecurityException(sb.toString());
                    }
                }
                else {
                    this.b.put((Object)b, (Object)obj);
                }
                return this;
            }
            throw new NullPointerException("wrapper must be non-null");
        }
    }
    
    private static final class c
    {
        private final Class a;
        private final Class b;
        
        private c(final Class a, final Class b) {
            this.a = a;
            this.b = b;
        }
        
        @Override
        public boolean equals(final Object o) {
            final boolean b = o instanceof c;
            final boolean b2 = false;
            if (!b) {
                return false;
            }
            final c c = (c)o;
            boolean b3 = b2;
            if (c.a.equals(this.a)) {
                b3 = b2;
                if (c.b.equals(this.b)) {
                    b3 = true;
                }
            }
            return b3;
        }
        
        @Override
        public int hashCode() {
            return Objects.hash(new Object[] { this.a, this.b });
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append(this.a.getSimpleName());
            sb.append(" with primitive type: ");
            sb.append(this.b.getSimpleName());
            return sb.toString();
        }
    }
}
