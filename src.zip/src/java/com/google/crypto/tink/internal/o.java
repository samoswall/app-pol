package com.google.crypto.tink.internal;

import java.security.GeneralSecurityException;
import d6.I;
import d6.y$c;
import com.google.crypto.tink.shaded.protobuf.h;
import f6.a;

public final class o implements q
{
    private final String a;
    private final a b;
    private final h c;
    private final y$c d;
    private final I e;
    private final Integer f;
    
    private o(final String a, final h c, final y$c d, final I e, final Integer f) {
        this.a = a;
        this.b = t.e(a);
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    
    public static o b(final String s, final h h, final y$c y$c, final I i, final Integer n) {
        if (i == I.RAW) {
            if (n != null) {
                throw new GeneralSecurityException("Keys with output prefix type raw should not have an id requirement.");
            }
        }
        else if (n == null) {
            throw new GeneralSecurityException("Keys with output prefix type different from raw should have an id requirement.");
        }
        return new o(s, h, y$c, i, n);
    }
    
    @Override
    public a a() {
        return this.b;
    }
    
    public Integer c() {
        return this.f;
    }
    
    public y$c d() {
        return this.d;
    }
    
    public I e() {
        return this.e;
    }
    
    public String f() {
        return this.a;
    }
    
    public h g() {
        return this.c;
    }
}
