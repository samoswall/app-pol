package com.google.crypto.tink.internal;

public abstract class p implements q
{
}
