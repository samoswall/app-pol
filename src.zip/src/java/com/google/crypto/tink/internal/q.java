package com.google.crypto.tink.internal;

import f6.a;

public interface q
{
    a a();
}
