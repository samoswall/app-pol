package com.google.crypto.tink.internal;

import java.util.Objects;
import f6.a;
import java.security.GeneralSecurityException;
import S5.g;
import S5.x;
import java.util.HashMap;
import java.util.Map;

public final class r
{
    private final Map a;
    private final Map b;
    private final Map c;
    private final Map d;
    
    private r(final b b) {
        this.a = (Map)new HashMap(b.a);
        this.b = (Map)new HashMap(b.b);
        this.c = (Map)new HashMap(b.c);
        this.d = (Map)new HashMap(b.d);
    }
    
    public boolean e(final q q) {
        return this.b.containsKey((Object)new c((Class)q.getClass(), q.a()));
    }
    
    public g f(final q q, final x x) {
        final c c = new c((Class)q.getClass(), q.a());
        if (this.b.containsKey((Object)c)) {
            return ((com.google.crypto.tink.internal.b)this.b.get((Object)c)).d(q, x);
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("No Key Parser for requested key type ");
        sb.append((Object)c);
        sb.append(" available");
        throw new GeneralSecurityException(sb.toString());
    }
    
    public static final class b
    {
        private final Map a;
        private final Map b;
        private final Map c;
        private final Map d;
        
        public b() {
            this.a = (Map)new HashMap();
            this.b = (Map)new HashMap();
            this.c = (Map)new HashMap();
            this.d = (Map)new HashMap();
        }
        
        public b(final r r) {
            this.a = (Map)new HashMap(r.a);
            this.b = (Map)new HashMap(r.b);
            this.c = (Map)new HashMap(r.c);
            this.d = (Map)new HashMap(r.d);
        }
        
        r e() {
            return new r(this, null);
        }
        
        public b f(final com.google.crypto.tink.internal.b obj) {
            final c c = new c(obj.c(), obj.b());
            if (this.b.containsKey((Object)c)) {
                final com.google.crypto.tink.internal.b obj2 = (com.google.crypto.tink.internal.b)this.b.get((Object)c);
                if (!obj2.equals(obj) || !obj.equals(obj2)) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append("Attempt to register non-equal parser for already existing object of type: ");
                    sb.append((Object)c);
                    throw new GeneralSecurityException(sb.toString());
                }
            }
            else {
                this.b.put((Object)c, (Object)obj);
            }
            return this;
        }
        
        public b g(final com.google.crypto.tink.internal.c obj) {
            final d d = new d(obj.b(), obj.c());
            if (this.a.containsKey((Object)d)) {
                final com.google.crypto.tink.internal.c obj2 = (com.google.crypto.tink.internal.c)this.a.get((Object)d);
                if (!obj2.equals(obj) || !obj.equals(obj2)) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append("Attempt to register non-equal serializer for already existing object of type: ");
                    sb.append((Object)d);
                    throw new GeneralSecurityException(sb.toString());
                }
            }
            else {
                this.a.put((Object)d, (Object)obj);
            }
            return this;
        }
        
        public b h(final j obj) {
            final c c = new c(obj.c(), obj.b());
            if (this.d.containsKey((Object)c)) {
                final j obj2 = (j)this.d.get((Object)c);
                if (!obj2.equals(obj) || !obj.equals(obj2)) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append("Attempt to register non-equal parser for already existing object of type: ");
                    sb.append((Object)c);
                    throw new GeneralSecurityException(sb.toString());
                }
            }
            else {
                this.d.put((Object)c, (Object)obj);
            }
            return this;
        }
        
        public b i(final k obj) {
            final d d = new d(obj.b(), obj.c());
            if (this.c.containsKey((Object)d)) {
                final k obj2 = (k)this.c.get((Object)d);
                if (!obj2.equals(obj) || !obj.equals(obj2)) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append("Attempt to register non-equal serializer for already existing object of type: ");
                    sb.append((Object)d);
                    throw new GeneralSecurityException(sb.toString());
                }
            }
            else {
                this.c.put((Object)d, (Object)obj);
            }
            return this;
        }
    }
    
    private static class c
    {
        private final Class a;
        private final a b;
        
        private c(final Class a, final a b) {
            this.a = a;
            this.b = b;
        }
        
        @Override
        public boolean equals(final Object o) {
            final boolean b = o instanceof c;
            final boolean b2 = false;
            if (!b) {
                return false;
            }
            final c c = (c)o;
            boolean b3 = b2;
            if (c.a.equals(this.a)) {
                b3 = b2;
                if (c.b.equals((Object)this.b)) {
                    b3 = true;
                }
            }
            return b3;
        }
        
        @Override
        public int hashCode() {
            return Objects.hash(new Object[] { this.a, this.b });
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append(this.a.getSimpleName());
            sb.append(", object identifier: ");
            sb.append((Object)this.b);
            return sb.toString();
        }
    }
    
    private static class d
    {
        private final Class a;
        private final Class b;
        
        private d(final Class a, final Class b) {
            this.a = a;
            this.b = b;
        }
        
        @Override
        public boolean equals(final Object o) {
            final boolean b = o instanceof d;
            final boolean b2 = false;
            if (!b) {
                return false;
            }
            final d d = (d)o;
            boolean b3 = b2;
            if (d.a.equals(this.a)) {
                b3 = b2;
                if (d.b.equals(this.b)) {
                    b3 = true;
                }
            }
            return b3;
        }
        
        @Override
        public int hashCode() {
            return Objects.hash(new Object[] { this.a, this.b });
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append(this.a.getSimpleName());
            sb.append(" with serialization type: ");
            sb.append(this.b.getSimpleName());
            return sb.toString();
        }
    }
}
