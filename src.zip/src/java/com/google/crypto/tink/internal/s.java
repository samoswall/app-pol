package com.google.crypto.tink.internal;

public final class s extends RuntimeException
{
    public s(final String s) {
        super(s);
    }
    
    public s(final String s, final Throwable t) {
        super(s, t);
    }
}
