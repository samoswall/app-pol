package com.google.crypto.tink.internal;

import java.security.SecureRandom;
import java.util.Objects;
import java.nio.charset.Charset;

public abstract class t
{
    public static final Charset a;
    
    static {
        a = Charset.forName("UTF-8");
    }
    
    public static Integer a() {
        if (!b()) {
            return null;
        }
        return com.google.crypto.tink.internal.a.a();
    }
    
    public static boolean b() {
        return Objects.equals((Object)System.getProperty("java.vendor"), (Object)"The Android Project");
    }
    
    public static int c() {
        final SecureRandom secureRandom = new SecureRandom();
        byte[] array;
        int i;
        for (array = new byte[4], i = 0; i == 0; i = ((array[0] & 0x7F) << 24 | (array[1] & 0xFF) << 16 | (array[2] & 0xFF) << 8 | (array[3] & 0xFF))) {
            secureRandom.nextBytes(array);
        }
        return i;
    }
    
    private static final byte d(final char c) {
        if (c >= '!' && c <= '~') {
            return (byte)c;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("Not a printable ASCII character: ");
        sb.append(c);
        throw new s(sb.toString());
    }
    
    public static final f6.a e(final String s) {
        final byte[] array = new byte[s.length()];
        for (int i = 0; i < s.length(); ++i) {
            array[i] = d(s.charAt(i));
        }
        return f6.a.a(array);
    }
}
