package com.google.crypto.tink.shaded.protobuf;

import java.io.IOException;

public abstract class a implements O
{
    protected int memoizedHashCode;
    
    public a() {
        this.memoizedHashCode = 0;
    }
    
    private String i(final String s) {
        final StringBuilder sb = new StringBuilder();
        sb.append("Serializing ");
        sb.append(this.getClass().getName());
        sb.append(" to a ");
        sb.append(s);
        sb.append(" threw an IOException (should never happen).");
        return sb.toString();
    }
    
    @Override
    public h e() {
        try {
            final h.h w = h.w(this.b());
            this.d(w.b());
            return w.a();
        }
        catch (final IOException ex) {
            throw new RuntimeException(this.i("ByteString"), (Throwable)ex);
        }
    }
    
    @Override
    public byte[] f() {
        try {
            final byte[] array = new byte[this.b()];
            final k u = k.U(array);
            this.d(u);
            u.c();
            return array;
        }
        catch (final IOException ex) {
            throw new RuntimeException(this.i("byte array"), (Throwable)ex);
        }
    }
    
    abstract int h(final e0 p0);
    
    j0 j() {
        return new j0(this);
    }
    
    public abstract static class a implements O.a
    {
        protected static j0 h(final O o) {
            return new j0(o);
        }
    }
}
