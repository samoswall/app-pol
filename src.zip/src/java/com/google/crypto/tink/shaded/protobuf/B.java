package com.google.crypto.tink.shaded.protobuf;

public abstract class b implements X
{
    private static final p a;
    
    static {
        a = p.b();
    }
}
