package com.google.crypto.tink.shaded.protobuf;

abstract class d
{
    private static boolean a;
    private static final Class b;
    private static final boolean c;
    
    static {
        b = a("libcore.io.Memory");
        c = (!d.a && a("org.robolectric.Robolectric") != null);
    }
    
    private static Class a(final String className) {
        try {
            return Class.forName(className);
        }
        finally {
            return null;
        }
    }
    
    static Class b() {
        return d.b;
    }
    
    static boolean c() {
        return d.a || (d.b != null && !d.c);
    }
}
