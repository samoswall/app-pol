package com.google.crypto.tink.shaded.protobuf;

import java.util.List;

abstract class e
{
    static int A(final int n, final byte[] array, int i, final int n2, final z.d d, final a a) {
        final F f = (F)d;
        i = K(array, i, a);
        f.c(i.c(a.b));
        while (i < n2) {
            final int h = H(array, i, a);
            if (n != a.a) {
                break;
            }
            i = K(array, h, a);
            f.c(i.c(a.b));
        }
        return i;
    }
    
    static int B(final byte[] array, int h, final a a) {
        h = H(array, h, a);
        final int a2 = a.a;
        if (a2 < 0) {
            throw A.g();
        }
        if (a2 == 0) {
            a.c = "";
            return h;
        }
        a.c = new String(array, h, a2, z.b);
        return h + a2;
    }
    
    static int C(final int n, final byte[] array, int i, final int n2, final z.d d, final a a) {
        i = H(array, i, a);
        int n3 = a.a;
        if (n3 >= 0) {
            while (true) {
                Label_0060: {
                    if (n3 != 0) {
                        ((List)d).add((Object)new String(array, i, n3, z.b));
                        break Label_0060;
                    }
                    ((List)d).add((Object)"");
                    while (i < n2) {
                        final int h = H(array, i, a);
                        if (n != a.a) {
                            break;
                        }
                        i = H(array, h, a);
                        n3 = a.a;
                        if (n3 < 0) {
                            throw A.g();
                        }
                        if (n3 != 0) {
                            ((List)d).add((Object)new String(array, i, n3, z.b));
                            break Label_0060;
                        }
                        ((List)d).add((Object)"");
                    }
                    return i;
                }
                i += n3;
                continue;
            }
        }
        throw A.g();
    }
    
    static int D(final int n, final byte[] array, int i, final int n2, final z.d d, final a a) {
        final int h = H(array, i, a);
        final int a2 = a.a;
        if (a2 >= 0) {
            if (a2 == 0) {
                ((List)d).add((Object)"");
                i = h;
            }
            else {
                i = h + a2;
                if (!p0.n(array, h, i)) {
                    throw A.d();
                }
                ((List)d).add((Object)new String(array, h, a2, z.b));
            }
            while (i < n2) {
                final int h2 = H(array, i, a);
                if (n != a.a) {
                    break;
                }
                i = H(array, h2, a);
                final int a3 = a.a;
                if (a3 < 0) {
                    throw A.g();
                }
                if (a3 == 0) {
                    ((List)d).add((Object)"");
                }
                else {
                    final int n3 = i + a3;
                    if (!p0.n(array, i, n3)) {
                        throw A.d();
                    }
                    ((List)d).add((Object)new String(array, i, a3, z.b));
                    i = n3;
                }
            }
            return i;
        }
        throw A.g();
    }
    
    static int E(final byte[] array, int h, final a a) {
        h = H(array, h, a);
        final int a2 = a.a;
        if (a2 < 0) {
            throw A.g();
        }
        if (a2 == 0) {
            a.c = "";
            return h;
        }
        a.c = p0.e(array, h, a2);
        return h + a2;
    }
    
    static int F(final int n, final byte[] array, int n2, int h, final l0 l0, final a a) {
        if (q0.a(n) == 0) {
            throw A.c();
        }
        final int b = q0.b(n);
        if (b == 0) {
            n2 = K(array, n2, a);
            l0.n(n, a.b);
            return n2;
        }
        if (b == 1) {
            l0.n(n, i(array, n2));
            return n2 + 8;
        }
        if (b != 2) {
            if (b != 3) {
                if (b == 5) {
                    l0.n(n, g(array, n2));
                    return n2 + 4;
                }
                throw A.c();
            }
            else {
                final l0 k = l0.k();
                final int n3 = (n & 0xFFFFFFF8) | 0x4;
                int a2 = 0;
                int h2;
                while (true) {
                    h2 = n2;
                    if (n2 >= h) {
                        break;
                    }
                    h2 = H(array, n2, a);
                    a2 = a.a;
                    if (a2 == n3) {
                        break;
                    }
                    n2 = F(a2, array, h2, h, k, a);
                }
                if (h2 <= h && a2 == n3) {
                    l0.n(n, k);
                    return h2;
                }
                throw A.h();
            }
        }
        else {
            h = H(array, n2, a);
            n2 = a.a;
            if (n2 < 0) {
                throw A.g();
            }
            if (n2 <= array.length - h) {
                if (n2 == 0) {
                    l0.n(n, h.b);
                }
                else {
                    l0.n(n, h.o(array, h, n2));
                }
                return h + n2;
            }
            throw A.m();
        }
    }
    
    static int G(int n, final byte[] array, int n2, final a a) {
        final int n3 = n & 0x7F;
        final int n4 = n2 + 1;
        n = array[n2];
        if (n >= 0) {
            a.a = (n3 | n << 7);
            return n4;
        }
        final int n5 = n3 | (n & 0x7F) << 7;
        n = n2 + 2;
        final byte b = array[n4];
        if (b >= 0) {
            a.a = (n5 | b << 14);
            return n;
        }
        final int n6 = n5 | (b & 0x7F) << 14;
        final int n7 = n2 + 3;
        n = array[n];
        if (n >= 0) {
            a.a = (n6 | n << 21);
            return n7;
        }
        final int n8 = n6 | (n & 0x7F) << 21;
        n = n2 + 4;
        final byte b2 = array[n7];
        if (b2 >= 0) {
            a.a = (n8 | b2 << 28);
            return n;
        }
        while (true) {
            n2 = n + 1;
            if (array[n] >= 0) {
                break;
            }
            n = n2;
        }
        a.a = (n8 | (b2 & 0x7F) << 28);
        return n2;
    }
    
    static int H(final byte[] array, int a, final a a2) {
        final int n = a + 1;
        a = array[a];
        if (a >= 0) {
            a2.a = a;
            return n;
        }
        return G(a, array, n, a2);
    }
    
    static int I(final int n, final byte[] array, int i, final int n2, final z.d d, final a a) {
        final y y = (y)d;
        i = H(array, i, a);
        y.c(a.a);
        while (i < n2) {
            final int h = H(array, i, a);
            if (n != a.a) {
                break;
            }
            i = H(array, h, a);
            y.c(a.a);
        }
        return i;
    }
    
    static int J(long b, final byte[] array, int n, final a a) {
        int n2;
        byte b2;
        for (n2 = n + 1, b2 = array[n], b = ((b & 0x7FL) | (long)(b2 & 0x7F) << 7), n = 7; b2 < 0; b2 = array[n2], n += 7, b |= (long)(b2 & 0x7F) << n, ++n2) {}
        a.b = b;
        return n2;
    }
    
    static int K(final byte[] array, final int n, final a a) {
        final int n2 = n + 1;
        final long b = array[n];
        if (b >= 0L) {
            a.b = b;
            return n2;
        }
        return J(b, array, n2, a);
    }
    
    static int L(final int n, final byte[] array, int i, final int n2, final z.d d, final a a) {
        final F f = (F)d;
        i = K(array, i, a);
        f.c(a.b);
        while (i < n2) {
            final int h = H(array, i, a);
            if (n != a.a) {
                break;
            }
            i = K(array, h, a);
            f.c(a.b);
        }
        return i;
    }
    
    static int M(final Object c, final e0 e0, final byte[] array, int g0, final int n, final int n2, final a a) {
        g0 = ((S)e0).g0(c, array, g0, n, n2, a);
        a.c = c;
        return g0;
    }
    
    static int N(final Object c, final e0 e0, final byte[] array, int g, int n, final a a) {
        final int n2 = g + 1;
        final byte b = array[g];
        g = n2;
        int a2 = b;
        if (b < 0) {
            g = G(b, array, n2, a);
            a2 = a.a;
        }
        if (a2 >= 0 && a2 <= n - g) {
            n = a2 + g;
            e0.h(c, array, g, n, a);
            a.c = c;
            return n;
        }
        throw A.m();
    }
    
    static int a(final int n, final byte[] array, int i, final int n2, final z.d d, final a a) {
        final f f = (f)d;
        i = K(array, i, a);
        f.c(a.b != 0L);
        while (i < n2) {
            final int h = H(array, i, a);
            if (n != a.a) {
                break;
            }
            i = K(array, h, a);
            f.c(a.b != 0L);
        }
        return i;
    }
    
    static int b(final byte[] array, int h, final a a) {
        h = H(array, h, a);
        final int a2 = a.a;
        if (a2 < 0) {
            throw A.g();
        }
        if (a2 > array.length - h) {
            throw A.m();
        }
        if (a2 == 0) {
            a.c = h.b;
            return h;
        }
        a.c = h.o(array, h, a2);
        return h + a2;
    }
    
    static int c(final int n, final byte[] array, int i, final int n2, final z.d d, final a a) {
        i = H(array, i, a);
        int n3 = a.a;
        if (n3 < 0) {
            throw A.g();
        }
        if (n3 <= array.length - i) {
            while (true) {
                Label_0063: {
                    if (n3 != 0) {
                        ((List)d).add((Object)h.o(array, i, n3));
                        break Label_0063;
                    }
                    ((List)d).add((Object)h.b);
                    while (i < n2) {
                        final int h = H(array, i, a);
                        if (n != a.a) {
                            break;
                        }
                        i = H(array, h, a);
                        n3 = a.a;
                        if (n3 < 0) {
                            throw A.g();
                        }
                        if (n3 > array.length - i) {
                            throw A.m();
                        }
                        if (n3 != 0) {
                            ((List)d).add((Object)com.google.crypto.tink.shaded.protobuf.h.o(array, i, n3));
                            break Label_0063;
                        }
                        ((List)d).add((Object)com.google.crypto.tink.shaded.protobuf.h.b);
                    }
                    return i;
                }
                i += n3;
                continue;
            }
        }
        throw A.m();
    }
    
    static double d(final byte[] array, final int n) {
        return Double.longBitsToDouble(i(array, n));
    }
    
    static int e(final int n, final byte[] array, int i, final int n2, final z.d d, final a a) {
        final m m = (m)d;
        m.c(d(array, i));
        int h;
        for (i += 8; i < n2; i = h + 8) {
            h = H(array, i, a);
            if (n != a.a) {
                break;
            }
            m.c(d(array, h));
        }
        return i;
    }
    
    static int f(final int n, final byte[] array, final int n2, final int n3, final Object o, final O o2, final k0 k0, final a a) {
        a.d.a(o2, n >>> 3);
        return F(n, array, n2, n3, S.w(o), a);
    }
    
    static int g(final byte[] array, final int n) {
        return (array[n + 3] & 0xFF) << 24 | ((array[n] & 0xFF) | (array[n + 1] & 0xFF) << 8 | (array[n + 2] & 0xFF) << 16);
    }
    
    static int h(final int n, final byte[] array, int i, final int n2, final z.d d, final a a) {
        final y y = (y)d;
        y.c(g(array, i));
        int h;
        for (i += 4; i < n2; i = h + 4) {
            h = H(array, i, a);
            if (n != a.a) {
                break;
            }
            y.c(g(array, h));
        }
        return i;
    }
    
    static long i(final byte[] array, final int n) {
        return ((long)array[n + 7] & 0xFFL) << 56 | (((long)array[n] & 0xFFL) | ((long)array[n + 1] & 0xFFL) << 8 | ((long)array[n + 2] & 0xFFL) << 16 | ((long)array[n + 3] & 0xFFL) << 24 | ((long)array[n + 4] & 0xFFL) << 32 | ((long)array[n + 5] & 0xFFL) << 40 | ((long)array[n + 6] & 0xFFL) << 48);
    }
    
    static int j(final int n, final byte[] array, int i, final int n2, final z.d d, final a a) {
        final F f = (F)d;
        f.c(i(array, i));
        int h;
        for (i += 8; i < n2; i = h + 8) {
            h = H(array, i, a);
            if (n != a.a) {
                break;
            }
            f.c(i(array, h));
        }
        return i;
    }
    
    static float k(final byte[] array, final int n) {
        return Float.intBitsToFloat(g(array, n));
    }
    
    static int l(final int n, final byte[] array, int i, final int n2, final z.d d, final a a) {
        final v v = (v)d;
        v.c(k(array, i));
        int h;
        for (i += 4; i < n2; i = h + 4) {
            h = H(array, i, a);
            if (n != a.a) {
                break;
            }
            v.c(k(array, h));
        }
        return i;
    }
    
    static int m(final e0 e0, final byte[] array, int m, final int n, final int n2, final a a) {
        final Object f = e0.f();
        m = M(f, e0, array, m, n, n2, a);
        e0.b(f);
        a.c = f;
        return m;
    }
    
    static int n(final e0 e0, final int n, final byte[] array, int i, final int n2, final z.d d, final a a) {
        final int n3 = (n & 0xFFFFFFF8) | 0x4;
        i = m(e0, array, i, n2, n3, a);
        ((List)d).add(a.c);
        while (i < n2) {
            final int h = H(array, i, a);
            if (n != a.a) {
                break;
            }
            i = m(e0, array, h, n2, n3, a);
            ((List)d).add(a.c);
        }
        return i;
    }
    
    static int o(final e0 e0, final byte[] array, int n, final int n2, final a a) {
        final Object f = e0.f();
        n = N(f, e0, array, n, n2, a);
        e0.b(f);
        a.c = f;
        return n;
    }
    
    static int p(final e0 e0, final int n, final byte[] array, int i, final int n2, final z.d d, final a a) {
        i = o(e0, array, i, n2, a);
        ((List)d).add(a.c);
        while (i < n2) {
            final int h = H(array, i, a);
            if (n != a.a) {
                break;
            }
            i = o(e0, array, h, n2, a);
            ((List)d).add(a.c);
        }
        return i;
    }
    
    static int q(final byte[] array, int i, final z.d d, final a a) {
        final f f = (f)d;
        i = H(array, i, a);
        final int n = a.a + i;
        while (i < n) {
            i = K(array, i, a);
            f.c(a.b != 0L);
        }
        if (i == n) {
            return i;
        }
        throw A.m();
    }
    
    static int r(final byte[] array, int i, final z.d d, final a a) {
        final m m = (m)d;
        int n;
        for (i = H(array, i, a), n = a.a + i; i < n; i += 8) {
            m.c(d(array, i));
        }
        if (i == n) {
            return i;
        }
        throw A.m();
    }
    
    static int s(final byte[] array, int i, final z.d d, final a a) {
        final y y = (y)d;
        int n;
        for (i = H(array, i, a), n = a.a + i; i < n; i += 4) {
            y.c(g(array, i));
        }
        if (i == n) {
            return i;
        }
        throw A.m();
    }
    
    static int t(final byte[] array, int i, final z.d d, final a a) {
        final F f = (F)d;
        int n;
        for (i = H(array, i, a), n = a.a + i; i < n; i += 8) {
            f.c(i(array, i));
        }
        if (i == n) {
            return i;
        }
        throw A.m();
    }
    
    static int u(final byte[] array, int i, final z.d d, final a a) {
        final v v = (v)d;
        int n;
        for (i = H(array, i, a), n = a.a + i; i < n; i += 4) {
            v.c(k(array, i));
        }
        if (i == n) {
            return i;
        }
        throw A.m();
    }
    
    static int v(final byte[] array, int i, final z.d d, final a a) {
        final y y = (y)d;
        i = H(array, i, a);
        final int n = a.a + i;
        while (i < n) {
            i = H(array, i, a);
            y.c(i.b(a.a));
        }
        if (i == n) {
            return i;
        }
        throw A.m();
    }
    
    static int w(final byte[] array, int i, final z.d d, final a a) {
        final F f = (F)d;
        i = H(array, i, a);
        final int n = a.a + i;
        while (i < n) {
            i = K(array, i, a);
            f.c(i.c(a.b));
        }
        if (i == n) {
            return i;
        }
        throw A.m();
    }
    
    static int x(final byte[] array, int i, final z.d d, final a a) {
        final y y = (y)d;
        i = H(array, i, a);
        final int n = a.a + i;
        while (i < n) {
            i = H(array, i, a);
            y.c(a.a);
        }
        if (i == n) {
            return i;
        }
        throw A.m();
    }
    
    static int y(final byte[] array, int i, final z.d d, final a a) {
        final F f = (F)d;
        i = H(array, i, a);
        final int n = a.a + i;
        while (i < n) {
            i = K(array, i, a);
            f.c(a.b);
        }
        if (i == n) {
            return i;
        }
        throw A.m();
    }
    
    static int z(final int n, final byte[] array, int i, final int n2, final z.d d, final a a) {
        final y y = (y)d;
        i = H(array, i, a);
        y.c(i.b(a.a));
        while (i < n2) {
            final int h = H(array, i, a);
            if (n != a.a) {
                break;
            }
            i = H(array, h, a);
            y.c(i.b(a.a));
        }
        return i;
    }
    
    static final class a
    {
        public int a;
        public long b;
        public Object c;
        public final p d;
        
        a(final p d) {
            d.getClass();
            this.d = d;
        }
    }
}
