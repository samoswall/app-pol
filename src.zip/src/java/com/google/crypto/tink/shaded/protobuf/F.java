package com.google.crypto.tink.shaded.protobuf;

import java.util.RandomAccess;

abstract class f extends c implements d, RandomAccess, Y
{
    public abstract void c(final boolean p0);
}
