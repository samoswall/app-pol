package com.google.crypto.tink.shaded.protobuf;

public abstract class g
{
    public abstract void a(final byte[] p0, final int p1, final int p2);
}
