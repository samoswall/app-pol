package com.google.crypto.tink.shaded.protobuf;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Locale;
import java.nio.charset.Charset;
import java.util.Comparator;
import java.io.Serializable;

public abstract class h implements Iterable, Serializable
{
    public static final h b;
    private static final f c;
    private static final Comparator d;
    private int a;
    
    static {
        b = new j(z.d);
        f c2;
        if (com.google.crypto.tink.shaded.protobuf.d.c()) {
            c2 = new k();
        }
        else {
            c2 = new d();
        }
        c = c2;
        d = (Comparator)new Comparator() {
            public int a(final h h, final h h2) {
                final g v = h.v();
                final g v2 = h2.v();
                while (((Iterator)v).hasNext() && ((Iterator)v2).hasNext()) {
                    final int compareTo = Integer.valueOf(C(v.b())).compareTo(Integer.valueOf(C(v2.b())));
                    if (compareTo != 0) {
                        return compareTo;
                    }
                }
                return Integer.valueOf(h.size()).compareTo(Integer.valueOf(h2.size()));
            }
        };
    }
    
    h() {
        this.a = 0;
    }
    
    private static int C(final byte b) {
        return b & 0xFF;
    }
    
    private String H() {
        String s;
        if (this.size() <= 50) {
            s = i0.a(this);
        }
        else {
            final StringBuilder sb = new StringBuilder();
            sb.append(i0.a(this.A(0, 47)));
            sb.append("...");
            s = sb.toString();
        }
        return s;
    }
    
    static h J(final byte[] array) {
        return new j(array);
    }
    
    static h K(final byte[] array, final int n, final int n2) {
        return new e(array, n, n2);
    }
    
    static void g(final int n, final int n2) {
        if ((n2 - (n + 1) | n) >= 0) {
            return;
        }
        if (n < 0) {
            final StringBuilder sb = new StringBuilder();
            sb.append("Index < 0: ");
            sb.append(n);
            throw new ArrayIndexOutOfBoundsException(sb.toString());
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("Index > length: ");
        sb2.append(n);
        sb2.append(", ");
        sb2.append(n2);
        throw new ArrayIndexOutOfBoundsException(sb2.toString());
    }
    
    static int j(final int n, final int n2, final int n3) {
        final int n4 = n2 - n;
        if ((n | n2 | n4 | n3 - n2) >= 0) {
            return n4;
        }
        if (n < 0) {
            final StringBuilder sb = new StringBuilder();
            sb.append("Beginning index: ");
            sb.append(n);
            sb.append(" < 0");
            throw new IndexOutOfBoundsException(sb.toString());
        }
        if (n2 < n) {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("Beginning index larger than ending index: ");
            sb2.append(n);
            sb2.append(", ");
            sb2.append(n2);
            throw new IndexOutOfBoundsException(sb2.toString());
        }
        final StringBuilder sb3 = new StringBuilder();
        sb3.append("End index: ");
        sb3.append(n2);
        sb3.append(" >= ");
        sb3.append(n3);
        throw new IndexOutOfBoundsException(sb3.toString());
    }
    
    public static h n(final byte[] array) {
        return o(array, 0, array.length);
    }
    
    public static h o(final byte[] array, final int n, final int n2) {
        j(n, n + n2, array.length);
        return new j(h.c.a(array, n, n2));
    }
    
    public static h p(final String s) {
        return new j(s.getBytes(z.b));
    }
    
    static h w(final int n) {
        return new h(n);
    }
    
    public abstract h A(final int p0, final int p1);
    
    public final byte[] B() {
        final int size = this.size();
        if (size == 0) {
            return z.d;
        }
        final byte[] array = new byte[size];
        this.q(array, 0, 0, size);
        return array;
    }
    
    public final String D(final Charset charset) {
        String f;
        if (this.size() == 0) {
            f = "";
        }
        else {
            f = this.F(charset);
        }
        return f;
    }
    
    protected abstract String F(final Charset p0);
    
    public final String G() {
        return this.D(z.b);
    }
    
    abstract void M(final com.google.crypto.tink.shaded.protobuf.g p0);
    
    public abstract byte c(final int p0);
    
    @Override
    public abstract boolean equals(final Object p0);
    
    @Override
    public final int hashCode() {
        int a;
        if ((a = this.a) == 0) {
            final int size = this.size();
            if ((a = this.y(size, 0, size)) == 0) {
                a = 1;
            }
            this.a = a;
        }
        return a;
    }
    
    protected abstract void q(final byte[] p0, final int p1, final int p2, final int p3);
    
    abstract byte s(final int p0);
    
    public abstract int size();
    
    @Override
    public final String toString() {
        return String.format(Locale.ROOT, "<ByteString@%s size=%d contents=\"%s\">", new Object[] { Integer.toHexString(System.identityHashCode((Object)this)), this.size(), this.H() });
    }
    
    public abstract boolean u();
    
    public g v() {
        return (g)new c(this) {
            private int a = 0;
            private final int b = c.size();
            final h c;
            
            @Override
            public byte b() {
                final int a = this.a;
                if (a < this.b) {
                    this.a = a + 1;
                    return this.c.s(a);
                }
                throw new NoSuchElementException();
            }
            
            public boolean hasNext() {
                return this.a < this.b;
            }
        };
    }
    
    public abstract com.google.crypto.tink.shaded.protobuf.i x();
    
    protected abstract int y(final int p0, final int p1, final int p2);
    
    protected final int z() {
        return this.a;
    }
    
    abstract static class c implements g
    {
        public final Byte a() {
            return ((g)this).b();
        }
        
        public final void remove() {
            throw new UnsupportedOperationException();
        }
    }
    
    public interface g extends Iterator
    {
        byte b();
    }
    
    private static final class d implements f
    {
        @Override
        public byte[] a(final byte[] array, final int n, final int n2) {
            return Arrays.copyOfRange(array, n, n2 + n);
        }
    }
    
    private static final class e extends j
    {
        private final int f;
        private final int g;
        
        e(final byte[] array, final int f, final int g) {
            super(array);
            h.j(f, f + g, array.length);
            this.f = f;
            this.g = g;
        }
        
        @Override
        protected int O() {
            return this.f;
        }
        
        @Override
        public byte c(final int n) {
            h.g(n, this.size());
            return super.e[this.f + n];
        }
        
        @Override
        protected void q(final byte[] array, final int n, final int n2, final int n3) {
            System.arraycopy((Object)super.e, this.O() + n, (Object)array, n2, n3);
        }
        
        @Override
        byte s(final int n) {
            return super.e[this.f + n];
        }
        
        @Override
        public int size() {
            return this.g;
        }
    }
    
    private interface f
    {
        byte[] a(final byte[] p0, final int p1, final int p2);
    }
    
    static final class h
    {
        private final com.google.crypto.tink.shaded.protobuf.k a;
        private final byte[] b;
        
        private h(final int n) {
            final byte[] b = new byte[n];
            this.b = b;
            this.a = com.google.crypto.tink.shaded.protobuf.k.U(b);
        }
        
        public com.google.crypto.tink.shaded.protobuf.h a() {
            this.a.c();
            return new j(this.b);
        }
        
        public com.google.crypto.tink.shaded.protobuf.k b() {
            return this.a;
        }
    }
    
    abstract static class i extends h
    {
    }
    
    private static class j extends i
    {
        protected final byte[] e;
        
        j(final byte[] e) {
            e.getClass();
            this.e = e;
        }
        
        @Override
        public final h A(final int n, int j) {
            j = h.j(n, j, this.size());
            if (j == 0) {
                return h.b;
            }
            return new e(this.e, this.O() + n, j);
        }
        
        @Override
        protected final String F(final Charset charset) {
            return new String(this.e, this.O(), this.size(), charset);
        }
        
        @Override
        final void M(final com.google.crypto.tink.shaded.protobuf.g g) {
            g.a(this.e, this.O(), this.size());
        }
        
        final boolean N(final h h, int n, final int n2) {
            if (n2 > h.size()) {
                final StringBuilder sb = new StringBuilder();
                sb.append("Length too large: ");
                sb.append(n2);
                sb.append(this.size());
                throw new IllegalArgumentException(sb.toString());
            }
            final int n3 = n + n2;
            if (n3 > h.size()) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("Ran off end of other: ");
                sb2.append(n);
                sb2.append(", ");
                sb2.append(n2);
                sb2.append(", ");
                sb2.append(h.size());
                throw new IllegalArgumentException(sb2.toString());
            }
            if (h instanceof j) {
                final j j = (j)h;
                final byte[] e = this.e;
                final byte[] e2 = j.e;
                int o;
                int i;
                for (o = this.O(), i = this.O(), n += j.O(); i < o + n2; ++i, ++n) {
                    if (e[i] != e2[n]) {
                        return false;
                    }
                }
                return true;
            }
            return h.A(n, n3).equals(this.A(0, n2));
        }
        
        protected int O() {
            return 0;
        }
        
        @Override
        public byte c(final int n) {
            return this.e[n];
        }
        
        @Override
        public final boolean equals(final Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof h)) {
                return false;
            }
            if (this.size() != ((h)o).size()) {
                return false;
            }
            if (this.size() == 0) {
                return true;
            }
            if (o instanceof j) {
                final j j = (j)o;
                final int z = this.z();
                final int z2 = j.z();
                return (z == 0 || z2 == 0 || z == z2) && this.N(j, 0, this.size());
            }
            return o.equals(this);
        }
        
        @Override
        protected void q(final byte[] array, final int n, final int n2, final int n3) {
            System.arraycopy((Object)this.e, n, (Object)array, n2, n3);
        }
        
        @Override
        byte s(final int n) {
            return this.e[n];
        }
        
        @Override
        public int size() {
            return this.e.length;
        }
        
        @Override
        public final boolean u() {
            final int o = this.O();
            return p0.n(this.e, o, this.size() + o);
        }
        
        @Override
        public final com.google.crypto.tink.shaded.protobuf.i x() {
            return com.google.crypto.tink.shaded.protobuf.i.j(this.e, this.O(), this.size(), true);
        }
        
        @Override
        protected final int y(final int n, final int n2, final int n3) {
            return z.h(n, this.e, this.O() + n2, n3);
        }
    }
    
    private static final class k implements f
    {
        @Override
        public byte[] a(final byte[] array, final int n, final int n2) {
            final byte[] array2 = new byte[n2];
            System.arraycopy((Object)array, n, (Object)array2, 0, n2);
            return array2;
        }
    }
}
