package com.google.crypto.tink.shaded.protobuf;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Arrays;
import java.io.InputStream;

public abstract class i
{
    private static volatile int f = 100;
    int a;
    int b;
    int c;
    j d;
    private boolean e;
    
    private i() {
        this.b = i.f;
        this.c = Integer.MAX_VALUE;
        this.e = false;
    }
    
    public static int b(final int n) {
        return -(n & 0x1) ^ n >>> 1;
    }
    
    public static long c(final long n) {
        return -(n & 0x1L) ^ n >>> 1;
    }
    
    public static i f(final InputStream inputStream) {
        return g(inputStream, 4096);
    }
    
    public static i g(final InputStream inputStream, final int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("bufferSize must be > 0");
        }
        if (inputStream == null) {
            return h(z.d);
        }
        return new c(inputStream, n);
    }
    
    public static i h(final byte[] array) {
        return i(array, 0, array.length);
    }
    
    public static i i(final byte[] array, final int n, final int n2) {
        return j(array, n, n2, false);
    }
    
    static i j(final byte[] array, final int n, final int n2, final boolean b) {
        final b b2 = new b(array, n, n2, b);
        try {
            b2.l(n2);
            return b2;
        }
        catch (final A a) {
            throw new IllegalArgumentException((Throwable)a);
        }
    }
    
    public abstract String A();
    
    public abstract int B();
    
    public abstract int C();
    
    public abstract long D();
    
    public abstract boolean E(final int p0);
    
    public abstract void a(final int p0);
    
    public abstract int d();
    
    public abstract boolean e();
    
    public abstract void k(final int p0);
    
    public abstract int l(final int p0);
    
    public abstract boolean m();
    
    public abstract h n();
    
    public abstract double o();
    
    public abstract int p();
    
    public abstract int q();
    
    public abstract long r();
    
    public abstract float s();
    
    public abstract int t();
    
    public abstract long u();
    
    public abstract int v();
    
    public abstract long w();
    
    public abstract int x();
    
    public abstract long y();
    
    public abstract String z();
    
    private static final class b extends i
    {
        private final byte[] g;
        private final boolean h;
        private int i;
        private int j;
        private int k;
        private int l;
        private int m;
        private boolean n;
        private int o;
        
        private b(final byte[] g, final int n, final int n2, final boolean h) {
            super(null);
            this.o = Integer.MAX_VALUE;
            this.g = g;
            this.i = n2 + n;
            this.k = n;
            this.l = n;
            this.h = h;
        }
        
        private void M() {
            final int i = this.i + this.j;
            this.i = i;
            final int n = i - this.l;
            final int o = this.o;
            if (n > o) {
                final int j = n - o;
                this.j = j;
                this.i = i - j;
            }
            else {
                this.j = 0;
            }
        }
        
        private void P() {
            if (this.i - this.k >= 10) {
                this.Q();
            }
            else {
                this.R();
            }
        }
        
        private void Q() {
            for (int i = 0; i < 10; ++i) {
                if (this.g[this.k++] >= 0) {
                    return;
                }
            }
            throw A.f();
        }
        
        private void R() {
            for (int i = 0; i < 10; ++i) {
                if (this.F() >= 0) {
                    return;
                }
            }
            throw A.f();
        }
        
        @Override
        public String A() {
            final int j = this.J();
            if (j > 0) {
                final int i = this.i;
                final int k = this.k;
                if (j <= i - k) {
                    final String e = p0.e(this.g, k, j);
                    this.k += j;
                    return e;
                }
            }
            if (j == 0) {
                return "";
            }
            if (j <= 0) {
                throw A.g();
            }
            throw A.m();
        }
        
        @Override
        public int B() {
            if (this.e()) {
                return this.m = 0;
            }
            final int j = this.J();
            this.m = j;
            if (q0.a(j) != 0) {
                return this.m;
            }
            throw A.c();
        }
        
        @Override
        public int C() {
            return this.J();
        }
        
        @Override
        public long D() {
            return this.K();
        }
        
        @Override
        public boolean E(final int n) {
            final int b = q0.b(n);
            if (b == 0) {
                this.P();
                return true;
            }
            if (b == 1) {
                this.O(8);
                return true;
            }
            if (b == 2) {
                this.O(this.J());
                return true;
            }
            if (b == 3) {
                this.N();
                this.a(q0.c(q0.a(n), 4));
                return true;
            }
            if (b == 4) {
                return false;
            }
            if (b == 5) {
                this.O(4);
                return true;
            }
            throw A.e();
        }
        
        public byte F() {
            final int k = this.k;
            if (k != this.i) {
                final byte[] g = this.g;
                this.k = k + 1;
                return g[k];
            }
            throw A.m();
        }
        
        public byte[] G(int k) {
            if (k > 0) {
                final int i = this.i;
                final int j = this.k;
                if (k <= i - j) {
                    k += j;
                    this.k = k;
                    return Arrays.copyOfRange(this.g, j, k);
                }
            }
            if (k > 0) {
                throw A.m();
            }
            if (k == 0) {
                return z.d;
            }
            throw A.g();
        }
        
        public int H() {
            final int k = this.k;
            if (this.i - k >= 4) {
                final byte[] g = this.g;
                this.k = k + 4;
                return (g[k] & 0xFF) | (g[k + 1] & 0xFF) << 8 | (g[k + 2] & 0xFF) << 16 | (g[k + 3] & 0xFF) << 24;
            }
            throw A.m();
        }
        
        public long I() {
            final int k = this.k;
            if (this.i - k >= 8) {
                final byte[] g = this.g;
                this.k = k + 8;
                return ((long)g[k + 7] & 0xFFL) << 56 | (((long)g[k] & 0xFFL) | ((long)g[k + 1] & 0xFFL) << 8 | ((long)g[k + 2] & 0xFFL) << 16 | ((long)g[k + 3] & 0xFFL) << 24 | ((long)g[k + 4] & 0xFFL) << 32 | ((long)g[k + 5] & 0xFFL) << 40 | ((long)g[k + 6] & 0xFFL) << 48);
            }
            throw A.m();
        }
        
        public int J() {
            final int k = this.k;
            final int i = this.i;
            if (i != k) {
                final byte[] g = this.g;
                final int j = k + 1;
                final byte b = g[k];
                if (b >= 0) {
                    this.k = j;
                    return b;
                }
                if (i - j >= 9) {
                    int l = k + 2;
                    final int n = g[j] << 7 ^ b;
                    int n2 = 0;
                    Label_0282: {
                        if (n < 0) {
                            n2 = (n ^ 0xFFFFFF80);
                        }
                        else {
                            final int n3 = k + 3;
                            final int n4 = g[l] << 14 ^ n;
                            int n8 = 0;
                            int n9 = 0;
                            Label_0113: {
                                if (n4 < 0) {
                                    int n5 = k + 4;
                                    final int n6 = n4 ^ g[n3] << 21;
                                    Label_0146: {
                                        if (n6 >= 0) {
                                            final int n7 = k + 5;
                                            final byte b2 = g[n5];
                                            n8 = (n6 ^ b2 << 28 ^ 0xFE03F80);
                                            n9 = n7;
                                            Label_0276: {
                                                if (b2 < 0) {
                                                    final int n10 = n5 = k + 6;
                                                    if (g[n7] < 0) {
                                                        n9 = k + 7;
                                                        if (g[n10] >= 0) {
                                                            break Label_0276;
                                                        }
                                                        final int n11 = n5 = k + 8;
                                                        if (g[n9] < 0) {
                                                            final int n12 = n9 = k + 9;
                                                            if (g[n11] >= 0) {
                                                                break Label_0276;
                                                            }
                                                            if (g[n12] < 0) {
                                                                return (int)this.L();
                                                            }
                                                            final int n13 = k + 10;
                                                            n2 = n8;
                                                            l = n13;
                                                            break Label_0282;
                                                        }
                                                    }
                                                    break Label_0146;
                                                }
                                            }
                                            break Label_0113;
                                        }
                                        n8 = (0xFFE03F80 ^ n6);
                                    }
                                    final int n14 = n5;
                                    n2 = n8;
                                    l = n14;
                                    break Label_0282;
                                }
                                n8 = (n4 ^ 0x3F80);
                                n9 = n3;
                            }
                            final int n15 = n9;
                            n2 = n8;
                            l = n15;
                        }
                    }
                    this.k = l;
                    return n2;
                }
            }
            return (int)this.L();
        }
        
        public long K() {
            final int k = this.k;
            final int i = this.i;
            if (i != k) {
                final byte[] g = this.g;
                final int j = k + 1;
                final byte b = g[k];
                if (b >= 0) {
                    this.k = j;
                    return b;
                }
                if (i - j >= 9) {
                    int l = k + 2;
                    final int n = g[j] << 7 ^ b;
                    long n2 = 0L;
                    Label_0359: {
                        if (n < 0) {
                            n2 = (n ^ 0xFFFFFF80);
                        }
                        else {
                            final int n3 = k + 3;
                            final int n4 = g[l] << 14 ^ n;
                            if (n4 >= 0) {
                                n2 = (n4 ^ 0x3F80);
                                l = n3;
                            }
                            else {
                                l = k + 4;
                                final int n5 = n4 ^ g[n3] << 21;
                                if (n5 < 0) {
                                    n2 = (0xFFE03F80 ^ n5);
                                }
                                else {
                                    final long n6 = n5;
                                    final int n7 = k + 5;
                                    long n8 = n6 ^ (long)g[l] << 28;
                                    long n12 = 0L;
                                    Label_0190: {
                                        if (n8 < 0L) {
                                            l = k + 6;
                                            long n9 = n8 ^ (long)g[n7] << 35;
                                            long n10;
                                            if (n9 < 0L) {
                                                n10 = -34093383808L;
                                            }
                                            else {
                                                final int n11 = k + 7;
                                                n8 = (n9 ^ (long)g[l] << 42);
                                                if (n8 >= 0L) {
                                                    n12 = 4363953127296L;
                                                    l = n11;
                                                    break Label_0190;
                                                }
                                                l = k + 8;
                                                n9 = (n8 ^ (long)g[n11] << 49);
                                                if (n9 < 0L) {
                                                    n10 = -558586000294016L;
                                                }
                                                else {
                                                    final int n13 = k + 9;
                                                    n2 = (n9 ^ (long)g[l] << 56 ^ 0xFE03F80FE03F80L);
                                                    l = n13;
                                                    if (n2 >= 0L) {
                                                        break Label_0359;
                                                    }
                                                    if (g[n13] < 0L) {
                                                        return this.L();
                                                    }
                                                    l = k + 10;
                                                    break Label_0359;
                                                }
                                            }
                                            n2 = (n9 ^ n10);
                                            break Label_0359;
                                        }
                                        n12 = 266354560L;
                                        l = n7;
                                    }
                                    n2 = (n8 ^ n12);
                                }
                            }
                        }
                    }
                    this.k = l;
                    return n2;
                }
            }
            return this.L();
        }
        
        long L() {
            long n = 0L;
            for (int i = 0; i < 64; i += 7) {
                final byte f = this.F();
                n |= (long)(f & 0x7F) << i;
                if ((f & 0x80) == 0x0) {
                    return n;
                }
            }
            throw A.f();
        }
        
        public void N() {
            int b;
            do {
                b = this.B();
            } while (b != 0 && this.E(b));
        }
        
        public void O(final int n) {
            if (n >= 0) {
                final int i = this.i;
                final int k = this.k;
                if (n <= i - k) {
                    this.k = k + n;
                    return;
                }
            }
            if (n < 0) {
                throw A.g();
            }
            throw A.m();
        }
        
        @Override
        public void a(final int n) {
            if (this.m == n) {
                return;
            }
            throw A.b();
        }
        
        @Override
        public int d() {
            return this.k - this.l;
        }
        
        @Override
        public boolean e() {
            return this.k == this.i;
        }
        
        @Override
        public void k(final int o) {
            this.o = o;
            this.M();
        }
        
        @Override
        public int l(int o) {
            if (o < 0) {
                throw A.g();
            }
            o += this.d();
            if (o < 0) {
                throw A.h();
            }
            final int o2 = this.o;
            if (o <= o2) {
                this.o = o;
                this.M();
                return o2;
            }
            throw A.m();
        }
        
        @Override
        public boolean m() {
            return this.K() != 0L;
        }
        
        @Override
        public h n() {
            final int j = this.J();
            if (j > 0) {
                final int i = this.i;
                final int k = this.k;
                if (j <= i - k) {
                    h h;
                    if (this.h && this.n) {
                        h = com.google.crypto.tink.shaded.protobuf.h.K(this.g, k, j);
                    }
                    else {
                        h = com.google.crypto.tink.shaded.protobuf.h.o(this.g, k, j);
                    }
                    this.k += j;
                    return h;
                }
            }
            if (j == 0) {
                return com.google.crypto.tink.shaded.protobuf.h.b;
            }
            return com.google.crypto.tink.shaded.protobuf.h.J(this.G(j));
        }
        
        @Override
        public double o() {
            return Double.longBitsToDouble(this.I());
        }
        
        @Override
        public int p() {
            return this.J();
        }
        
        @Override
        public int q() {
            return this.H();
        }
        
        @Override
        public long r() {
            return this.I();
        }
        
        @Override
        public float s() {
            return Float.intBitsToFloat(this.H());
        }
        
        @Override
        public int t() {
            return this.J();
        }
        
        @Override
        public long u() {
            return this.K();
        }
        
        @Override
        public int v() {
            return this.H();
        }
        
        @Override
        public long w() {
            return this.I();
        }
        
        @Override
        public int x() {
            return com.google.crypto.tink.shaded.protobuf.i.b(this.J());
        }
        
        @Override
        public long y() {
            return com.google.crypto.tink.shaded.protobuf.i.c(this.K());
        }
        
        @Override
        public String z() {
            final int j = this.J();
            if (j > 0) {
                final int i = this.i;
                final int k = this.k;
                if (j <= i - k) {
                    final String s = new String(this.g, k, j, z.b);
                    this.k += j;
                    return s;
                }
            }
            if (j == 0) {
                return "";
            }
            if (j < 0) {
                throw A.g();
            }
            throw A.m();
        }
    }
    
    private static final class c extends i
    {
        private final InputStream g;
        private final byte[] h;
        private int i;
        private int j;
        private int k;
        private int l;
        private int m;
        private int n;
        
        private c(final InputStream g, final int n) {
            super(null);
            this.n = Integer.MAX_VALUE;
            z.b(g, "input");
            this.g = g;
            this.h = new byte[n];
            this.i = 0;
            this.k = 0;
            this.m = 0;
        }
        
        private static int F(final InputStream inputStream) {
            try {
                return inputStream.available();
            }
            catch (final A a) {
                a.j();
                throw a;
            }
        }
        
        private static int G(final InputStream inputStream, final byte[] array, int read, final int n) {
            try {
                read = inputStream.read(array, read, n);
                return read;
            }
            catch (final A a) {
                a.j();
                throw a;
            }
        }
        
        private h H(int n) {
            final byte[] k = this.K(n);
            if (k != null) {
                return com.google.crypto.tink.shaded.protobuf.h.n(k);
            }
            final int i = this.k;
            final int j = this.i;
            final int n2 = j - i;
            this.m += j;
            this.k = 0;
            this.i = 0;
            final List l = this.L(n - n2);
            final byte[] array = new byte[n];
            System.arraycopy((Object)this.h, i, (Object)array, 0, n2);
            final Iterator iterator = l.iterator();
            n = n2;
            while (iterator.hasNext()) {
                final byte[] array2 = (byte[])iterator.next();
                System.arraycopy((Object)array2, 0, (Object)array, n, array2.length);
                n += array2.length;
            }
            return com.google.crypto.tink.shaded.protobuf.h.J(array);
        }
        
        private byte[] J(int n, final boolean b) {
            final byte[] k = this.K(n);
            if (k != null) {
                byte[] array = k;
                if (b) {
                    array = k.clone();
                }
                return array;
            }
            final int i = this.k;
            final int j = this.i;
            final int n2 = j - i;
            this.m += j;
            this.k = 0;
            this.i = 0;
            final List l = this.L(n - n2);
            final byte[] array2 = new byte[n];
            System.arraycopy((Object)this.h, i, (Object)array2, 0, n2);
            final Iterator iterator = l.iterator();
            n = n2;
            while (iterator.hasNext()) {
                final byte[] array3 = (byte[])iterator.next();
                System.arraycopy((Object)array3, 0, (Object)array2, n, array3.length);
                n += array3.length;
            }
            return array2;
        }
        
        private byte[] K(final int n) {
            if (n == 0) {
                return z.d;
            }
            if (n < 0) {
                throw A.g();
            }
            final int m = this.m;
            final int k = this.k;
            final int n2 = m + k + n;
            if (n2 - super.c > 0) {
                throw A.l();
            }
            final int n3 = this.n;
            if (n2 > n3) {
                this.V(n3 - m - k);
                throw A.m();
            }
            int i = this.i - k;
            final int n4 = n - i;
            if (n4 >= 4096 && n4 > F(this.g)) {
                return null;
            }
            final byte[] array = new byte[n];
            System.arraycopy((Object)this.h, this.k, (Object)array, 0, i);
            this.m += this.i;
            this.k = 0;
            this.i = 0;
            while (i < n) {
                final int g = G(this.g, array, i, n - i);
                if (g == -1) {
                    throw A.m();
                }
                this.m += g;
                i += g;
            }
            return array;
        }
        
        private List L(int i) {
            final ArrayList list = new ArrayList();
            while (i > 0) {
                final int min = Math.min(i, 4096);
                final byte[] array = new byte[min];
                int read;
                for (int j = 0; j < min; j += read) {
                    read = this.g.read(array, j, min - j);
                    if (read == -1) {
                        throw A.m();
                    }
                    this.m += read;
                }
                i -= min;
                ((List)list).add((Object)array);
            }
            return (List)list;
        }
        
        private void R() {
            final int i = this.i + this.j;
            this.i = i;
            final int n = this.m + i;
            final int n2 = this.n;
            if (n > n2) {
                final int j = n - n2;
                this.j = j;
                this.i = i - j;
            }
            else {
                this.j = 0;
            }
        }
        
        private void S(final int n) {
            if (this.a0(n)) {
                return;
            }
            if (n > super.c - this.m - this.k) {
                throw A.l();
            }
            throw A.m();
        }
        
        private static long T(final InputStream inputStream, long skip) {
            try {
                skip = inputStream.skip(skip);
                return skip;
            }
            catch (final A a) {
                a.j();
                throw a;
            }
        }
        
        private void W(final int n) {
            if (n < 0) {
                throw A.g();
            }
            final int m = this.m;
            final int k = this.k;
            final int n2 = this.n;
            if (m + k + n <= n2) {
                this.m = m + k;
                int i = this.i - k;
                this.i = 0;
                this.k = 0;
                while (i < n) {
                    try {
                        final InputStream g = this.g;
                        final long n3 = n - i;
                        final long t = T(g, n3);
                        final long n4 = lcmp(t, 0L);
                        if (n4 < 0 || t > n3) {
                            final StringBuilder sb = new StringBuilder();
                            sb.append((Object)this.g.getClass());
                            sb.append("#skip returned invalid result: ");
                            sb.append(t);
                            sb.append("\nThe InputStream implementation is buggy.");
                            throw new IllegalStateException(sb.toString());
                        }
                        if (n4 != 0) {
                            i += (int)t;
                            continue;
                        }
                    }
                    finally {
                        this.m += i;
                        this.R();
                    }
                    break;
                }
                this.m += i;
                this.R();
                if (i < n) {
                    final int j = this.i;
                    int n5 = j - this.k;
                    this.k = j;
                    this.S(1);
                    int l;
                    while (true) {
                        l = n - n5;
                        final int i2 = this.i;
                        if (l <= i2) {
                            break;
                        }
                        n5 += i2;
                        this.k = i2;
                        this.S(1);
                    }
                    this.k = l;
                }
                return;
            }
            this.V(n2 - m - k);
            throw A.m();
        }
        
        private void X() {
            if (this.i - this.k >= 10) {
                this.Y();
            }
            else {
                this.Z();
            }
        }
        
        private void Y() {
            for (int i = 0; i < 10; ++i) {
                if (this.h[this.k++] >= 0) {
                    return;
                }
            }
            throw A.f();
        }
        
        private void Z() {
            for (int i = 0; i < 10; ++i) {
                if (this.I() >= 0) {
                    return;
                }
            }
            throw A.f();
        }
        
        private boolean a0(final int n) {
            final int k = this.k;
            final int i = this.i;
            if (k + n <= i) {
                final StringBuilder sb = new StringBuilder();
                sb.append("refillBuffer() called when ");
                sb.append(n);
                sb.append(" bytes were already available in buffer");
                throw new IllegalStateException(sb.toString());
            }
            final int c = super.c;
            final int m = this.m;
            if (n > c - m - k) {
                return false;
            }
            if (m + k + n > this.n) {
                return false;
            }
            if (k > 0) {
                if (i > k) {
                    final byte[] h = this.h;
                    System.arraycopy((Object)h, k, (Object)h, 0, i - k);
                }
                this.m += k;
                this.i -= k;
                this.k = 0;
            }
            final InputStream g = this.g;
            final byte[] h2 = this.h;
            final int j = this.i;
            final int g2 = G(g, h2, j, Math.min(h2.length - j, super.c - this.m - j));
            if (g2 == 0 || g2 < -1 || g2 > this.h.length) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append((Object)this.g.getClass());
                sb2.append("#read(byte[]) returned invalid result: ");
                sb2.append(g2);
                sb2.append("\nThe InputStream implementation is buggy.");
                throw new IllegalStateException(sb2.toString());
            }
            if (g2 > 0) {
                this.i += g2;
                this.R();
                return this.i >= n || this.a0(n);
            }
            return false;
        }
        
        @Override
        public String A() {
            final int o = this.O();
            int k = this.k;
            final int i = this.i;
            byte[] array;
            if (o <= i - k && o > 0) {
                array = this.h;
                this.k = k + o;
            }
            else {
                if (o == 0) {
                    return "";
                }
                k = 0;
                if (o <= i) {
                    this.S(o);
                    array = this.h;
                    this.k = o;
                }
                else {
                    array = this.J(o, false);
                }
            }
            return p0.e(array, k, o);
        }
        
        @Override
        public int B() {
            if (this.e()) {
                return this.l = 0;
            }
            final int o = this.O();
            this.l = o;
            if (q0.a(o) != 0) {
                return this.l;
            }
            throw A.c();
        }
        
        @Override
        public int C() {
            return this.O();
        }
        
        @Override
        public long D() {
            return this.P();
        }
        
        @Override
        public boolean E(final int n) {
            final int b = q0.b(n);
            if (b == 0) {
                this.X();
                return true;
            }
            if (b == 1) {
                this.V(8);
                return true;
            }
            if (b == 2) {
                this.V(this.O());
                return true;
            }
            if (b == 3) {
                this.U();
                this.a(q0.c(q0.a(n), 4));
                return true;
            }
            if (b == 4) {
                return false;
            }
            if (b == 5) {
                this.V(4);
                return true;
            }
            throw A.e();
        }
        
        public byte I() {
            if (this.k == this.i) {
                this.S(1);
            }
            return this.h[this.k++];
        }
        
        public int M() {
            int n;
            if (this.i - (n = this.k) < 4) {
                this.S(4);
                n = this.k;
            }
            final byte[] h = this.h;
            this.k = n + 4;
            return (h[n] & 0xFF) | (h[n + 1] & 0xFF) << 8 | (h[n + 2] & 0xFF) << 16 | (h[n + 3] & 0xFF) << 24;
        }
        
        public long N() {
            int n;
            if (this.i - (n = this.k) < 8) {
                this.S(8);
                n = this.k;
            }
            final byte[] h = this.h;
            this.k = n + 8;
            return ((long)h[n + 7] & 0xFFL) << 56 | (((long)h[n] & 0xFFL) | ((long)h[n + 1] & 0xFFL) << 8 | ((long)h[n + 2] & 0xFFL) << 16 | ((long)h[n + 3] & 0xFFL) << 24 | ((long)h[n + 4] & 0xFFL) << 32 | ((long)h[n + 5] & 0xFFL) << 40 | ((long)h[n + 6] & 0xFFL) << 48);
        }
        
        public int O() {
            final int k = this.k;
            final int i = this.i;
            if (i != k) {
                final byte[] h = this.h;
                final int j = k + 1;
                final byte b = h[k];
                if (b >= 0) {
                    this.k = j;
                    return b;
                }
                if (i - j >= 9) {
                    int l = k + 2;
                    final int n = h[j] << 7 ^ b;
                    int n2 = 0;
                    Label_0287: {
                        if (n < 0) {
                            n2 = (n ^ 0xFFFFFF80);
                        }
                        else {
                            final int n3 = k + 3;
                            final int n4 = h[l] << 14 ^ n;
                            int n8 = 0;
                            int n9 = 0;
                            Label_0113: {
                                if (n4 < 0) {
                                    int n5 = k + 4;
                                    final int n6 = n4 ^ h[n3] << 21;
                                    Label_0147: {
                                        if (n6 >= 0) {
                                            final int n7 = k + 5;
                                            final byte b2 = h[n5];
                                            n8 = (n6 ^ b2 << 28 ^ 0xFE03F80);
                                            n9 = n7;
                                            Label_0281: {
                                                if (b2 < 0) {
                                                    final int n10 = n5 = k + 6;
                                                    if (h[n7] < 0) {
                                                        n9 = k + 7;
                                                        if (h[n10] >= 0) {
                                                            break Label_0281;
                                                        }
                                                        final int n11 = n5 = k + 8;
                                                        if (h[n9] < 0) {
                                                            final int n12 = n9 = k + 9;
                                                            if (h[n11] >= 0) {
                                                                break Label_0281;
                                                            }
                                                            if (h[n12] < 0) {
                                                                return (int)this.Q();
                                                            }
                                                            final int n13 = k + 10;
                                                            n2 = n8;
                                                            l = n13;
                                                            break Label_0287;
                                                        }
                                                    }
                                                    break Label_0147;
                                                }
                                            }
                                            break Label_0113;
                                        }
                                        n8 = (0xFFE03F80 ^ n6);
                                    }
                                    final int n14 = n5;
                                    n2 = n8;
                                    l = n14;
                                    break Label_0287;
                                }
                                n8 = (n4 ^ 0x3F80);
                                n9 = n3;
                            }
                            final int n15 = n9;
                            n2 = n8;
                            l = n15;
                        }
                    }
                    this.k = l;
                    return n2;
                }
            }
            return (int)this.Q();
        }
        
        public long P() {
            final int k = this.k;
            final int i = this.i;
            if (i != k) {
                final byte[] h = this.h;
                final int j = k + 1;
                final byte b = h[k];
                if (b >= 0) {
                    this.k = j;
                    return b;
                }
                if (i - j >= 9) {
                    final int n = k + 2;
                    final int n2 = h[j] << 7 ^ b;
                    long n3 = 0L;
                    int l = 0;
                    Label_0363: {
                        if (n2 < 0) {
                            n3 = (n2 ^ 0xFFFFFF80);
                            l = n;
                        }
                        else {
                            l = k + 3;
                            final int n4 = h[n] << 14 ^ n2;
                            if (n4 >= 0) {
                                n3 = (n4 ^ 0x3F80);
                            }
                            else {
                                final int n5 = k + 4;
                                final int n6 = n4 ^ h[l] << 21;
                                if (n6 < 0) {
                                    n3 = (0xFFE03F80 ^ n6);
                                    l = n5;
                                }
                                else {
                                    final long n7 = n6;
                                    l = k + 5;
                                    long n8 = n7 ^ (long)h[n5] << 28;
                                    long n13 = 0L;
                                    Label_0187: {
                                        if (n8 < 0L) {
                                            final int n9 = k + 6;
                                            long n10 = n8 ^ (long)h[l] << 35;
                                            long n11;
                                            if (n10 < 0L) {
                                                n11 = -34093383808L;
                                                l = n9;
                                            }
                                            else {
                                                final int n12 = k + 7;
                                                n8 = (n10 ^ (long)h[n9] << 42);
                                                if (n8 >= 0L) {
                                                    n13 = 4363953127296L;
                                                    l = n12;
                                                    break Label_0187;
                                                }
                                                l = k + 8;
                                                n10 = (n8 ^ (long)h[n12] << 49);
                                                if (n10 < 0L) {
                                                    n11 = -558586000294016L;
                                                }
                                                else {
                                                    final int n14 = k + 9;
                                                    n3 = (n10 ^ (long)h[l] << 56 ^ 0xFE03F80FE03F80L);
                                                    l = n14;
                                                    if (n3 >= 0L) {
                                                        break Label_0363;
                                                    }
                                                    if (h[n14] < 0L) {
                                                        return this.Q();
                                                    }
                                                    l = k + 10;
                                                    break Label_0363;
                                                }
                                            }
                                            n3 = (n10 ^ n11);
                                            break Label_0363;
                                        }
                                        n13 = 266354560L;
                                    }
                                    n3 = (n8 ^ n13);
                                }
                            }
                        }
                    }
                    this.k = l;
                    return n3;
                }
            }
            return this.Q();
        }
        
        long Q() {
            long n = 0L;
            for (int i = 0; i < 64; i += 7) {
                final byte j = this.I();
                n |= (long)(j & 0x7F) << i;
                if ((j & 0x80) == 0x0) {
                    return n;
                }
            }
            throw A.f();
        }
        
        public void U() {
            int b;
            do {
                b = this.B();
            } while (b != 0 && this.E(b));
        }
        
        public void V(final int n) {
            final int i = this.i;
            final int k = this.k;
            if (n <= i - k && n >= 0) {
                this.k = k + n;
            }
            else {
                this.W(n);
            }
        }
        
        @Override
        public void a(final int n) {
            if (this.l == n) {
                return;
            }
            throw A.b();
        }
        
        @Override
        public int d() {
            return this.m + this.k;
        }
        
        @Override
        public boolean e() {
            if (this.k == this.i) {
                final boolean b = true;
                if (!this.a0(1)) {
                    return b;
                }
            }
            return false;
        }
        
        @Override
        public void k(final int n) {
            this.n = n;
            this.R();
        }
        
        @Override
        public int l(int n) {
            if (n < 0) {
                throw A.g();
            }
            n += this.m + this.k;
            final int n2 = this.n;
            if (n <= n2) {
                this.n = n;
                this.R();
                return n2;
            }
            throw A.m();
        }
        
        @Override
        public boolean m() {
            return this.P() != 0L;
        }
        
        @Override
        public h n() {
            final int o = this.O();
            final int i = this.i;
            final int k = this.k;
            if (o <= i - k && o > 0) {
                final h o2 = com.google.crypto.tink.shaded.protobuf.h.o(this.h, k, o);
                this.k += o;
                return o2;
            }
            if (o == 0) {
                return com.google.crypto.tink.shaded.protobuf.h.b;
            }
            return this.H(o);
        }
        
        @Override
        public double o() {
            return Double.longBitsToDouble(this.N());
        }
        
        @Override
        public int p() {
            return this.O();
        }
        
        @Override
        public int q() {
            return this.M();
        }
        
        @Override
        public long r() {
            return this.N();
        }
        
        @Override
        public float s() {
            return Float.intBitsToFloat(this.M());
        }
        
        @Override
        public int t() {
            return this.O();
        }
        
        @Override
        public long u() {
            return this.P();
        }
        
        @Override
        public int v() {
            return this.M();
        }
        
        @Override
        public long w() {
            return this.N();
        }
        
        @Override
        public int x() {
            return com.google.crypto.tink.shaded.protobuf.i.b(this.O());
        }
        
        @Override
        public long y() {
            return com.google.crypto.tink.shaded.protobuf.i.c(this.P());
        }
        
        @Override
        public String z() {
            final int o = this.O();
            if (o > 0) {
                final int i = this.i;
                final int k = this.k;
                if (o <= i - k) {
                    final String s = new String(this.h, k, o, z.b);
                    this.k += o;
                    return s;
                }
            }
            if (o == 0) {
                return "";
            }
            if (o <= this.i) {
                this.S(o);
                final String s2 = new String(this.h, this.k, o, z.b);
                this.k += o;
                return s2;
            }
            return new String(this.J(o, false), z.b);
        }
    }
}
