package com.google.crypto.tink.shaded.protobuf;

import java.util.Map;
import java.util.List;

final class j implements d0
{
    private final i a;
    private int b;
    private int c;
    private int d;
    
    private j(i a) {
        this.d = 0;
        a = (i)z.b(a, "input");
        this.a = a;
        a.d = this;
    }
    
    public static j O(final i i) {
        final j d = i.d;
        if (d != null) {
            return d;
        }
        return new j(i);
    }
    
    private void P(final Object o, final e0 e0, final p p3) {
        final int c = this.c;
        this.c = q0.c(q0.a(this.b), 4);
        try {
            e0.j(o, this, p3);
            if (this.b == this.c) {
                return;
            }
            throw A.h();
        }
        finally {
            this.c = c;
        }
    }
    
    private void Q(final Object o, final e0 e0, final p p3) {
        final int c = this.a.C();
        final i a = this.a;
        if (a.a < a.b) {
            final int l = a.l(c);
            final i a2 = this.a;
            ++a2.a;
            e0.j(o, this, p3);
            this.a.a(0);
            final i a3 = this.a;
            --a3.a;
            a3.k(l);
            return;
        }
        throw A.i();
    }
    
    private Object R(final e0 e0, final p p2) {
        final Object f = e0.f();
        this.P(f, e0, p2);
        e0.b(f);
        return f;
    }
    
    private Object S(final e0 e0, final p p2) {
        final Object f = e0.f();
        this.Q(f, e0, p2);
        e0.b(f);
        return f;
    }
    
    private void U(final int n) {
        if (this.a.d() == n) {
            return;
        }
        throw A.m();
    }
    
    private void V(final int n) {
        if (q0.b(this.b) == n) {
            return;
        }
        throw A.e();
    }
    
    private void W(final int n) {
        if ((n & 0x3) == 0x0) {
            return;
        }
        throw A.h();
    }
    
    private void X(final int n) {
        if ((n & 0x7) == 0x0) {
            return;
        }
        throw A.h();
    }
    
    @Override
    public void A(final List list) {
        if (list instanceof v) {
            final v v = (v)list;
            final int b = q0.b(this.b);
            if (b != 2) {
                if (b == 5) {
                    int i;
                    do {
                        v.c(this.a.s());
                        if (this.a.e()) {
                            return;
                        }
                        i = this.a.B();
                    } while (i == this.b);
                    this.d = i;
                    return;
                }
                throw A.e();
            }
            else {
                final int c = this.a.C();
                this.W(c);
                do {
                    v.c(this.a.s());
                } while (this.a.d() < this.a.d() + c);
            }
        }
        else {
            final int b2 = q0.b(this.b);
            if (b2 != 2) {
                if (b2 == 5) {
                    int j;
                    do {
                        list.add((Object)this.a.s());
                        if (this.a.e()) {
                            return;
                        }
                        j = this.a.B();
                    } while (j == this.b);
                    this.d = j;
                    return;
                }
                throw A.e();
            }
            else {
                final int c2 = this.a.C();
                this.W(c2);
                do {
                    list.add((Object)this.a.s());
                } while (this.a.d() < this.a.d() + c2);
            }
        }
    }
    
    @Override
    public int B() {
        this.V(0);
        return this.a.t();
    }
    
    @Override
    public boolean C() {
        if (!this.a.e()) {
            final int b = this.b;
            if (b != this.c) {
                return this.a.E(b);
            }
        }
        return false;
    }
    
    @Override
    public int D() {
        this.V(5);
        return this.a.v();
    }
    
    @Override
    public void E(final List list) {
        if (q0.b(this.b) == 2) {
            int i;
            do {
                list.add((Object)this.z());
                if (this.a.e()) {
                    return;
                }
                i = this.a.B();
            } while (i == this.b);
            this.d = i;
            return;
        }
        throw A.e();
    }
    
    @Override
    public void F(final List list) {
        if (list instanceof m) {
            final m m = (m)list;
            final int b = q0.b(this.b);
            if (b == 1) {
                int i;
                do {
                    m.c(this.a.o());
                    if (this.a.e()) {
                        return;
                    }
                    i = this.a.B();
                } while (i == this.b);
                this.d = i;
                return;
            }
            if (b != 2) {
                throw A.e();
            }
            final int c = this.a.C();
            this.X(c);
            do {
                m.c(this.a.o());
            } while (this.a.d() < this.a.d() + c);
        }
        else {
            final int b2 = q0.b(this.b);
            if (b2 == 1) {
                int j;
                do {
                    list.add((Object)this.a.o());
                    if (this.a.e()) {
                        return;
                    }
                    j = this.a.B();
                } while (j == this.b);
                this.d = j;
                return;
            }
            if (b2 != 2) {
                throw A.e();
            }
            final int c2 = this.a.C();
            this.X(c2);
            do {
                list.add((Object)this.a.o());
            } while (this.a.d() < this.a.d() + c2);
        }
    }
    
    @Override
    public long G() {
        this.V(0);
        return this.a.u();
    }
    
    @Override
    public String H() {
        this.V(2);
        return this.a.A();
    }
    
    @Override
    public void I(final List list) {
        if (list instanceof F) {
            final F f = (F)list;
            final int b = q0.b(this.b);
            if (b == 1) {
                int i;
                do {
                    f.c(this.a.r());
                    if (this.a.e()) {
                        return;
                    }
                    i = this.a.B();
                } while (i == this.b);
                this.d = i;
                return;
            }
            if (b != 2) {
                throw A.e();
            }
            final int c = this.a.C();
            this.X(c);
            do {
                f.c(this.a.r());
            } while (this.a.d() < this.a.d() + c);
        }
        else {
            final int b2 = q0.b(this.b);
            if (b2 == 1) {
                int j;
                do {
                    list.add((Object)this.a.r());
                    if (this.a.e()) {
                        return;
                    }
                    j = this.a.B();
                } while (j == this.b);
                this.d = j;
                return;
            }
            if (b2 != 2) {
                throw A.e();
            }
            final int c2 = this.a.C();
            this.X(c2);
            do {
                list.add((Object)this.a.r());
            } while (this.a.d() < this.a.d() + c2);
        }
    }
    
    @Override
    public void J(final Object o, final e0 e0, final p p3) {
        this.V(2);
        this.Q(o, e0, p3);
    }
    
    @Override
    public void K(final List list, final e0 e0, final p p3) {
        if (q0.b(this.b) == 2) {
            int i;
            do {
                list.add(this.S(e0, p3));
                if (!this.a.e()) {
                    if (this.d == 0) {
                        i = this.a.B();
                        continue;
                    }
                }
                return;
            } while (i == this.b);
            this.d = i;
            return;
        }
        throw A.e();
    }
    
    @Override
    public void L(final Object o, final e0 e0, final p p3) {
        this.V(3);
        this.P(o, e0, p3);
    }
    
    @Override
    public void M(final Map map, final H.a a, final p p3) {
        this.V(2);
        this.a.l(this.a.C());
        throw null;
    }
    
    @Override
    public void N(final List list, final e0 e0, final p p3) {
        if (q0.b(this.b) == 3) {
            int i;
            do {
                list.add(this.R(e0, p3));
                if (!this.a.e()) {
                    if (this.d == 0) {
                        i = this.a.B();
                        continue;
                    }
                }
                return;
            } while (i == this.b);
            this.d = i;
            return;
        }
        throw A.e();
    }
    
    public void T(final List list, final boolean b) {
        if (q0.b(this.b) != 2) {
            throw A.e();
        }
        if (list instanceof D && !b) {
            final D d = (D)list;
            int i;
            do {
                d.E(this.z());
                if (this.a.e()) {
                    return;
                }
                i = this.a.B();
            } while (i == this.b);
            this.d = i;
            return;
        }
        int j;
        do {
            String s;
            if (b) {
                s = this.H();
            }
            else {
                s = this.v();
            }
            list.add((Object)s);
            if (this.a.e()) {
                return;
            }
            j = this.a.B();
        } while (j == this.b);
        this.d = j;
    }
    
    @Override
    public int a() {
        return this.b;
    }
    
    @Override
    public void b(final List list) {
        if (list instanceof y) {
            final y y = (y)list;
            final int b = q0.b(this.b);
            if (b == 0) {
                int i;
                do {
                    y.c(this.a.x());
                    if (this.a.e()) {
                        return;
                    }
                    i = this.a.B();
                } while (i == this.b);
                this.d = i;
                return;
            }
            if (b != 2) {
                throw A.e();
            }
            final int n = this.a.d() + this.a.C();
            do {
                y.c(this.a.x());
            } while (this.a.d() < n);
            this.U(n);
        }
        else {
            final int b2 = q0.b(this.b);
            if (b2 == 0) {
                int j;
                do {
                    list.add((Object)this.a.x());
                    if (this.a.e()) {
                        return;
                    }
                    j = this.a.B();
                } while (j == this.b);
                this.d = j;
                return;
            }
            if (b2 != 2) {
                throw A.e();
            }
            final int n2 = this.a.d() + this.a.C();
            do {
                list.add((Object)this.a.x());
            } while (this.a.d() < n2);
            this.U(n2);
        }
    }
    
    @Override
    public long c() {
        this.V(0);
        return this.a.D();
    }
    
    @Override
    public long d() {
        this.V(1);
        return this.a.r();
    }
    
    @Override
    public void e(final List list) {
        if (list instanceof y) {
            final y y = (y)list;
            final int b = q0.b(this.b);
            if (b != 2) {
                if (b == 5) {
                    int i;
                    do {
                        y.c(this.a.v());
                        if (this.a.e()) {
                            return;
                        }
                        i = this.a.B();
                    } while (i == this.b);
                    this.d = i;
                    return;
                }
                throw A.e();
            }
            else {
                final int c = this.a.C();
                this.W(c);
                do {
                    y.c(this.a.v());
                } while (this.a.d() < this.a.d() + c);
            }
        }
        else {
            final int b2 = q0.b(this.b);
            if (b2 != 2) {
                if (b2 == 5) {
                    int j;
                    do {
                        list.add((Object)this.a.v());
                        if (this.a.e()) {
                            return;
                        }
                        j = this.a.B();
                    } while (j == this.b);
                    this.d = j;
                    return;
                }
                throw A.e();
            }
            else {
                final int c2 = this.a.C();
                this.W(c2);
                do {
                    list.add((Object)this.a.v());
                } while (this.a.d() < this.a.d() + c2);
            }
        }
    }
    
    @Override
    public void f(final List list) {
        if (list instanceof F) {
            final F f = (F)list;
            final int b = q0.b(this.b);
            if (b == 0) {
                int i;
                do {
                    f.c(this.a.y());
                    if (this.a.e()) {
                        return;
                    }
                    i = this.a.B();
                } while (i == this.b);
                this.d = i;
                return;
            }
            if (b != 2) {
                throw A.e();
            }
            final int n = this.a.d() + this.a.C();
            do {
                f.c(this.a.y());
            } while (this.a.d() < n);
            this.U(n);
        }
        else {
            final int b2 = q0.b(this.b);
            if (b2 == 0) {
                int j;
                do {
                    list.add((Object)this.a.y());
                    if (this.a.e()) {
                        return;
                    }
                    j = this.a.B();
                } while (j == this.b);
                this.d = j;
                return;
            }
            if (b2 != 2) {
                throw A.e();
            }
            final int n2 = this.a.d() + this.a.C();
            do {
                list.add((Object)this.a.y());
            } while (this.a.d() < n2);
            this.U(n2);
        }
    }
    
    @Override
    public void g(final List list) {
        if (list instanceof y) {
            final y y = (y)list;
            final int b = q0.b(this.b);
            if (b == 0) {
                int i;
                do {
                    y.c(this.a.C());
                    if (this.a.e()) {
                        return;
                    }
                    i = this.a.B();
                } while (i == this.b);
                this.d = i;
                return;
            }
            if (b != 2) {
                throw A.e();
            }
            final int n = this.a.d() + this.a.C();
            do {
                y.c(this.a.C());
            } while (this.a.d() < n);
            this.U(n);
        }
        else {
            final int b2 = q0.b(this.b);
            if (b2 == 0) {
                int j;
                do {
                    list.add((Object)this.a.C());
                    if (this.a.e()) {
                        return;
                    }
                    j = this.a.B();
                } while (j == this.b);
                this.d = j;
                return;
            }
            if (b2 != 2) {
                throw A.e();
            }
            final int n2 = this.a.d() + this.a.C();
            do {
                list.add((Object)this.a.C());
            } while (this.a.d() < n2);
            this.U(n2);
        }
    }
    
    @Override
    public int h() {
        this.V(5);
        return this.a.q();
    }
    
    @Override
    public boolean i() {
        this.V(0);
        return this.a.m();
    }
    
    @Override
    public long j() {
        this.V(1);
        return this.a.w();
    }
    
    @Override
    public void k(final List list) {
        if (list instanceof F) {
            final F f = (F)list;
            final int b = q0.b(this.b);
            if (b == 0) {
                int i;
                do {
                    f.c(this.a.D());
                    if (this.a.e()) {
                        return;
                    }
                    i = this.a.B();
                } while (i == this.b);
                this.d = i;
                return;
            }
            if (b != 2) {
                throw A.e();
            }
            final int n = this.a.d() + this.a.C();
            do {
                f.c(this.a.D());
            } while (this.a.d() < n);
            this.U(n);
        }
        else {
            final int b2 = q0.b(this.b);
            if (b2 == 0) {
                int j;
                do {
                    list.add((Object)this.a.D());
                    if (this.a.e()) {
                        return;
                    }
                    j = this.a.B();
                } while (j == this.b);
                this.d = j;
                return;
            }
            if (b2 != 2) {
                throw A.e();
            }
            final int n2 = this.a.d() + this.a.C();
            do {
                list.add((Object)this.a.D());
            } while (this.a.d() < n2);
            this.U(n2);
        }
    }
    
    @Override
    public int l() {
        this.V(0);
        return this.a.C();
    }
    
    @Override
    public void m(final List list) {
        if (list instanceof F) {
            final F f = (F)list;
            final int b = q0.b(this.b);
            if (b == 0) {
                int i;
                do {
                    f.c(this.a.u());
                    if (this.a.e()) {
                        return;
                    }
                    i = this.a.B();
                } while (i == this.b);
                this.d = i;
                return;
            }
            if (b != 2) {
                throw A.e();
            }
            final int n = this.a.d() + this.a.C();
            do {
                f.c(this.a.u());
            } while (this.a.d() < n);
            this.U(n);
        }
        else {
            final int b2 = q0.b(this.b);
            if (b2 == 0) {
                int j;
                do {
                    list.add((Object)this.a.u());
                    if (this.a.e()) {
                        return;
                    }
                    j = this.a.B();
                } while (j == this.b);
                this.d = j;
                return;
            }
            if (b2 != 2) {
                throw A.e();
            }
            final int n2 = this.a.d() + this.a.C();
            do {
                list.add((Object)this.a.u());
            } while (this.a.d() < n2);
            this.U(n2);
        }
    }
    
    @Override
    public void n(final List list) {
        if (list instanceof F) {
            final F f = (F)list;
            final int b = q0.b(this.b);
            if (b == 1) {
                int i;
                do {
                    f.c(this.a.w());
                    if (this.a.e()) {
                        return;
                    }
                    i = this.a.B();
                } while (i == this.b);
                this.d = i;
                return;
            }
            if (b != 2) {
                throw A.e();
            }
            final int c = this.a.C();
            this.X(c);
            do {
                f.c(this.a.w());
            } while (this.a.d() < this.a.d() + c);
        }
        else {
            final int b2 = q0.b(this.b);
            if (b2 == 1) {
                int j;
                do {
                    list.add((Object)this.a.w());
                    if (this.a.e()) {
                        return;
                    }
                    j = this.a.B();
                } while (j == this.b);
                this.d = j;
                return;
            }
            if (b2 != 2) {
                throw A.e();
            }
            final int c2 = this.a.C();
            this.X(c2);
            do {
                list.add((Object)this.a.w());
            } while (this.a.d() < this.a.d() + c2);
        }
    }
    
    @Override
    public void o(final List list) {
        if (list instanceof y) {
            final y y = (y)list;
            final int b = q0.b(this.b);
            if (b == 0) {
                int i;
                do {
                    y.c(this.a.t());
                    if (this.a.e()) {
                        return;
                    }
                    i = this.a.B();
                } while (i == this.b);
                this.d = i;
                return;
            }
            if (b != 2) {
                throw A.e();
            }
            final int n = this.a.d() + this.a.C();
            do {
                y.c(this.a.t());
            } while (this.a.d() < n);
            this.U(n);
        }
        else {
            final int b2 = q0.b(this.b);
            if (b2 == 0) {
                int j;
                do {
                    list.add((Object)this.a.t());
                    if (this.a.e()) {
                        return;
                    }
                    j = this.a.B();
                } while (j == this.b);
                this.d = j;
                return;
            }
            if (b2 != 2) {
                throw A.e();
            }
            final int n2 = this.a.d() + this.a.C();
            do {
                list.add((Object)this.a.t());
            } while (this.a.d() < n2);
            this.U(n2);
        }
    }
    
    @Override
    public void p(final List list) {
        if (list instanceof y) {
            final y y = (y)list;
            final int b = q0.b(this.b);
            if (b == 0) {
                int i;
                do {
                    y.c(this.a.p());
                    if (this.a.e()) {
                        return;
                    }
                    i = this.a.B();
                } while (i == this.b);
                this.d = i;
                return;
            }
            if (b != 2) {
                throw A.e();
            }
            final int n = this.a.d() + this.a.C();
            do {
                y.c(this.a.p());
            } while (this.a.d() < n);
            this.U(n);
        }
        else {
            final int b2 = q0.b(this.b);
            if (b2 == 0) {
                int j;
                do {
                    list.add((Object)this.a.p());
                    if (this.a.e()) {
                        return;
                    }
                    j = this.a.B();
                } while (j == this.b);
                this.d = j;
                return;
            }
            if (b2 != 2) {
                throw A.e();
            }
            final int n2 = this.a.d() + this.a.C();
            do {
                list.add((Object)this.a.p());
            } while (this.a.d() < n2);
            this.U(n2);
        }
    }
    
    @Override
    public int q() {
        this.V(0);
        return this.a.p();
    }
    
    @Override
    public void r(final List list) {
        if (list instanceof y) {
            final y y = (y)list;
            final int b = q0.b(this.b);
            if (b != 2) {
                if (b == 5) {
                    int i;
                    do {
                        y.c(this.a.q());
                        if (this.a.e()) {
                            return;
                        }
                        i = this.a.B();
                    } while (i == this.b);
                    this.d = i;
                    return;
                }
                throw A.e();
            }
            else {
                final int c = this.a.C();
                this.W(c);
                do {
                    y.c(this.a.q());
                } while (this.a.d() < this.a.d() + c);
            }
        }
        else {
            final int b2 = q0.b(this.b);
            if (b2 != 2) {
                if (b2 == 5) {
                    int j;
                    do {
                        list.add((Object)this.a.q());
                        if (this.a.e()) {
                            return;
                        }
                        j = this.a.B();
                    } while (j == this.b);
                    this.d = j;
                    return;
                }
                throw A.e();
            }
            else {
                final int c2 = this.a.C();
                this.W(c2);
                do {
                    list.add((Object)this.a.q());
                } while (this.a.d() < this.a.d() + c2);
            }
        }
    }
    
    @Override
    public double readDouble() {
        this.V(1);
        return this.a.o();
    }
    
    @Override
    public float readFloat() {
        this.V(5);
        return this.a.s();
    }
    
    @Override
    public int s() {
        this.V(0);
        return this.a.x();
    }
    
    @Override
    public long t() {
        this.V(0);
        return this.a.y();
    }
    
    @Override
    public void u(final List list) {
        if (list instanceof f) {
            final f f = (f)list;
            final int b = q0.b(this.b);
            if (b == 0) {
                int i;
                do {
                    f.c(this.a.m());
                    if (this.a.e()) {
                        return;
                    }
                    i = this.a.B();
                } while (i == this.b);
                this.d = i;
                return;
            }
            if (b != 2) {
                throw A.e();
            }
            final int n = this.a.d() + this.a.C();
            do {
                f.c(this.a.m());
            } while (this.a.d() < n);
            this.U(n);
        }
        else {
            final int b2 = q0.b(this.b);
            if (b2 == 0) {
                int j;
                do {
                    list.add((Object)this.a.m());
                    if (this.a.e()) {
                        return;
                    }
                    j = this.a.B();
                } while (j == this.b);
                this.d = j;
                return;
            }
            if (b2 != 2) {
                throw A.e();
            }
            final int n2 = this.a.d() + this.a.C();
            do {
                list.add((Object)this.a.m());
            } while (this.a.d() < n2);
            this.U(n2);
        }
    }
    
    @Override
    public String v() {
        this.V(2);
        return this.a.z();
    }
    
    @Override
    public int w() {
        final int d = this.d;
        if (d != 0) {
            this.b = d;
            this.d = 0;
        }
        else {
            this.b = this.a.B();
        }
        final int b = this.b;
        if (b != 0 && b != this.c) {
            return q0.a(b);
        }
        return Integer.MAX_VALUE;
    }
    
    @Override
    public void x(final List list) {
        this.T(list, false);
    }
    
    @Override
    public void y(final List list) {
        this.T(list, true);
    }
    
    @Override
    public h z() {
        this.V(2);
        return this.a.n();
    }
}
