package com.google.crypto.tink.shaded.protobuf;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class k extends g
{
    private static final Logger c;
    private static final boolean d;
    l a;
    private boolean b;
    
    static {
        c = Logger.getLogger(k.class.getName());
        d = o0.E();
    }
    
    private k() {
    }
    
    public static int A(final int n, final h h) {
        return L(1) * 2 + M(2, n) + f(3, h);
    }
    
    public static int B(final int n, final int n2) {
        return L(n) + C(n2);
    }
    
    public static int C(final int n) {
        return 4;
    }
    
    public static int D(final int n, final long n2) {
        return L(n) + E(n2);
    }
    
    public static int E(final long n) {
        return 8;
    }
    
    public static int F(final int n, final int n2) {
        return L(n) + G(n2);
    }
    
    public static int G(final int n) {
        return N(Q(n));
    }
    
    public static int H(final int n, final long n2) {
        return L(n) + I(n2);
    }
    
    public static int I(final long n) {
        return P(R(n));
    }
    
    public static int J(final int n, final String s) {
        return L(n) + K(s);
    }
    
    public static int K(final String s) {
        int n;
        try {
            n = p0.g((CharSequence)s);
        }
        catch (final p0.d d) {
            n = s.getBytes(z.b).length;
        }
        return x(n);
    }
    
    public static int L(final int n) {
        return N(q0.c(n, 0));
    }
    
    public static int M(final int n, final int n2) {
        return L(n) + N(n2);
    }
    
    public static int N(final int n) {
        if ((n & 0xFFFFFF80) == 0x0) {
            return 1;
        }
        if ((n & 0xFFFFC000) == 0x0) {
            return 2;
        }
        if ((0xFFE00000 & n) == 0x0) {
            return 3;
        }
        if ((n & 0xF0000000) == 0x0) {
            return 4;
        }
        return 5;
    }
    
    public static int O(final int n, final long n2) {
        return L(n) + P(n2);
    }
    
    public static int P(long n) {
        if ((0xFFFFFFFFFFFFFF80L & n) == 0x0L) {
            return 1;
        }
        if (n < 0L) {
            return 10;
        }
        int n2;
        if ((0xFFFFFFF800000000L & n) != 0x0L) {
            n >>>= 28;
            n2 = 6;
        }
        else {
            n2 = 2;
        }
        int n3 = n2;
        long n4 = n;
        if ((0xFFFFFFFFFFE00000L & n) != 0x0L) {
            n3 = n2 + 2;
            n4 = n >>> 14;
        }
        int n5 = n3;
        if ((n4 & 0xFFFFFFFFFFFFC000L) != 0x0L) {
            n5 = n3 + 1;
        }
        return n5;
    }
    
    public static int Q(final int n) {
        return n >> 31 ^ n << 1;
    }
    
    public static long R(final long n) {
        return n >> 63 ^ n << 1;
    }
    
    public static k U(final byte[] array) {
        return V(array, 0, array.length);
    }
    
    public static k V(final byte[] array, final int n, final int n2) {
        return new b(array, n, n2);
    }
    
    public static int d(final int n, final boolean b) {
        return L(n) + e(b);
    }
    
    public static int e(final boolean b) {
        return 1;
    }
    
    public static int f(final int n, final h h) {
        return L(n) + g(h);
    }
    
    public static int g(final h h) {
        return x(h.size());
    }
    
    public static int h(final int n, final double n2) {
        return L(n) + i(n2);
    }
    
    public static int i(final double n) {
        return 8;
    }
    
    public static int j(final int n, final int n2) {
        return L(n) + k(n2);
    }
    
    public static int k(final int n) {
        return u(n);
    }
    
    public static int l(final int n, final int n2) {
        return L(n) + m(n2);
    }
    
    public static int m(final int n) {
        return 4;
    }
    
    public static int n(final int n, final long n2) {
        return L(n) + o(n2);
    }
    
    public static int o(final long n) {
        return 8;
    }
    
    public static int p(final int n, final float n2) {
        return L(n) + q(n2);
    }
    
    public static int q(final float n) {
        return 4;
    }
    
    static int r(final int n, final O o, final e0 e0) {
        return L(n) * 2 + s(o, e0);
    }
    
    static int s(final O o, final e0 e0) {
        return ((a)o).h(e0);
    }
    
    public static int t(final int n, final int n2) {
        return L(n) + u(n2);
    }
    
    public static int u(final int n) {
        if (n >= 0) {
            return N(n);
        }
        return 10;
    }
    
    public static int v(final int n, final long n2) {
        return L(n) + w(n2);
    }
    
    public static int w(final long n) {
        return P(n);
    }
    
    static int x(final int n) {
        return N(n) + n;
    }
    
    static int y(final int n, final O o, final e0 e0) {
        return L(n) + z(o, e0);
    }
    
    static int z(final O o, final e0 e0) {
        return x(((a)o).h(e0));
    }
    
    public final void A0(final int n, final long n2) {
        this.G0(n, R(n2));
    }
    
    public final void B0(final long n) {
        this.H0(R(n));
    }
    
    public abstract void C0(final int p0, final String p1);
    
    public abstract void D0(final int p0, final int p1);
    
    public abstract void E0(final int p0, final int p1);
    
    public abstract void F0(final int p0);
    
    public abstract void G0(final int p0, final long p1);
    
    public abstract void H0(final long p0);
    
    final void S(final String s, final p0.d d) {
        k.c.log(Level.WARNING, "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!", (Throwable)d);
        final byte[] bytes = s.getBytes(z.b);
        try {
            this.F0(bytes.length);
            this.a(bytes, 0, bytes.length);
        }
        catch (final IndexOutOfBoundsException ex) {
            throw new c((Throwable)ex);
        }
    }
    
    boolean T() {
        return this.b;
    }
    
    public abstract int W();
    
    public abstract void X(final byte p0);
    
    public abstract void Y(final int p0, final boolean p1);
    
    public final void Z(final boolean b) {
        this.X((byte)(b ? 1 : 0));
    }
    
    @Override
    public abstract void a(final byte[] p0, final int p1, final int p2);
    
    public abstract void a0(final int p0, final h p1);
    
    public final void b0(final int n, final double n2) {
        this.h0(n, Double.doubleToRawLongBits(n2));
    }
    
    public final void c() {
        if (this.W() == 0) {
            return;
        }
        throw new IllegalStateException("Did not write as much data as expected.");
    }
    
    public final void c0(final double n) {
        this.i0(Double.doubleToRawLongBits(n));
    }
    
    public final void d0(final int n, final int n2) {
        this.n0(n, n2);
    }
    
    public final void e0(final int n) {
        this.o0(n);
    }
    
    public abstract void f0(final int p0, final int p1);
    
    public abstract void g0(final int p0);
    
    public abstract void h0(final int p0, final long p1);
    
    public abstract void i0(final long p0);
    
    public final void j0(final int n, final float n2) {
        this.f0(n, Float.floatToRawIntBits(n2));
    }
    
    public final void k0(final float n) {
        this.g0(Float.floatToRawIntBits(n));
    }
    
    final void l0(final int n, final O o, final e0 e0) {
        this.D0(n, 3);
        this.m0(o, e0);
        this.D0(n, 4);
    }
    
    final void m0(final O o, final e0 e0) {
        e0.i(o, this.a);
    }
    
    public abstract void n0(final int p0, final int p1);
    
    public abstract void o0(final int p0);
    
    public final void p0(final int n, final long n2) {
        this.G0(n, n2);
    }
    
    public final void q0(final long n) {
        this.H0(n);
    }
    
    abstract void r0(final int p0, final O p1, final e0 p2);
    
    public abstract void s0(final int p0, final O p1);
    
    public abstract void t0(final int p0, final h p1);
    
    public final void u0(final int n, final int n2) {
        this.f0(n, n2);
    }
    
    public final void v0(final int n) {
        this.g0(n);
    }
    
    public final void w0(final int n, final long n2) {
        this.h0(n, n2);
    }
    
    public final void x0(final long n) {
        this.i0(n);
    }
    
    public final void y0(final int n, final int n2) {
        this.E0(n, Q(n2));
    }
    
    public final void z0(final int n) {
        this.F0(Q(n));
    }
    
    private static class b extends k
    {
        private final byte[] e;
        private final int f;
        private final int g;
        private int h;
        
        b(final byte[] e, final int n, final int n2) {
            super(null);
            if (e == null) {
                throw new NullPointerException("buffer");
            }
            final int length = e.length;
            final int g = n + n2;
            if ((n | n2 | length - g) >= 0) {
                this.e = e;
                this.f = n;
                this.h = n;
                this.g = g;
                return;
            }
            throw new IllegalArgumentException(String.format("Array range is invalid. Buffer.length=%d, offset=%d, length=%d", new Object[] { e.length, n, n2 }));
        }
        
        @Override
        public final void C0(final int n, final String s) {
            this.D0(n, 2);
            this.M0(s);
        }
        
        @Override
        public final void D0(final int n, final int n2) {
            this.F0(q0.c(n, n2));
        }
        
        @Override
        public final void E0(final int n, final int n2) {
            this.D0(n, 0);
            this.F0(n2);
        }
        
        @Override
        public final void F0(int n) {
            while (true) {
                if ((n & 0xFFFFFF80) == 0x0) {
                    try {
                        this.e[this.h++] = (byte)n;
                        return;
                    }
                    catch (final IndexOutOfBoundsException ex) {
                        break;
                    }
                }
                this.e[this.h++] = (byte)((n & 0x7F) | 0x80);
                n >>>= 7;
            }
            final IndexOutOfBoundsException ex;
            throw new c(String.format("Pos: %d, limit: %d, len: %d", new Object[] { this.h, this.g, 1 }), (Throwable)ex);
        }
        
        @Override
        public final void G0(final int n, final long n2) {
            this.D0(n, 0);
            this.H0(n2);
        }
        
        @Override
        public final void H0(long n) {
            long n2 = n;
            if (k.d) {
                n2 = n;
                if (this.W() >= 10) {
                    while ((n & 0xFFFFFFFFFFFFFF80L) != 0x0L) {
                        o0.K(this.e, this.h++, (byte)(((int)n & 0x7F) | 0x80));
                        n >>>= 7;
                    }
                    o0.K(this.e, this.h++, (byte)n);
                    return;
                }
            }
            while (true) {
                if ((n2 & 0xFFFFFFFFFFFFFF80L) == 0x0L) {
                    try {
                        this.e[this.h++] = (byte)n2;
                        return;
                    }
                    catch (final IndexOutOfBoundsException ex) {
                        break;
                    }
                }
                this.e[this.h++] = (byte)(((int)n2 & 0x7F) | 0x80);
                n2 >>>= 7;
            }
            final IndexOutOfBoundsException ex;
            throw new c(String.format("Pos: %d, limit: %d, len: %d", new Object[] { this.h, this.g, 1 }), (Throwable)ex);
        }
        
        public final void I0(final byte[] array, final int n, final int n2) {
            try {
                System.arraycopy((Object)array, n, (Object)this.e, this.h, n2);
                this.h += n2;
            }
            catch (final IndexOutOfBoundsException ex) {
                throw new c(String.format("Pos: %d, limit: %d, len: %d", new Object[] { this.h, this.g, n2 }), (Throwable)ex);
            }
        }
        
        public final void J0(final h h) {
            this.F0(h.size());
            h.M(this);
        }
        
        public final void K0(final int n, final O o) {
            this.D0(n, 2);
            this.L0(o);
        }
        
        public final void L0(final O o) {
            this.F0(o.b());
            o.d(this);
        }
        
        public final void M0(final String s) {
            final int h = this.h;
            Label_0130: {
                try {
                    final int n = k.N(s.length() * 3);
                    final int n2 = k.N(s.length());
                    if (n2 == n) {
                        final int h2 = h + n2;
                        this.h = h2;
                        final int f = p0.f((CharSequence)s, this.e, h2, this.W());
                        this.F0(f - (this.h = h) - n2);
                        this.h = f;
                        return;
                    }
                }
                catch (final IndexOutOfBoundsException ex) {
                    throw new c((Throwable)ex);
                }
                catch (final p0.d d) {
                    break Label_0130;
                }
                this.F0(p0.g((CharSequence)s));
                this.h = p0.f((CharSequence)s, this.e, this.h, this.W());
                return;
            }
            this.h = h;
            final p0.d d;
            this.S(s, d);
        }
        
        @Override
        public final int W() {
            return this.g - this.h;
        }
        
        @Override
        public final void X(final byte b) {
            try {
                this.e[this.h++] = b;
            }
            catch (final IndexOutOfBoundsException ex) {
                throw new c(String.format("Pos: %d, limit: %d, len: %d", new Object[] { this.h, this.g, 1 }), (Throwable)ex);
            }
        }
        
        @Override
        public final void Y(final int n, final boolean b) {
            this.D0(n, 0);
            this.X((byte)(b ? 1 : 0));
        }
        
        @Override
        public final void a(final byte[] array, final int n, final int n2) {
            this.I0(array, n, n2);
        }
        
        @Override
        public final void a0(final int n, final h h) {
            this.D0(n, 2);
            this.J0(h);
        }
        
        @Override
        public final void f0(final int n, final int n2) {
            this.D0(n, 5);
            this.g0(n2);
        }
        
        @Override
        public final void g0(final int n) {
            try {
                final byte[] e = this.e;
                final int h = this.h;
                final int h2 = h + 1;
                this.h = h2;
                e[h] = (byte)(n & 0xFF);
                final int h3 = h + 2;
                this.h = h3;
                e[h2] = (byte)(n >> 8 & 0xFF);
                final int h4 = h + 3;
                this.h = h4;
                e[h3] = (byte)(n >> 16 & 0xFF);
                this.h = h + 4;
                e[h4] = (byte)(n >> 24 & 0xFF);
            }
            catch (final IndexOutOfBoundsException ex) {
                throw new c(String.format("Pos: %d, limit: %d, len: %d", new Object[] { this.h, this.g, 1 }), (Throwable)ex);
            }
        }
        
        @Override
        public final void h0(final int n, final long n2) {
            this.D0(n, 1);
            this.i0(n2);
        }
        
        @Override
        public final void i0(final long n) {
            try {
                final byte[] e = this.e;
                final int h = this.h;
                final int h2 = h + 1;
                this.h = h2;
                e[h] = (byte)((int)n & 0xFF);
                final int h3 = h + 2;
                this.h = h3;
                e[h2] = (byte)((int)(n >> 8) & 0xFF);
                final int h4 = h + 3;
                this.h = h4;
                e[h3] = (byte)((int)(n >> 16) & 0xFF);
                final int h5 = h + 4;
                this.h = h5;
                e[h4] = (byte)((int)(n >> 24) & 0xFF);
                final int h6 = h + 5;
                this.h = h6;
                e[h5] = (byte)((int)(n >> 32) & 0xFF);
                final int h7 = h + 6;
                this.h = h7;
                e[h6] = (byte)((int)(n >> 40) & 0xFF);
                final int h8 = h + 7;
                this.h = h8;
                e[h7] = (byte)((int)(n >> 48) & 0xFF);
                this.h = h + 8;
                e[h8] = (byte)((int)(n >> 56) & 0xFF);
            }
            catch (final IndexOutOfBoundsException ex) {
                throw new c(String.format("Pos: %d, limit: %d, len: %d", new Object[] { this.h, this.g, 1 }), (Throwable)ex);
            }
        }
        
        @Override
        public final void n0(final int n, final int n2) {
            this.D0(n, 0);
            this.o0(n2);
        }
        
        @Override
        public final void o0(final int n) {
            if (n >= 0) {
                this.F0(n);
            }
            else {
                this.H0(n);
            }
        }
        
        @Override
        final void r0(final int n, final O o, final e0 e0) {
            this.D0(n, 2);
            this.F0(((a)o).h(e0));
            e0.i(o, super.a);
        }
        
        @Override
        public final void s0(final int n, final O o) {
            this.D0(1, 3);
            this.E0(2, n);
            this.K0(3, o);
            this.D0(1, 4);
        }
        
        @Override
        public final void t0(final int n, final h h) {
            this.D0(1, 3);
            this.E0(2, n);
            this.a0(3, h);
            this.D0(1, 4);
        }
    }
    
    public static class c extends IOException
    {
        c(final String s, final Throwable t) {
            final StringBuilder sb = new StringBuilder();
            sb.append("CodedOutputStream was writing to a flat byte array and ran out of space.: ");
            sb.append(s);
            super(sb.toString(), t);
        }
        
        c(final Throwable t) {
            super("CodedOutputStream was writing to a flat byte array and ran out of space.", t);
        }
    }
}
