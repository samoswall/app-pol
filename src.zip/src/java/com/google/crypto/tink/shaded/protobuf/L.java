package com.google.crypto.tink.shaded.protobuf;

import java.util.Iterator;
import java.util.Map$Entry;
import java.util.List;
import java.util.Map;

final class l implements r0
{
    private final k a;
    
    private l(k a) {
        a = (k)z.b(a, "output");
        this.a = a;
        a.a = this;
    }
    
    public static l P(final k k) {
        final l a = k.a;
        if (a != null) {
            return a;
        }
        return new l(k);
    }
    
    private void Q(final int n, final H.a a, final Map map) {
        final int[] a2 = l$a.a;
        throw null;
    }
    
    private void R(final int n, final Object o) {
        if (o instanceof String) {
            this.a.C0(n, (String)o);
        }
        else {
            this.a.a0(n, (h)o);
        }
    }
    
    @Override
    public void A(final int n, final float n2) {
        this.a.j0(n, n2);
    }
    
    @Override
    public void B(final int n) {
        this.a.D0(n, 4);
    }
    
    @Override
    public void C(int i, final List list, final boolean b) {
        int j = 0;
        final int n = 0;
        if (b) {
            this.a.D0(i, 2);
            int k = 0;
            i = 0;
            while (k < list.size()) {
                i += com.google.crypto.tink.shaded.protobuf.k.G((int)list.get(k));
                ++k;
            }
            this.a.F0(i);
            for (i = n; i < list.size(); ++i) {
                this.a.z0((int)list.get(i));
            }
        }
        else {
            while (j < list.size()) {
                this.a.y0(i, (int)list.get(j));
                ++j;
            }
        }
    }
    
    @Override
    public void D(final int n, final int n2) {
        this.a.d0(n, n2);
    }
    
    @Override
    public void E(int i, final List list, final boolean b) {
        int j = 0;
        final int n = 0;
        if (b) {
            this.a.D0(i, 2);
            int k = 0;
            i = 0;
            while (k < list.size()) {
                i += com.google.crypto.tink.shaded.protobuf.k.w((long)list.get(k));
                ++k;
            }
            this.a.F0(i);
            for (i = n; i < list.size(); ++i) {
                this.a.q0((long)list.get(i));
            }
        }
        else {
            while (j < list.size()) {
                this.a.p0(i, (long)list.get(j));
                ++j;
            }
        }
    }
    
    @Override
    public void F(int i, final List list, final boolean b) {
        int j = 0;
        final int n = 0;
        if (b) {
            this.a.D0(i, 2);
            i = 0;
            int n2 = 0;
            while (i < list.size()) {
                n2 += k.k((int)list.get(i));
                ++i;
            }
            this.a.F0(n2);
            for (i = n; i < list.size(); ++i) {
                this.a.e0((int)list.get(i));
            }
        }
        else {
            while (j < list.size()) {
                this.a.d0(i, (int)list.get(j));
                ++j;
            }
        }
    }
    
    @Override
    public void G(int i, final List list, final boolean b) {
        int j = 0;
        final int n = 0;
        if (b) {
            this.a.D0(i, 2);
            int k = 0;
            i = 0;
            while (k < list.size()) {
                i += com.google.crypto.tink.shaded.protobuf.k.i((double)list.get(k));
                ++k;
            }
            this.a.F0(i);
            for (i = n; i < list.size(); ++i) {
                this.a.c0((double)list.get(i));
            }
        }
        else {
            while (j < list.size()) {
                this.a.b0(i, (double)list.get(j));
                ++j;
            }
        }
    }
    
    @Override
    public void H(final int n, final int n2) {
        this.a.y0(n, n2);
    }
    
    @Override
    public void I(final int n, final List list) {
        for (int i = 0; i < list.size(); ++i) {
            this.a.a0(n, (h)list.get(i));
        }
    }
    
    @Override
    public void J(final int n, final Object o, final e0 e0) {
        this.a.r0(n, (O)o, e0);
    }
    
    @Override
    public void K(final int n, final H.a a, final Map map) {
        if (this.a.T()) {
            this.Q(n, a, map);
            return;
        }
        for (final Map$Entry map$Entry : map.entrySet()) {
            this.a.D0(n, 2);
            this.a.F0(H.a(a, map$Entry.getKey(), map$Entry.getValue()));
            H.b(this.a, a, map$Entry.getKey(), map$Entry.getValue());
        }
    }
    
    @Override
    public void L(final int n, final Object o, final e0 e0) {
        this.a.l0(n, (O)o, e0);
    }
    
    @Override
    public void M(final int n, final List list, final e0 e0) {
        for (int i = 0; i < list.size(); ++i) {
            this.L(n, list.get(i), e0);
        }
    }
    
    @Override
    public void N(final int n, final List list, final e0 e0) {
        for (int i = 0; i < list.size(); ++i) {
            this.J(n, list.get(i), e0);
        }
    }
    
    @Override
    public void O(final int n, final h h) {
        this.a.a0(n, h);
    }
    
    @Override
    public void a(int i, final List list, final boolean b) {
        int j = 0;
        final int n = 0;
        if (b) {
            this.a.D0(i, 2);
            i = 0;
            int n2 = 0;
            while (i < list.size()) {
                n2 += k.q((float)list.get(i));
                ++i;
            }
            this.a.F0(n2);
            for (i = n; i < list.size(); ++i) {
                this.a.k0((float)list.get(i));
            }
        }
        else {
            while (j < list.size()) {
                this.a.j0(i, (float)list.get(j));
                ++j;
            }
        }
    }
    
    @Override
    public void b(final int n, final int n2) {
        this.a.E0(n, n2);
    }
    
    @Override
    public final void c(final int n, final Object o) {
        if (o instanceof h) {
            this.a.t0(n, (h)o);
        }
        else {
            this.a.s0(n, (O)o);
        }
    }
    
    @Override
    public void d(final int n, final int n2) {
        this.a.f0(n, n2);
    }
    
    @Override
    public void e(final int n, final double n2) {
        this.a.b0(n, n2);
    }
    
    @Override
    public void f(int i, final List list, final boolean b) {
        int j = 0;
        final int n = 0;
        if (b) {
            this.a.D0(i, 2);
            i = 0;
            int n2 = 0;
            while (i < list.size()) {
                n2 += k.E((long)list.get(i));
                ++i;
            }
            this.a.F0(n2);
            for (i = n; i < list.size(); ++i) {
                this.a.x0((long)list.get(i));
            }
        }
        else {
            while (j < list.size()) {
                this.a.w0(i, (long)list.get(j));
                ++j;
            }
        }
    }
    
    @Override
    public void g(int i, final List list, final boolean b) {
        int j = 0;
        final int n = 0;
        if (b) {
            this.a.D0(i, 2);
            i = 0;
            int n2 = 0;
            while (i < list.size()) {
                n2 += k.P((long)list.get(i));
                ++i;
            }
            this.a.F0(n2);
            for (i = n; i < list.size(); ++i) {
                this.a.H0((long)list.get(i));
            }
        }
        else {
            while (j < list.size()) {
                this.a.G0(i, (long)list.get(j));
                ++j;
            }
        }
    }
    
    @Override
    public void h(final int n, final long n2) {
        this.a.h0(n, n2);
    }
    
    @Override
    public a i() {
        return r0.a.ASCENDING;
    }
    
    @Override
    public void j(final int n, final List list) {
        final boolean b = list instanceof D;
        int i = 0;
        final int n2 = 0;
        if (b) {
            final D d = (D)list;
            for (int j = n2; j < list.size(); ++j) {
                this.R(n, d.h(j));
            }
        }
        else {
            while (i < list.size()) {
                this.a.C0(n, (String)list.get(i));
                ++i;
            }
        }
    }
    
    @Override
    public void k(final int n, final String s) {
        this.a.C0(n, s);
    }
    
    @Override
    public void l(final int n, final long n2) {
        this.a.G0(n, n2);
    }
    
    @Override
    public void m(int i, final List list, final boolean b) {
        int j = 0;
        final int n = 0;
        if (b) {
            this.a.D0(i, 2);
            int k = 0;
            i = 0;
            while (k < list.size()) {
                i += com.google.crypto.tink.shaded.protobuf.k.u((int)list.get(k));
                ++k;
            }
            this.a.F0(i);
            for (i = n; i < list.size(); ++i) {
                this.a.o0((int)list.get(i));
            }
        }
        else {
            while (j < list.size()) {
                this.a.n0(i, (int)list.get(j));
                ++j;
            }
        }
    }
    
    @Override
    public void n(final int n, final long n2) {
        this.a.p0(n, n2);
    }
    
    @Override
    public void o(final int n, final boolean b) {
        this.a.Y(n, b);
    }
    
    @Override
    public void p(final int n, final int n2) {
        this.a.u0(n, n2);
    }
    
    @Override
    public void q(final int n) {
        this.a.D0(n, 3);
    }
    
    @Override
    public void r(final int n, final int n2) {
        this.a.n0(n, n2);
    }
    
    @Override
    public void s(int i, final List list, final boolean b) {
        int j = 0;
        final int n = 0;
        if (b) {
            this.a.D0(i, 2);
            int k = 0;
            i = 0;
            while (k < list.size()) {
                i += com.google.crypto.tink.shaded.protobuf.k.o((long)list.get(k));
                ++k;
            }
            this.a.F0(i);
            for (i = n; i < list.size(); ++i) {
                this.a.i0((long)list.get(i));
            }
        }
        else {
            while (j < list.size()) {
                this.a.h0(i, (long)list.get(j));
                ++j;
            }
        }
    }
    
    @Override
    public void t(int i, final List list, final boolean b) {
        int j = 0;
        final int n = 0;
        if (b) {
            this.a.D0(i, 2);
            i = 0;
            int n2 = 0;
            while (i < list.size()) {
                n2 += k.C((int)list.get(i));
                ++i;
            }
            this.a.F0(n2);
            for (i = n; i < list.size(); ++i) {
                this.a.v0((int)list.get(i));
            }
        }
        else {
            while (j < list.size()) {
                this.a.u0(i, (int)list.get(j));
                ++j;
            }
        }
    }
    
    @Override
    public void u(final int n, final long n2) {
        this.a.w0(n, n2);
    }
    
    @Override
    public void v(int i, final List list, final boolean b) {
        int j = 0;
        final int n = 0;
        if (b) {
            this.a.D0(i, 2);
            int k = 0;
            i = 0;
            while (k < list.size()) {
                i += com.google.crypto.tink.shaded.protobuf.k.m((int)list.get(k));
                ++k;
            }
            this.a.F0(i);
            for (i = n; i < list.size(); ++i) {
                this.a.g0((int)list.get(i));
            }
        }
        else {
            while (j < list.size()) {
                this.a.f0(i, (int)list.get(j));
                ++j;
            }
        }
    }
    
    @Override
    public void w(int i, final List list, final boolean b) {
        int j = 0;
        final int n = 0;
        if (b) {
            this.a.D0(i, 2);
            i = 0;
            int n2 = 0;
            while (i < list.size()) {
                n2 += k.e((boolean)list.get(i));
                ++i;
            }
            this.a.F0(n2);
            for (i = n; i < list.size(); ++i) {
                this.a.Z((boolean)list.get(i));
            }
        }
        else {
            while (j < list.size()) {
                this.a.Y(i, (boolean)list.get(j));
                ++j;
            }
        }
    }
    
    @Override
    public void x(int i, final List list, final boolean b) {
        int j = 0;
        final int n = 0;
        if (b) {
            this.a.D0(i, 2);
            int k = 0;
            i = 0;
            while (k < list.size()) {
                i += com.google.crypto.tink.shaded.protobuf.k.N((int)list.get(k));
                ++k;
            }
            this.a.F0(i);
            for (i = n; i < list.size(); ++i) {
                this.a.F0((int)list.get(i));
            }
        }
        else {
            while (j < list.size()) {
                this.a.E0(i, (int)list.get(j));
                ++j;
            }
        }
    }
    
    @Override
    public void y(int i, final List list, final boolean b) {
        int j = 0;
        final int n = 0;
        if (b) {
            this.a.D0(i, 2);
            i = 0;
            int n2 = 0;
            while (i < list.size()) {
                n2 += k.I((long)list.get(i));
                ++i;
            }
            this.a.F0(n2);
            for (i = n; i < list.size(); ++i) {
                this.a.B0((long)list.get(i));
            }
        }
        else {
            while (j < list.size()) {
                this.a.A0(i, (long)list.get(j));
                ++j;
            }
        }
    }
    
    @Override
    public void z(final int n, final long n2) {
        this.a.A0(n, n2);
    }
}
