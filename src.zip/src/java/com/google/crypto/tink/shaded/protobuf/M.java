package com.google.crypto.tink.shaded.protobuf;

import java.util.RandomAccess;

abstract class m extends c implements d, RandomAccess, Y
{
    public abstract void c(final double p0);
}
