package com.google.crypto.tink.shaded.protobuf;

public abstract class n
{
}
