package com.google.crypto.tink.shaded.protobuf;

abstract class o
{
    static final Class a;
    
    static {
        a = c();
    }
    
    public static p a() {
        p p = b("getEmptyRegistry");
        if (p == null) {
            p = com.google.crypto.tink.shaded.protobuf.p.d;
        }
        return p;
    }
    
    private static final p b(final String name) {
        final Class a = o.a;
        if (a == null) {
            return null;
        }
        try {
            return (p)a.getDeclaredMethod(name, (Class[])new Class[0]).invoke((Object)null, new Object[0]);
        }
        catch (final Exception ex) {
            return null;
        }
    }
    
    static Class c() {
        try {
            return Class.forName("com.google.crypto.tink.shaded.protobuf.ExtensionRegistry");
        }
        catch (final ClassNotFoundException ex) {
            return null;
        }
    }
}
