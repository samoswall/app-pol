package com.google.crypto.tink.shaded.protobuf;

import androidx.appcompat.app.v;
import java.util.Collections;
import java.util.Map;

public class p
{
    private static boolean b = true;
    private static volatile p c;
    static final p d;
    private final Map a;
    
    static {
        d = new p(true);
    }
    
    p(final boolean b) {
        this.a = Collections.emptyMap();
    }
    
    public static p b() {
        p c;
        if ((c = p.c) == null) {
            final Class<p> clazz;
            monitorenter(clazz = p.class);
            Label_0050: {
                while (true) {
                    Label_0042: {
                        try {
                            if ((c = p.c) != null) {
                                break Label_0050;
                            }
                            if (p.b) {
                                c = o.a();
                                break Label_0046;
                            }
                            break Label_0042;
                        }
                        finally {
                            monitorexit(clazz);
                            p.c = c;
                            monitorexit(clazz);
                            return c;
                            c = p.d;
                            continue;
                        }
                    }
                    break;
                }
            }
        }
        return c;
    }
    
    public x.c a(final O o, final int n) {
        v.a(this.a.get((Object)new a(o, n)));
        return null;
    }
    
    private static final class a
    {
        private final Object a;
        private final int b;
        
        a(final Object a, final int b) {
            this.a = a;
            this.b = b;
        }
        
        @Override
        public boolean equals(final Object o) {
            final boolean b = o instanceof a;
            final boolean b2 = false;
            if (!b) {
                return false;
            }
            final a a = (a)o;
            boolean b3 = b2;
            if (this.a == a.a) {
                b3 = b2;
                if (this.b == a.b) {
                    b3 = true;
                }
            }
            return b3;
        }
        
        @Override
        public int hashCode() {
            return System.identityHashCode(this.a) * 65535 + this.b;
        }
    }
}
