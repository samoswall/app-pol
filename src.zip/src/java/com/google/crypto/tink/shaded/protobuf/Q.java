package com.google.crypto.tink.shaded.protobuf;

import java.util.Map$Entry;

abstract class q
{
    abstract int a(final Map$Entry p0);
    
    abstract Object b(final p p0, final O p1, final int p2);
    
    abstract t c(final Object p0);
    
    abstract t d(final Object p0);
    
    abstract boolean e(final O p0);
    
    abstract void f(final Object p0);
    
    abstract Object g(final Object p0, final d0 p1, final Object p2, final p p3, final t p4, final Object p5, final k0 p6);
    
    abstract void h(final d0 p0, final Object p1, final p p2, final t p3);
    
    abstract void i(final h p0, final Object p1, final p p2, final t p3);
    
    abstract void j(final r0 p0, final Map$Entry p1);
}
