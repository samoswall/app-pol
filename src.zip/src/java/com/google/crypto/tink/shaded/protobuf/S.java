package com.google.crypto.tink.shaded.protobuf;

abstract class s
{
    private static final q a;
    private static final q b;
    
    static {
        a = new r();
        b = c();
    }
    
    static q a() {
        final q b = s.b;
        if (b != null) {
            return b;
        }
        throw new IllegalStateException("Protobuf runtime is not correctly loaded.");
    }
    
    static q b() {
        return s.a;
    }
    
    private static q c() {
        try {
            return (q)Class.forName("com.google.crypto.tink.shaded.protobuf.ExtensionSchemaFull").getDeclaredConstructor((Class<?>[])new Class[0]).newInstance(new Object[0]);
        }
        catch (final Exception ex) {
            return null;
        }
    }
}
