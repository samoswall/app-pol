package com.google.crypto.tink.shaded.protobuf;

import java.util.Iterator;

abstract class t
{
    abstract Iterator a();
    
    public abstract int b();
    
    public abstract int c();
    
    abstract boolean d();
    
    public abstract boolean e();
    
    @Override
    public abstract boolean equals(final Object p0);
    
    public abstract Iterator f();
    
    public abstract void g();
    
    public abstract void h(final t p0);
    
    @Override
    public abstract int hashCode();
}
