package com.google.crypto.tink.shaded.protobuf;

import java.util.RandomAccess;

abstract class v extends c implements d, RandomAccess, Y
{
    public abstract void c(final float p0);
}
