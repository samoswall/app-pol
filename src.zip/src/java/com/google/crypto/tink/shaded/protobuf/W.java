package com.google.crypto.tink.shaded.protobuf;

class w implements N
{
    private static final w a;
    
    static {
        a = new w();
    }
    
    private w() {
    }
    
    public static w c() {
        return w.a;
    }
    
    @Override
    public M a(final Class cls) {
        if (x.class.isAssignableFrom(cls)) {
            try {
                return (M)x.v(cls.asSubclass(x.class)).k();
            }
            catch (final Exception ex) {
                final StringBuilder sb = new StringBuilder();
                sb.append("Unable to get message info for ");
                sb.append(cls.getName());
                throw new RuntimeException(sb.toString(), (Throwable)ex);
            }
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append("Unsupported message type: ");
        sb2.append(cls.getName());
        throw new IllegalArgumentException(sb2.toString());
    }
    
    @Override
    public boolean b(final Class cls) {
        return x.class.isAssignableFrom(cls);
    }
}
