package com.google.crypto.tink.shaded.protobuf;

import java.util.List;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public abstract class x extends com.google.crypto.tink.shaded.protobuf.a
{
    private static final int MEMOIZED_SERIALIZED_SIZE_MASK = Integer.MAX_VALUE;
    private static final int MUTABLE_FLAG_MASK = Integer.MIN_VALUE;
    static final int UNINITIALIZED_HASH_CODE = 0;
    static final int UNINITIALIZED_SERIALIZED_SIZE = Integer.MAX_VALUE;
    private static Map<Object, x> defaultInstanceMap;
    private int memoizedSerializedSize;
    protected l0 unknownFields;
    
    static {
        x.defaultInstanceMap = (Map<Object, x>)new ConcurrentHashMap();
    }
    
    public x() {
        this.memoizedSerializedSize = -1;
        this.unknownFields = l0.c();
    }
    
    static Object A(final Method method, final Object o, final Object... array) {
        try {
            return method.invoke(o, array);
        }
        catch (final InvocationTargetException ex) {
            final Throwable cause = ex.getCause();
            if (cause instanceof RuntimeException) {
                throw (RuntimeException)cause;
            }
            if (cause instanceof Error) {
                throw (Error)cause;
            }
            throw new RuntimeException("Unexpected exception thrown by generated accessor method.", cause);
        }
        catch (final IllegalAccessException ex2) {
            throw new RuntimeException("Couldn't use Java reflection to implement protocol message reflection.", (Throwable)ex2);
        }
    }
    
    protected static final boolean C(final x x, final boolean b) {
        final byte byteValue = (byte)x.r(d.GET_MEMOIZED_IS_INITIALIZED);
        if (byteValue == 1) {
            return true;
        }
        if (byteValue == 0) {
            return false;
        }
        final boolean c = a0.a().d(x).c(x);
        if (b) {
            final d set_MEMOIZED_IS_INITIALIZED = d.SET_MEMOIZED_IS_INITIALIZED;
            x x2;
            if (c) {
                x2 = x;
            }
            else {
                x2 = null;
            }
            x.s(set_MEMOIZED_IS_INITIALIZED, x2);
        }
        return c;
    }
    
    protected static z.d G(final z.d d) {
        final int size = ((List)d).size();
        int n;
        if (size == 0) {
            n = 10;
        }
        else {
            n = size * 2;
        }
        return d.e(n);
    }
    
    protected static Object I(final O o, final String s, final Object[] array) {
        return new c0(o, s, array);
    }
    
    protected static x K(final x x, final h h, final p p3) {
        return l(N(x, h, p3));
    }
    
    protected static x L(final x x, final InputStream inputStream, final p p3) {
        return l(O(x, i.f(inputStream), p3));
    }
    
    protected static x M(final x x, final byte[] array, final p p3) {
        return l(P(x, array, 0, array.length, p3));
    }
    
    private static x N(x o, final h h, final p p3) {
        final i x = h.x();
        o = O(o, x, p3);
        try {
            x.a(0);
            return o;
        }
        catch (final A a) {
            throw a.k(o);
        }
    }
    
    static x O(final x x, final i i, final p p3) {
        final x j = x.J();
        try {
            final e0 d = a0.a().d(j);
            d.j(j, com.google.crypto.tink.shaded.protobuf.j.O(i), p3);
            d.b(j);
            return j;
        }
        catch (final RuntimeException ex) {
            if (((Throwable)ex).getCause() instanceof A) {
                throw (A)((Throwable)ex).getCause();
            }
            throw ex;
        }
        catch (final IOException ex2) {
            final IOException ex3;
            if (((Throwable)ex3).getCause() instanceof A) {
                throw (A)((Throwable)ex3).getCause();
            }
            throw new A(ex3).k(j);
        }
        catch (final j0 j2) {}
        catch (final A a) {
            final j0 j3;
            throw j3.a().k(j);
            final A a3;
            A a2 = a3;
            iftrue(Label_0128:)(!a3.a());
            a2 = new A(a3);
            Label_0128: {
                throw a2.k(j);
            }
        }
    }
    
    private static x P(final x x, final byte[] array, final int n, final int n2, final p p5) {
        final x j = x.J();
        try {
            final e0 d = a0.a().d(j);
            d.h(j, array, n, n + n2, new e.a(p5));
            d.b(j);
            return j;
        }
        catch (final IOException ex) {
            if (((Throwable)ex).getCause() instanceof A) {
                throw (A)((Throwable)ex).getCause();
            }
            throw new A(ex).k(j);
        }
        catch (final j0 j2) {}
        catch (final A a) {
            final j0 j3;
            throw j3.a().k(j);
            while (true) {
                final A a3;
                A a2 = new A(a3);
                Label_0135: {
                    throw a2.k(j);
                }
                a2 = a3;
                iftrue(Label_0135:)(!a3.a());
                continue;
            }
        }
        catch (final IndexOutOfBoundsException ex2) {}
    }
    
    protected static void Q(final Class clazz, final x x) {
        x.F();
        x.defaultInstanceMap.put((Object)clazz, (Object)x);
    }
    
    private static x l(final x x) {
        if (x != null && !x.B()) {
            throw x.j().a().k(x);
        }
        return x;
    }
    
    private int p(final e0 e0) {
        if (e0 == null) {
            return a0.a().d(this).e(this);
        }
        return e0.e(this);
    }
    
    protected static z.d u() {
        return b0.g();
    }
    
    static x v(final Class clazz) {
        x x;
        if ((x = (x)com.google.crypto.tink.shaded.protobuf.x.defaultInstanceMap.get((Object)clazz)) == null) {
            try {
                Class.forName(clazz.getName(), true, clazz.getClassLoader());
                x = (x)com.google.crypto.tink.shaded.protobuf.x.defaultInstanceMap.get((Object)clazz);
            }
            catch (final ClassNotFoundException ex) {
                throw new IllegalStateException("Class initialization cannot fail.", (Throwable)ex);
            }
        }
        x w;
        if ((w = x) == null) {
            w = ((x)o0.k(clazz)).w();
            if (w == null) {
                throw new IllegalStateException();
            }
            com.google.crypto.tink.shaded.protobuf.x.defaultInstanceMap.put((Object)clazz, (Object)w);
        }
        return w;
    }
    
    public final boolean B() {
        return C(this, true);
    }
    
    boolean D() {
        return (this.memoizedSerializedSize & Integer.MIN_VALUE) != 0x0;
    }
    
    protected void E() {
        a0.a().d(this).b(this);
        this.F();
    }
    
    void F() {
        this.memoizedSerializedSize &= Integer.MAX_VALUE;
    }
    
    public final a H() {
        return (a)this.r(d.NEW_BUILDER);
    }
    
    x J() {
        return (x)this.r(d.NEW_MUTABLE_INSTANCE);
    }
    
    void R(final int memoizedHashCode) {
        super.memoizedHashCode = memoizedHashCode;
    }
    
    void S(final int n) {
        if (n >= 0) {
            this.memoizedSerializedSize = ((n & Integer.MAX_VALUE) | (this.memoizedSerializedSize & Integer.MIN_VALUE));
            return;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("serialized size must be non-negative, was ");
        sb.append(n);
        throw new IllegalStateException(sb.toString());
    }
    
    public final a T() {
        return ((a)this.r(d.NEW_BUILDER)).p(this);
    }
    
    @Override
    public int b() {
        return this.h(null);
    }
    
    @Override
    public void d(final k k) {
        a0.a().d(this).i(this, l.P(k));
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o != null && this.getClass() == o.getClass() && a0.a().d(this).d(this, o));
    }
    
    @Override
    int h(final e0 e0) {
        if (this.D()) {
            final int p = this.p(e0);
            if (p >= 0) {
                return p;
            }
            final StringBuilder sb = new StringBuilder();
            sb.append("serialized size must be non-negative, was ");
            sb.append(p);
            throw new IllegalStateException(sb.toString());
        }
        else {
            if (this.y() != Integer.MAX_VALUE) {
                return this.y();
            }
            final int p2 = this.p(e0);
            this.S(p2);
            return p2;
        }
    }
    
    @Override
    public int hashCode() {
        if (this.D()) {
            return this.o();
        }
        if (this.z()) {
            this.R(this.o());
        }
        return this.x();
    }
    
    Object k() {
        return this.r(d.BUILD_MESSAGE_INFO);
    }
    
    void m() {
        super.memoizedHashCode = 0;
    }
    
    void n() {
        this.S(Integer.MAX_VALUE);
    }
    
    int o() {
        return a0.a().d(this).g(this);
    }
    
    protected final a q() {
        return (a)this.r(d.NEW_BUILDER);
    }
    
    protected Object r(final d d) {
        return this.t(d, null, null);
    }
    
    protected Object s(final d d, final Object o) {
        return this.t(d, o, null);
    }
    
    protected abstract Object t(final d p0, final Object p1, final Object p2);
    
    @Override
    public String toString() {
        return Q.f(this, super.toString());
    }
    
    public final x w() {
        return (x)this.r(d.GET_DEFAULT_INSTANCE);
    }
    
    int x() {
        return super.memoizedHashCode;
    }
    
    int y() {
        return this.memoizedSerializedSize & Integer.MAX_VALUE;
    }
    
    boolean z() {
        return this.x() == 0;
    }
    
    public abstract static class a extends com.google.crypto.tink.shaded.protobuf.a.a
    {
        private final x a;
        protected x b;
        
        protected a(final x a) {
            this.a = a;
            if (!a.D()) {
                this.b = this.r();
                return;
            }
            throw new IllegalArgumentException("Default instance must be immutable.");
        }
        
        private static void q(final Object o, final Object o2) {
            a0.a().d(o).a(o, o2);
        }
        
        private x r() {
            return this.a.J();
        }
        
        public final x i() {
            final x j = this.j();
            if (j.B()) {
                return j;
            }
            throw com.google.crypto.tink.shaded.protobuf.a.a.h(j);
        }
        
        public x j() {
            if (!this.b.D()) {
                return this.b;
            }
            this.b.E();
            return this.b;
        }
        
        public a k() {
            final a h = this.n().H();
            h.b = this.j();
            return h;
        }
        
        protected final void l() {
            if (!this.b.D()) {
                this.m();
            }
        }
        
        protected void m() {
            final x r = this.r();
            q(r, this.b);
            this.b = r;
        }
        
        public x n() {
            return this.a;
        }
        
        public a p(final x x) {
            if (this.n().equals(x)) {
                return this;
            }
            this.l();
            q(this.b, x);
            return this;
        }
    }
    
    protected static class b extends com.google.crypto.tink.shaded.protobuf.b
    {
        private final x b;
        
        public b(final x b) {
            this.b = b;
        }
    }
    
    public abstract static class c extends n
    {
    }
    
    public enum d
    {
        private static final d[] $VALUES;
        
        BUILD_MESSAGE_INFO, 
        GET_DEFAULT_INSTANCE, 
        GET_MEMOIZED_IS_INITIALIZED, 
        GET_PARSER, 
        NEW_BUILDER, 
        NEW_MUTABLE_INSTANCE, 
        SET_MEMOIZED_IS_INITIALIZED;
    }
}
