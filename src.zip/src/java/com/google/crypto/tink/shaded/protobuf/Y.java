package com.google.crypto.tink.shaded.protobuf;

import java.util.RandomAccess;

abstract class y extends c implements d, RandomAccess, Y
{
    public abstract void c(final int p0);
    
    public abstract int g(final int p0);
}
