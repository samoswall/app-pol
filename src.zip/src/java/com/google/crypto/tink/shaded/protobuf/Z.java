package com.google.crypto.tink.shaded.protobuf;

import java.util.RandomAccess;
import java.util.List;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;

public abstract class z
{
    static final Charset a;
    static final Charset b;
    static final Charset c;
    public static final byte[] d;
    public static final ByteBuffer e;
    public static final i f;
    
    static {
        a = Charset.forName("US-ASCII");
        b = Charset.forName("UTF-8");
        c = Charset.forName("ISO-8859-1");
        final byte[] array = d = new byte[0];
        e = ByteBuffer.wrap(array);
        f = i.h(array);
    }
    
    static Object a(final Object o) {
        o.getClass();
        return o;
    }
    
    static Object b(final Object o, final String s) {
        if (o != null) {
            return o;
        }
        throw new NullPointerException(s);
    }
    
    public static int c(final boolean b) {
        int n;
        if (b) {
            n = 1231;
        }
        else {
            n = 1237;
        }
        return n;
    }
    
    public static int d(final byte[] array) {
        return e(array, 0, array.length);
    }
    
    static int e(final byte[] array, int h, int n) {
        n = (h = h(n, array, h, n));
        if (n == 0) {
            h = 1;
        }
        return h;
    }
    
    public static int f(final long n) {
        return (int)(n ^ n >>> 32);
    }
    
    public static boolean g(final byte[] array) {
        return p0.m(array);
    }
    
    static int h(int i, final byte[] array, final int n, final int n2) {
        int n3 = i;
        for (i = n; i < n + n2; ++i) {
            n3 = n3 * 31 + array[i];
        }
        return n3;
    }
    
    public static String i(final byte[] array) {
        return new String(array, z.b);
    }
    
    public interface a
    {
    }
    
    public interface b
    {
    }
    
    public interface c
    {
        boolean a(final int p0);
    }
    
    public interface d extends List, RandomAccess
    {
        void d();
        
        d e(final int p0);
        
        boolean i();
    }
}
