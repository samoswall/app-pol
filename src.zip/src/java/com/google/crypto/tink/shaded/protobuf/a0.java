package com.google.crypto.tink.shaded.protobuf;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

final class a0
{
    private static final a0 c;
    private final f0 a;
    private final ConcurrentMap b;
    
    static {
        c = new a0();
    }
    
    private a0() {
        this.b = (ConcurrentMap)new ConcurrentHashMap();
        this.a = new G();
    }
    
    public static a0 a() {
        return a0.c;
    }
    
    public e0 b(final Class clazz, final e0 e0) {
        z.b(clazz, "messageType");
        z.b(e0, "schema");
        return (e0)this.b.putIfAbsent((Object)clazz, (Object)e0);
    }
    
    public e0 c(final Class clazz) {
        z.b(clazz, "messageType");
        e0 a;
        if ((a = (e0)((Map)this.b).get((Object)clazz)) == null) {
            a = this.a.a(clazz);
            final e0 b = this.b(clazz, a);
            if (b != null) {
                a = b;
            }
        }
        return a;
    }
    
    public e0 d(final Object o) {
        return this.c(o.getClass());
    }
}
