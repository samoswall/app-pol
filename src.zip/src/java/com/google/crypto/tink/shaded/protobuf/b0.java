package com.google.crypto.tink.shaded.protobuf;

import java.util.Arrays;
import java.util.RandomAccess;

final class b0 extends c implements RandomAccess
{
    private static final b0 d;
    private Object[] b;
    private int c;
    
    static {
        (d = new b0(new Object[0], 0)).d();
    }
    
    private b0(final Object[] b, final int c) {
        this.b = b;
        this.c = c;
    }
    
    private static Object[] c(final int n) {
        return new Object[n];
    }
    
    public static b0 g() {
        return b0.d;
    }
    
    private void j(final int n) {
        if (n >= 0 && n < this.c) {
            return;
        }
        throw new IndexOutOfBoundsException(this.n(n));
    }
    
    private String n(final int n) {
        final StringBuilder sb = new StringBuilder();
        sb.append("Index:");
        sb.append(n);
        sb.append(", Size:");
        sb.append(this.c);
        return sb.toString();
    }
    
    public void add(final int n, final Object o) {
        this.b();
        if (n >= 0) {
            final int c = this.c;
            if (n <= c) {
                final Object[] b = this.b;
                if (c < b.length) {
                    System.arraycopy((Object)b, n, (Object)b, n + 1, c - n);
                }
                else {
                    final Object[] c2 = c(c * 3 / 2 + 1);
                    System.arraycopy((Object)this.b, 0, (Object)c2, 0, n);
                    System.arraycopy((Object)this.b, n, (Object)c2, n + 1, this.c - n);
                    this.b = c2;
                }
                this.b[n] = o;
                ++this.c;
                ++super.modCount;
                return;
            }
        }
        throw new IndexOutOfBoundsException(this.n(n));
    }
    
    @Override
    public boolean add(final Object o) {
        this.b();
        final int c = this.c;
        final Object[] b = this.b;
        if (c == b.length) {
            this.b = Arrays.copyOf(b, c * 3 / 2 + 1);
        }
        this.b[this.c++] = o;
        ++super.modCount;
        return true;
    }
    
    public Object get(final int n) {
        this.j(n);
        return this.b[n];
    }
    
    public b0 o(final int n) {
        if (n >= this.c) {
            return new b0(Arrays.copyOf(this.b, n), this.c);
        }
        throw new IllegalArgumentException();
    }
    
    @Override
    public Object remove(final int n) {
        this.b();
        this.j(n);
        final Object[] b = this.b;
        final Object o = b[n];
        final int c = this.c;
        if (n < c - 1) {
            System.arraycopy((Object)b, n + 1, (Object)b, n, c - n - 1);
        }
        --this.c;
        ++super.modCount;
        return o;
    }
    
    public Object set(final int n, final Object o) {
        this.b();
        this.j(n);
        final Object[] b = this.b;
        final Object o2 = b[n];
        b[n] = o;
        ++super.modCount;
        return o2;
    }
    
    public int size() {
        return this.c;
    }
}
