package com.google.crypto.tink.shaded.protobuf;

import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import java.util.RandomAccess;

public class C extends c implements D, RandomAccess
{
    private static final C c;
    public static final D d;
    private final List b;
    
    static {
        final C c2 = new C();
        (c = c2).d();
        d = c2;
    }
    
    public C() {
        this(10);
    }
    
    public C(final int n) {
        this(new ArrayList(n));
    }
    
    private C(final ArrayList b) {
        this.b = (List)b;
    }
    
    private static String g(final Object o) {
        if (o instanceof String) {
            return (String)o;
        }
        if (o instanceof h) {
            return ((h)o).G();
        }
        return z.i((byte[])o);
    }
    
    @Override
    public void E(final h h) {
        this.b();
        this.b.add((Object)h);
        ++super.modCount;
    }
    
    @Override
    public boolean addAll(final int n, final Collection collection) {
        this.b();
        Object f = collection;
        if (collection instanceof D) {
            f = ((D)collection).f();
        }
        final boolean addAll = this.b.addAll(n, (Collection)f);
        ++super.modCount;
        return addAll;
    }
    
    @Override
    public boolean addAll(final Collection collection) {
        return this.addAll(this.size(), collection);
    }
    
    public void c(final int n, final String s) {
        this.b();
        this.b.add(n, (Object)s);
        ++super.modCount;
    }
    
    @Override
    public void clear() {
        this.b();
        this.b.clear();
        ++super.modCount;
    }
    
    @Override
    public List f() {
        return Collections.unmodifiableList(this.b);
    }
    
    @Override
    public Object h(final int n) {
        return this.b.get(n);
    }
    
    public String j(final int n) {
        final Object value = this.b.get(n);
        if (value instanceof String) {
            return (String)value;
        }
        if (value instanceof h) {
            final h h = (h)value;
            final String g = h.G();
            if (h.u()) {
                this.b.set(n, (Object)g);
            }
            return g;
        }
        final byte[] array = (byte[])value;
        final String i = z.i(array);
        if (z.g(array)) {
            this.b.set(n, (Object)i);
        }
        return i;
    }
    
    @Override
    public D l() {
        if (this.i()) {
            return new n0(this);
        }
        return this;
    }
    
    public C n(final int n) {
        if (n >= this.size()) {
            final ArrayList list = new ArrayList(n);
            list.addAll((Collection)this.b);
            return new C(list);
        }
        throw new IllegalArgumentException();
    }
    
    public String o(final int n) {
        this.b();
        final Object remove = this.b.remove(n);
        ++super.modCount;
        return g(remove);
    }
    
    public String p(final int n, final String s) {
        this.b();
        return g(this.b.set(n, (Object)s));
    }
    
    public int size() {
        return this.b.size();
    }
}
