package com.google.crypto.tink.shaded.protobuf;

final class c0 implements M
{
    private final O a;
    private final String b;
    private final Object[] c;
    private final int d;
    
    c0(final O a, final String b, final Object[] c) {
        this.a = a;
        this.b = b;
        this.c = c;
        final char char1 = b.charAt(0);
        if (char1 < '\ud800') {
            this.d = char1;
        }
        else {
            int n = char1 & '\u1fff';
            int n2 = 13;
            int n3 = 1;
            char char2;
            while (true) {
                char2 = b.charAt(n3);
                if (char2 < '\ud800') {
                    break;
                }
                n |= (char2 & '\u1fff') << n2;
                n2 += 13;
                ++n3;
            }
            this.d = (n | char2 << n2);
        }
    }
    
    @Override
    public boolean a() {
        return (this.d & 0x2) == 0x2;
    }
    
    @Override
    public O b() {
        return this.a;
    }
    
    @Override
    public Z c() {
        Z z;
        if ((this.d & 0x1) == 0x1) {
            z = Z.PROTO2;
        }
        else {
            z = Z.PROTO3;
        }
        return z;
    }
    
    Object[] d() {
        return this.c;
    }
    
    String e() {
        return this.b;
    }
}
