package com.google.crypto.tink.shaded.protobuf;

import java.util.Map;
import java.util.List;

interface d0
{
    void A(final List p0);
    
    int B();
    
    boolean C();
    
    int D();
    
    void E(final List p0);
    
    void F(final List p0);
    
    long G();
    
    String H();
    
    void I(final List p0);
    
    void J(final Object p0, final e0 p1, final p p2);
    
    void K(final List p0, final e0 p1, final p p2);
    
    void L(final Object p0, final e0 p1, final p p2);
    
    void M(final Map p0, final H.a p1, final p p2);
    
    void N(final List p0, final e0 p1, final p p2);
    
    int a();
    
    void b(final List p0);
    
    long c();
    
    long d();
    
    void e(final List p0);
    
    void f(final List p0);
    
    void g(final List p0);
    
    int h();
    
    boolean i();
    
    long j();
    
    void k(final List p0);
    
    int l();
    
    void m(final List p0);
    
    void n(final List p0);
    
    void o(final List p0);
    
    void p(final List p0);
    
    int q();
    
    void r(final List p0);
    
    double readDouble();
    
    float readFloat();
    
    int s();
    
    long t();
    
    void u(final List p0);
    
    String v();
    
    int w();
    
    void x(final List p0);
    
    void y(final List p0);
    
    h z();
}
