package com.google.crypto.tink.shaded.protobuf;

interface e0
{
    void a(final Object p0, final Object p1);
    
    void b(final Object p0);
    
    boolean c(final Object p0);
    
    boolean d(final Object p0, final Object p1);
    
    int e(final Object p0);
    
    Object f();
    
    int g(final Object p0);
    
    void h(final Object p0, final byte[] p1, final int p2, final int p3, final e.a p4);
    
    void i(final Object p0, final r0 p1);
    
    void j(final Object p0, final d0 p1, final p p2);
}
