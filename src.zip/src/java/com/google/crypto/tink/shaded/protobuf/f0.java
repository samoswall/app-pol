package com.google.crypto.tink.shaded.protobuf;

interface f0
{
    e0 a(final Class p0);
}
