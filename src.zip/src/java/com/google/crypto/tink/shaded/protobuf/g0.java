package com.google.crypto.tink.shaded.protobuf;

import java.util.Iterator;
import java.util.RandomAccess;
import java.util.List;

abstract class g0
{
    private static final Class a;
    private static final k0 b;
    private static final k0 c;
    private static final k0 d;
    
    static {
        a = A();
        b = B(false);
        c = B(true);
        d = new m0();
    }
    
    private static Class A() {
        try {
            return Class.forName("com.google.crypto.tink.shaded.protobuf.GeneratedMessageV3");
        }
        finally {
            return null;
        }
    }
    
    private static k0 B(final boolean b) {
        try {
            final Class c = C();
            if (c == null) {}
            return (k0)c.getConstructor(Boolean.TYPE).newInstance(new Object[] { b });
        }
        finally {
            return null;
        }
    }
    
    private static Class C() {
        try {
            return Class.forName("com.google.crypto.tink.shaded.protobuf.UnknownFieldSetSchema");
        }
        finally {
            return null;
        }
    }
    
    static void D(final q q, final Object o, final Object o2) {
        final t c = q.c(o2);
        if (!c.d()) {
            q.d(o).h(c);
        }
    }
    
    static void E(final J j, final Object o, final Object o2, final long n) {
        o0.R(o, n, j.a(o0.C(o, n), o0.C(o2, n)));
    }
    
    static void F(final k0 k0, final Object o, final Object o2) {
        k0.p(o, k0.k(k0.g(o), k0.g(o2)));
    }
    
    public static k0 G() {
        return g0.b;
    }
    
    public static k0 H() {
        return g0.c;
    }
    
    public static void I(final Class clazz) {
        if (!x.class.isAssignableFrom(clazz)) {
            final Class a = g0.a;
            if (a != null) {
                if (!a.isAssignableFrom(clazz)) {
                    throw new IllegalArgumentException("Message classes must extend GeneratedMessageV3 or GeneratedMessageLite");
                }
            }
        }
    }
    
    static boolean J(final Object o, final Object obj) {
        return o == obj || (o != null && o.equals(obj));
    }
    
    static Object K(final Object o, final int n, final int n2, final Object o2, final k0 k0) {
        Object f = o2;
        if (o2 == null) {
            f = k0.f(o);
        }
        k0.e(f, n, n2);
        return f;
    }
    
    public static k0 L() {
        return g0.d;
    }
    
    public static void M(final int n, final List list, final r0 r0, final boolean b) {
        if (list != null && !list.isEmpty()) {
            r0.w(n, list, b);
        }
    }
    
    public static void N(final int n, final List list, final r0 r0) {
        if (list != null && !list.isEmpty()) {
            r0.I(n, list);
        }
    }
    
    public static void O(final int n, final List list, final r0 r0, final boolean b) {
        if (list != null && !list.isEmpty()) {
            r0.G(n, list, b);
        }
    }
    
    public static void P(final int n, final List list, final r0 r0, final boolean b) {
        if (list != null && !list.isEmpty()) {
            r0.F(n, list, b);
        }
    }
    
    public static void Q(final int n, final List list, final r0 r0, final boolean b) {
        if (list != null && !list.isEmpty()) {
            r0.v(n, list, b);
        }
    }
    
    public static void R(final int n, final List list, final r0 r0, final boolean b) {
        if (list != null && !list.isEmpty()) {
            r0.s(n, list, b);
        }
    }
    
    public static void S(final int n, final List list, final r0 r0, final boolean b) {
        if (list != null && !list.isEmpty()) {
            r0.a(n, list, b);
        }
    }
    
    public static void T(final int n, final List list, final r0 r0, final e0 e0) {
        if (list != null && !list.isEmpty()) {
            r0.M(n, list, e0);
        }
    }
    
    public static void U(final int n, final List list, final r0 r0, final boolean b) {
        if (list != null && !list.isEmpty()) {
            r0.m(n, list, b);
        }
    }
    
    public static void V(final int n, final List list, final r0 r0, final boolean b) {
        if (list != null && !list.isEmpty()) {
            r0.E(n, list, b);
        }
    }
    
    public static void W(final int n, final List list, final r0 r0, final e0 e0) {
        if (list != null && !list.isEmpty()) {
            r0.N(n, list, e0);
        }
    }
    
    public static void X(final int n, final List list, final r0 r0, final boolean b) {
        if (list != null && !list.isEmpty()) {
            r0.t(n, list, b);
        }
    }
    
    public static void Y(final int n, final List list, final r0 r0, final boolean b) {
        if (list != null && !list.isEmpty()) {
            r0.f(n, list, b);
        }
    }
    
    public static void Z(final int n, final List list, final r0 r0, final boolean b) {
        if (list != null && !list.isEmpty()) {
            r0.C(n, list, b);
        }
    }
    
    static int a(final int n, final List list, final boolean b) {
        final int size = list.size();
        if (size == 0) {
            return 0;
        }
        if (b) {
            return k.L(n) + k.x(size);
        }
        return size * k.d(n, true);
    }
    
    public static void a0(final int n, final List list, final r0 r0, final boolean b) {
        if (list != null && !list.isEmpty()) {
            r0.y(n, list, b);
        }
    }
    
    static int b(final List list) {
        return list.size();
    }
    
    public static void b0(final int n, final List list, final r0 r0) {
        if (list != null && !list.isEmpty()) {
            r0.j(n, list);
        }
    }
    
    static int c(int i, final List list) {
        final int size = list.size();
        final int n = 0;
        if (size == 0) {
            return 0;
        }
        final int n2 = size * k.L(i);
        i = n;
        int n3 = n2;
        while (i < list.size()) {
            n3 += k.g((h)list.get(i));
            ++i;
        }
        return n3;
    }
    
    public static void c0(final int n, final List list, final r0 r0, final boolean b) {
        if (list != null && !list.isEmpty()) {
            r0.x(n, list, b);
        }
    }
    
    static int d(final int n, final List list, final boolean b) {
        final int size = list.size();
        if (size == 0) {
            return 0;
        }
        final int e = e(list);
        if (b) {
            return k.L(n) + k.x(e);
        }
        return e + size * k.L(n);
    }
    
    public static void d0(final int n, final List list, final r0 r0, final boolean b) {
        if (list != null && !list.isEmpty()) {
            r0.g(n, list, b);
        }
    }
    
    static int e(final List list) {
        final int size = list.size();
        int n = 0;
        final int n2 = 0;
        if (size == 0) {
            return 0;
        }
        int n5;
        if (list instanceof y) {
            final y y = (y)list;
            int n3 = 0;
            int n4 = n2;
            while (true) {
                n5 = n3;
                if (n4 >= size) {
                    break;
                }
                n3 += k.k(y.g(n4));
                ++n4;
            }
        }
        else {
            int n6 = 0;
            while (true) {
                n5 = n6;
                if (n >= size) {
                    break;
                }
                n6 += k.k((int)list.get(n));
                ++n;
            }
        }
        return n5;
    }
    
    static int f(final int n, final List list, final boolean b) {
        final int size = list.size();
        if (size == 0) {
            return 0;
        }
        if (b) {
            return k.L(n) + k.x(size * 4);
        }
        return size * k.l(n, 0);
    }
    
    static int g(final List list) {
        return list.size() * 4;
    }
    
    static int h(final int n, final List list, final boolean b) {
        final int size = list.size();
        if (size == 0) {
            return 0;
        }
        if (b) {
            return k.L(n) + k.x(size * 8);
        }
        return size * k.n(n, 0L);
    }
    
    static int i(final List list) {
        return list.size() * 8;
    }
    
    static int j(final int n, final List list, final e0 e0) {
        final int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        int n2 = 0;
        while (i < size) {
            n2 += k.r(n, (O)list.get(i), e0);
            ++i;
        }
        return n2;
    }
    
    static int k(final int n, final List list, final boolean b) {
        final int size = list.size();
        if (size == 0) {
            return 0;
        }
        final int l = l(list);
        if (b) {
            return k.L(n) + k.x(l);
        }
        return l + size * k.L(n);
    }
    
    static int l(final List list) {
        final int size = list.size();
        int n = 0;
        final int n2 = 0;
        if (size == 0) {
            return 0;
        }
        int n5;
        if (list instanceof y) {
            final y y = (y)list;
            int n3 = 0;
            int n4 = n2;
            while (true) {
                n5 = n3;
                if (n4 >= size) {
                    break;
                }
                n3 += k.u(y.g(n4));
                ++n4;
            }
        }
        else {
            int n6 = 0;
            while (true) {
                n5 = n6;
                if (n >= size) {
                    break;
                }
                n6 += k.u((int)list.get(n));
                ++n;
            }
        }
        return n5;
    }
    
    static int m(final int n, final List list, final boolean b) {
        if (list.size() == 0) {
            return 0;
        }
        final int n2 = n(list);
        if (b) {
            return k.L(n) + k.x(n2);
        }
        return n2 + list.size() * k.L(n);
    }
    
    static int n(final List list) {
        final int size = list.size();
        int n = 0;
        final int n2 = 0;
        if (size == 0) {
            return 0;
        }
        int n5;
        if (list instanceof F) {
            final F f = (F)list;
            int n3 = 0;
            int n4 = n2;
            while (true) {
                n5 = n3;
                if (n4 >= size) {
                    break;
                }
                n3 += k.w(f.g(n4));
                ++n4;
            }
        }
        else {
            int n6 = 0;
            while (true) {
                n5 = n6;
                if (n >= size) {
                    break;
                }
                n6 += k.w((long)list.get(n));
                ++n;
            }
        }
        return n5;
    }
    
    static int o(final int n, final Object o, final e0 e0) {
        return k.y(n, (O)o, e0);
    }
    
    static int p(int n, final List list, final e0 e0) {
        final int size = list.size();
        int i = 0;
        if (size == 0) {
            return 0;
        }
        n = k.L(n) * size;
        while (i < size) {
            n += k.z((O)list.get(i), e0);
            ++i;
        }
        return n;
    }
    
    static int q(final int n, final List list, final boolean b) {
        final int size = list.size();
        if (size == 0) {
            return 0;
        }
        final int r = r(list);
        if (b) {
            return k.L(n) + k.x(r);
        }
        return r + size * k.L(n);
    }
    
    static int r(final List list) {
        final int size = list.size();
        final int n = 0;
        int n2 = 0;
        if (size == 0) {
            return 0;
        }
        int n4;
        if (list instanceof y) {
            final y y = (y)list;
            int n3 = 0;
            while (true) {
                n4 = n3;
                if (n2 >= size) {
                    break;
                }
                n3 += k.G(y.g(n2));
                ++n2;
            }
        }
        else {
            int n5 = 0;
            int n6 = n;
            while (true) {
                n4 = n5;
                if (n6 >= size) {
                    break;
                }
                n5 += k.G((int)list.get(n6));
                ++n6;
            }
        }
        return n4;
    }
    
    static int s(final int n, final List list, final boolean b) {
        final int size = list.size();
        if (size == 0) {
            return 0;
        }
        final int t = t(list);
        if (b) {
            return k.L(n) + k.x(t);
        }
        return t + size * k.L(n);
    }
    
    static int t(final List list) {
        final int size = list.size();
        int n = 0;
        final int n2 = 0;
        if (size == 0) {
            return 0;
        }
        int n5;
        if (list instanceof F) {
            final F f = (F)list;
            int n3 = 0;
            int n4 = n2;
            while (true) {
                n5 = n3;
                if (n4 >= size) {
                    break;
                }
                n3 += k.I(f.g(n4));
                ++n4;
            }
        }
        else {
            int n6 = 0;
            while (true) {
                n5 = n6;
                if (n >= size) {
                    break;
                }
                n6 += k.I((long)list.get(n));
                ++n;
            }
        }
        return n5;
    }
    
    static int u(int n, final List list) {
        final int size = list.size();
        int n2 = 0;
        final int n3 = 0;
        if (size == 0) {
            return 0;
        }
        final int n4 = n = k.L(n) * size;
        int n6;
        if (list instanceof D) {
            final D d = (D)list;
            n = n4;
            int n5 = n3;
            while (true) {
                n6 = n;
                if (n5 >= size) {
                    break;
                }
                final Object h = d.h(n5);
                int n7;
                if (h instanceof h) {
                    n7 = k.g((h)h);
                }
                else {
                    n7 = k.K((String)h);
                }
                n += n7;
                ++n5;
            }
        }
        else {
            while (true) {
                n6 = n;
                if (n2 >= size) {
                    break;
                }
                final Object value = list.get(n2);
                int n8;
                if (value instanceof h) {
                    n8 = k.g((h)value);
                }
                else {
                    n8 = k.K((String)value);
                }
                n += n8;
                ++n2;
            }
        }
        return n6;
    }
    
    static int v(final int n, final List list, final boolean b) {
        final int size = list.size();
        if (size == 0) {
            return 0;
        }
        final int w = w(list);
        if (b) {
            return k.L(n) + k.x(w);
        }
        return w + size * k.L(n);
    }
    
    static int w(final List list) {
        final int size = list.size();
        int n = 0;
        final int n2 = 0;
        if (size == 0) {
            return 0;
        }
        int n5;
        if (list instanceof y) {
            final y y = (y)list;
            int n3 = 0;
            int n4 = n2;
            while (true) {
                n5 = n3;
                if (n4 >= size) {
                    break;
                }
                n3 += k.N(y.g(n4));
                ++n4;
            }
        }
        else {
            int n6 = 0;
            while (true) {
                n5 = n6;
                if (n >= size) {
                    break;
                }
                n6 += k.N((int)list.get(n));
                ++n;
            }
        }
        return n5;
    }
    
    static int x(final int n, final List list, final boolean b) {
        final int size = list.size();
        if (size == 0) {
            return 0;
        }
        final int y = y(list);
        if (b) {
            return k.L(n) + k.x(y);
        }
        return y + size * k.L(n);
    }
    
    static int y(final List list) {
        final int size = list.size();
        int n = 0;
        final int n2 = 0;
        if (size == 0) {
            return 0;
        }
        int n5;
        if (list instanceof F) {
            final F f = (F)list;
            int n3 = 0;
            int n4 = n2;
            while (true) {
                n5 = n3;
                if (n4 >= size) {
                    break;
                }
                n3 += k.P(f.g(n4));
                ++n4;
            }
        }
        else {
            int n6 = 0;
            while (true) {
                n5 = n6;
                if (n >= size) {
                    break;
                }
                n6 += k.P((long)list.get(n));
                ++n;
            }
        }
        return n5;
    }
    
    static Object z(final Object o, final int n, final List list, final z.c c, Object o2, final k0 k0) {
        if (c == null) {
            return o2;
        }
        Object o3;
        if (list instanceof RandomAccess) {
            final int size = list.size();
            int i = 0;
            int n2 = 0;
            while (i < size) {
                final Integer n3 = (Integer)list.get(i);
                final int intValue = n3;
                if (c.a(intValue)) {
                    if (i != n2) {
                        list.set(n2, (Object)n3);
                    }
                    ++n2;
                }
                else {
                    o2 = K(o, n, intValue, o2, k0);
                }
                ++i;
            }
            o3 = o2;
            if (n2 != size) {
                list.subList(n2, size).clear();
                o3 = o2;
            }
        }
        else {
            final Iterator iterator = list.iterator();
            while (true) {
                o3 = o2;
                if (!iterator.hasNext()) {
                    break;
                }
                final int intValue2 = (int)iterator.next();
                if (c.a(intValue2)) {
                    continue;
                }
                o2 = K(o, n, intValue2, o2, k0);
                iterator.remove();
            }
        }
        return o3;
    }
}
