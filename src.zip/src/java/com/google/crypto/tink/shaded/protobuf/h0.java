package com.google.crypto.tink.shaded.protobuf;

abstract class h0 implements M
{
}
