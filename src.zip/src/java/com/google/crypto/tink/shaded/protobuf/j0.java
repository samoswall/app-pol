package com.google.crypto.tink.shaded.protobuf;

import java.util.List;

public class j0 extends RuntimeException
{
    private final List a;
    
    public j0(final O o) {
        super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
        this.a = null;
    }
    
    public A a() {
        return new A(((Throwable)this).getMessage());
    }
}
