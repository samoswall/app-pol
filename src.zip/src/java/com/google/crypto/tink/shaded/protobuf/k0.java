package com.google.crypto.tink.shaded.protobuf;

abstract class k0
{
    abstract void a(final Object p0, final int p1, final int p2);
    
    abstract void b(final Object p0, final int p1, final long p2);
    
    abstract void c(final Object p0, final int p1, final Object p2);
    
    abstract void d(final Object p0, final int p1, final h p2);
    
    abstract void e(final Object p0, final int p1, final long p2);
    
    abstract Object f(final Object p0);
    
    abstract Object g(final Object p0);
    
    abstract int h(final Object p0);
    
    abstract int i(final Object p0);
    
    abstract void j(final Object p0);
    
    abstract Object k(final Object p0, final Object p1);
    
    final void l(final Object o, final d0 d0) {
        while (d0.w() != Integer.MAX_VALUE && this.m(o, d0)) {}
    }
    
    final boolean m(final Object o, final d0 d0) {
        final int a = d0.a();
        final int a2 = q0.a(a);
        final int b = q0.b(a);
        if (b == 0) {
            this.e(o, a2, d0.G());
            return true;
        }
        if (b == 1) {
            this.b(o, a2, d0.d());
            return true;
        }
        if (b == 2) {
            this.d(o, a2, d0.z());
            return true;
        }
        if (b != 3) {
            if (b == 4) {
                return false;
            }
            if (b == 5) {
                this.a(o, a2, d0.h());
                return true;
            }
            throw A.e();
        }
        else {
            final Object n = this.n();
            final int c = q0.c(a2, 4);
            this.l(n, d0);
            if (c == d0.a()) {
                this.c(o, a2, this.r(n));
                return true;
            }
            throw A.b();
        }
    }
    
    abstract Object n();
    
    abstract void o(final Object p0, final Object p1);
    
    abstract void p(final Object p0, final Object p1);
    
    abstract boolean q(final d0 p0);
    
    abstract Object r(final Object p0);
    
    abstract void s(final Object p0, final r0 p1);
    
    abstract void t(final Object p0, final r0 p1);
}
