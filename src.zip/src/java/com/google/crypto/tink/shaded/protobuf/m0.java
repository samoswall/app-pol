package com.google.crypto.tink.shaded.protobuf;

class m0 extends k0
{
    l0 A(final Object o) {
        return ((x)o).unknownFields;
    }
    
    int B(final l0 l0) {
        return l0.d();
    }
    
    int C(final l0 l0) {
        return l0.e();
    }
    
    l0 D(final l0 l0, final l0 l2) {
        if (l0.c().equals(l2)) {
            return l0;
        }
        if (l0.c().equals(l0)) {
            return l0.j(l0, l2);
        }
        return l0.i(l2);
    }
    
    l0 E() {
        return l0.k();
    }
    
    void F(final Object o, final l0 l0) {
        this.G(o, l0);
    }
    
    void G(final Object o, final l0 unknownFields) {
        ((x)o).unknownFields = unknownFields;
    }
    
    l0 H(final l0 l0) {
        l0.h();
        return l0;
    }
    
    void I(final l0 l0, final r0 r0) {
        l0.p(r0);
    }
    
    void J(final l0 l0, final r0 r0) {
        l0.r(r0);
    }
    
    @Override
    void j(final Object o) {
        this.A(o).h();
    }
    
    @Override
    boolean q(final d0 d0) {
        return false;
    }
    
    void u(final l0 l0, final int n, final int n2) {
        l0.n(q0.c(n, 5), n2);
    }
    
    void v(final l0 l0, final int n, final long n2) {
        l0.n(q0.c(n, 1), n2);
    }
    
    void w(final l0 l0, final int n, final l0 l2) {
        l0.n(q0.c(n, 3), l2);
    }
    
    void x(final l0 l0, final int n, final h h) {
        l0.n(q0.c(n, 2), h);
    }
    
    void y(final l0 l0, final int n, final long n2) {
        l0.n(q0.c(n, 0), n2);
    }
    
    l0 z(final Object o) {
        l0 l0;
        if ((l0 = this.A(o)) == com.google.crypto.tink.shaded.protobuf.l0.c()) {
            l0 = com.google.crypto.tink.shaded.protobuf.l0.k();
            this.G(o, l0);
        }
        return l0;
    }
}
