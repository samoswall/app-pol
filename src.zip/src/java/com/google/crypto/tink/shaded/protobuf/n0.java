package com.google.crypto.tink.shaded.protobuf;

import java.util.ListIterator;
import java.util.Iterator;
import java.util.List;
import java.util.RandomAccess;
import java.util.AbstractList;

public class n0 extends AbstractList implements D, RandomAccess
{
    private final D a;
    
    public n0(final D a) {
        this.a = a;
    }
    
    public void E(final h h) {
        throw new UnsupportedOperationException();
    }
    
    public String c(final int n) {
        return (String)((List)this.a).get(n);
    }
    
    public List f() {
        return this.a.f();
    }
    
    public Object h(final int n) {
        return this.a.h(n);
    }
    
    public Iterator iterator() {
        return (Iterator)new Iterator(this) {
            Iterator a = ((List)b.a).iterator();
            final n0 b;
            
            public String a() {
                return (String)this.a.next();
            }
            
            public boolean hasNext() {
                return this.a.hasNext();
            }
            
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }
    
    public D l() {
        return this;
    }
    
    public ListIterator listIterator(final int n) {
        return (ListIterator)new ListIterator(this, n) {
            ListIterator a = ((List)c.a).listIterator(b);
            final int b;
            final n0 c;
            
            public void a(final String s) {
                throw new UnsupportedOperationException();
            }
            
            public String c() {
                return (String)this.a.next();
            }
            
            public String d() {
                return (String)this.a.previous();
            }
            
            public void e(final String s) {
                throw new UnsupportedOperationException();
            }
            
            public boolean hasNext() {
                return this.a.hasNext();
            }
            
            public boolean hasPrevious() {
                return this.a.hasPrevious();
            }
            
            public int nextIndex() {
                return this.a.nextIndex();
            }
            
            public int previousIndex() {
                return this.a.previousIndex();
            }
            
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }
    
    public int size() {
        return ((List)this.a).size();
    }
}
