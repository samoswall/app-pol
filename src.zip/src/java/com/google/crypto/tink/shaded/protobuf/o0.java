package com.google.crypto.tink.shaded.protobuf;

import java.lang.reflect.AccessibleObject;
import java.nio.Buffer;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.security.AccessController;
import java.lang.reflect.Field;
import java.security.PrivilegedExceptionAction;
import java.nio.ByteOrder;
import sun.misc.Unsafe;

abstract class o0
{
    private static final Unsafe a;
    private static final Class b;
    private static final boolean c;
    private static final boolean d;
    private static final e e;
    private static final boolean f;
    private static final boolean g;
    static final long h;
    private static final long i;
    private static final long j;
    private static final long k;
    private static final long l;
    private static final long m;
    private static final long n;
    private static final long o;
    private static final long p;
    private static final long q;
    private static final long r;
    private static final long s;
    private static final long t;
    private static final long u;
    private static final int v;
    static final boolean w;
    
    static {
        a = D();
        b = com.google.crypto.tink.shaded.protobuf.d.b();
        c = o(Long.TYPE);
        d = o(Integer.TYPE);
        e = B();
        f = T();
        g = S();
        final long n2 = h = l(byte[].class);
        i = l(boolean[].class);
        j = m(boolean[].class);
        k = l(int[].class);
        l = m(int[].class);
        m = l(long[].class);
        n = m(long[].class);
        o = l(float[].class);
        p = m(float[].class);
        q = l(double[].class);
        r = m(double[].class);
        s = l(Object[].class);
        t = m(Object[].class);
        u = q(n());
        v = (int)(n2 & 0x7L);
        w = (ByteOrder.nativeOrder() == ByteOrder.BIG_ENDIAN);
    }
    
    static long A(final Object o, final long n) {
        return o0.e.h(o, n);
    }
    
    private static e B() {
        final Unsafe a = o0.a;
        Object o = null;
        if (a == null) {
            return null;
        }
        if (!com.google.crypto.tink.shaded.protobuf.d.c()) {
            return (e)new d(a);
        }
        if (o0.c) {
            return (e)new c(a);
        }
        if (o0.d) {
            o = new b(a);
        }
        return (e)o;
    }
    
    static Object C(final Object o, final long n) {
        return o0.e.i(o, n);
    }
    
    static Unsafe D() {
        Unsafe unsafe2;
        try {
            final Unsafe unsafe = (Unsafe)AccessController.doPrivileged((PrivilegedExceptionAction)new PrivilegedExceptionAction() {
                public Unsafe a() {
                    for (final Field field : Unsafe.class.getDeclaredFields()) {
                        ((AccessibleObject)field).setAccessible(true);
                        final Object value = field.get((Object)null);
                        if (Unsafe.class.isInstance(value)) {
                            return Unsafe.class.cast(value);
                        }
                    }
                    return null;
                }
            });
        }
        finally {
            unsafe2 = null;
        }
        return unsafe2;
    }
    
    static boolean E() {
        return o0.g;
    }
    
    static boolean F() {
        return o0.f;
    }
    
    private static void G(final Throwable t) {
        final Logger logger = Logger.getLogger(o0.class.getName());
        final Level warning = Level.WARNING;
        final StringBuilder sb = new StringBuilder();
        sb.append("platform method missing - proto runtime falling back to safer methods: ");
        sb.append((Object)t);
        logger.log(warning, sb.toString());
    }
    
    static void H(final Object o, final long n, final boolean b) {
        o0.e.k(o, n, b);
    }
    
    private static void I(final Object o, final long n, final boolean b) {
        L(o, n, (byte)(b ? 1 : 0));
    }
    
    private static void J(final Object o, final long n, final boolean b) {
        M(o, n, (byte)(b ? 1 : 0));
    }
    
    static void K(final byte[] array, final long n, final byte b) {
        o0.e.l(array, o0.h + n, b);
    }
    
    private static void L(final Object o, final long n, final byte b) {
        final long n2 = 0xFFFFFFFFFFFFFFFCL & n;
        final int z = z(o, n2);
        final int n3 = (~(int)n & 0x3) << 3;
        P(o, n2, (0xFF & b) << n3 | (z & ~(255 << n3)));
    }
    
    private static void M(final Object o, final long n, final byte b) {
        final long n2 = 0xFFFFFFFFFFFFFFFCL & n;
        final int z = z(o, n2);
        final int n3 = ((int)n & 0x3) << 3;
        P(o, n2, (0xFF & b) << n3 | (z & ~(255 << n3)));
    }
    
    static void N(final Object o, final long n, final double n2) {
        o0.e.m(o, n, n2);
    }
    
    static void O(final Object o, final long n, final float n2) {
        o0.e.n(o, n, n2);
    }
    
    static void P(final Object o, final long n, final int n2) {
        o0.e.o(o, n, n2);
    }
    
    static void Q(final Object o, final long n, final long n2) {
        o0.e.p(o, n, n2);
    }
    
    static void R(final Object o, final long n, final Object o2) {
        o0.e.q(o, n, o2);
    }
    
    private static boolean S() {
        final e e = o0.e;
        return e != null && e.r();
    }
    
    private static boolean T() {
        final e e = o0.e;
        return e != null && e.s();
    }
    
    static Object k(final Class clazz) {
        try {
            return o0.a.allocateInstance(clazz);
        }
        catch (final InstantiationException ex) {
            throw new IllegalStateException((Throwable)ex);
        }
    }
    
    private static int l(final Class clazz) {
        int a;
        if (o0.g) {
            a = o0.e.a(clazz);
        }
        else {
            a = -1;
        }
        return a;
    }
    
    private static int m(final Class clazz) {
        int b;
        if (o0.g) {
            b = o0.e.b(clazz);
        }
        else {
            b = -1;
        }
        return b;
    }
    
    private static Field n() {
        if (com.google.crypto.tink.shaded.protobuf.d.c()) {
            final Field p = p(Buffer.class, "effectiveDirectAddress");
            if (p != null) {
                return p;
            }
        }
        Field p2 = p(Buffer.class, "address");
        if (p2 == null || p2.getType() != Long.TYPE) {
            p2 = null;
        }
        return p2;
    }
    
    static boolean o(final Class clazz) {
        if (!com.google.crypto.tink.shaded.protobuf.d.c()) {
            return false;
        }
        try {
            final Class b = o0.b;
            final Class type = Boolean.TYPE;
            b.getMethod("peekLong", clazz, type);
            b.getMethod("pokeLong", clazz, Long.TYPE, type);
            final Class type2 = Integer.TYPE;
            b.getMethod("pokeInt", clazz, type2, type);
            b.getMethod("peekInt", clazz, type);
            b.getMethod("pokeByte", clazz, Byte.TYPE);
            b.getMethod("peekByte", clazz);
            b.getMethod("pokeByteArray", clazz, byte[].class, type2, type2);
            b.getMethod("peekByteArray", clazz, byte[].class, type2, type2);
            return true;
        }
        finally {
            return false;
        }
    }
    
    private static Field p(final Class clazz, final String s) {
        Field field;
        try {
            clazz.getDeclaredField(s);
        }
        finally {
            field = null;
        }
        return field;
    }
    
    private static long q(final Field field) {
        if (field != null) {
            final e e = o0.e;
            if (e != null) {
                return e.j(field);
            }
        }
        return -1L;
    }
    
    static boolean r(final Object o, final long n) {
        return o0.e.c(o, n);
    }
    
    private static boolean s(final Object o, final long n) {
        return v(o, n) != 0;
    }
    
    private static boolean t(final Object o, final long n) {
        return w(o, n) != 0;
    }
    
    static byte u(final byte[] array, final long n) {
        return o0.e.d(array, o0.h + n);
    }
    
    private static byte v(final Object o, final long n) {
        return (byte)(z(o, 0xFFFFFFFFFFFFFFFCL & n) >>> (int)((~n & 0x3L) << 3) & 0xFF);
    }
    
    private static byte w(final Object o, final long n) {
        return (byte)(z(o, 0xFFFFFFFFFFFFFFFCL & n) >>> (int)((n & 0x3L) << 3) & 0xFF);
    }
    
    static double x(final Object o, final long n) {
        return o0.e.e(o, n);
    }
    
    static float y(final Object o, final long n) {
        return o0.e.f(o, n);
    }
    
    static int z(final Object o, final long n) {
        return o0.e.g(o, n);
    }
    
    private static final class b extends e
    {
        b(final Unsafe unsafe) {
            super(unsafe);
        }
        
        @Override
        public boolean c(final Object o, final long n) {
            if (o0.w) {
                return s(o, n);
            }
            return t(o, n);
        }
        
        @Override
        public byte d(final Object o, final long n) {
            if (o0.w) {
                return v(o, n);
            }
            return w(o, n);
        }
        
        @Override
        public double e(final Object o, final long n) {
            return Double.longBitsToDouble(((e)this).h(o, n));
        }
        
        @Override
        public float f(final Object o, final long n) {
            return Float.intBitsToFloat(((e)this).g(o, n));
        }
        
        @Override
        public void k(final Object o, final long n, final boolean b) {
            if (o0.w) {
                I(o, n, b);
            }
            else {
                J(o, n, b);
            }
        }
        
        @Override
        public void l(final Object o, final long n, final byte b) {
            if (o0.w) {
                L(o, n, b);
            }
            else {
                M(o, n, b);
            }
        }
        
        @Override
        public void m(final Object o, final long n, final double n2) {
            ((e)this).p(o, n, Double.doubleToLongBits(n2));
        }
        
        @Override
        public void n(final Object o, final long n, final float n2) {
            ((e)this).o(o, n, Float.floatToIntBits(n2));
        }
        
        @Override
        public boolean s() {
            return false;
        }
    }
    
    private static final class c extends e
    {
        c(final Unsafe unsafe) {
            super(unsafe);
        }
        
        @Override
        public boolean c(final Object o, final long n) {
            if (o0.w) {
                return s(o, n);
            }
            return t(o, n);
        }
        
        @Override
        public byte d(final Object o, final long n) {
            if (o0.w) {
                return v(o, n);
            }
            return w(o, n);
        }
        
        @Override
        public double e(final Object o, final long n) {
            return Double.longBitsToDouble(((e)this).h(o, n));
        }
        
        @Override
        public float f(final Object o, final long n) {
            return Float.intBitsToFloat(((e)this).g(o, n));
        }
        
        @Override
        public void k(final Object o, final long n, final boolean b) {
            if (o0.w) {
                I(o, n, b);
            }
            else {
                J(o, n, b);
            }
        }
        
        @Override
        public void l(final Object o, final long n, final byte b) {
            if (o0.w) {
                L(o, n, b);
            }
            else {
                M(o, n, b);
            }
        }
        
        @Override
        public void m(final Object o, final long n, final double n2) {
            ((e)this).p(o, n, Double.doubleToLongBits(n2));
        }
        
        @Override
        public void n(final Object o, final long n, final float n2) {
            ((e)this).o(o, n, Float.floatToIntBits(n2));
        }
        
        @Override
        public boolean s() {
            return false;
        }
    }
    
    private static final class d extends e
    {
        d(final Unsafe unsafe) {
            super(unsafe);
        }
        
        @Override
        public boolean c(final Object o, final long n) {
            return super.a.getBoolean(o, n);
        }
        
        @Override
        public byte d(final Object o, final long n) {
            return super.a.getByte(o, n);
        }
        
        @Override
        public double e(final Object o, final long n) {
            return super.a.getDouble(o, n);
        }
        
        @Override
        public float f(final Object o, final long n) {
            return super.a.getFloat(o, n);
        }
        
        @Override
        public void k(final Object o, final long n, final boolean b) {
            super.a.putBoolean(o, n, b);
        }
        
        @Override
        public void l(final Object o, final long n, final byte b) {
            super.a.putByte(o, n, b);
        }
        
        @Override
        public void m(final Object o, final long n, final double n2) {
            super.a.putDouble(o, n, n2);
        }
        
        @Override
        public void n(final Object o, final long n, final float n2) {
            super.a.putFloat(o, n, n2);
        }
        
        @Override
        public boolean r() {
            if (!super.r()) {
                return false;
            }
            try {
                final Class<? extends Unsafe> class1 = super.a.getClass();
                final Class type = Long.TYPE;
                class1.getMethod("getByte", Object.class, type);
                class1.getMethod("putByte", Object.class, type, Byte.TYPE);
                class1.getMethod("getBoolean", Object.class, type);
                class1.getMethod("putBoolean", Object.class, type, Boolean.TYPE);
                class1.getMethod("getFloat", Object.class, type);
                class1.getMethod("putFloat", Object.class, type, Float.TYPE);
                class1.getMethod("getDouble", Object.class, type);
                class1.getMethod("putDouble", Object.class, type, Double.TYPE);
                return true;
            }
            finally {
                final Throwable t;
                G(t);
                return false;
            }
        }
        
        @Override
        public boolean s() {
            if (!super.s()) {
                return false;
            }
            try {
                final Class<? extends Unsafe> class1 = super.a.getClass();
                final Class type = Long.TYPE;
                class1.getMethod("getByte", type);
                class1.getMethod("putByte", type, Byte.TYPE);
                class1.getMethod("getInt", type);
                class1.getMethod("putInt", type, Integer.TYPE);
                class1.getMethod("getLong", type);
                class1.getMethod("putLong", type, type);
                class1.getMethod("copyMemory", type, type, type);
                class1.getMethod("copyMemory", Object.class, type, Object.class, type, type);
                return true;
            }
            finally {
                final Throwable t;
                G(t);
                return false;
            }
        }
    }
    
    private abstract static class e
    {
        Unsafe a;
        
        e(final Unsafe a) {
            this.a = a;
        }
        
        public final int a(final Class clazz) {
            return this.a.arrayBaseOffset(clazz);
        }
        
        public final int b(final Class clazz) {
            return this.a.arrayIndexScale(clazz);
        }
        
        public abstract boolean c(final Object p0, final long p1);
        
        public abstract byte d(final Object p0, final long p1);
        
        public abstract double e(final Object p0, final long p1);
        
        public abstract float f(final Object p0, final long p1);
        
        public final int g(final Object o, final long n) {
            return this.a.getInt(o, n);
        }
        
        public final long h(final Object o, final long n) {
            return this.a.getLong(o, n);
        }
        
        public final Object i(final Object o, final long n) {
            return this.a.getObject(o, n);
        }
        
        public final long j(final Field field) {
            return this.a.objectFieldOffset(field);
        }
        
        public abstract void k(final Object p0, final long p1, final boolean p2);
        
        public abstract void l(final Object p0, final long p1, final byte p2);
        
        public abstract void m(final Object p0, final long p1, final double p2);
        
        public abstract void n(final Object p0, final long p1, final float p2);
        
        public final void o(final Object o, final long n, final int n2) {
            this.a.putInt(o, n, n2);
        }
        
        public final void p(final Object o, final long n, final long n2) {
            this.a.putLong(o, n, n2);
        }
        
        public final void q(final Object o, final long n, final Object o2) {
            this.a.putObject(o, n, o2);
        }
        
        public boolean r() {
            final Unsafe a = this.a;
            if (a == null) {
                return false;
            }
            try {
                final Class<? extends Unsafe> class1 = a.getClass();
                class1.getMethod("objectFieldOffset", Field.class);
                class1.getMethod("arrayBaseOffset", Class.class);
                class1.getMethod("arrayIndexScale", Class.class);
                final Class type = Long.TYPE;
                class1.getMethod("getInt", Object.class, type);
                class1.getMethod("putInt", Object.class, type, Integer.TYPE);
                class1.getMethod("getLong", Object.class, type);
                class1.getMethod("putLong", Object.class, type, type);
                class1.getMethod("getObject", Object.class, type);
                class1.getMethod("putObject", Object.class, type, Object.class);
                return true;
            }
            finally {
                final Throwable t;
                G(t);
                return false;
            }
        }
        
        public boolean s() {
            final Unsafe a = this.a;
            if (a == null) {
                return false;
            }
            try {
                final Class<? extends Unsafe> class1 = a.getClass();
                class1.getMethod("objectFieldOffset", Field.class);
                class1.getMethod("getLong", Object.class, Long.TYPE);
                return n() != null;
            }
            finally {
                final Throwable t;
                G(t);
                return false;
            }
        }
    }
}
