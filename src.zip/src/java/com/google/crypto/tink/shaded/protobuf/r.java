package com.google.crypto.tink.shaded.protobuf;

import androidx.appcompat.app.v;
import java.util.Map$Entry;

final class r extends q
{
    @Override
    int a(final Map$Entry map$Entry) {
        v.a(map$Entry.getKey());
        throw null;
    }
    
    @Override
    Object b(final p p3, final O o, final int n) {
        p3.a(o, n);
        return null;
    }
    
    @Override
    t c(final Object o) {
        v.a(o);
        throw null;
    }
    
    @Override
    t d(final Object o) {
        v.a(o);
        throw null;
    }
    
    @Override
    boolean e(final O o) {
        return false;
    }
    
    @Override
    void f(final Object o) {
        this.c(o).g();
    }
    
    @Override
    Object g(final Object o, final d0 d0, final Object o2, final p p7, final t t, final Object o3, final k0 k0) {
        v.a(o2);
        throw null;
    }
    
    @Override
    void h(final d0 d0, final Object o, final p p4, final t t) {
        v.a(o);
        throw null;
    }
    
    @Override
    void i(final h h, final Object o, final p p4, final t t) {
        v.a(o);
        throw null;
    }
    
    @Override
    void j(final r0 r0, final Map$Entry map$Entry) {
        v.a(map$Entry.getKey());
        throw null;
    }
}
