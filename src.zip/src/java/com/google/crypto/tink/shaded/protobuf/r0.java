package com.google.crypto.tink.shaded.protobuf;

import java.util.Map;
import java.util.List;

interface r0
{
    void A(final int p0, final float p1);
    
    void B(final int p0);
    
    void C(final int p0, final List p1, final boolean p2);
    
    void D(final int p0, final int p1);
    
    void E(final int p0, final List p1, final boolean p2);
    
    void F(final int p0, final List p1, final boolean p2);
    
    void G(final int p0, final List p1, final boolean p2);
    
    void H(final int p0, final int p1);
    
    void I(final int p0, final List p1);
    
    void J(final int p0, final Object p1, final e0 p2);
    
    void K(final int p0, final H.a p1, final Map p2);
    
    void L(final int p0, final Object p1, final e0 p2);
    
    void M(final int p0, final List p1, final e0 p2);
    
    void N(final int p0, final List p1, final e0 p2);
    
    void O(final int p0, final h p1);
    
    void a(final int p0, final List p1, final boolean p2);
    
    void b(final int p0, final int p1);
    
    void c(final int p0, final Object p1);
    
    void d(final int p0, final int p1);
    
    void e(final int p0, final double p1);
    
    void f(final int p0, final List p1, final boolean p2);
    
    void g(final int p0, final List p1, final boolean p2);
    
    void h(final int p0, final long p1);
    
    a i();
    
    void j(final int p0, final List p1);
    
    void k(final int p0, final String p1);
    
    void l(final int p0, final long p1);
    
    void m(final int p0, final List p1, final boolean p2);
    
    void n(final int p0, final long p1);
    
    void o(final int p0, final boolean p1);
    
    void p(final int p0, final int p1);
    
    void q(final int p0);
    
    void r(final int p0, final int p1);
    
    void s(final int p0, final List p1, final boolean p2);
    
    void t(final int p0, final List p1, final boolean p2);
    
    void u(final int p0, final long p1);
    
    void v(final int p0, final List p1, final boolean p2);
    
    void w(final int p0, final List p1, final boolean p2);
    
    void x(final int p0, final List p1, final boolean p2);
    
    void y(final int p0, final List p1, final boolean p2);
    
    void z(final int p0, final long p1);
    
    public enum a
    {
        private static final a[] $VALUES;
        
        ASCENDING, 
        DESCENDING;
    }
}
