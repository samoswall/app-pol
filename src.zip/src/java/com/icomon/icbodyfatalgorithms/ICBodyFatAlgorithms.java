package com.icomon.icbodyfatalgorithms;

import java.util.Iterator;
import java.util.Map$Entry;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import androidx.annotation.Keep;

@Keep
public class ICBodyFatAlgorithms
{
    static boolean isLoaded;
    static final Integer lock;
    
    static {
        lock = 0;
        ICBodyFatAlgorithms.isLoaded = false;
    }
    
    @Keep
    public ICBodyFatAlgorithms() {
    }
    
    @Keep
    public static ICBodyFatAlgorithmsResult calc(final ICBodyFatAlgorithmsParams icBodyFatAlgorithmsParams) {
        load();
        final int value = icBodyFatAlgorithmsParams.algType.getValue();
        final HashMap hashMap = new HashMap();
        hashMap.put((Object)"weight", (Object)icBodyFatAlgorithmsParams.weight);
        hashMap.put((Object)"height", (Object)icBodyFatAlgorithmsParams.height);
        hashMap.put((Object)"age", (Object)icBodyFatAlgorithmsParams.age);
        hashMap.put((Object)"bmiStandard", (Object)icBodyFatAlgorithmsParams.bmiStandard);
        hashMap.put((Object)"sex", (Object)icBodyFatAlgorithmsParams.sex.getValue());
        hashMap.put((Object)"algType", (Object)value);
        hashMap.put((Object)"peopleType", (Object)icBodyFatAlgorithmsParams.peopleType.getValue());
        hashMap.put((Object)"imp1", (Object)icBodyFatAlgorithmsParams.imp1);
        hashMap.put((Object)"imp2", (Object)icBodyFatAlgorithmsParams.imp2);
        hashMap.put((Object)"imp3", (Object)icBodyFatAlgorithmsParams.imp3);
        hashMap.put((Object)"imp4", (Object)icBodyFatAlgorithmsParams.imp4);
        hashMap.put((Object)"imp5", (Object)icBodyFatAlgorithmsParams.imp5);
        final List<Double> imps = icBodyFatAlgorithmsParams.imps;
        if (imps != null && imps.size() != 0) {
            hashMap.put((Object)"impCount", (Object)icBodyFatAlgorithmsParams.imps.size());
            hashMap.put((Object)"imps", (Object)icBodyFatAlgorithmsParams.imps);
            if (icBodyFatAlgorithmsParams.imps.size() >= 1) {
                hashMap.put((Object)"imp1", icBodyFatAlgorithmsParams.imps.get(0));
            }
            if (icBodyFatAlgorithmsParams.imps.size() >= 2) {
                hashMap.put((Object)"imp2", icBodyFatAlgorithmsParams.imps.get(1));
            }
            if (icBodyFatAlgorithmsParams.imps.size() >= 3) {
                hashMap.put((Object)"imp3", icBodyFatAlgorithmsParams.imps.get(2));
            }
            if (icBodyFatAlgorithmsParams.imps.size() >= 4) {
                hashMap.put((Object)"imp4", icBodyFatAlgorithmsParams.imps.get(3));
            }
            if (icBodyFatAlgorithmsParams.imps.size() >= 5) {
                hashMap.put((Object)"imp5", icBodyFatAlgorithmsParams.imps.get(4));
            }
        }
        else {
            (icBodyFatAlgorithmsParams.imps = (List<Double>)new ArrayList()).add((Object)icBodyFatAlgorithmsParams.imp1);
            icBodyFatAlgorithmsParams.imps.add((Object)icBodyFatAlgorithmsParams.imp2);
            icBodyFatAlgorithmsParams.imps.add((Object)icBodyFatAlgorithmsParams.imp3);
            icBodyFatAlgorithmsParams.imps.add((Object)icBodyFatAlgorithmsParams.imp4);
            icBodyFatAlgorithmsParams.imps.add((Object)icBodyFatAlgorithmsParams.imp5);
            hashMap.put((Object)"impCount", (Object)icBodyFatAlgorithmsParams.imps.size());
            hashMap.put((Object)"imps", (Object)icBodyFatAlgorithmsParams.imps);
        }
        final HashMap<String, Object> native_calc = native_calc((HashMap<String, Object>)hashMap);
        final ICBodyFatAlgorithmsResult icBodyFatAlgorithmsResult = new ICBodyFatAlgorithmsResult();
        icBodyFatAlgorithmsResult.bmi = (double)native_calc.get((Object)"bmi");
        icBodyFatAlgorithmsResult.bfr = (double)native_calc.get((Object)"bfr");
        icBodyFatAlgorithmsResult.muscle = (double)native_calc.get((Object)"muscle");
        icBodyFatAlgorithmsResult.subcutfat = (double)native_calc.get((Object)"subcutfat");
        icBodyFatAlgorithmsResult.vfal = (double)native_calc.get((Object)"vfal");
        icBodyFatAlgorithmsResult.bone = (double)native_calc.get((Object)"bone");
        icBodyFatAlgorithmsResult.water = (double)native_calc.get((Object)"water");
        icBodyFatAlgorithmsResult.protein = (double)native_calc.get((Object)"protein");
        icBodyFatAlgorithmsResult.sm = (double)native_calc.get((Object)"sm");
        icBodyFatAlgorithmsResult.bmr = (int)native_calc.get((Object)"bmr");
        icBodyFatAlgorithmsResult.age = (int)native_calc.get((Object)"age");
        icBodyFatAlgorithmsResult.leftArmMuscle = (double)native_calc.get((Object)"leftArmMuscle");
        icBodyFatAlgorithmsResult.leftArmMuscleMass = (double)native_calc.get((Object)"leftArmMuscleMass");
        icBodyFatAlgorithmsResult.leftArmBodyfatPercentage = (double)native_calc.get((Object)"leftArmBodyfatPercentage");
        icBodyFatAlgorithmsResult.leftArmBodyfatMass = (double)native_calc.get((Object)"leftArmBodyfatMass");
        icBodyFatAlgorithmsResult.leftLegMuscle = (double)native_calc.get((Object)"leftLegMuscle");
        icBodyFatAlgorithmsResult.leftLegMuscleMass = (double)native_calc.get((Object)"leftLegMuscleMass");
        icBodyFatAlgorithmsResult.leftLegBodyfatPercentage = (double)native_calc.get((Object)"leftLegBodyfatPercentage");
        icBodyFatAlgorithmsResult.leftLegBodyfatMass = (double)native_calc.get((Object)"leftLegBodyfatMass");
        icBodyFatAlgorithmsResult.rightArmMuscle = (double)native_calc.get((Object)"rightArmMuscle");
        icBodyFatAlgorithmsResult.rightArmMuscleMass = (double)native_calc.get((Object)"rightArmMuscleMass");
        icBodyFatAlgorithmsResult.rightArmBodyfatPercentage = (double)native_calc.get((Object)"rightArmBodyfatPercentage");
        icBodyFatAlgorithmsResult.rightArmBodyfatMass = (double)native_calc.get((Object)"rightArmBodyfatMass");
        icBodyFatAlgorithmsResult.rightLegMuscle = (double)native_calc.get((Object)"rightLegMuscle");
        icBodyFatAlgorithmsResult.rightLegMuscleMass = (double)native_calc.get((Object)"rightLegMuscleMass");
        icBodyFatAlgorithmsResult.rightLegBodyfatPercentage = (double)native_calc.get((Object)"rightLegBodyfatPercentage");
        icBodyFatAlgorithmsResult.rightLegBodyfatMass = (double)native_calc.get((Object)"rightLegBodyfatMass");
        icBodyFatAlgorithmsResult.trunkMuscle = (double)native_calc.get((Object)"trunkMuscle");
        icBodyFatAlgorithmsResult.trunkMuscleMass = (double)native_calc.get((Object)"trunkMuscleMass");
        icBodyFatAlgorithmsResult.trunkBodyfatPercentage = (double)native_calc.get((Object)"trunkBodyfatPercentage");
        icBodyFatAlgorithmsResult.trunkBodyfatMass = (double)native_calc.get((Object)"trunkBodyfatMass");
        icBodyFatAlgorithmsResult.bodyScore = (double)native_calc.get((Object)"bodyScore");
        icBodyFatAlgorithmsResult.bodyType = (int)native_calc.get((Object)"bodyType");
        icBodyFatAlgorithmsResult.bfmControl = (double)native_calc.get((Object)"bfmControl");
        icBodyFatAlgorithmsResult.ffmControl = (double)native_calc.get((Object)"ffmControl");
        icBodyFatAlgorithmsResult.weightControl = (double)native_calc.get((Object)"weightControl");
        icBodyFatAlgorithmsResult.weightTarget = (double)native_calc.get((Object)"weightTarget");
        icBodyFatAlgorithmsResult.bfmStandard = (double)native_calc.get((Object)"bfmStandard");
        icBodyFatAlgorithmsResult.bfpStandard = (double)native_calc.get((Object)"bfpStandard");
        icBodyFatAlgorithmsResult.bmiStandard = (double)native_calc.get((Object)"bmiStandard");
        icBodyFatAlgorithmsResult.bmrStandard = (int)native_calc.get((Object)"bmrStandard");
        icBodyFatAlgorithmsResult.weightStandard = (double)native_calc.get((Object)"weightStandard");
        icBodyFatAlgorithmsResult.ffmStandard = (double)native_calc.get((Object)"ffmStandard");
        icBodyFatAlgorithmsResult.smmStandard = (double)native_calc.get((Object)"smmStandard");
        icBodyFatAlgorithmsResult.smi = (double)native_calc.get((Object)"smi");
        icBodyFatAlgorithmsResult.obesityDegree = (int)native_calc.get((Object)"obesityDegree");
        icBodyFatAlgorithmsResult.whr = (double)native_calc.get((Object)"whr");
        icBodyFatAlgorithmsResult.bmiMax = (double)native_calc.get((Object)"bmi_max");
        icBodyFatAlgorithmsResult.bmiMin = (double)native_calc.get((Object)"bmi_min");
        icBodyFatAlgorithmsResult.bfmMax = (double)native_calc.get((Object)"bfm_max");
        icBodyFatAlgorithmsResult.bfmMin = (double)native_calc.get((Object)"bfm_min");
        icBodyFatAlgorithmsResult.bfpMax = (double)native_calc.get((Object)"bfp_max");
        icBodyFatAlgorithmsResult.bfpMin = (double)native_calc.get((Object)"bfp_min");
        icBodyFatAlgorithmsResult.weightMax = (double)native_calc.get((Object)"weight_max");
        icBodyFatAlgorithmsResult.weightMin = (double)native_calc.get((Object)"weight_min");
        icBodyFatAlgorithmsResult.smmMax = (double)native_calc.get((Object)"smm_max");
        icBodyFatAlgorithmsResult.smmMin = (double)native_calc.get((Object)"smm_min");
        icBodyFatAlgorithmsResult.boneMax = (double)native_calc.get((Object)"bone_max");
        icBodyFatAlgorithmsResult.boneMin = (double)native_calc.get((Object)"bone_min");
        icBodyFatAlgorithmsResult.waterMassMax = (double)native_calc.get((Object)"waterMass_max");
        icBodyFatAlgorithmsResult.waterMassMin = (double)native_calc.get((Object)"waterMass_min");
        icBodyFatAlgorithmsResult.proteinMassMax = (double)native_calc.get((Object)"proteinMass_max");
        icBodyFatAlgorithmsResult.proteinMassMin = (double)native_calc.get((Object)"proteinMass_min");
        icBodyFatAlgorithmsResult.muscleMassMax = (double)native_calc.get((Object)"muscleMass_max");
        icBodyFatAlgorithmsResult.muscleMassMin = (double)native_calc.get((Object)"muscleMass_min");
        icBodyFatAlgorithmsResult.bmrMax = (int)native_calc.get((Object)"bmr_max");
        icBodyFatAlgorithmsResult.bmrMin = (int)native_calc.get((Object)"bmr_min");
        return icBodyFatAlgorithmsResult;
    }
    
    @Keep
    public static double getBMI(final double n, final int n2, final ICBodyFatAlgorithmsType icBodyFatAlgorithmsType, final ICBodyFatAlgorithmsPeopleType icBodyFatAlgorithmsPeopleType) {
        load();
        return native_getBMI(n, n2, icBodyFatAlgorithmsType.getValue(), icBodyFatAlgorithmsPeopleType.getValue());
    }
    
    @Keep
    public static int getBMR(final double n, final int n2, final int n3, final double n4, final double n5, final ICBodyFatAlgorithmsSex icBodyFatAlgorithmsSex, final ICBodyFatAlgorithmsType icBodyFatAlgorithmsType, final ICBodyFatAlgorithmsPeopleType icBodyFatAlgorithmsPeopleType) {
        load();
        return native_getBMR(n, n2, n3, n4, n5, icBodyFatAlgorithmsSex.getValue(), icBodyFatAlgorithmsType.getValue(), icBodyFatAlgorithmsPeopleType.getValue());
    }
    
    @Keep
    public static double getBodyFatPercent(final double n, final int n2, final int n3, final double n4, final double n5, final ICBodyFatAlgorithmsSex icBodyFatAlgorithmsSex, final ICBodyFatAlgorithmsType icBodyFatAlgorithmsType, final ICBodyFatAlgorithmsPeopleType icBodyFatAlgorithmsPeopleType) {
        load();
        return native_getBodyFatPercent(n, n2, n3, n4, n5, icBodyFatAlgorithmsSex.getValue(), icBodyFatAlgorithmsType.getValue(), icBodyFatAlgorithmsPeopleType.getValue());
    }
    
    @Keep
    public static double getBoneMass(final double n, final int n2, final int n3, final double n4, final double n5, final ICBodyFatAlgorithmsSex icBodyFatAlgorithmsSex, final ICBodyFatAlgorithmsType icBodyFatAlgorithmsType, final ICBodyFatAlgorithmsPeopleType icBodyFatAlgorithmsPeopleType) {
        load();
        return native_getBoneMass(n, n2, n3, n4, n5, icBodyFatAlgorithmsSex.getValue(), icBodyFatAlgorithmsType.getValue(), icBodyFatAlgorithmsPeopleType.getValue());
    }
    
    @Keep
    public static List<String> getKeysFromMap(final Map<String, Object> map) {
        final ArrayList list = new ArrayList();
        final Iterator iterator = map.entrySet().iterator();
        while (iterator.hasNext()) {
            list.add((Object)((Map$Entry)iterator.next()).getKey());
        }
        return (List<String>)list;
    }
    
    @Keep
    public static double getMoisturePercent(final double n, final int n2, final int n3, final double n4, final double n5, final ICBodyFatAlgorithmsSex icBodyFatAlgorithmsSex, final ICBodyFatAlgorithmsType icBodyFatAlgorithmsType, final ICBodyFatAlgorithmsPeopleType icBodyFatAlgorithmsPeopleType) {
        load();
        return native_getMoisturePercent(n, n2, n3, n4, n5, icBodyFatAlgorithmsSex.getValue(), icBodyFatAlgorithmsType.getValue(), icBodyFatAlgorithmsPeopleType.getValue());
    }
    
    @Keep
    public static double getMusclePercent(final double n, final int n2, final int n3, final double n4, final double n5, final ICBodyFatAlgorithmsSex icBodyFatAlgorithmsSex, final ICBodyFatAlgorithmsType icBodyFatAlgorithmsType, final ICBodyFatAlgorithmsPeopleType icBodyFatAlgorithmsPeopleType) {
        load();
        return native_getMusclePercent(n, n2, n3, n4, n5, icBodyFatAlgorithmsSex.getValue(), icBodyFatAlgorithmsType.getValue(), icBodyFatAlgorithmsPeopleType.getValue());
    }
    
    @Keep
    public static int getObjectType(final Object o) {
        if (o instanceof Integer) {
            return 1;
        }
        if (o instanceof Double) {
            return 2;
        }
        if (o instanceof String) {
            return 3;
        }
        if (o instanceof List) {
            return 4;
        }
        if (o instanceof Map) {
            return 5;
        }
        if (o instanceof byte[]) {
            return 6;
        }
        if (o instanceof Long) {
            return 7;
        }
        if (o instanceof Float) {
            return 8;
        }
        if (o instanceof Byte) {
            return 9;
        }
        int n;
        if (o instanceof Short) {
            n = 10;
        }
        else {
            n = 0;
        }
        return n;
    }
    
    @Keep
    public static int getPhysicalAge(final double n, final int n2, final int n3, final double n4, final double n5, final ICBodyFatAlgorithmsSex icBodyFatAlgorithmsSex, final ICBodyFatAlgorithmsType icBodyFatAlgorithmsType, final ICBodyFatAlgorithmsPeopleType icBodyFatAlgorithmsPeopleType) {
        load();
        return native_getPhysicalAge(n, n2, n3, n4, n5, icBodyFatAlgorithmsSex.getValue(), icBodyFatAlgorithmsType.getValue(), icBodyFatAlgorithmsPeopleType.getValue());
    }
    
    @Keep
    public static double getProtein(final double n, final int n2, final int n3, final double n4, final double n5, final ICBodyFatAlgorithmsSex icBodyFatAlgorithmsSex, final ICBodyFatAlgorithmsType icBodyFatAlgorithmsType, final ICBodyFatAlgorithmsPeopleType icBodyFatAlgorithmsPeopleType) {
        load();
        return native_getProtein(n, n2, n3, n4, n5, icBodyFatAlgorithmsSex.getValue(), icBodyFatAlgorithmsType.getValue(), icBodyFatAlgorithmsPeopleType.getValue());
    }
    
    @Keep
    public static double getSkeletalMuscle(final double n, final int n2, final int n3, final double n4, final double n5, final ICBodyFatAlgorithmsSex icBodyFatAlgorithmsSex, final ICBodyFatAlgorithmsType icBodyFatAlgorithmsType, final ICBodyFatAlgorithmsPeopleType icBodyFatAlgorithmsPeopleType) {
        load();
        return native_getSkeletalMuscle(n, n2, n3, n4, n5, icBodyFatAlgorithmsSex.getValue(), icBodyFatAlgorithmsType.getValue(), icBodyFatAlgorithmsPeopleType.getValue());
    }
    
    @Keep
    public static double getSubcutaneousFatPercent(final double n, final int n2, final int n3, final double n4, final double n5, final ICBodyFatAlgorithmsSex icBodyFatAlgorithmsSex, final ICBodyFatAlgorithmsType icBodyFatAlgorithmsType, final ICBodyFatAlgorithmsPeopleType icBodyFatAlgorithmsPeopleType) {
        load();
        return native_getSubcutaneousFatPercent(n, n2, n3, n4, n5, icBodyFatAlgorithmsSex.getValue(), icBodyFatAlgorithmsType.getValue(), icBodyFatAlgorithmsPeopleType.getValue());
    }
    
    @Keep
    public static double getVisceralFat(final double n, final int n2, final int n3, final double n4, final double n5, final ICBodyFatAlgorithmsSex icBodyFatAlgorithmsSex, final ICBodyFatAlgorithmsType icBodyFatAlgorithmsType, final ICBodyFatAlgorithmsPeopleType icBodyFatAlgorithmsPeopleType) {
        load();
        return native_getVisceralFat(n, n2, n3, n4, n5, icBodyFatAlgorithmsSex.getValue(), icBodyFatAlgorithmsType.getValue(), icBodyFatAlgorithmsPeopleType.getValue());
    }
    
    @Keep
    private static void load() {
        final Integer lock;
        monitorenter(lock = ICBodyFatAlgorithms.lock);
        Label_0031: {
            try {
                if (!ICBodyFatAlgorithms.isLoaded) {
                    System.loadLibrary("ICBodyFatAlgorithms");
                    ICBodyFatAlgorithms.isLoaded = true;
                }
                break Label_0031;
            }
            finally {
                monitorexit(lock);
                monitorexit(lock);
            }
        }
    }
    
    @Keep
    private static native HashMap<String, Object> native_calc(final HashMap<String, Object> p0);
    
    @Keep
    private static native double native_getBMI(final double p0, final int p1, final int p2, final int p3);
    
    @Keep
    private static native int native_getBMR(final double p0, final int p1, final int p2, final double p3, final double p4, final int p5, final int p6, final int p7);
    
    @Keep
    private static native double native_getBodyFatPercent(final double p0, final int p1, final int p2, final double p3, final double p4, final int p5, final int p6, final int p7);
    
    @Keep
    private static native double native_getBoneMass(final double p0, final int p1, final int p2, final double p3, final double p4, final int p5, final int p6, final int p7);
    
    @Keep
    private static native double native_getMoisturePercent(final double p0, final int p1, final int p2, final double p3, final double p4, final int p5, final int p6, final int p7);
    
    @Keep
    private static native double native_getMusclePercent(final double p0, final int p1, final int p2, final double p3, final double p4, final int p5, final int p6, final int p7);
    
    @Keep
    private static native int native_getPhysicalAge(final double p0, final int p1, final int p2, final double p3, final double p4, final int p5, final int p6, final int p7);
    
    @Keep
    private static native double native_getProtein(final double p0, final int p1, final int p2, final double p3, final double p4, final int p5, final int p6, final int p7);
    
    @Keep
    private static native double native_getSkeletalMuscle(final double p0, final int p1, final int p2, final double p3, final double p4, final int p5, final int p6, final int p7);
    
    @Keep
    private static native double native_getSubcutaneousFatPercent(final double p0, final int p1, final int p2, final double p3, final double p4, final int p5, final int p6, final int p7);
    
    @Keep
    private static native double native_getVisceralFat(final double p0, final int p1, final int p2, final double p3, final double p4, final int p5, final int p6, final int p7);
    
    @Keep
    public static String version() {
        return "master_build_235_3efc096_20231101160401";
    }
}
