package com.icomon.icbodyfatalgorithms;

import java.util.List;
import androidx.annotation.Keep;

@Keep
public class ICBodyFatAlgorithmsParams
{
    public int ICBodyFatAlgorithmsBMI_Standard_ASIA;
    public int ICBodyFatAlgorithmsBMI_Standard_WHO;
    public int ICBodyFatAlgorithmsBMI_Standard_ZHCN;
    public int ICBodyFatAlgorithmsBMI_Standard_ZHTW;
    public int age;
    public ICBodyFatAlgorithmsType algType;
    public int bmiStandard;
    public int height;
    public double imp1;
    public double imp2;
    public double imp3;
    public double imp4;
    public double imp5;
    public List<Double> imps;
    public ICBodyFatAlgorithmsPeopleType peopleType;
    public ICBodyFatAlgorithmsSex sex;
    public double weight;
    
    @Keep
    public ICBodyFatAlgorithmsParams() {
        this.ICBodyFatAlgorithmsBMI_Standard_WHO = 0;
        this.ICBodyFatAlgorithmsBMI_Standard_ZHCN = 1;
        this.ICBodyFatAlgorithmsBMI_Standard_ASIA = 2;
        this.ICBodyFatAlgorithmsBMI_Standard_ZHTW = 3;
        this.sex = ICBodyFatAlgorithmsSex.Male;
        this.bmiStandard = 0;
        this.peopleType = ICBodyFatAlgorithmsPeopleType.ICBodyFatAlgorithmsPeopleTypeNormal;
    }
    
    @Keep
    public int getAge() {
        return this.age;
    }
    
    @Keep
    public ICBodyFatAlgorithmsType getAlgType() {
        return this.algType;
    }
    
    @Keep
    public int getHeight() {
        return this.height;
    }
    
    @Keep
    public double getImp1() {
        return this.imp1;
    }
    
    @Keep
    public double getImp2() {
        return this.imp2;
    }
    
    @Keep
    public double getImp3() {
        return this.imp3;
    }
    
    @Keep
    public double getImp4() {
        return this.imp4;
    }
    
    @Keep
    public double getImp5() {
        return this.imp5;
    }
    
    @Keep
    public ICBodyFatAlgorithmsPeopleType getPeopleType() {
        return this.peopleType;
    }
    
    @Keep
    public ICBodyFatAlgorithmsSex getSex() {
        return this.sex;
    }
    
    @Keep
    public double getWeight() {
        return this.weight;
    }
    
    @Keep
    public void setAge(final int age) {
        this.age = age;
    }
    
    @Keep
    public void setAlgType(final ICBodyFatAlgorithmsType algType) {
        this.algType = algType;
    }
    
    @Keep
    public void setHeight(final int height) {
        this.height = height;
    }
    
    @Keep
    public void setImp1(final double imp1) {
        this.imp1 = imp1;
    }
    
    @Keep
    public void setImp2(final double imp2) {
        this.imp2 = imp2;
    }
    
    @Keep
    public void setImp3(final double imp3) {
        this.imp3 = imp3;
    }
    
    @Keep
    public void setImp4(final double imp4) {
        this.imp4 = imp4;
    }
    
    @Keep
    public void setImp5(final double imp5) {
        this.imp5 = imp5;
    }
    
    @Keep
    public void setPeopleType(final ICBodyFatAlgorithmsPeopleType peopleType) {
        this.peopleType = peopleType;
    }
    
    @Keep
    public void setSex(final ICBodyFatAlgorithmsSex sex) {
        this.sex = sex;
    }
    
    @Keep
    public void setWeight(final double weight) {
        this.weight = weight;
    }
}
