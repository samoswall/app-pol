package com.icomon.icbodyfatalgorithms;

import androidx.annotation.Keep;

@Keep
public enum ICBodyFatAlgorithmsPeopleType
{
    private static final ICBodyFatAlgorithmsPeopleType[] $VALUES;
    
    ICBodyFatAlgorithmsPeopleTypeNormal(0), 
    ICBodyFatAlgorithmsPeopleTypeSportsMan(1);
    
    private final int value;
    
    private static /* synthetic */ ICBodyFatAlgorithmsPeopleType[] $values() {
        return new ICBodyFatAlgorithmsPeopleType[] { ICBodyFatAlgorithmsPeopleType.ICBodyFatAlgorithmsPeopleTypeNormal, ICBodyFatAlgorithmsPeopleType.ICBodyFatAlgorithmsPeopleTypeSportsMan };
    }
    
    static {
        $VALUES = $values();
    }
    
    @Keep
    private ICBodyFatAlgorithmsPeopleType(final int value) {
        this.value = value;
    }
    
    @Keep
    public static ICBodyFatAlgorithmsPeopleType valueOf(final int n) {
        if (n == 0) {
            return ICBodyFatAlgorithmsPeopleType.ICBodyFatAlgorithmsPeopleTypeNormal;
        }
        if (n != 1) {
            return null;
        }
        return ICBodyFatAlgorithmsPeopleType.ICBodyFatAlgorithmsPeopleTypeSportsMan;
    }
    
    @Keep
    public int getValue() {
        return this.value;
    }
}
