package com.icomon.icbodyfatalgorithms;

import androidx.annotation.Keep;

@Keep
public class ICBodyFatAlgorithmsResult
{
    public int age;
    public double bfmControl;
    public double bfmMax;
    public double bfmMin;
    public double bfmStandard;
    public double bfpMax;
    public double bfpMin;
    public double bfpStandard;
    public double bfr;
    public double bmi;
    public double bmiMax;
    public double bmiMin;
    public double bmiStandard;
    public int bmr;
    public int bmrMax;
    public int bmrMin;
    public int bmrStandard;
    public double bodyScore;
    public int bodyType;
    public double bone;
    public double boneMax;
    public double boneMin;
    public double ffmControl;
    public double ffmStandard;
    public double leftArmBodyfatMass;
    public double leftArmBodyfatPercentage;
    public double leftArmMuscle;
    public double leftArmMuscleMass;
    public double leftLegBodyfatMass;
    public double leftLegBodyfatPercentage;
    public double leftLegMuscle;
    public double leftLegMuscleMass;
    public double muscle;
    public double muscleMassMax;
    public double muscleMassMin;
    public int obesityDegree;
    public double protein;
    public double proteinMassMax;
    public double proteinMassMin;
    public double rightArmBodyfatMass;
    public double rightArmBodyfatPercentage;
    public double rightArmMuscle;
    public double rightArmMuscleMass;
    public double rightLegBodyfatMass;
    public double rightLegBodyfatPercentage;
    public double rightLegMuscle;
    public double rightLegMuscleMass;
    public double sm;
    public double smi;
    public double smmMax;
    public double smmMin;
    public double smmStandard;
    public double subcutfat;
    public double trunkBodyfatMass;
    public double trunkBodyfatPercentage;
    public double trunkMuscle;
    public double trunkMuscleMass;
    public double vfal;
    public double water;
    public double waterMassMax;
    public double waterMassMin;
    public double weightControl;
    public double weightMax;
    public double weightMin;
    public double weightStandard;
    public double weightTarget;
    public double whr;
    
    @Keep
    public ICBodyFatAlgorithmsResult() {
    }
    
    @Keep
    public int getAge() {
        return this.age;
    }
    
    @Keep
    public double getBfmControl() {
        return this.bfmControl;
    }
    
    @Keep
    public double getBfmMax() {
        return this.bfmMax;
    }
    
    @Keep
    public double getBfmMin() {
        return this.bfmMin;
    }
    
    @Keep
    public double getBfmStandard() {
        return this.bfmStandard;
    }
    
    @Keep
    public double getBfpMax() {
        return this.bfpMax;
    }
    
    @Keep
    public double getBfpMin() {
        return this.bfpMin;
    }
    
    @Keep
    public double getBfpStandard() {
        return this.bfpStandard;
    }
    
    @Keep
    public double getBfr() {
        return this.bfr;
    }
    
    @Keep
    public double getBmi() {
        return this.bmi;
    }
    
    @Keep
    public double getBmiMax() {
        return this.bmiMax;
    }
    
    @Keep
    public double getBmiMin() {
        return this.bmiMin;
    }
    
    @Keep
    public double getBmiStandard() {
        return this.bmiStandard;
    }
    
    @Keep
    public int getBmr() {
        return this.bmr;
    }
    
    @Keep
    public int getBmrMax() {
        return this.bmrMax;
    }
    
    @Keep
    public int getBmrMin() {
        return this.bmrMin;
    }
    
    @Keep
    public int getBmrStandard() {
        return this.bmrStandard;
    }
    
    @Keep
    public double getBodyScore() {
        return this.bodyScore;
    }
    
    @Keep
    public int getBodyType() {
        return this.bodyType;
    }
    
    @Keep
    public double getBone() {
        return this.bone;
    }
    
    @Keep
    public double getBoneMax() {
        return this.boneMax;
    }
    
    @Keep
    public double getBoneMin() {
        return this.boneMin;
    }
    
    @Keep
    public double getFfmControl() {
        return this.ffmControl;
    }
    
    @Keep
    public double getFfmStandard() {
        return this.ffmStandard;
    }
    
    @Keep
    public double getLeftArmBodyfatMass() {
        return this.leftArmBodyfatMass;
    }
    
    @Keep
    public double getLeftArmBodyfatPercentage() {
        return this.leftArmBodyfatPercentage;
    }
    
    @Keep
    public double getLeftArmMuscle() {
        return this.leftArmMuscle;
    }
    
    @Keep
    public double getLeftArmMuscleMass() {
        return this.leftArmMuscleMass;
    }
    
    @Keep
    public double getLeftLegBodyfatMass() {
        return this.leftLegBodyfatMass;
    }
    
    @Keep
    public double getLeftLegBodyfatPercentage() {
        return this.leftLegBodyfatPercentage;
    }
    
    @Keep
    public double getLeftLegMuscle() {
        return this.leftLegMuscle;
    }
    
    @Keep
    public double getLeftLegMuscleMass() {
        return this.leftLegMuscleMass;
    }
    
    @Keep
    public double getMuscle() {
        return this.muscle;
    }
    
    @Keep
    public double getMuscleMassMax() {
        return this.muscleMassMax;
    }
    
    @Keep
    public double getMuscleMassMin() {
        return this.muscleMassMin;
    }
    
    @Keep
    public int getObesityDegree() {
        return this.obesityDegree;
    }
    
    @Keep
    public double getProtein() {
        return this.protein;
    }
    
    @Keep
    public double getProteinMassMax() {
        return this.proteinMassMax;
    }
    
    @Keep
    public double getProteinMassMin() {
        return this.proteinMassMin;
    }
    
    @Keep
    public double getRightArmBodyfatMass() {
        return this.rightArmBodyfatMass;
    }
    
    @Keep
    public double getRightArmBodyfatPercentage() {
        return this.rightArmBodyfatPercentage;
    }
    
    @Keep
    public double getRightArmMuscle() {
        return this.rightArmMuscle;
    }
    
    @Keep
    public double getRightArmMuscleMass() {
        return this.rightArmMuscleMass;
    }
    
    @Keep
    public double getRightLegBodyfatMass() {
        return this.rightLegBodyfatMass;
    }
    
    @Keep
    public double getRightLegBodyfatPercentage() {
        return this.rightLegBodyfatPercentage;
    }
    
    @Keep
    public double getRightLegMuscle() {
        return this.rightLegMuscle;
    }
    
    @Keep
    public double getRightLegMuscleMass() {
        return this.rightLegMuscleMass;
    }
    
    @Keep
    public double getSm() {
        return this.sm;
    }
    
    @Keep
    public double getSmi() {
        return this.smi;
    }
    
    @Keep
    public double getSmmMax() {
        return this.smmMax;
    }
    
    @Keep
    public double getSmmMin() {
        return this.smmMin;
    }
    
    @Keep
    public double getSmmStandard() {
        return this.smmStandard;
    }
    
    @Keep
    public double getSubcutfat() {
        return this.subcutfat;
    }
    
    @Keep
    public double getTrunkBodyfatMass() {
        return this.trunkBodyfatMass;
    }
    
    @Keep
    public double getTrunkBodyfatPercentage() {
        return this.trunkBodyfatPercentage;
    }
    
    @Keep
    public double getTrunkMuscle() {
        return this.trunkMuscle;
    }
    
    @Keep
    public double getTrunkMuscleMass() {
        return this.trunkMuscleMass;
    }
    
    @Keep
    public double getVfal() {
        return this.vfal;
    }
    
    @Keep
    public double getWater() {
        return this.water;
    }
    
    @Keep
    public double getWaterMassMax() {
        return this.waterMassMax;
    }
    
    @Keep
    public double getWaterMassMin() {
        return this.waterMassMin;
    }
    
    @Keep
    public double getWeightControl() {
        return this.weightControl;
    }
    
    @Keep
    public double getWeightMax() {
        return this.weightMax;
    }
    
    @Keep
    public double getWeightMin() {
        return this.weightMin;
    }
    
    @Keep
    public double getWeightStandard() {
        return this.weightStandard;
    }
    
    @Keep
    public double getWeightTarget() {
        return this.weightTarget;
    }
    
    @Keep
    public double getWhr() {
        return this.whr;
    }
    
    @Keep
    public void setAge(final int age) {
        this.age = age;
    }
    
    @Keep
    public void setBfmControl(final double bfmControl) {
        this.bfmControl = bfmControl;
    }
    
    @Keep
    public void setBfmMax(final double bfmMax) {
        this.bfmMax = bfmMax;
    }
    
    @Keep
    public void setBfmMin(final double bfmMin) {
        this.bfmMin = bfmMin;
    }
    
    @Keep
    public void setBfmStandard(final double bfmStandard) {
        this.bfmStandard = bfmStandard;
    }
    
    @Keep
    public void setBfpMax(final double bfpMax) {
        this.bfpMax = bfpMax;
    }
    
    @Keep
    public void setBfpMin(final double bfpMin) {
        this.bfpMin = bfpMin;
    }
    
    @Keep
    public void setBfpStandard(final double bfpStandard) {
        this.bfpStandard = bfpStandard;
    }
    
    @Keep
    public void setBfr(final double bfr) {
        this.bfr = bfr;
    }
    
    @Keep
    public void setBmi(final double bmi) {
        this.bmi = bmi;
    }
    
    @Keep
    public void setBmiMax(final double bmiMax) {
        this.bmiMax = bmiMax;
    }
    
    @Keep
    public void setBmiMin(final double bmiMin) {
        this.bmiMin = bmiMin;
    }
    
    @Keep
    public void setBmiStandard(final double bmiStandard) {
        this.bmiStandard = bmiStandard;
    }
    
    @Keep
    public void setBmr(final int bmr) {
        this.bmr = bmr;
    }
    
    @Keep
    public void setBmrMax(final int bmrMax) {
        this.bmrMax = bmrMax;
    }
    
    @Keep
    public void setBmrMin(final int bmrMin) {
        this.bmrMin = bmrMin;
    }
    
    @Keep
    public void setBmrStandard(final int bmrStandard) {
        this.bmrStandard = bmrStandard;
    }
    
    @Keep
    public void setBodyScore(final double bodyScore) {
        this.bodyScore = bodyScore;
    }
    
    @Keep
    public void setBodyType(final int bodyType) {
        this.bodyType = bodyType;
    }
    
    @Keep
    public void setBone(final double bone) {
        this.bone = bone;
    }
    
    @Keep
    public void setBoneMax(final double boneMax) {
        this.boneMax = boneMax;
    }
    
    @Keep
    public void setBoneMin(final double boneMin) {
        this.boneMin = boneMin;
    }
    
    @Keep
    public void setFfmControl(final double ffmControl) {
        this.ffmControl = ffmControl;
    }
    
    @Keep
    public void setFfmStandard(final double ffmStandard) {
        this.ffmStandard = ffmStandard;
    }
    
    @Keep
    public void setLeftArmBodyfatMass(final double leftArmBodyfatMass) {
        this.leftArmBodyfatMass = leftArmBodyfatMass;
    }
    
    @Keep
    public void setLeftArmBodyfatPercentage(final double leftArmBodyfatPercentage) {
        this.leftArmBodyfatPercentage = leftArmBodyfatPercentage;
    }
    
    @Keep
    public void setLeftArmMuscle(final double leftArmMuscle) {
        this.leftArmMuscle = leftArmMuscle;
    }
    
    @Keep
    public void setLeftArmMuscleMass(final double leftArmMuscleMass) {
        this.leftArmMuscleMass = leftArmMuscleMass;
    }
    
    @Keep
    public void setLeftLegBodyfatMass(final double leftLegBodyfatMass) {
        this.leftLegBodyfatMass = leftLegBodyfatMass;
    }
    
    @Keep
    public void setLeftLegBodyfatPercentage(final double leftLegBodyfatPercentage) {
        this.leftLegBodyfatPercentage = leftLegBodyfatPercentage;
    }
    
    @Keep
    public void setLeftLegMuscle(final double leftLegMuscle) {
        this.leftLegMuscle = leftLegMuscle;
    }
    
    @Keep
    public void setLeftLegMuscleMass(final double leftLegMuscleMass) {
        this.leftLegMuscleMass = leftLegMuscleMass;
    }
    
    @Keep
    public void setMuscle(final double muscle) {
        this.muscle = muscle;
    }
    
    @Keep
    public void setMuscleMassMax(final double muscleMassMax) {
        this.muscleMassMax = muscleMassMax;
    }
    
    @Keep
    public void setMuscleMassMin(final double muscleMassMin) {
        this.muscleMassMin = muscleMassMin;
    }
    
    @Keep
    public void setObesityDegree(final int obesityDegree) {
        this.obesityDegree = obesityDegree;
    }
    
    @Keep
    public void setProtein(final double protein) {
        this.protein = protein;
    }
    
    @Keep
    public void setProteinMassMax(final double proteinMassMax) {
        this.proteinMassMax = proteinMassMax;
    }
    
    @Keep
    public void setProteinMassMin(final double proteinMassMin) {
        this.proteinMassMin = proteinMassMin;
    }
    
    @Keep
    public void setRightArmBodyfatMass(final double rightArmBodyfatMass) {
        this.rightArmBodyfatMass = rightArmBodyfatMass;
    }
    
    @Keep
    public void setRightArmBodyfatPercentage(final double rightArmBodyfatPercentage) {
        this.rightArmBodyfatPercentage = rightArmBodyfatPercentage;
    }
    
    @Keep
    public void setRightArmMuscle(final double rightArmMuscle) {
        this.rightArmMuscle = rightArmMuscle;
    }
    
    @Keep
    public void setRightArmMuscleMass(final double rightArmMuscleMass) {
        this.rightArmMuscleMass = rightArmMuscleMass;
    }
    
    @Keep
    public void setRightLegBodyfatMass(final double rightLegBodyfatMass) {
        this.rightLegBodyfatMass = rightLegBodyfatMass;
    }
    
    @Keep
    public void setRightLegBodyfatPercentage(final double rightLegBodyfatPercentage) {
        this.rightLegBodyfatPercentage = rightLegBodyfatPercentage;
    }
    
    @Keep
    public void setRightLegMuscle(final double rightLegMuscle) {
        this.rightLegMuscle = rightLegMuscle;
    }
    
    @Keep
    public void setRightLegMuscleMass(final double rightLegMuscleMass) {
        this.rightLegMuscleMass = rightLegMuscleMass;
    }
    
    @Keep
    public void setSm(final double sm) {
        this.sm = sm;
    }
    
    @Keep
    public void setSmi(final double smi) {
        this.smi = smi;
    }
    
    @Keep
    public void setSmmMax(final double smmMax) {
        this.smmMax = smmMax;
    }
    
    @Keep
    public void setSmmMin(final double smmMin) {
        this.smmMin = smmMin;
    }
    
    @Keep
    public void setSmmStandard(final double smmStandard) {
        this.smmStandard = smmStandard;
    }
    
    @Keep
    public void setSubcutfat(final double subcutfat) {
        this.subcutfat = subcutfat;
    }
    
    @Keep
    public void setTrunkBodyfatMass(final double trunkBodyfatMass) {
        this.trunkBodyfatMass = trunkBodyfatMass;
    }
    
    @Keep
    public void setTrunkBodyfatPercentage(final double trunkBodyfatPercentage) {
        this.trunkBodyfatPercentage = trunkBodyfatPercentage;
    }
    
    @Keep
    public void setTrunkMuscle(final double trunkMuscle) {
        this.trunkMuscle = trunkMuscle;
    }
    
    @Keep
    public void setTrunkMuscleMass(final double trunkMuscleMass) {
        this.trunkMuscleMass = trunkMuscleMass;
    }
    
    @Keep
    public void setVfal(final double vfal) {
        this.vfal = vfal;
    }
    
    @Keep
    public void setWater(final double water) {
        this.water = water;
    }
    
    @Keep
    public void setWaterMassMax(final double waterMassMax) {
        this.waterMassMax = waterMassMax;
    }
    
    @Keep
    public void setWaterMassMin(final double waterMassMin) {
        this.waterMassMin = waterMassMin;
    }
    
    @Keep
    public void setWeightControl(final double weightControl) {
        this.weightControl = weightControl;
    }
    
    @Keep
    public void setWeightMax(final double weightMax) {
        this.weightMax = weightMax;
    }
    
    @Keep
    public void setWeightMin(final double weightMin) {
        this.weightMin = weightMin;
    }
    
    @Keep
    public void setWeightStandard(final double weightStandard) {
        this.weightStandard = weightStandard;
    }
    
    @Keep
    public void setWeightTarget(final double weightTarget) {
        this.weightTarget = weightTarget;
    }
    
    @Keep
    public void setWhr(final double whr) {
        this.whr = whr;
    }
}
