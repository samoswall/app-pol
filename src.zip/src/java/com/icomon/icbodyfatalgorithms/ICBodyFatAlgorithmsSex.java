package com.icomon.icbodyfatalgorithms;

import androidx.annotation.Keep;

@Keep
public enum ICBodyFatAlgorithmsSex
{
    private static final ICBodyFatAlgorithmsSex[] $VALUES;
    
    Female(2), 
    Male(1);
    
    private final int value;
    
    private static /* synthetic */ ICBodyFatAlgorithmsSex[] $values() {
        return new ICBodyFatAlgorithmsSex[] { ICBodyFatAlgorithmsSex.Male, ICBodyFatAlgorithmsSex.Female };
    }
    
    static {
        $VALUES = $values();
    }
    
    @Keep
    private ICBodyFatAlgorithmsSex(final int value) {
        this.value = value;
    }
    
    @Keep
    public static ICBodyFatAlgorithmsSex valueOf(final int n) {
        if (n != 2) {
            return ICBodyFatAlgorithmsSex.Male;
        }
        return ICBodyFatAlgorithmsSex.Female;
    }
    
    @Keep
    public int getValue() {
        return this.value;
    }
}
