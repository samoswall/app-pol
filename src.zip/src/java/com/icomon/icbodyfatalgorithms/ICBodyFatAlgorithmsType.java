package com.icomon.icbodyfatalgorithms;

import androidx.annotation.Keep;

@Keep
public enum ICBodyFatAlgorithmsType
{
    private static final ICBodyFatAlgorithmsType[] $VALUES;
    
    ICBodyFatAlgorithmsTypeRev(99), 
    ICBodyFatAlgorithmsTypeWLA02(1), 
    ICBodyFatAlgorithmsTypeWLA28(27);
    
    private final int value;
    
    private static /* synthetic */ ICBodyFatAlgorithmsType[] $values() {
        return new ICBodyFatAlgorithmsType[] { ICBodyFatAlgorithmsType.ICBodyFatAlgorithmsTypeWLA02, ICBodyFatAlgorithmsType.ICBodyFatAlgorithmsTypeWLA28, ICBodyFatAlgorithmsType.ICBodyFatAlgorithmsTypeRev };
    }
    
    static {
        $VALUES = $values();
    }
    
    @Keep
    private ICBodyFatAlgorithmsType(final int value) {
        this.value = value;
    }
    
    @Keep
    public static ICBodyFatAlgorithmsType valueOf(final int n) {
        if (n == 1) {
            return ICBodyFatAlgorithmsType.ICBodyFatAlgorithmsTypeWLA02;
        }
        if (n != 99) {
            return null;
        }
        return ICBodyFatAlgorithmsType.ICBodyFatAlgorithmsTypeRev;
    }
    
    @Keep
    public int getValue() {
        return this.value;
    }
}
