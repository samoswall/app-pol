package com.journeyapps.barcodescanner;

import A7.t;
import A7.l;
import java.util.Map;
import Y6.e;
import java.util.HashMap;
import A7.j;
import A7.h;
import java.util.List;
import A7.c;
import android.os.Message;
import android.util.AttributeSet;
import android.content.Context;
import android.os.Handler$Callback;
import android.os.Handler;
import A7.i;
import A7.k;

public class BarcodeView extends a
{
    private b B;
    private A7.a C;
    private k H;
    private i L;
    private Handler M;
    private final Handler$Callback Q;
    
    public BarcodeView(final Context context, final AttributeSet set) {
        super(context, set);
        this.B = b.NONE;
        this.C = null;
        this.Q = (Handler$Callback)new Handler$Callback() {
            final BarcodeView a;
            
            public boolean handleMessage(final Message message) {
                final int what = message.what;
                if (what == d7.k.g) {
                    final c c = (c)message.obj;
                    if (c != null && this.a.C != null && this.a.B != b.NONE) {
                        this.a.C.b(c);
                        if (this.a.B == b.SINGLE) {
                            this.a.N();
                        }
                    }
                    return true;
                }
                if (what == d7.k.f) {
                    return true;
                }
                if (what == d7.k.h) {
                    final List list = (List)message.obj;
                    if (this.a.C != null && this.a.B != b.NONE) {
                        this.a.C.a(list);
                    }
                    return true;
                }
                return false;
            }
        };
        this.K();
    }
    
    private h G() {
        if (this.L == null) {
            this.L = this.H();
        }
        final j j = new j();
        final HashMap hashMap = new HashMap();
        ((Map)hashMap).put((Object)Y6.e.NEED_RESULT_POINT_CALLBACK, (Object)j);
        final h a = this.L.a((Map)hashMap);
        j.b(a);
        return a;
    }
    
    private void K() {
        this.L = (i)new l();
        this.M = new Handler(this.Q);
    }
    
    private void L() {
        this.M();
        if (this.B != b.NONE && this.t()) {
            (this.H = new k(this.getCameraInstance(), this.G(), this.M)).i(this.getPreviewFramingRect());
            this.H.k();
        }
    }
    
    private void M() {
        final k h = this.H;
        if (h != null) {
            h.l();
            this.H = null;
        }
    }
    
    protected i H() {
        return (i)new l();
    }
    
    public void I(final A7.a c) {
        this.B = b.CONTINUOUS;
        this.C = c;
        this.L();
    }
    
    public void J(final A7.a c) {
        this.B = b.SINGLE;
        this.C = c;
        this.L();
    }
    
    public void N() {
        this.B = b.NONE;
        this.C = null;
        this.M();
    }
    
    public i getDecoderFactory() {
        return this.L;
    }
    
    public void setDecoderFactory(final i l) {
        A7.t.a();
        this.L = l;
        final k h = this.H;
        if (h != null) {
            h.j(this.G());
        }
    }
    
    @Override
    public void u() {
        this.M();
        super.u();
    }
    
    @Override
    protected void x() {
        super.x();
        this.L();
    }
    
    private enum b
    {
        private static final b[] $VALUES;
        
        CONTINUOUS, 
        NONE, 
        SINGLE;
        
        private static /* synthetic */ b[] $values() {
            return new b[] { b.NONE, b.SINGLE, b.CONTINUOUS };
        }
        
        static {
            $VALUES = $values();
        }
    }
}
