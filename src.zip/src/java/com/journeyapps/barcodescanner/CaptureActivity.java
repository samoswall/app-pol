package com.journeyapps.barcodescanner;

import android.view.KeyEvent;
import android.os.Bundle;
import d7.k;
import d7.l;
import android.app.Activity;

public class CaptureActivity extends Activity
{
    private e a;
    private DecoratedBarcodeView b;
    
    protected DecoratedBarcodeView a() {
        this.setContentView(l.b);
        return (DecoratedBarcodeView)this.findViewById(k.a);
    }
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        this.b = this.a();
        (this.a = new e(this, this.b)).p(this.getIntent(), bundle);
        this.a.l();
    }
    
    protected void onDestroy() {
        super.onDestroy();
        this.a.u();
    }
    
    public boolean onKeyDown(final int n, final KeyEvent keyEvent) {
        return this.b.onKeyDown(n, keyEvent) || super.onKeyDown(n, keyEvent);
    }
    
    protected void onPause() {
        super.onPause();
        this.a.v();
    }
    
    public void onRequestPermissionsResult(final int n, final String[] array, final int[] array2) {
        this.a.w(n, array, array2);
    }
    
    protected void onResume() {
        super.onResume();
        this.a.x();
    }
    
    protected void onSaveInstanceState(final Bundle bundle) {
        super.onSaveInstanceState(bundle);
        this.a.y(bundle);
    }
}
