package com.journeyapps.barcodescanner;

import android.view.KeyEvent;
import java.util.Map;
import java.util.Set;
import java.util.Collection;
import B7.i;
import d7.g;
import d7.f;
import android.content.Intent;
import android.content.res.TypedArray;
import d7.k;
import android.view.ViewGroup;
import android.view.View;
import d7.l;
import d7.o;
import android.util.AttributeSet;
import android.content.Context;
import android.widget.TextView;
import android.widget.FrameLayout;

public class DecoratedBarcodeView extends FrameLayout
{
    private BarcodeView a;
    private ViewfinderView b;
    private TextView c;
    
    public DecoratedBarcodeView(final Context context) {
        super(context);
        this.d();
    }
    
    public DecoratedBarcodeView(final Context context, final AttributeSet set) {
        super(context, set);
        this.e(set);
    }
    
    private void d() {
        this.e(null);
    }
    
    private void e(final AttributeSet set) {
        final TypedArray obtainStyledAttributes = ((View)this).getContext().obtainStyledAttributes(set, o.t);
        final int resourceId = obtainStyledAttributes.getResourceId(o.u, l.a);
        obtainStyledAttributes.recycle();
        View.inflate(((View)this).getContext(), resourceId, (ViewGroup)this);
        final BarcodeView a = (BarcodeView)((View)this).findViewById(k.b);
        this.a = a;
        if (a == null) {
            throw new IllegalArgumentException("There is no a com.journeyapps.barcodescanner.BarcodeView on provided layout with the id \"zxing_barcode_surface\".");
        }
        ((a)a).q(set);
        final ViewfinderView b = (ViewfinderView)((View)this).findViewById(k.l);
        if ((this.b = b) != null) {
            b.setCameraPreview((a)this.a);
            this.c = (TextView)((View)this).findViewById(k.k);
            return;
        }
        throw new IllegalArgumentException("There is no a com.journeyapps.barcodescanner.ViewfinderView on provided layout with the id \"zxing_viewfinder_view\".");
    }
    
    public void b(final A7.a a) {
        this.a.I((A7.a)new DecoratedBarcodeView.DecoratedBarcodeView$b(this, a));
    }
    
    public void c(final A7.a a) {
        this.a.J((A7.a)new DecoratedBarcodeView.DecoratedBarcodeView$b(this, a));
    }
    
    public void f(final Intent intent) {
        final Set a = f.a(intent);
        final Map a2 = g.a(intent);
        final i cameraSettings = new i();
        if (intent.hasExtra("SCAN_CAMERA_ID")) {
            final int intExtra = intent.getIntExtra("SCAN_CAMERA_ID", -1);
            if (intExtra >= 0) {
                cameraSettings.i(intExtra);
            }
        }
        if (intent.hasExtra("TORCH_ENABLED") && intent.getBooleanExtra("TORCH_ENABLED", false)) {
            this.k();
        }
        final String stringExtra = intent.getStringExtra("PROMPT_MESSAGE");
        if (stringExtra != null) {
            this.setStatusText(stringExtra);
        }
        final int intExtra2 = intent.getIntExtra("SCAN_TYPE", 0);
        final String stringExtra2 = intent.getStringExtra("CHARACTER_SET");
        new Y6.k().f(a2);
        ((a)this.a).setCameraSettings(cameraSettings);
        this.a.setDecoderFactory((A7.i)new A7.l((Collection)a, a2, stringExtra2, intExtra2));
    }
    
    public void g() {
        this.a.u();
    }
    
    public BarcodeView getBarcodeView() {
        return (BarcodeView)((View)this).findViewById(k.b);
    }
    
    public i getCameraSettings() {
        return ((a)this.a).getCameraSettings();
    }
    
    public A7.i getDecoderFactory() {
        return this.a.getDecoderFactory();
    }
    
    public TextView getStatusView() {
        return this.c;
    }
    
    public ViewfinderView getViewFinder() {
        return this.b;
    }
    
    public void h() {
        ((a)this.a).v();
    }
    
    public void i() {
        ((a)this.a).y();
    }
    
    public void j() {
        ((a)this.a).setTorch(false);
    }
    
    public void k() {
        ((a)this.a).setTorch(true);
    }
    
    public boolean onKeyDown(final int n, final KeyEvent keyEvent) {
        if (n == 24) {
            this.k();
            return true;
        }
        if (n != 25) {
            return n == 27 || n == 80 || super.onKeyDown(n, keyEvent);
        }
        this.j();
        return true;
    }
    
    public void setCameraSettings(final i cameraSettings) {
        ((a)this.a).setCameraSettings(cameraSettings);
    }
    
    public void setDecoderFactory(final A7.i decoderFactory) {
        this.a.setDecoderFactory(decoderFactory);
    }
    
    public void setStatusText(final String text) {
        final TextView c = this.c;
        if (c != null) {
            c.setText((CharSequence)text);
        }
    }
    
    public void setTorchListener(final DecoratedBarcodeView.DecoratedBarcodeView$a decoratedBarcodeView$a) {
    }
}
