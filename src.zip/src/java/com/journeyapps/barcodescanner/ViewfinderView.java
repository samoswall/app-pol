package com.journeyapps.barcodescanner;

import java.util.Iterator;
import android.graphics.Canvas;
import Y6.t;
import android.content.res.TypedArray;
import android.content.res.Resources;
import java.util.ArrayList;
import d7.j;
import d7.o;
import android.util.AttributeSet;
import android.content.Context;
import A7.r;
import android.graphics.Rect;
import java.util.List;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.view.View;

public class ViewfinderView extends View
{
    protected static final int[] n;
    protected final Paint a;
    protected Bitmap b;
    protected int c;
    protected final int d;
    protected final int e;
    protected final int f;
    protected boolean g;
    protected int h;
    protected List i;
    protected List j;
    protected a k;
    protected Rect l;
    protected r m;
    
    static {
        n = new int[] { 0, 64, 128, 192, 255, 192, 128, 64 };
    }
    
    public ViewfinderView(final Context context, final AttributeSet set) {
        super(context, set);
        this.a = new Paint(1);
        final Resources resources = this.getResources();
        final TypedArray obtainStyledAttributes = this.getContext().obtainStyledAttributes(set, o.n);
        this.c = obtainStyledAttributes.getColor(o.s, resources.getColor(d7.j.d));
        this.d = obtainStyledAttributes.getColor(o.p, resources.getColor(d7.j.b));
        this.e = obtainStyledAttributes.getColor(o.q, resources.getColor(d7.j.c));
        this.f = obtainStyledAttributes.getColor(o.o, resources.getColor(d7.j.a));
        this.g = obtainStyledAttributes.getBoolean(o.r, true);
        obtainStyledAttributes.recycle();
        this.h = 0;
        this.i = (List)new ArrayList(20);
        this.j = (List)new ArrayList(20);
    }
    
    public void a(final t t) {
        if (this.i.size() < 20) {
            this.i.add((Object)t);
        }
    }
    
    protected void b() {
        final a k = this.k;
        if (k == null) {
            return;
        }
        final Rect framingRect = k.getFramingRect();
        final r previewSize = this.k.getPreviewSize();
        if (framingRect != null && previewSize != null) {
            this.l = framingRect;
            this.m = previewSize;
        }
    }
    
    public void onDraw(final Canvas canvas) {
        this.b();
        final Rect l = this.l;
        if (l != null) {
            final r m = this.m;
            if (m != null) {
                final int width = this.getWidth();
                final int height = this.getHeight();
                final Paint a = this.a;
                int color;
                if (this.b != null) {
                    color = this.d;
                }
                else {
                    color = this.c;
                }
                a.setColor(color);
                final float n = (float)width;
                canvas.drawRect(0.0f, 0.0f, n, (float)l.top, this.a);
                canvas.drawRect(0.0f, (float)l.top, (float)l.left, (float)(l.bottom + 1), this.a);
                canvas.drawRect((float)(l.right + 1), (float)l.top, n, (float)(l.bottom + 1), this.a);
                canvas.drawRect(0.0f, (float)(l.bottom + 1), n, (float)height, this.a);
                if (this.b != null) {
                    this.a.setAlpha(160);
                    canvas.drawBitmap(this.b, (Rect)null, l, this.a);
                }
                else {
                    if (this.g) {
                        this.a.setColor(this.e);
                        final Paint a2 = this.a;
                        final int[] n2 = ViewfinderView.n;
                        a2.setAlpha(n2[this.h]);
                        this.h = (this.h + 1) % n2.length;
                        final int n3 = l.height() / 2 + l.top;
                        canvas.drawRect((float)(l.left + 2), (float)(n3 - 1), (float)(l.right - 1), (float)(n3 + 2), this.a);
                    }
                    final float n4 = this.getWidth() / (float)m.a;
                    final float n5 = this.getHeight() / (float)m.b;
                    if (!this.j.isEmpty()) {
                        this.a.setAlpha(80);
                        this.a.setColor(this.f);
                        for (final t t : this.j) {
                            canvas.drawCircle((float)(int)(t.c() * n4), (float)(int)(t.d() * n5), 3.0f, this.a);
                        }
                        this.j.clear();
                    }
                    if (!this.i.isEmpty()) {
                        this.a.setAlpha(160);
                        this.a.setColor(this.f);
                        for (final t t2 : this.i) {
                            canvas.drawCircle((float)(int)(t2.c() * n4), (float)(int)(t2.d() * n5), 6.0f, this.a);
                        }
                        final List i = this.i;
                        final List j = this.j;
                        this.i = j;
                        this.j = i;
                        j.clear();
                    }
                    this.postInvalidateDelayed(80L, l.left - 6, l.top - 6, l.right + 6, l.bottom + 6);
                }
            }
        }
    }
    
    public void setCameraPreview(final a k) {
        (this.k = k).i((a.f)new a.f(this) {
            final ViewfinderView a;
            
            @Override
            public void a() {
                this.a.b();
                this.a.invalidate();
            }
            
            @Override
            public void b(final Exception ex) {
            }
            
            @Override
            public void c() {
            }
            
            @Override
            public void d() {
            }
            
            @Override
            public void e() {
            }
        });
    }
    
    public void setLaserVisibility(final boolean g) {
        this.g = g;
    }
    
    public void setMaskColor(final int c) {
        this.c = c;
    }
}
