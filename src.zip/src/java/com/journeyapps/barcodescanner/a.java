package com.journeyapps.barcodescanner;

import android.os.BaseBundle;
import A7.t;
import android.content.res.TypedArray;
import d7.o;
import android.os.Bundle;
import android.os.Parcelable;
import android.graphics.Matrix;
import B7.n;
import B7.l;
import android.graphics.SurfaceTexture;
import android.view.TextureView$SurfaceTextureListener;
import B7.j;
import android.view.View;
import java.util.Iterator;
import d7.k;
import android.os.Message;
import android.util.Log;
import android.view.SurfaceHolder;
import java.util.ArrayList;
import android.util.AttributeSet;
import android.content.Context;
import A7.p;
import android.os.Handler$Callback;
import android.view.SurfaceHolder$Callback;
import android.graphics.Rect;
import A7.r;
import B7.i;
import B7.m;
import java.util.List;
import A7.q;
import android.view.TextureView;
import android.view.SurfaceView;
import android.os.Handler;
import android.view.WindowManager;
import B7.g;
import android.view.ViewGroup;

public abstract class a extends ViewGroup
{
    private static final String A = "a";
    private g a;
    private WindowManager b;
    private Handler c;
    private boolean d;
    private SurfaceView e;
    private TextureView f;
    private boolean g;
    private q h;
    private int i;
    private List j;
    private m k;
    private i l;
    private r m;
    private r n;
    private Rect o;
    private r p;
    private Rect q;
    private Rect r;
    private r s;
    private double t;
    private B7.q u;
    private boolean v;
    private final SurfaceHolder$Callback w;
    private final Handler$Callback x;
    private p y;
    private final f z;
    
    public a(final Context context, final AttributeSet set) {
        super(context, set);
        this.d = false;
        this.g = false;
        this.i = -1;
        this.j = (List)new ArrayList();
        this.l = new i();
        this.q = null;
        this.r = null;
        this.s = null;
        this.t = 0.1;
        this.u = null;
        this.v = false;
        this.w = (SurfaceHolder$Callback)new SurfaceHolder$Callback() {
            final a a;
            
            public void surfaceChanged(final SurfaceHolder surfaceHolder, final int n, final int n2, final int n3) {
                if (surfaceHolder == null) {
                    Log.e(com.journeyapps.barcodescanner.a.A, "*** WARNING *** surfaceChanged() gave us a null surface!");
                    return;
                }
                this.a.p = new r(n2, n3);
                this.a.C();
            }
            
            public void surfaceCreated(final SurfaceHolder surfaceHolder) {
            }
            
            public void surfaceDestroyed(final SurfaceHolder surfaceHolder) {
                this.a.p = null;
            }
        };
        this.x = (Handler$Callback)new Handler$Callback() {
            final a a;
            
            public boolean handleMessage(final Message message) {
                final int what = message.what;
                if (what == d7.k.j) {
                    this.a.w((r)message.obj);
                    return true;
                }
                if (what == d7.k.d) {
                    final Exception ex = (Exception)message.obj;
                    if (this.a.r()) {
                        this.a.u();
                        this.a.z.b(ex);
                    }
                }
                else if (what == d7.k.c) {
                    this.a.z.d();
                }
                return false;
            }
        };
        this.y = (p)new p() {
            final a a;
            
            public void a(final int n) {
                this.a.c.postDelayed((Runnable)new b(this), 250L);
            }
        };
        this.z = (f)new f() {
            final a a;
            
            @Override
            public void a() {
                final Iterator iterator = this.a.j.iterator();
                while (iterator.hasNext()) {
                    ((f)iterator.next()).a();
                }
            }
            
            @Override
            public void b(final Exception ex) {
                final Iterator iterator = this.a.j.iterator();
                while (iterator.hasNext()) {
                    ((f)iterator.next()).b(ex);
                }
            }
            
            @Override
            public void c() {
                final Iterator iterator = this.a.j.iterator();
                while (iterator.hasNext()) {
                    ((f)iterator.next()).c();
                }
            }
            
            @Override
            public void d() {
                final Iterator iterator = this.a.j.iterator();
                while (iterator.hasNext()) {
                    ((f)iterator.next()).d();
                }
            }
            
            @Override
            public void e() {
                final Iterator iterator = this.a.j.iterator();
                while (iterator.hasNext()) {
                    ((f)iterator.next()).e();
                }
            }
        };
        this.p(context, set, 0, 0);
    }
    
    private void A() {
        if (this.d) {
            (this.f = new TextureView(((View)this).getContext())).setSurfaceTextureListener(this.D());
            this.addView((View)this.f);
        }
        else {
            final SurfaceView e = new SurfaceView(((View)this).getContext());
            this.e = e;
            e.getHolder().addCallback(this.w);
            this.addView((View)this.e);
        }
    }
    
    private void B(final j j) {
        if (!this.g && this.a != null) {
            Log.i(com.journeyapps.barcodescanner.a.A, "Starting preview");
            this.a.z(j);
            this.a.B();
            this.g = true;
            this.x();
            this.z.e();
        }
    }
    
    private void C() {
        final r p = this.p;
        if (p != null && this.n != null) {
            final Rect o = this.o;
            if (o != null) {
                if (this.e != null && p.equals((Object)new r(o.width(), this.o.height()))) {
                    this.B(new j(this.e.getHolder()));
                }
                else {
                    final TextureView f = this.f;
                    if (f != null && f.getSurfaceTexture() != null) {
                        if (this.n != null) {
                            this.f.setTransform(this.l(new r(((View)this.f).getWidth(), ((View)this.f).getHeight()), this.n));
                        }
                        this.B(new j(this.f.getSurfaceTexture()));
                    }
                }
            }
        }
    }
    
    private TextureView$SurfaceTextureListener D() {
        return (TextureView$SurfaceTextureListener)new TextureView$SurfaceTextureListener(this) {
            final a a;
            
            public void onSurfaceTextureAvailable(final SurfaceTexture surfaceTexture, final int n, final int n2) {
                this.onSurfaceTextureSizeChanged(surfaceTexture, n, n2);
            }
            
            public boolean onSurfaceTextureDestroyed(final SurfaceTexture surfaceTexture) {
                return false;
            }
            
            public void onSurfaceTextureSizeChanged(final SurfaceTexture surfaceTexture, final int n, final int n2) {
                this.a.p = new r(n, n2);
                this.a.C();
            }
            
            public void onSurfaceTextureUpdated(final SurfaceTexture surfaceTexture) {
            }
        };
    }
    
    private int getDisplayRotation() {
        return this.b.getDefaultDisplay().getRotation();
    }
    
    private void j() {
        final r m = this.m;
        if (m != null) {
            final r n = this.n;
            if (n != null) {
                final m k = this.k;
                if (k != null) {
                    final int a = n.a;
                    final int b = n.b;
                    final int a2 = m.a;
                    final int b2 = m.b;
                    final Rect d = k.d(n);
                    if (d.width() > 0) {
                        if (d.height() > 0) {
                            this.o = d;
                            this.q = this.k(new Rect(0, 0, a2, b2), this.o);
                            final Rect rect = new Rect(this.q);
                            final Rect o = this.o;
                            rect.offset(-o.left, -o.top);
                            final Rect r = new Rect(rect.left * a / this.o.width(), rect.top * b / this.o.height(), rect.right * a / this.o.width(), rect.bottom * b / this.o.height());
                            this.r = r;
                            if (r.width() > 0 && this.r.height() > 0) {
                                this.z.a();
                            }
                            else {
                                this.r = null;
                                this.q = null;
                                Log.w(com.journeyapps.barcodescanner.a.A, "Preview frame is too small");
                            }
                        }
                    }
                    return;
                }
            }
        }
        this.r = null;
        this.q = null;
        this.o = null;
        throw new IllegalStateException("containerSize or previewSize is not set yet");
    }
    
    private void m(final r m) {
        this.m = m;
        final g a = this.a;
        if (a != null && a.n() == null) {
            (this.k = new m(this.getDisplayRotation(), m)).e(this.getPreviewScalingStrategy());
            this.a.x(this.k);
            this.a.m();
            final boolean v = this.v;
            if (v) {
                this.a.A(v);
            }
        }
    }
    
    private void o() {
        if (this.a != null) {
            Log.w(com.journeyapps.barcodescanner.a.A, "initCamera called twice");
            return;
        }
        (this.a = this.n()).y(this.c);
        this.a.u();
        this.i = this.getDisplayRotation();
    }
    
    private void p(final Context context, final AttributeSet set, final int n, final int n2) {
        if (((View)this).getBackground() == null) {
            ((View)this).setBackgroundColor(-16777216);
        }
        this.q(set);
        this.b = (WindowManager)context.getSystemService("window");
        this.c = new Handler(this.x);
        this.h = new q();
    }
    
    private void w(final r n) {
        this.n = n;
        if (this.m != null) {
            this.j();
            ((View)this).requestLayout();
            this.C();
        }
    }
    
    private void z() {
        if (this.r() && this.getDisplayRotation() != this.i) {
            this.u();
            this.y();
        }
    }
    
    public g getCameraInstance() {
        return this.a;
    }
    
    public i getCameraSettings() {
        return this.l;
    }
    
    public Rect getFramingRect() {
        return this.q;
    }
    
    public r getFramingRectSize() {
        return this.s;
    }
    
    public double getMarginFraction() {
        return this.t;
    }
    
    public Rect getPreviewFramingRect() {
        return this.r;
    }
    
    public B7.q getPreviewScalingStrategy() {
        final B7.q u = this.u;
        if (u != null) {
            return u;
        }
        if (this.f != null) {
            return (B7.q)new l();
        }
        return (B7.q)new n();
    }
    
    public r getPreviewSize() {
        return this.n;
    }
    
    public void i(final f f) {
        this.j.add((Object)f);
    }
    
    protected Rect k(Rect rect, final Rect rect2) {
        rect = new Rect(rect);
        rect.intersect(rect2);
        if (this.s != null) {
            rect.inset(Math.max(0, (rect.width() - this.s.a) / 2), Math.max(0, (rect.height() - this.s.b) / 2));
            return rect;
        }
        final int n = (int)Math.min(rect.width() * this.t, rect.height() * this.t);
        rect.inset(n, n);
        if (rect.height() > rect.width()) {
            rect.inset(0, (rect.height() - rect.width()) / 2);
        }
        return rect;
    }
    
    protected Matrix l(final r r, final r r2) {
        final float n = r.a / (float)r.b;
        final float n2 = r2.a / (float)r2.b;
        float n3 = 1.0f;
        float n4;
        if (n < n2) {
            n3 = n2 / n;
            n4 = 1.0f;
        }
        else {
            n4 = n / n2;
        }
        final Matrix matrix = new Matrix();
        matrix.setScale(n3, n4);
        final int a = r.a;
        final float n5 = (float)a;
        final int b = r.b;
        matrix.postTranslate((a - n5 * n3) / 2.0f, (b - b * n4) / 2.0f);
        return matrix;
    }
    
    protected g n() {
        final g g = new g(((View)this).getContext());
        g.w(this.l);
        return g;
    }
    
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.A();
    }
    
    protected void onLayout(final boolean b, final int n, final int n2, final int n3, final int n4) {
        this.m(new r(n3 - n, n4 - n2));
        final SurfaceView e = this.e;
        if (e != null) {
            final Rect o = this.o;
            if (o == null) {
                ((View)e).layout(0, 0, ((View)this).getWidth(), ((View)this).getHeight());
            }
            else {
                ((View)e).layout(o.left, o.top, o.right, o.bottom);
            }
        }
        else {
            final TextureView f = this.f;
            if (f != null) {
                ((View)f).layout(0, 0, ((View)this).getWidth(), ((View)this).getHeight());
            }
        }
    }
    
    protected void onRestoreInstanceState(final Parcelable parcelable) {
        if (!(parcelable instanceof Bundle)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        final Bundle bundle = (Bundle)parcelable;
        super.onRestoreInstanceState(bundle.getParcelable("super"));
        this.setTorch(((BaseBundle)bundle).getBoolean("torch"));
    }
    
    protected Parcelable onSaveInstanceState() {
        final Parcelable onSaveInstanceState = super.onSaveInstanceState();
        final Bundle bundle = new Bundle();
        bundle.putParcelable("super", onSaveInstanceState);
        ((BaseBundle)bundle).putBoolean("torch", this.v);
        return (Parcelable)bundle;
    }
    
    protected void q(final AttributeSet set) {
        final TypedArray obtainStyledAttributes = ((View)this).getContext().obtainStyledAttributes(set, d7.o.i);
        final int n = (int)obtainStyledAttributes.getDimension(d7.o.k, -1.0f);
        final int n2 = (int)obtainStyledAttributes.getDimension(d7.o.j, -1.0f);
        if (n > 0 && n2 > 0) {
            this.s = new r(n, n2);
        }
        this.d = obtainStyledAttributes.getBoolean(d7.o.m, true);
        final int integer = obtainStyledAttributes.getInteger(d7.o.l, -1);
        if (integer == 1) {
            this.u = (B7.q)new l();
        }
        else if (integer == 2) {
            this.u = (B7.q)new n();
        }
        else if (integer == 3) {
            this.u = (B7.q)new B7.o();
        }
        obtainStyledAttributes.recycle();
    }
    
    protected boolean r() {
        return this.a != null;
    }
    
    public boolean s() {
        final g a = this.a;
        return a == null || a.p();
    }
    
    public void setCameraSettings(final i l) {
        this.l = l;
    }
    
    public void setFramingRectSize(final r s) {
        this.s = s;
    }
    
    public void setMarginFraction(final double t) {
        if (t < 0.5) {
            this.t = t;
            return;
        }
        throw new IllegalArgumentException("The margin fraction must be less than 0.5");
    }
    
    public void setPreviewScalingStrategy(final B7.q u) {
        this.u = u;
    }
    
    public void setTorch(final boolean v) {
        this.v = v;
        final g a = this.a;
        if (a != null) {
            a.A(v);
        }
    }
    
    public void setUseTextureView(final boolean d) {
        this.d = d;
    }
    
    public boolean t() {
        return this.g;
    }
    
    public void u() {
        A7.t.a();
        Log.d(com.journeyapps.barcodescanner.a.A, "pause()");
        this.i = -1;
        final g a = this.a;
        if (a != null) {
            a.l();
            this.a = null;
            this.g = false;
        }
        else {
            this.c.sendEmptyMessage(d7.k.c);
        }
        if (this.p == null) {
            final SurfaceView e = this.e;
            if (e != null) {
                e.getHolder().removeCallback(this.w);
            }
        }
        if (this.p == null) {
            final TextureView f = this.f;
            if (f != null) {
                f.setSurfaceTextureListener((TextureView$SurfaceTextureListener)null);
            }
        }
        this.m = null;
        this.n = null;
        this.r = null;
        this.h.f();
        this.z.c();
    }
    
    public void v() {
        final g cameraInstance = this.getCameraInstance();
        this.u();
        final long nanoTime = System.nanoTime();
        while (true) {
            if (cameraInstance == null || cameraInstance.p()) {
                return;
            }
            if (System.nanoTime() - nanoTime > 2000000000L) {
                return;
            }
            try {
                Thread.sleep(1L);
                continue;
            }
            catch (final InterruptedException ex) {}
        }
    }
    
    protected void x() {
    }
    
    public void y() {
        A7.t.a();
        Log.d(com.journeyapps.barcodescanner.a.A, "resume()");
        this.o();
        if (this.p != null) {
            this.C();
        }
        else {
            final SurfaceView e = this.e;
            if (e != null) {
                e.getHolder().addCallback(this.w);
            }
            else {
                final TextureView f = this.f;
                if (f != null) {
                    if (f.isAvailable()) {
                        this.D().onSurfaceTextureAvailable(this.f.getSurfaceTexture(), ((View)this.f).getWidth(), ((View)this.f).getHeight());
                    }
                    else {
                        this.f.setSurfaceTextureListener(this.D());
                    }
                }
            }
        }
        ((View)this).requestLayout();
        this.h.e(((View)this).getContext(), this.y);
    }
    
    public interface f
    {
        void a();
        
        void b(final Exception p0);
        
        void c();
        
        void d();
        
        void e();
    }
}
