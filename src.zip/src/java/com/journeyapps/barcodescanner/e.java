package com.journeyapps.barcodescanner;

import android.os.BaseBundle;
import android.os.Bundle;
import android.content.DialogInterface$OnCancelListener;
import A7.f;
import android.content.DialogInterface$OnClickListener;
import android.app.AlertDialog$Builder;
import android.graphics.Bitmap;
import java.io.IOException;
import java.io.OutputStream;
import android.graphics.Bitmap$CompressFormat;
import java.io.FileOutputStream;
import java.io.File;
import android.content.DialogInterface;
import java.util.Iterator;
import java.util.Map;
import Y6.s;
import android.content.Intent;
import android.content.Context;
import android.util.Log;
import d7.n;
import java.util.List;
import A7.c;
import A7.a;
import android.os.Handler;
import d7.h;
import android.app.Activity;

public class e
{
    private static final String o = "e";
    private static int p = 250;
    private Activity a;
    private DecoratedBarcodeView b;
    private int c;
    private boolean d;
    private boolean e;
    private String f;
    private boolean g;
    private h h;
    private d7.e i;
    private Handler j;
    private boolean k;
    private a l;
    private final com.journeyapps.barcodescanner.a.f m;
    private boolean n;
    
    public e(final Activity a, final DecoratedBarcodeView b) {
        this.c = -1;
        this.d = false;
        this.e = true;
        this.f = "";
        this.g = false;
        this.k = false;
        this.l = (a)new a() {
            final e a;
            
            public void a(final List list) {
            }
            
            public void b(final c c) {
                this.a.b.g();
                this.a.i.f();
                this.a.j.post((Runnable)new d(this, c));
            }
        };
        final com.journeyapps.barcodescanner.a.f m = new com.journeyapps.barcodescanner.a.f() {
            final e a;
            
            @Override
            public void a() {
            }
            
            @Override
            public void b(final Exception ex) {
                final e a = this.a;
                a.m(((Context)a.a).getString(n.c));
            }
            
            @Override
            public void c() {
            }
            
            @Override
            public void d() {
                if (this.a.k) {
                    Log.d(e.o, "Camera closed; finishing activity");
                    this.a.n();
                }
            }
            
            @Override
            public void e() {
            }
        };
        this.m = m;
        this.n = false;
        this.a = a;
        this.b = b;
        b.getBarcodeView().i((com.journeyapps.barcodescanner.a.f)m);
        this.j = new Handler();
        this.h = new h((Context)a, (Runnable)new A7.d(this));
        this.i = new d7.e(a);
    }
    
    public static Intent A(final c c, final String s) {
        final Intent intent = new Intent("com.google.zxing.client.android.SCAN");
        intent.addFlags(524288);
        intent.putExtra("SCAN_RESULT", c.toString());
        intent.putExtra("SCAN_RESULT_FORMAT", c.a().toString());
        final byte[] c2 = c.c();
        if (c2 != null && c2.length > 0) {
            intent.putExtra("SCAN_RESULT_BYTES", c2);
        }
        final Map d = c.d();
        if (d != null) {
            final s upc_EAN_EXTENSION = s.UPC_EAN_EXTENSION;
            if (d.containsKey((Object)upc_EAN_EXTENSION)) {
                intent.putExtra("SCAN_RESULT_UPC_EAN_EXTENSION", d.get((Object)upc_EAN_EXTENSION).toString());
            }
            final Number n = (Number)d.get((Object)s.ORIENTATION);
            if (n != null) {
                intent.putExtra("SCAN_RESULT_ORIENTATION", n.intValue());
            }
            final String s2 = (String)d.get((Object)s.ERROR_CORRECTION_LEVEL);
            if (s2 != null) {
                intent.putExtra("SCAN_RESULT_ERROR_CORRECTION_LEVEL", s2);
            }
            final Iterable iterable = (Iterable)d.get((Object)s.BYTE_SEGMENTS);
            if (iterable != null) {
                final Iterator iterator = iterable.iterator();
                int n2 = 0;
                while (iterator.hasNext()) {
                    final byte[] array = (byte[])iterator.next();
                    final StringBuilder sb = new StringBuilder();
                    sb.append("SCAN_RESULT_BYTE_SEGMENTS_");
                    sb.append(n2);
                    intent.putExtra(sb.toString(), array);
                    ++n2;
                }
            }
        }
        if (s != null) {
            intent.putExtra("SCAN_RESULT_IMAGE_PATH", s);
        }
        return intent;
    }
    
    private void D() {
        final Intent intent = new Intent("com.google.zxing.client.android.SCAN");
        intent.putExtra("MISSING_CAMERA_PERMISSION", true);
        this.a.setResult(0, intent);
    }
    
    private void n() {
        this.a.finish();
    }
    
    private String o(final c c) {
        if (this.d) {
            final Bitmap b = c.b();
            try {
                final File tempFile = File.createTempFile("barcodeimage", ".jpg", ((Context)this.a).getCacheDir());
                final FileOutputStream fileOutputStream = new FileOutputStream(tempFile);
                b.compress(Bitmap$CompressFormat.JPEG, 100, (OutputStream)fileOutputStream);
                fileOutputStream.close();
                return tempFile.getAbsolutePath();
            }
            catch (final IOException ex) {
                final String o = com.journeyapps.barcodescanner.e.o;
                final StringBuilder sb = new StringBuilder();
                sb.append("Unable to create temporary file and store bitmap! ");
                sb.append((Object)ex);
                Log.w(o, sb.toString());
            }
        }
        return null;
    }
    
    private void z() {
        if (androidx.core.content.a.checkSelfPermission((Context)this.a, "android.permission.CAMERA") == 0) {
            this.b.i();
        }
        else if (!this.n) {
            androidx.core.app.a.e(this.a, new String[] { "android.permission.CAMERA" }, com.journeyapps.barcodescanner.e.p);
            this.n = true;
        }
    }
    
    protected void B(final c c) {
        this.a.setResult(-1, A(c, this.o(c)));
        this.k();
    }
    
    protected void C() {
        final Intent intent = new Intent("com.google.zxing.client.android.SCAN");
        intent.putExtra("TIMEOUT", true);
        this.a.setResult(0, intent);
        this.k();
    }
    
    public void E(final boolean e, String f) {
        this.e = e;
        if (f == null) {
            f = "";
        }
        this.f = f;
    }
    
    protected void k() {
        if (this.b.getBarcodeView().s()) {
            this.n();
        }
        else {
            this.k = true;
        }
        this.b.g();
        this.h.d();
    }
    
    public void l() {
        this.b.c(this.l);
    }
    
    protected void m(final String s) {
        if (!this.a.isFinishing() && !this.g) {
            if (!this.k) {
                String string = s;
                if (s.isEmpty()) {
                    string = ((Context)this.a).getString(d7.n.c);
                }
                final AlertDialog$Builder alertDialog$Builder = new AlertDialog$Builder((Context)this.a);
                alertDialog$Builder.setTitle((CharSequence)((Context)this.a).getString(d7.n.a));
                alertDialog$Builder.setMessage((CharSequence)string);
                alertDialog$Builder.setPositiveButton(d7.n.b, (DialogInterface$OnClickListener)new A7.e(this));
                alertDialog$Builder.setOnCancelListener((DialogInterface$OnCancelListener)new f(this));
                alertDialog$Builder.show();
            }
        }
    }
    
    public void p(final Intent intent, final Bundle bundle) {
        this.a.getWindow().addFlags(128);
        if (bundle != null) {
            this.c = ((BaseBundle)bundle).getInt("SAVED_ORIENTATION_LOCK", -1);
        }
        if (intent != null) {
            if (intent.getBooleanExtra("SCAN_ORIENTATION_LOCKED", true)) {
                this.t();
            }
            if ("com.google.zxing.client.android.SCAN".equals((Object)intent.getAction())) {
                this.b.f(intent);
            }
            if (!intent.getBooleanExtra("BEEP_ENABLED", true)) {
                this.i.g(false);
            }
            if (intent.hasExtra("SHOW_MISSING_CAMERA_PERMISSION_DIALOG")) {
                this.E(intent.getBooleanExtra("SHOW_MISSING_CAMERA_PERMISSION_DIALOG", true), intent.getStringExtra("MISSING_CAMERA_PERMISSION_DIALOG_MESSAGE"));
            }
            if (intent.hasExtra("TIMEOUT")) {
                this.j.postDelayed((Runnable)new com.journeyapps.barcodescanner.c(this), intent.getLongExtra("TIMEOUT", 0L));
            }
            if (intent.getBooleanExtra("BARCODE_IMAGE_ENABLED", false)) {
                this.d = true;
            }
        }
    }
    
    protected void t() {
        if (this.c == -1) {
            final int rotation = this.a.getWindowManager().getDefaultDisplay().getRotation();
            final int orientation = ((Context)this.a).getResources().getConfiguration().orientation;
            final boolean b = false;
            int c;
            if (orientation == 2) {
                c = (b ? 1 : 0);
                if (rotation != 0) {
                    if (rotation == 1) {
                        c = (b ? 1 : 0);
                    }
                    else {
                        c = 8;
                    }
                }
            }
            else {
                c = (b ? 1 : 0);
                if (orientation == 1) {
                    if (rotation != 0 && rotation != 3) {
                        c = 9;
                    }
                    else {
                        c = 1;
                    }
                }
            }
            this.c = c;
        }
        this.a.setRequestedOrientation(this.c);
    }
    
    public void u() {
        this.g = true;
        this.h.d();
        this.j.removeCallbacksAndMessages((Object)null);
    }
    
    public void v() {
        this.h.d();
        this.b.h();
    }
    
    public void w(final int n, final String[] array, final int[] array2) {
        if (n == com.journeyapps.barcodescanner.e.p) {
            if (array2.length > 0 && array2[0] == 0) {
                this.b.i();
            }
            else {
                this.D();
                if (this.e) {
                    this.m(this.f);
                }
                else {
                    this.k();
                }
            }
        }
    }
    
    public void x() {
        this.z();
        this.h.h();
    }
    
    public void y(final Bundle bundle) {
        ((BaseBundle)bundle).putInt("SAVED_ORIENTATION_LOCK", this.c);
    }
}
