package com.polaris.iot;

import com.syncleoiot.core.domain.config.objects.SyncleoBuildInfo;
import com.syncleoiot.core.domain.config.objects.SyncleoResources;

public final class AppConfigKt
{
    private static final SyncleoResources appResources;
    
    static {
        appResources = new SyncleoResources(2131886153, 2131689472, 2131165593);
    }
    
    public static final SyncleoBuildInfo getAppBuildInfo() {
        return new SyncleoBuildInfo(false, "com.polaris.iot", "release", "gmsStore", 267, "3.0.3", 1740804716931L, "0ebd7dfc6");
    }
    
    public static final SyncleoResources getAppResources() {
        return AppConfigKt.appResources;
    }
}
