package com.polaris.iot.application.appwidget;

import android.os.BaseBundle;
import java.util.Collection;
import com.syncleoiot.core.ext.NumberExtKt;
import com.syncleoiot.core.utils.AppThemeMode;
import i9.c0;
import com.polaris.iot.presentation.appwidget.widget.AppWidget;
import com.polaris.iot.presentation.appwidget.receiver.DeviceSmallWidgetReceiver;
import y2.c;
import r2.a;
import K8.u;
import com.syncleoiot.core.ext.DeviceStateExtKt;
import com.polaris.iot.domain.appwidget.AppWidgetState;
import X8.p;
import com.polaris.iot.domain.appwidget.AppWidgetStateDefinition;
import n2.z;
import com.polaris.iot.domain.appwidget.AppWidgetData;
import com.polaris.iot.domain.appwidget.AppWidgetDataKt;
import java.util.UUID;
import android.content.Intent;
import com.polaris.iot.presentation.appwidget.receiver.AppWidgetPinnedReceiver;
import android.os.Bundle;
import android.app.PendingIntent;
import l2.s;
import l9.H$a;
import com.polaris.iot.domain.appwidget.AppWidgetParams;
import l9.O;
import l9.H;
import androidx.lifecycle.f0;
import l9.i;
import java.util.Iterator;
import java.util.LinkedHashMap;
import d9.n;
import L8.P;
import L8.t;
import com.syncleoiot.core.data.model.UserDeviceItemKt;
import com.syncleoiot.core.data.model.UserDeviceItem;
import com.syncleoiot.core.data.model.DeviceKt;
import com.syncleoiot.core.data.model.Device;
import com.syncleoiot.core.data.db.entity.UserDevice;
import java.util.ArrayList;
import Q8.b;
import java.util.Map;
import java.util.List;
import P8.d;
import kotlin.coroutines.jvm.internal.l;
import X8.q;
import kotlin.jvm.internal.v;
import com.syncleoiot.core.data.db.AppDatabase;
import l9.M;
import com.syncleoiot.core.domain.devices.DevicesRepository;
import l9.g;
import android.content.Context;
import l9.x;
import androidx.lifecycle.e0;

public final class AppWidgetSetupViewModel extends e0
{
    public static final int $stable = 8;
    private final x _isLoading;
    private final x _selectedMac;
    private final x _widgetParams;
    private final Context context;
    private final g devices;
    private final DevicesRepository devicesRepository;
    private boolean isInitialized;
    private final M selectedUserDeviceItem;
    private final M userDeviceItems;
    private final g userDevices;
    private int widgetId;
    
    public AppWidgetSetupViewModel(final AppDatabase appDatabase, final DevicesRepository devicesRepository, final Context context) {
        v.j((Object)appDatabase, "appDatabase");
        v.j((Object)devicesRepository, "devicesRepository");
        v.j((Object)context, "context");
        this.devicesRepository = devicesRepository;
        this.context = context;
        final g selectAllNotDeletedFlow = appDatabase.userDeviceDao().selectAllNotDeletedFlow();
        this.userDevices = selectAllNotDeletedFlow;
        final g watchDevicesChanges = devicesRepository.watchDevicesChanges();
        this.devices = watchDevicesChanges;
        final g n = i.n(i.k(selectAllNotDeletedFlow, watchDevicesChanges, (q)new q(null) {
            Object A;
            int y;
            Object z;
            
            public final Object f(final List z, final Map a, final d d) {
                final q q = (q)new q(d) {
                    Object A;
                    int y;
                    Object z;
                };
                q.z = z;
                q.A = a;
                return q.invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(Object o) {
                b.f();
                if (this.y == 0) {
                    K8.x.b(o);
                    final List list = (List)this.z;
                    final Map map = (Map)this.A;
                    final Iterable iterable = (Iterable)list;
                    final ArrayList list2 = new ArrayList();
                    for (final UserDevice userDevice : iterable) {
                        final Device device = (Device)map.get((Object)DeviceKt.getAsDeviceType(userDevice));
                        Object o3;
                        final Object o2 = o3 = null;
                        if (device != null) {
                            final UserDeviceItem userDeviceItem = new UserDeviceItem(userDevice, device);
                            o3 = o2;
                            if (UserDeviceItemKt.getHasWidget(userDeviceItem)) {
                                o3 = userDeviceItem;
                            }
                        }
                        if (o3 != null) {
                            ((Collection)list2).add(o3);
                        }
                    }
                    o = new LinkedHashMap(d9.n.f(P.d(t.x((Iterable)list2, 10)), 16));
                    for (final Object next : list2) {
                        ((Map)o).put((Object)((UserDeviceItem)next).getUserDevice().getMac(), next);
                    }
                    return o;
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }));
        final i9.M a = f0.a((e0)this);
        final H$a a2 = H.a;
        final M k = i.K(n, a, a2.c(), (Object)P.j());
        this.userDeviceItems = k;
        this._isLoading = O.a((Object)Boolean.TRUE);
        this._selectedMac = O.a((Object)null);
        this._widgetParams = O.a((Object)AppWidgetParams.Companion.getDEFAULT());
        this.selectedUserDeviceItem = i.K(i.n(i.k((g)this.getSelectedMac(), (g)k, (q)new q(null) {
            Object A;
            int y;
            Object z;
            
            public final Object f(final String z, final Map a, final d d) {
                final q q = (q)new q(d) {
                    Object A;
                    int y;
                    Object z;
                };
                q.z = z;
                q.A = a;
                return q.invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(final Object o) {
                b.f();
                if (this.y == 0) {
                    K8.x.b(o);
                    return ((Map)this.A).get((Object)this.z);
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        })), f0.a((e0)this), a2.c(), (Object)null);
    }
    
    public static final /* synthetic */ Context access$getContext$p(final AppWidgetSetupViewModel appWidgetSetupViewModel) {
        return appWidgetSetupViewModel.context;
    }
    
    public static final /* synthetic */ DevicesRepository access$getDevicesRepository$p(final AppWidgetSetupViewModel appWidgetSetupViewModel) {
        return appWidgetSetupViewModel.devicesRepository;
    }
    
    public static final /* synthetic */ x access$get_isLoading$p(final AppWidgetSetupViewModel appWidgetSetupViewModel) {
        return appWidgetSetupViewModel._isLoading;
    }
    
    public static final /* synthetic */ x access$get_selectedMac$p(final AppWidgetSetupViewModel appWidgetSetupViewModel) {
        return appWidgetSetupViewModel._selectedMac;
    }
    
    public static final /* synthetic */ x access$get_widgetParams$p(final AppWidgetSetupViewModel appWidgetSetupViewModel) {
        return appWidgetSetupViewModel._widgetParams;
    }
    
    public final Object actionSave(final d d) {
        while (true) {
            Label_0035: {
                if (!(d instanceof AppWidgetSetupViewModel$a)) {
                    break Label_0035;
                }
                final kotlin.coroutines.jvm.internal.d d2 = (AppWidgetSetupViewModel$a)d;
                final int m = d2.M;
                if ((m & Integer.MIN_VALUE) == 0x0) {
                    break Label_0035;
                }
                d2.M = m + Integer.MIN_VALUE;
                Object o = d2.H;
                final Object f = b.f();
                final int i = d2.M;
                AppWidgetSetupViewModel appWidgetSetupViewModel = null;
                Label_0717: {
                    s s = null;
                    Label_0669: {
                        String string;
                        PendingIntent broadcast;
                        AppWidgetParams a;
                        UserDeviceItem z;
                        if (i != 0) {
                            if (i != 1) {
                                if (i != 2) {
                                    if (i == 3) {
                                        s = (s)d2.z;
                                        appWidgetSetupViewModel = (AppWidgetSetupViewModel)d2.y;
                                        K8.x.b(o);
                                        break Label_0669;
                                    }
                                    if (i != 4) {
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                }
                                appWidgetSetupViewModel = (AppWidgetSetupViewModel)d2.y;
                                K8.x.b(o);
                                break Label_0717;
                            }
                            string = (String)d2.C;
                            broadcast = (PendingIntent)d2.B;
                            a = (AppWidgetParams)d2.A;
                            z = (UserDeviceItem)d2.z;
                            appWidgetSetupViewModel = (AppWidgetSetupViewModel)d2.y;
                            K8.x.b(o);
                        }
                        else {
                            K8.x.b(o);
                            z = (UserDeviceItem)this.selectedUserDeviceItem.getValue();
                            if (z == null) {
                                return K8.M.a;
                            }
                            a = (AppWidgetParams)this._widgetParams.getValue();
                            this._isLoading.setValue((Object)kotlin.coroutines.jvm.internal.b.a(true));
                            final int widgetId = this.widgetId;
                            if (widgetId == 0) {
                                final Bundle bundle = new Bundle();
                                ((BaseBundle)bundle).putString("DEVICE_MAC", z.getUserDevice().getMac());
                                ((BaseBundle)bundle).putString("THEME", ((Enum)a.getTheme()).name());
                                ((BaseBundle)bundle).putBoolean("IS_DYNAMIC", a.isDynamic());
                                bundle.putFloat("ALPHA", a.getAlpha());
                                final Intent intent = new Intent(this.context, (Class)AppWidgetPinnedReceiver.class);
                                intent.putExtras(bundle);
                                broadcast = PendingIntent.getBroadcast(this.context, z.getUserDevice().hashCode() + (int)System.currentTimeMillis(), intent, 67108864);
                                string = UUID.randomUUID().toString();
                                v.i((Object)string, "toString(...)");
                                final Context context = this.context;
                                d2.y = this;
                                d2.z = z;
                                d2.A = a;
                                d2.B = broadcast;
                                d2.C = string;
                                d2.M = 1;
                                o = AppWidgetDataKt.loadAppWidgetImages(context, string, z, (AppWidgetData)null, (d)d2);
                                if (o == f) {
                                    return f;
                                }
                                appWidgetSetupViewModel = this;
                            }
                            else {
                                final s j = new z(this.context).j(widgetId);
                                final Context context2 = this.context;
                                final AppWidgetStateDefinition instance = AppWidgetStateDefinition.INSTANCE;
                                final p p = (p)new p(this, z, a, null) {
                                    final AppWidgetSetupViewModel A;
                                    final UserDeviceItem B;
                                    final AppWidgetParams C;
                                    int y;
                                    Object z;
                                    
                                    public final d create(final Object z, final d d) {
                                        final p p2 = (p)new p(this.A, this.B, this.C, d) {
                                            final AppWidgetSetupViewModel A;
                                            final UserDeviceItem B;
                                            final AppWidgetParams C;
                                            int y;
                                            Object z;
                                        };
                                        p2.z = z;
                                        return (d)p2;
                                    }
                                    
                                    public final Object f(final AppWidgetState appWidgetState, final d d) {
                                        return ((AppWidgetSetupViewModel$b)this.create(appWidgetState, d)).invokeSuspend(K8.M.a);
                                    }
                                    
                                    public final Object invokeSuspend(final Object o) {
                                        final Object f = b.f();
                                        final int y = this.y;
                                        String s;
                                        Object loadAppWidgetImages;
                                        if (y != 0) {
                                            if (y != 1) {
                                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                            }
                                            s = (String)this.z;
                                            K8.x.b(o);
                                            loadAppWidgetImages = o;
                                        }
                                        else {
                                            K8.x.b(o);
                                            final AppWidgetState appWidgetState = (AppWidgetState)this.z;
                                            String z = null;
                                            Label_0104: {
                                                if (((CharSequence)appWidgetState.getWidgetId()).length() != 0) {
                                                    if (!v.e((Object)appWidgetState.getWidgetId(), (Object)DeviceStateExtKt.getEmptyUUID().toString())) {
                                                        z = appWidgetState.getWidgetId();
                                                        break Label_0104;
                                                    }
                                                }
                                                z = UUID.randomUUID().toString();
                                            }
                                            v.g((Object)z);
                                            final Context access$getContext$p = AppWidgetSetupViewModel.access$getContext$p(this.A);
                                            final UserDeviceItem b = this.B;
                                            this.z = z;
                                            this.y = 1;
                                            loadAppWidgetImages = AppWidgetDataKt.loadAppWidgetImages(access$getContext$p, z, b, (AppWidgetData)null, (d)this);
                                            if (loadAppWidgetImages == f) {
                                                return f;
                                            }
                                            s = z;
                                        }
                                        AppWidgetData baseAppWidgetData;
                                        if ((baseAppWidgetData = (AppWidgetData)((u)loadAppWidgetImages).b()) == null) {
                                            baseAppWidgetData = AppWidgetDataKt.baseAppWidgetData(this.B, s);
                                        }
                                        return new AppWidgetState(s, baseAppWidgetData, this.C, false);
                                    }
                                };
                                d2.y = this;
                                d2.z = j;
                                d2.M = 3;
                                s = j;
                                appWidgetSetupViewModel = this;
                                if (r2.a.c(context2, (c)instance, j, (p)p, (d)d2) == f) {
                                    return f;
                                }
                                break Label_0669;
                            }
                        }
                        final AppWidgetData appWidgetData = (AppWidgetData)((u)o).b();
                        final String string2 = UUID.randomUUID().toString();
                        v.i((Object)string2, "toString(...)");
                        AppWidgetData baseAppWidgetData = appWidgetData;
                        if (appWidgetData == null) {
                            baseAppWidgetData = AppWidgetDataKt.baseAppWidgetData(z, string);
                        }
                        final AppWidgetState appWidgetState = new AppWidgetState(string2, baseAppWidgetData, a, false);
                        final z z2 = new z(appWidgetSetupViewModel.context);
                        d2.y = appWidgetSetupViewModel;
                        d2.z = null;
                        d2.A = null;
                        d2.B = null;
                        d2.C = null;
                        d2.M = 2;
                        if (n2.z.o(z2, (Class)DeviceSmallWidgetReceiver.class, (androidx.glance.appwidget.d)null, (Object)appWidgetState, broadcast, (d)d2, 2, (Object)null) == f) {
                            return f;
                        }
                        break Label_0717;
                    }
                    final AppWidget appWidget = new AppWidget();
                    final Context context3 = appWidgetSetupViewModel.context;
                    d2.y = appWidgetSetupViewModel;
                    d2.z = null;
                    d2.M = 4;
                    if (((androidx.glance.appwidget.d)appWidget).update(context3, s, (d)d2) == f) {
                        return f;
                    }
                }
                appWidgetSetupViewModel._isLoading.setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
                return K8.M.a;
            }
            final kotlin.coroutines.jvm.internal.d d2 = new kotlin.coroutines.jvm.internal.d(this, d) {
                Object A;
                Object B;
                Object C;
                Object H;
                final AppWidgetSetupViewModel L;
                int M;
                Object y;
                Object z;
                
                public final Object invokeSuspend(final Object h) {
                    this.H = h;
                    this.M |= Integer.MIN_VALUE;
                    return this.L.actionSave((d)this);
                }
            };
            continue;
        }
    }
    
    public final void actionSelectDevice(final UserDeviceItem userDeviceItem) {
        final x selectedMac = this._selectedMac;
        String mac = null;
        Label_0028: {
            if (userDeviceItem != null) {
                final UserDevice userDevice = userDeviceItem.getUserDevice();
                if (userDevice != null) {
                    mac = userDevice.getMac();
                    break Label_0028;
                }
            }
            mac = null;
        }
        selectedMac.setValue((Object)mac);
    }
    
    public final g getDevices() {
        return this.devices;
    }
    
    public final M getSelectedMac() {
        return (M)this._selectedMac;
    }
    
    public final M getSelectedUserDeviceItem() {
        return this.selectedUserDeviceItem;
    }
    
    public final M getUserDeviceItems() {
        return this.userDeviceItems;
    }
    
    public final M getWidgetParams() {
        return (M)this._widgetParams;
    }
    
    public final void init(final String s, final int widgetId) {
        if (this.isInitialized) {
            return;
        }
        this.isInitialized = true;
        this.widgetId = widgetId;
        i9.i.d(f0.a((e0)this), (P8.g)c0.b(), (i9.O)null, (p)new p(this, widgetId, s, null) {
            final int A;
            final String B;
            int y;
            final AppWidgetSetupViewModel z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.z, this.A, this.B, d) {
                    final int A;
                    final String B;
                    int y;
                    final AppWidgetSetupViewModel z;
                };
            }
            
            public final Object invoke(final i9.M m, final d d) {
                return ((AppWidgetSetupViewModel$c)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(Object a) {
                final Object f = b.f();
                final int y = this.y;
                AppWidgetState default1 = null;
                Label_0176: {
                    Label_0171: {
                        if (y != 0) {
                            if (y != 1) {
                                if (y == 2) {
                                    K8.x.b(a);
                                    break Label_0171;
                                }
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            else {
                                K8.x.b(a);
                            }
                        }
                        else {
                            K8.x.b(a);
                            AppWidgetSetupViewModel.access$get_isLoading$p(this.z).setValue((Object)kotlin.coroutines.jvm.internal.b.a(true));
                            final DevicesRepository access$getDevicesRepository$p = AppWidgetSetupViewModel.access$getDevicesRepository$p(this.z);
                            this.y = 1;
                            if (access$getDevicesRepository$p.refreshDevices(true, (d)this) == f) {
                                return f;
                            }
                        }
                        default1 = AppWidgetState.Companion.getDEFAULT();
                        if (this.A == 0) {
                            break Label_0176;
                        }
                        final s j = new z(AppWidgetSetupViewModel.access$getContext$p(this.z)).j(this.A);
                        final Context access$getContext$p = AppWidgetSetupViewModel.access$getContext$p(this.z);
                        final AppWidgetStateDefinition instance = AppWidgetStateDefinition.INSTANCE;
                        this.y = 2;
                        if ((a = a.a(access$getContext$p, (c)instance, j, (d)this)) == f) {
                            return f;
                        }
                    }
                    default1 = (AppWidgetState)a;
                }
                if (default1.isValid()) {
                    final x access$get_selectedMac$p = AppWidgetSetupViewModel.access$get_selectedMac$p(this.z);
                    String mac;
                    if (((CharSequence)(mac = default1.getDevice().getMac())).length() == 0) {
                        mac = null;
                    }
                    access$get_selectedMac$p.setValue((Object)mac);
                    AppWidgetSetupViewModel.access$get_widgetParams$p(this.z).setValue((Object)default1.getParams());
                }
                else {
                    AppWidgetSetupViewModel.access$get_selectedMac$p(this.z).setValue((Object)this.B);
                    AppWidgetSetupViewModel.access$get_widgetParams$p(this.z).setValue((Object)AppWidgetParams.Companion.getDEFAULT());
                }
                AppWidgetSetupViewModel.access$get_isLoading$p(this.z).setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
                return K8.M.a;
            }
        }, 2, (Object)null);
    }
    
    public final M isLoading() {
        return (M)this._isLoading;
    }
    
    public final void updateIsDynamic(final boolean b) {
        final x widgetParams = this._widgetParams;
        widgetParams.setValue((Object)AppWidgetParams.copy$default((AppWidgetParams)widgetParams.getValue(), (AppThemeMode)null, b, 0.0f, 5, (Object)null));
    }
    
    public final void updateWidgetAlpha(final float n) {
        final x widgetParams = this._widgetParams;
        widgetParams.setValue((Object)AppWidgetParams.copy$default((AppWidgetParams)widgetParams.getValue(), (AppThemeMode)null, false, NumberExtKt.round(n, 1), 3, (Object)null));
    }
    
    public final void updateWidgetTheme(final AppThemeMode appThemeMode) {
        v.j((Object)appThemeMode, "newValue");
        final x widgetParams = this._widgetParams;
        widgetParams.setValue((Object)AppWidgetParams.copy$default((AppWidgetParams)widgetParams.getValue(), appThemeMode, false, 0.0f, 6, (Object)null));
    }
}
