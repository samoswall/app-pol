package com.polaris.iot.application.appwidget;

import android.content.Context;
import com.syncleoiot.core.domain.devices.DevicesRepository;
import com.syncleoiot.core.data.db.AppDatabase;
import I8.a;
import A8.b;

public final class AppWidgetSetupViewModel_Factory implements b
{
    private final a appDatabaseProvider;
    private final a contextProvider;
    private final a devicesRepositoryProvider;
    
    public AppWidgetSetupViewModel_Factory(final a appDatabaseProvider, final a devicesRepositoryProvider, final a contextProvider) {
        this.appDatabaseProvider = appDatabaseProvider;
        this.devicesRepositoryProvider = devicesRepositoryProvider;
        this.contextProvider = contextProvider;
    }
    
    public static AppWidgetSetupViewModel_Factory create(final a a, final a a2, final a a3) {
        return new AppWidgetSetupViewModel_Factory(a, a2, a3);
    }
    
    public static AppWidgetSetupViewModel newInstance(final AppDatabase appDatabase, final DevicesRepository devicesRepository, final Context context) {
        return new AppWidgetSetupViewModel(appDatabase, devicesRepository, context);
    }
    
    public AppWidgetSetupViewModel get() {
        return newInstance((AppDatabase)this.appDatabaseProvider.get(), (DevicesRepository)this.devicesRepositoryProvider.get(), (Context)this.contextProvider.get());
    }
}
