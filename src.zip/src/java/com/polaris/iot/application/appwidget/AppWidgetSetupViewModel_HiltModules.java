package com.polaris.iot.application.appwidget;

import androidx.lifecycle.e0;

public final class AppWidgetSetupViewModel_HiltModules
{
    private AppWidgetSetupViewModel_HiltModules() {
    }
    
    public abstract static class BindsModule
    {
        private BindsModule() {
        }
        
        public abstract e0 binds(final AppWidgetSetupViewModel p0);
    }
    
    public static final class KeyModule
    {
        private KeyModule() {
        }
        
        public static boolean provide() {
            return true;
        }
    }
}
