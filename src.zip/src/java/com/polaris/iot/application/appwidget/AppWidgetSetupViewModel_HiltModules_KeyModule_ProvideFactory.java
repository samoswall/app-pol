package com.polaris.iot.application.appwidget;

import A8.b;

public final class AppWidgetSetupViewModel_HiltModules_KeyModule_ProvideFactory implements b
{
    public static AppWidgetSetupViewModel_HiltModules_KeyModule_ProvideFactory create() {
        return a.a;
    }
    
    public static boolean provide() {
        return AppWidgetSetupViewModel_HiltModules.KeyModule.provide();
    }
    
    public Boolean get() {
        return provide();
    }
    
    private abstract static final class a
    {
        private static final AppWidgetSetupViewModel_HiltModules_KeyModule_ProvideFactory a;
        
        static {
            a = new AppWidgetSetupViewModel_HiltModules_KeyModule_ProvideFactory();
        }
    }
}
