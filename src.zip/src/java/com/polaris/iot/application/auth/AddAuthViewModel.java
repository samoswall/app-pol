package com.polaris.iot.application.auth;

import com.syncleoiot.core.domain.auth.ExtKt;
import g9.o;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.tasks.Task;
import com.syncleoiot.core.domain.auth.entities.Initiation;
import K8.s;
import com.syncleoiot.core.domain.core.objects.Either$Right;
import com.syncleoiot.core.domain.auth.AuthFailure$TooManyRequests;
import com.syncleoiot.core.domain.auth.AuthFailure$AlreadyAuthorized;
import com.syncleoiot.core.domain.auth.AuthFailure;
import com.syncleoiot.core.domain.core.objects.Either$Left;
import com.syncleoiot.core.domain.core.objects.Either;
import android.content.Context;
import android.widget.Toast;
import com.syncleoiot.core.domain.core.failures.IFailable;
import com.syncleoiot.core.domain.core.failures.FailuresKt;
import java.util.concurrent.CancellationException;
import i9.z0$a;
import P8.g;
import i9.i;
import i9.X;
import d9.n;
import Q8.b;
import i9.M;
import P8.d;
import kotlin.coroutines.jvm.internal.l;
import X8.p;
import i9.c0;
import androidx.lifecycle.f0;
import L8.t;
import com.syncleoiot.core.domain.auth.PhoneNumber;
import l9.O;
import com.syncleoiot.core.domain.auth.EmailAddress;
import kotlin.jvm.internal.v;
import kotlin.jvm.internal.m;
import i9.z0;
import com.syncleoiot.core.application.auth.usecases.ResponseAddAuthUseCase;
import android.app.Application;
import com.syncleoiot.core.domain.auth.IdentityType;
import java.util.List;
import com.syncleoiot.core.application.auth.usecases.AddSignInWithYandexUseCase;
import com.syncleoiot.core.application.auth.usecases.AddSignInWithGoogleUseCase;
import com.syncleoiot.core.application.auth.usecases.AddAuthWithPhoneUseCase;
import com.syncleoiot.core.application.auth.usecases.AddAuthWithEmailUseCase;
import l9.x;
import androidx.lifecycle.e0;

public final class AddAuthViewModel extends e0
{
    public static final int $stable;
    public static final Companion Companion;
    private static final String TAG;
    private final x _authMethod;
    private final x _emailLogin;
    private final x _initiation;
    private final x _isSubmitting;
    private final x _phoneLogin;
    private final x _resendTimeMillis;
    private final x _response;
    private final x _responseResult;
    private final AddAuthWithEmailUseCase addAuthWithEmailUseCase;
    private final AddAuthWithPhoneUseCase addAuthWithPhoneUseCase;
    private final AddSignInWithGoogleUseCase addSignInWithGoogleUseCase;
    private final AddSignInWithYandexUseCase addSignInWithYandexUseCase;
    private List<? extends IdentityType> authMethods;
    private final Application context;
    private boolean hasGoogle;
    private final ResponseAddAuthUseCase responseAddAuthUseCase;
    private z0 timerJob;
    
    static {
        String simpleName = null;
        final Companion companion = Companion = new Companion(null);
        $stable = 8;
        final Class<?> enclosingClass = companion.getClass().getEnclosingClass();
        if (enclosingClass != null) {
            simpleName = enclosingClass.getSimpleName();
        }
        String tag;
        if ((tag = simpleName) == null) {
            tag = "TAG";
        }
        TAG = tag;
    }
    
    public AddAuthViewModel(final Application context, final AddAuthWithEmailUseCase addAuthWithEmailUseCase, final AddAuthWithPhoneUseCase addAuthWithPhoneUseCase, final ResponseAddAuthUseCase responseAddAuthUseCase, final AddSignInWithGoogleUseCase addSignInWithGoogleUseCase, final AddSignInWithYandexUseCase addSignInWithYandexUseCase) {
        v.j((Object)context, "context");
        v.j((Object)addAuthWithEmailUseCase, "addAuthWithEmailUseCase");
        v.j((Object)addAuthWithPhoneUseCase, "addAuthWithPhoneUseCase");
        v.j((Object)responseAddAuthUseCase, "responseAddAuthUseCase");
        v.j((Object)addSignInWithGoogleUseCase, "addSignInWithGoogleUseCase");
        v.j((Object)addSignInWithYandexUseCase, "addSignInWithYandexUseCase");
        this.context = context;
        this.addAuthWithEmailUseCase = addAuthWithEmailUseCase;
        this.addAuthWithPhoneUseCase = addAuthWithPhoneUseCase;
        this.responseAddAuthUseCase = responseAddAuthUseCase;
        this.addSignInWithGoogleUseCase = addSignInWithGoogleUseCase;
        this.addSignInWithYandexUseCase = addSignInWithYandexUseCase;
        this._emailLogin = O.a((Object)new EmailAddress(""));
        this._phoneLogin = O.a((Object)new PhoneNumber(""));
        this._response = O.a((Object)"");
        this._authMethod = O.a((Object)null);
        this._isSubmitting = O.a((Object)Boolean.FALSE);
        this._initiation = O.a((Object)null);
        this._responseResult = O.a((Object)null);
        this._resendTimeMillis = O.a((Object)0L);
        this.authMethods = (List<? extends IdentityType>)t.n();
    }
    
    public static final /* synthetic */ AddAuthWithEmailUseCase access$getAddAuthWithEmailUseCase$p(final AddAuthViewModel addAuthViewModel) {
        return addAuthViewModel.addAuthWithEmailUseCase;
    }
    
    public static final /* synthetic */ AddAuthWithPhoneUseCase access$getAddAuthWithPhoneUseCase$p(final AddAuthViewModel addAuthViewModel) {
        return addAuthViewModel.addAuthWithPhoneUseCase;
    }
    
    public static final /* synthetic */ AddSignInWithGoogleUseCase access$getAddSignInWithGoogleUseCase$p(final AddAuthViewModel addAuthViewModel) {
        return addAuthViewModel.addSignInWithGoogleUseCase;
    }
    
    public static final /* synthetic */ AddSignInWithYandexUseCase access$getAddSignInWithYandexUseCase$p(final AddAuthViewModel addAuthViewModel) {
        return addAuthViewModel.addSignInWithYandexUseCase;
    }
    
    public static final /* synthetic */ ResponseAddAuthUseCase access$getResponseAddAuthUseCase$p(final AddAuthViewModel addAuthViewModel) {
        return addAuthViewModel.responseAddAuthUseCase;
    }
    
    public static final /* synthetic */ x access$get_authMethod$p(final AddAuthViewModel addAuthViewModel) {
        return addAuthViewModel._authMethod;
    }
    
    public static final /* synthetic */ x access$get_emailLogin$p(final AddAuthViewModel addAuthViewModel) {
        return addAuthViewModel._emailLogin;
    }
    
    public static final /* synthetic */ x access$get_initiation$p(final AddAuthViewModel addAuthViewModel) {
        return addAuthViewModel._initiation;
    }
    
    public static final /* synthetic */ x access$get_isSubmitting$p(final AddAuthViewModel addAuthViewModel) {
        return addAuthViewModel._isSubmitting;
    }
    
    public static final /* synthetic */ x access$get_phoneLogin$p(final AddAuthViewModel addAuthViewModel) {
        return addAuthViewModel._phoneLogin;
    }
    
    public static final /* synthetic */ x access$get_resendTimeMillis$p(final AddAuthViewModel addAuthViewModel) {
        return addAuthViewModel._resendTimeMillis;
    }
    
    public static final /* synthetic */ x access$get_response$p(final AddAuthViewModel addAuthViewModel) {
        return addAuthViewModel._response;
    }
    
    public static final /* synthetic */ x access$get_responseResult$p(final AddAuthViewModel addAuthViewModel) {
        return addAuthViewModel._responseResult;
    }
    
    static /* synthetic */ z0 b(final AddAuthViewModel addAuthViewModel, final long n, long n2, final int n3, final Object o) {
        if ((n3 & 0x2) != 0x0) {
            n2 = 500L;
        }
        return addAuthViewModel.launchTimeJob(n, n2);
    }
    
    private final z0 launchTimeJob(final long n, final long n2) {
        return i.d(f0.a((e0)this), (g)c0.a(), (i9.O)null, (p)new p(n, this, n2, null) {
            final AddAuthViewModel A;
            final long B;
            int y;
            final long z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.z, this.A, this.B, d) {
                    final AddAuthViewModel A;
                    final long B;
                    int y;
                    final long z;
                };
            }
            
            public final Object invoke(final M m, final d d) {
                return ((AddAuthViewModel$b)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(final Object o) {
                final Object f = b.f();
                final int y = this.y;
                while (true) {
                    Label_0101: {
                        long n;
                        if (y != 0) {
                            if (y == 1) {
                                K8.x.b(o);
                                break Label_0101;
                            }
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        else {
                            K8.x.b(o);
                            n = System.currentTimeMillis();
                        }
                        if (n >= this.z) {
                            AddAuthViewModel.access$get_resendTimeMillis$p(this.A).setValue((Object)kotlin.coroutines.jvm.internal.b.f(0L));
                            return K8.M.a;
                        }
                        AddAuthViewModel.access$get_resendTimeMillis$p(this.A).setValue((Object)kotlin.coroutines.jvm.internal.b.f(d9.n.g(this.z - n, 0L)));
                        final long b = this.B;
                        this.y = 1;
                        if (X.b(b, (d)this) == f) {
                            return f;
                        }
                    }
                    long n = System.currentTimeMillis();
                    continue;
                }
            }
        }, 2, (Object)null);
    }
    
    private final void resetState() {
        this.resetUI();
        this._authMethod.setValue((Object)null);
        this._phoneLogin.setValue((Object)new PhoneNumber(""));
        this._emailLogin.setValue((Object)new EmailAddress(""));
    }
    
    private final void resetUI() {
        this._response.setValue((Object)"");
        this._initiation.setValue((Object)null);
        this._responseResult.setValue((Object)null);
    }
    
    private final void startTimer(final long n) {
        this.stopTimer();
        this.timerJob = b(this, n, 0L, 2, null);
    }
    
    private final void stopTimer() {
        final z0 timerJob = this.timerJob;
        if (timerJob != null) {
            z0$a.b(timerJob, (CancellationException)null, 1, (Object)null);
        }
        this.timerJob = null;
    }
    
    public final l9.M getAuthMethod() {
        return l9.i.b(this._authMethod);
    }
    
    public final Application getContext() {
        return this.context;
    }
    
    public final l9.M getEmailLogin() {
        return l9.i.b(this._emailLogin);
    }
    
    public final l9.M getInitiation() {
        return l9.i.b(this._initiation);
    }
    
    public final l9.M getPhoneLogin() {
        return l9.i.b(this._phoneLogin);
    }
    
    public final l9.M getResendTimeMillis() {
        return l9.i.b(this._resendTimeMillis);
    }
    
    public final l9.M getResponse() {
        return l9.i.b(this._response);
    }
    
    public final l9.M getResponseResult() {
        return l9.i.b(this._responseResult);
    }
    
    public final void init(final List<? extends IdentityType> authMethods, final boolean hasGoogle) {
        v.j((Object)authMethods, "authMethods");
        this.authMethods = authMethods;
        this.hasGoogle = hasGoogle;
        this.resetState();
    }
    
    public final void initAuth() {
        i.d(f0.a((e0)this), (g)null, (i9.O)null, (p)new p(this, null) {
            int y;
            final AddAuthViewModel z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.z, d) {
                    int y;
                    final AddAuthViewModel z;
                };
            }
            
            public final Object invoke(final M m, final d d) {
                return ((AddAuthViewModel$a)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(Object o) {
                final Object f = b.f();
                final int y = this.y;
                Either value = null;
                Label_0304: {
                    Label_0299: {
                        if (y != 0) {
                            if (y != 1) {
                                if (y == 2) {
                                    K8.x.b(o);
                                    break Label_0299;
                                }
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            else {
                                K8.x.b(o);
                            }
                        }
                        else {
                            K8.x.b(o);
                            AddAuthViewModel.access$get_response$p(this.z).setValue((Object)"");
                            if (AddAuthViewModel.access$get_authMethod$p(this.z).getValue() == IdentityType.PHONE) {
                                final PhoneNumber phoneNumber = (PhoneNumber)AddAuthViewModel.access$get_phoneLogin$p(this.z).getValue();
                                if (!FailuresKt.isValid((IFailable)phoneNumber)) {
                                    Toast.makeText((Context)this.z.getContext(), 2131886920, 1).show();
                                    return K8.M.a;
                                }
                                AddAuthViewModel.access$get_isSubmitting$p(this.z).setValue((Object)kotlin.coroutines.jvm.internal.b.a(true));
                                final x access$get_phoneLogin$p = AddAuthViewModel.access$get_phoneLogin$p(this.z);
                                final String formattedValueOrCrash = phoneNumber.getFormattedValueOrCrash();
                                v.g((Object)formattedValueOrCrash);
                                access$get_phoneLogin$p.setValue((Object)new PhoneNumber(formattedValueOrCrash));
                                final AddAuthWithPhoneUseCase access$getAddAuthWithPhoneUseCase$p = AddAuthViewModel.access$getAddAuthWithPhoneUseCase$p(this.z);
                                this.y = 1;
                                if ((o = access$getAddAuthWithPhoneUseCase$p.invoke(phoneNumber, (d)this)) == f) {
                                    return f;
                                }
                            }
                            else {
                                final EmailAddress emailAddress = (EmailAddress)AddAuthViewModel.access$get_emailLogin$p(this.z).getValue();
                                if (!FailuresKt.isValid((IFailable)emailAddress)) {
                                    Toast.makeText((Context)this.z.getContext(), 2131886454, 1).show();
                                    return K8.M.a;
                                }
                                AddAuthViewModel.access$get_isSubmitting$p(this.z).setValue((Object)kotlin.coroutines.jvm.internal.b.a(true));
                                final AddAuthWithEmailUseCase access$getAddAuthWithEmailUseCase$p = AddAuthViewModel.access$getAddAuthWithEmailUseCase$p(this.z);
                                this.y = 2;
                                if ((o = access$getAddAuthWithEmailUseCase$p.invoke(emailAddress, (d)this)) == f) {
                                    return f;
                                }
                                break Label_0299;
                            }
                        }
                        value = (Either)o;
                        break Label_0304;
                    }
                    value = (Either)o;
                }
                AddAuthViewModel.access$get_isSubmitting$p(this.z).setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
                AddAuthViewModel.access$get_initiation$p(this.z).setValue((Object)value);
                final AddAuthViewModel z = this.z;
                if (value instanceof Either$Left) {
                    final AuthFailure authFailure = (AuthFailure)((Either$Left)value).getValue();
                    if (!v.e((Object)authFailure, (Object)AuthFailure$AlreadyAuthorized.INSTANCE) && authFailure instanceof AuthFailure$TooManyRequests) {
                        final long retryAfterTimestamp = ((AuthFailure$TooManyRequests)authFailure).getRetryAfterTimestamp();
                        if (retryAfterTimestamp > 0L) {
                            z.startTimer(retryAfterTimestamp);
                        }
                    }
                }
                else {
                    if (!(value instanceof Either$Right)) {
                        throw new s();
                    }
                    final Initiation initiation = (Initiation)((Either$Right)value).getValue();
                    z.startTimer(System.currentTimeMillis() + 60000);
                }
                return K8.M.a;
            }
        }, 3, (Object)null);
    }
    
    public final l9.M isSubmitting() {
        return l9.i.b(this._isSubmitting);
    }
    
    public final void responseAuth() {
        final Either either = (Either)this._initiation.getValue();
        if (either != null) {
            Initiation initiation;
            if (either instanceof Either$Left) {
                final AuthFailure authFailure = (AuthFailure)((Either$Left)either).getValue();
                initiation = null;
            }
            else {
                if (!(either instanceof Either$Right)) {
                    throw new s();
                }
                initiation = (Initiation)((Either$Right)either).getValue();
            }
            if (initiation != null) {
                final String s = (String)this._response.getValue();
                if (((CharSequence)s).length() == 0) {
                    return;
                }
                i.d(f0.a((e0)this), (g)null, (i9.O)null, (p)new p(this, initiation, s, null) {
                    final Initiation A;
                    final String B;
                    int y;
                    final AddAuthViewModel z;
                    
                    public final d create(final Object o, final d d) {
                        return (d)new p(this.z, this.A, this.B, d) {
                            final Initiation A;
                            final String B;
                            int y;
                            final AddAuthViewModel z;
                        };
                    }
                    
                    public final Object invoke(final M m, final d d) {
                        return ((AddAuthViewModel$c)this.create(m, d)).invokeSuspend(K8.M.a);
                    }
                    
                    public final Object invokeSuspend(Object invoke) {
                        final Object f = b.f();
                        final int y = this.y;
                        if (y != 0) {
                            if (y != 1) {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            K8.x.b(invoke);
                        }
                        else {
                            K8.x.b(invoke);
                            AddAuthViewModel.access$get_isSubmitting$p(this.z).setValue((Object)kotlin.coroutines.jvm.internal.b.a(true));
                            final ResponseAddAuthUseCase access$getResponseAddAuthUseCase$p = AddAuthViewModel.access$getResponseAddAuthUseCase$p(this.z);
                            final Initiation a = this.A;
                            final String b = this.B;
                            this.y = 1;
                            if ((invoke = access$getResponseAddAuthUseCase$p.invoke(a, b, (d)this)) == f) {
                                return f;
                            }
                        }
                        final Either value = (Either)invoke;
                        AddAuthViewModel.access$get_responseResult$p(this.z).setValue((Object)value);
                        final AddAuthViewModel z = this.z;
                        if (value instanceof Either$Left) {
                            final AuthFailure authFailure = (AuthFailure)((Either$Left)value).getValue();
                            Toast.makeText((Context)z.getContext(), 2131886167, 1).show();
                            AddAuthViewModel.access$get_isSubmitting$p(z).setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
                        }
                        else {
                            if (!(value instanceof Either$Right)) {
                                throw new s();
                            }
                            final K8.M m = (K8.M)((Either$Right)value).getValue();
                            z.resetState();
                            AddAuthViewModel.access$get_isSubmitting$p(z).setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
                        }
                        return K8.M.a;
                    }
                }, 3, (Object)null);
            }
        }
    }
    
    public final void selectAuthMethod(final IdentityType identityType) {
        i.d(f0.a((e0)this), (g)null, (i9.O)null, (p)new p(this, identityType, null) {
            final IdentityType A;
            int y;
            final AddAuthViewModel z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.z, this.A, d) {
                    final IdentityType A;
                    int y;
                    final AddAuthViewModel z;
                };
            }
            
            public final Object invoke(final M m, final d d) {
                return ((AddAuthViewModel$d)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(final Object o) {
                b.f();
                if (this.y == 0) {
                    K8.x.b(o);
                    this.z.resetUI();
                    AddAuthViewModel.access$get_authMethod$p(this.z).setValue((Object)this.A);
                    return K8.M.a;
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }, 3, (Object)null);
    }
    
    public final void signInWithGoogle(final Task<GoogleSignInAccount> task) {
        v.j((Object)task, "googleAuthResponse");
        i.d(f0.a((e0)this), (g)null, (i9.O)null, (p)new p(this, task, null) {
            final Task A;
            int y;
            final AddAuthViewModel z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.z, this.A, d) {
                    final Task A;
                    int y;
                    final AddAuthViewModel z;
                };
            }
            
            public final Object invoke(final M m, final d d) {
                return ((AddAuthViewModel$e)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(Object invoke) {
                final Object f = b.f();
                final int y = this.y;
                if (y != 0) {
                    if (y != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    K8.x.b(invoke);
                }
                else {
                    K8.x.b(invoke);
                    this.z.resetUI();
                    AddAuthViewModel.access$get_isSubmitting$p(this.z).setValue((Object)kotlin.coroutines.jvm.internal.b.a(true));
                    final AddSignInWithGoogleUseCase access$getAddSignInWithGoogleUseCase$p = AddAuthViewModel.access$getAddSignInWithGoogleUseCase$p(this.z);
                    final Task a = this.A;
                    this.y = 1;
                    if ((invoke = access$getAddSignInWithGoogleUseCase$p.invoke(a, (d)this)) == f) {
                        return f;
                    }
                }
                final Either either = (Either)invoke;
                final AddAuthViewModel z = this.z;
                if (either instanceof Either$Left) {
                    final AuthFailure authFailure = (AuthFailure)((Either$Left)either).getValue();
                    if (!v.e((Object)authFailure, (Object)AuthFailure$AlreadyAuthorized.INSTANCE)) {
                        Toast.makeText((Context)z.getContext(), 2131887087, 1).show();
                    }
                    AddAuthViewModel.access$get_isSubmitting$p(z).setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
                    AddAuthViewModel.access$get_responseResult$p(z).setValue((Object)new Either$Left((Object)authFailure));
                }
                else {
                    if (!(either instanceof Either$Right)) {
                        throw new s();
                    }
                    final K8.M m = (K8.M)((Either$Right)either).getValue();
                    z.resetState();
                    AddAuthViewModel.access$get_isSubmitting$p(z).setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
                    AddAuthViewModel.access$get_responseResult$p(z).setValue((Object)new Either$Right((Object)K8.M.a));
                }
                return K8.M.a;
            }
        }, 3, (Object)null);
    }
    
    public final void signInWithYandex(final l8.d d) {
        v.j((Object)d, "yandexAuthResult");
        i.d(f0.a((e0)this), (g)c0.b(), (i9.O)null, (p)new p(this, d, null) {
            final l8.d A;
            int y;
            final AddAuthViewModel z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.z, this.A, d) {
                    final l8.d A;
                    int y;
                    final AddAuthViewModel z;
                };
            }
            
            public final Object invoke(final M m, final d d) {
                return ((AddAuthViewModel$f)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(Object o) {
                final Object f = b.f();
                final int y = this.y;
                if (y != 0) {
                    if (y != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    K8.x.b(o);
                }
                else {
                    K8.x.b(o);
                    this.z.resetUI();
                    AddAuthViewModel.access$get_isSubmitting$p(this.z).setValue((Object)kotlin.coroutines.jvm.internal.b.a(true));
                    final AddSignInWithYandexUseCase access$getAddSignInWithYandexUseCase$p = AddAuthViewModel.access$getAddSignInWithYandexUseCase$p(this.z);
                    final l8.d a = this.A;
                    this.y = 1;
                    if ((o = access$getAddSignInWithYandexUseCase$p.invoke(a, (d)this)) == f) {
                        return f;
                    }
                }
                final Either either = (Either)o;
                o = this.z;
                if (either instanceof Either$Left) {
                    final AuthFailure authFailure = (AuthFailure)((Either$Left)either).getValue();
                    if (!v.e((Object)authFailure, (Object)AuthFailure$AlreadyAuthorized.INSTANCE)) {
                        try {
                            i.d(f0.a((e0)o), (g)c0.c(), (i9.O)null, (p)new p(o, null) {
                                int y;
                                final AddAuthViewModel z;
                                
                                public final d create(final Object o, final d d) {
                                    return (d)new p(this.z, d) {
                                        int y;
                                        final AddAuthViewModel z;
                                    };
                                }
                                
                                public final Object invoke(final M m, final d d) {
                                    return ((AddAuthViewModel$f$a)this.create(m, d)).invokeSuspend(K8.M.a);
                                }
                                
                                public final Object invokeSuspend(final Object o) {
                                    b.f();
                                    if (this.y == 0) {
                                        K8.x.b(o);
                                        Toast.makeText((Context)this.z.getContext(), 2131887087, 1).show();
                                        return K8.M.a;
                                    }
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                            }, 2, (Object)null);
                        }
                        catch (final Exception ex) {
                            ((Throwable)ex).printStackTrace();
                        }
                    }
                    AddAuthViewModel.access$get_isSubmitting$p((AddAuthViewModel)o).setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
                    AddAuthViewModel.access$get_responseResult$p((AddAuthViewModel)o).setValue((Object)new Either$Left((Object)authFailure));
                }
                else {
                    if (!(either instanceof Either$Right)) {
                        throw new s();
                    }
                    final K8.M m = (K8.M)((Either$Right)either).getValue();
                    ((AddAuthViewModel)o).resetState();
                    AddAuthViewModel.access$get_isSubmitting$p((AddAuthViewModel)o).setValue((Object)kotlin.coroutines.jvm.internal.b.a(false));
                    AddAuthViewModel.access$get_responseResult$p((AddAuthViewModel)o).setValue((Object)new Either$Right((Object)K8.M.a));
                }
                return K8.M.a;
            }
        }, 2, (Object)null);
    }
    
    public final void updateEmailLogin(final String s) {
        v.j((Object)s, "str");
        this.resetUI();
        this._emailLogin.setValue((Object)new EmailAddress(o.j1((CharSequence)s).toString()));
    }
    
    public final void updatePhoneLogin(String correctPhoneNumber) {
        v.j((Object)correctPhoneNumber, "str");
        this.resetUI();
        if ((correctPhoneNumber = ExtKt.correctPhoneNumber((Context)this.context, correctPhoneNumber)) == null) {
            correctPhoneNumber = "";
        }
        this._phoneLogin.setValue((Object)new PhoneNumber(correctPhoneNumber));
    }
    
    public final void updateResponseStr(final String value) {
        v.j((Object)value, "str");
        this._responseResult.setValue((Object)null);
        this._response.setValue((Object)value);
    }
    
    public static final class Companion
    {
        private Companion() {
        }
    }
}
