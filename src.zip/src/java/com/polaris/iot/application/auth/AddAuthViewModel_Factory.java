package com.polaris.iot.application.auth;

import com.syncleoiot.core.application.auth.usecases.AddSignInWithYandexUseCase;
import com.syncleoiot.core.application.auth.usecases.AddSignInWithGoogleUseCase;
import com.syncleoiot.core.application.auth.usecases.ResponseAddAuthUseCase;
import com.syncleoiot.core.application.auth.usecases.AddAuthWithPhoneUseCase;
import com.syncleoiot.core.application.auth.usecases.AddAuthWithEmailUseCase;
import android.app.Application;
import I8.a;
import A8.b;

public final class AddAuthViewModel_Factory implements b
{
    private final a addAuthWithEmailUseCaseProvider;
    private final a addAuthWithPhoneUseCaseProvider;
    private final a addSignInWithGoogleUseCaseProvider;
    private final a addSignInWithYandexUseCaseProvider;
    private final a contextProvider;
    private final a responseAddAuthUseCaseProvider;
    
    public AddAuthViewModel_Factory(final a contextProvider, final a addAuthWithEmailUseCaseProvider, final a addAuthWithPhoneUseCaseProvider, final a responseAddAuthUseCaseProvider, final a addSignInWithGoogleUseCaseProvider, final a addSignInWithYandexUseCaseProvider) {
        this.contextProvider = contextProvider;
        this.addAuthWithEmailUseCaseProvider = addAuthWithEmailUseCaseProvider;
        this.addAuthWithPhoneUseCaseProvider = addAuthWithPhoneUseCaseProvider;
        this.responseAddAuthUseCaseProvider = responseAddAuthUseCaseProvider;
        this.addSignInWithGoogleUseCaseProvider = addSignInWithGoogleUseCaseProvider;
        this.addSignInWithYandexUseCaseProvider = addSignInWithYandexUseCaseProvider;
    }
    
    public static AddAuthViewModel_Factory create(final a a, final a a2, final a a3, final a a4, final a a5, final a a6) {
        return new AddAuthViewModel_Factory(a, a2, a3, a4, a5, a6);
    }
    
    public static AddAuthViewModel newInstance(final Application application, final AddAuthWithEmailUseCase addAuthWithEmailUseCase, final AddAuthWithPhoneUseCase addAuthWithPhoneUseCase, final ResponseAddAuthUseCase responseAddAuthUseCase, final AddSignInWithGoogleUseCase addSignInWithGoogleUseCase, final AddSignInWithYandexUseCase addSignInWithYandexUseCase) {
        return new AddAuthViewModel(application, addAuthWithEmailUseCase, addAuthWithPhoneUseCase, responseAddAuthUseCase, addSignInWithGoogleUseCase, addSignInWithYandexUseCase);
    }
    
    public AddAuthViewModel get() {
        return newInstance((Application)this.contextProvider.get(), (AddAuthWithEmailUseCase)this.addAuthWithEmailUseCaseProvider.get(), (AddAuthWithPhoneUseCase)this.addAuthWithPhoneUseCaseProvider.get(), (ResponseAddAuthUseCase)this.responseAddAuthUseCaseProvider.get(), (AddSignInWithGoogleUseCase)this.addSignInWithGoogleUseCaseProvider.get(), (AddSignInWithYandexUseCase)this.addSignInWithYandexUseCaseProvider.get());
    }
}
