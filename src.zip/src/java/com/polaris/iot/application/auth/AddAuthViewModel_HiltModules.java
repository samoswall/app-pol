package com.polaris.iot.application.auth;

import androidx.lifecycle.e0;

public final class AddAuthViewModel_HiltModules
{
    private AddAuthViewModel_HiltModules() {
    }
    
    public abstract static class BindsModule
    {
        private BindsModule() {
        }
        
        public abstract e0 binds(final AddAuthViewModel p0);
    }
    
    public static final class KeyModule
    {
        private KeyModule() {
        }
        
        public static boolean provide() {
            return true;
        }
    }
}
