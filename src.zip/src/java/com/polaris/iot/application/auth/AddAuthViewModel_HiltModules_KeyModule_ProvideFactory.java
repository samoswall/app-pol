package com.polaris.iot.application.auth;

import A8.b;

public final class AddAuthViewModel_HiltModules_KeyModule_ProvideFactory implements b
{
    public static AddAuthViewModel_HiltModules_KeyModule_ProvideFactory create() {
        return a.a;
    }
    
    public static boolean provide() {
        return AddAuthViewModel_HiltModules.KeyModule.provide();
    }
    
    public Boolean get() {
        return provide();
    }
    
    private abstract static final class a
    {
        private static final AddAuthViewModel_HiltModules_KeyModule_ProvideFactory a;
        
        static {
            a = new AddAuthViewModel_HiltModules_KeyModule_ProvideFactory();
        }
    }
}
