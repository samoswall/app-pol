package com.polaris.iot.application.debug.devicelogs;

import v0.G1;
import android.widget.Toast;
import android.content.ClipData;
import android.content.ClipboardManager;
import com.syncleoiot.core.utils.debug.DeviceLog;
import v0.u1;
import v0.v1;
import kotlin.jvm.internal.v;
import kotlin.jvm.internal.m;
import com.syncleoiot.core.api.commands.LogLevel;
import v0.t0;
import android.content.Context;
import androidx.lifecycle.e0;

public final class DebugDeviceLogsViewModel extends e0
{
    public static final int $stable;
    public static final Companion Companion;
    private static final String TAG;
    private final Context appContext;
    private Byte channels;
    private final t0 isConnectionLogsEnabled$delegate;
    private final t0 isInternalLogsEnabled$delegate;
    private LogLevel level;
    private Byte types;
    
    static {
        String simpleName = null;
        final Companion companion = Companion = new Companion(null);
        $stable = 8;
        final Class<?> enclosingClass = companion.getClass().getEnclosingClass();
        if (enclosingClass != null) {
            simpleName = enclosingClass.getSimpleName();
        }
        String tag;
        if ((tag = simpleName) == null) {
            tag = "TAG";
        }
        TAG = tag;
    }
    
    public DebugDeviceLogsViewModel(final Context appContext) {
        v.j((Object)appContext, "appContext");
        this.appContext = appContext;
        final Boolean false = Boolean.FALSE;
        this.isInternalLogsEnabled$delegate = v1.i((Object)false, (u1)null, 2, (Object)null);
        this.isConnectionLogsEnabled$delegate = v1.i((Object)false, (u1)null, 2, (Object)null);
        this.level = LogLevel.None;
    }
    
    public final Byte getChannels() {
        return this.channels;
    }
    
    public final LogLevel getLevel() {
        return this.level;
    }
    
    public final Byte getTypes() {
        return this.types;
    }
    
    public final void handleCopyLog(final DeviceLog deviceLog) {
        v.j((Object)deviceLog, "log");
        final Object systemService = this.appContext.getSystemService("clipboard");
        v.h(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
        ((ClipboardManager)systemService).setPrimaryClip(ClipData.newPlainText((CharSequence)"log", (CharSequence)deviceLog.toString()));
        final Context appContext = this.appContext;
        Toast.makeText(appContext, (CharSequence)appContext.getString(2131886305), 0).show();
    }
    
    public final boolean isConnectionLogsEnabled() {
        return (boolean)((G1)this.isConnectionLogsEnabled$delegate).getValue();
    }
    
    public final boolean isInternalLogsEnabled() {
        return (boolean)((G1)this.isInternalLogsEnabled$delegate).getValue();
    }
    
    public final void setChannels(final Byte channels) {
        this.channels = channels;
    }
    
    public final void setConnectionLogsEnabled(final boolean b) {
        this.isConnectionLogsEnabled$delegate.setValue((Object)b);
    }
    
    public final void setInternalLogsEnabled(final boolean b) {
        this.isInternalLogsEnabled$delegate.setValue((Object)b);
    }
    
    public final void setLevel(final LogLevel level) {
        v.j((Object)level, "<set-?>");
        this.level = level;
    }
    
    public final void setTypes(final Byte types) {
        this.types = types;
    }
    
    public static final class Companion
    {
        private Companion() {
        }
    }
}
