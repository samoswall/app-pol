package com.polaris.iot.application.debug.devicelogs;

import android.content.Context;
import I8.a;
import A8.b;

public final class DebugDeviceLogsViewModel_Factory implements b
{
    private final a appContextProvider;
    
    public DebugDeviceLogsViewModel_Factory(final a appContextProvider) {
        this.appContextProvider = appContextProvider;
    }
    
    public static DebugDeviceLogsViewModel_Factory create(final a a) {
        return new DebugDeviceLogsViewModel_Factory(a);
    }
    
    public static DebugDeviceLogsViewModel newInstance(final Context context) {
        return new DebugDeviceLogsViewModel(context);
    }
    
    public DebugDeviceLogsViewModel get() {
        return newInstance((Context)this.appContextProvider.get());
    }
}
