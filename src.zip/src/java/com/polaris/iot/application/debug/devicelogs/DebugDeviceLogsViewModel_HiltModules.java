package com.polaris.iot.application.debug.devicelogs;

import androidx.lifecycle.e0;

public final class DebugDeviceLogsViewModel_HiltModules
{
    private DebugDeviceLogsViewModel_HiltModules() {
    }
    
    public abstract static class BindsModule
    {
        private BindsModule() {
        }
        
        public abstract e0 binds(final DebugDeviceLogsViewModel p0);
    }
    
    public static final class KeyModule
    {
        private KeyModule() {
        }
        
        public static boolean provide() {
            return true;
        }
    }
}
