package com.polaris.iot.application.debug.devicelogs;

import A8.b;

public final class DebugDeviceLogsViewModel_HiltModules_KeyModule_ProvideFactory implements b
{
    public static DebugDeviceLogsViewModel_HiltModules_KeyModule_ProvideFactory create() {
        return a.a;
    }
    
    public static boolean provide() {
        return DebugDeviceLogsViewModel_HiltModules.KeyModule.provide();
    }
    
    public Boolean get() {
        return provide();
    }
    
    private abstract static final class a
    {
        private static final DebugDeviceLogsViewModel_HiltModules_KeyModule_ProvideFactory a;
        
        static {
            a = new DebugDeviceLogsViewModel_HiltModules_KeyModule_ProvideFactory();
        }
    }
}
