package com.polaris.iot.application.debug.firmwaretest;

import java.text.DateFormat;
import com.syncleoiot.core.data.db.entity.UserDevice;
import java.nio.charset.Charset;
import java.io.OutputStream;
import com.syncleoiot.core.utils.FileUtils;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Locale;
import com.syncleoiot.core.data.model.UserDeviceItem;
import com.syncleoiot.transport.ble.base.BleTransport;
import com.syncleoiot.transport.udp.base.UdpTransport;
import com.syncleoiot.transport.core.connection.DeviceConnectionState;
import i9.U;
import java.util.Iterator;
import com.syncleoiot.core.data.model.DeviceParams;
import kotlin.jvm.internal.w;
import com.syncleoiot.core.data.model.FirmwareTestItem$FirmwareTestResult;
import com.syncleoiot.core.data.model.FirmwareTestItem;
import java.util.concurrent.CancellationException;
import i9.z0$a;
import com.syncleoiot.transport.core.models.DeviceFirmware;
import android.content.Context;
import com.syncleoiot.transport.firmware.core.FirmwareViewModelKt;
import com.syncleoiot.core.data.model.FirmwareType;
import com.syncleoiot.core.data.model.FirmwareSlot;
import java.util.List;
import i9.X;
import Q8.b;
import i9.c0;
import java.util.Collection;
import java.util.ArrayList;
import k9.u;
import k9.u$a;
import com.syncleoiot.tools.logwriter.Log;
import X8.p;
import i9.i;
import androidx.lifecycle.f0;
import java.util.concurrent.ExecutorService;
import i9.N;
import i9.q0;
import java.util.concurrent.Executors;
import i9.W0;
import com.syncleoiot.core.data.model.TestingState;
import com.syncleoiot.core.data.model.FirmwareTestConfig;
import v0.u1;
import v0.v1;
import L8.t;
import X8.l;
import k9.a;
import k9.g;
import l9.O;
import com.syncleoiot.transport.firmware.core.FirmwareState;
import kotlin.jvm.internal.v;
import kotlin.jvm.internal.m;
import android.net.Uri;
import com.syncleoiot.transport.core.models.ObservableDevice;
import i9.z0;
import com.syncleoiot.core.data.model.Device;
import androidx.lifecycle.J;
import com.syncleoiot.transport.firmware.core.FirmwareConnectionUpdater;
import com.syncleoiot.core.api.DeviceManager;
import k9.d;
import com.syncleoiot.transport.core.connection.DeviceConnection;
import v0.t0;
import com.syncleoiot.transport.core.connection.DeviceConnectionCallback;
import i9.M;
import i9.A;
import android.app.Application;
import com.syncleoiot.core.api.ApiService;
import androidx.annotation.Keep;
import l9.x;
import com.syncleoiot.core.vm.ConnectibleViewModel;
import androidx.lifecycle.e0;

public final class FirmwareTestViewModel extends e0 implements ConnectibleViewModel
{
    public static final int $stable;
    public static final FirmwareTestViewModel.FirmwareTestViewModel$Companion Companion;
    private static final String TAG;
    public static final long TIMEOUT = 180000L;
    @Keep
    private final x _firmwareFlow;
    private final ApiService apiService;
    private final Application appContext;
    private final A connectDeviceJob;
    private final M connectDeviceScope;
    private final DeviceConnectionCallback connectionCallback;
    private t0 currentTestItem;
    private t0 delayMutableState;
    private DeviceConnection deviceConnection;
    private d deviceFwVersionChannel;
    private final DeviceManager deviceManager;
    private final t0 firmwareCaseItems;
    private t0 firmwareConfig;
    @Keep
    private final l9.M firmwareFlow;
    private FirmwareConnectionUpdater firmwareUpdateManager;
    private J firstFileUri;
    private final d fwChannel;
    private String macToConnect;
    private final t0 messageList;
    private J secondFileUri;
    private Device testingDevice;
    private z0 testingJob;
    private String testingMac;
    private ObservableDevice testingObsDevice;
    private final t0 testingState;
    private Uri uri;
    
    static {
        String simpleName = null;
        final FirmwareTestViewModel.FirmwareTestViewModel$Companion firmwareTestViewModel$Companion = Companion = new FirmwareTestViewModel.FirmwareTestViewModel$Companion((m)null);
        $stable = 8;
        final Class<?> enclosingClass = firmwareTestViewModel$Companion.getClass().getEnclosingClass();
        if (enclosingClass != null) {
            simpleName = enclosingClass.getSimpleName();
        }
        String tag;
        if ((tag = simpleName) == null) {
            tag = "TAG";
        }
        TAG = tag;
    }
    
    public FirmwareTestViewModel(final DeviceManager deviceManager, final ApiService apiService, final Application appContext) {
        v.j((Object)deviceManager, "deviceManager");
        v.j((Object)apiService, "apiService");
        v.j((Object)appContext, "appContext");
        this.deviceManager = deviceManager;
        this.apiService = apiService;
        this.appContext = appContext;
        final x a = O.a((Object)FirmwareState.Companion.getChecking());
        this._firmwareFlow = a;
        this.firmwareFlow = (l9.M)a;
        this.fwChannel = g.b(0, (a)null, (l)null, 6, (Object)null);
        this.firmwareCaseItems = v1.i((Object)t.n(), (u1)null, 2, (Object)null);
        this.firmwareConfig = v1.i((Object)new FirmwareTestConfig((Uri)null, (Uri)null, 0L, 0, (Integer)null, 31, (m)null), (u1)null, 2, (Object)null);
        this.currentTestItem = v1.i((Object)null, (u1)null, 2, (Object)null);
        this.firstFileUri = new J((Object)null);
        this.secondFileUri = new J((Object)null);
        this.testingState = v1.i((Object)TestingState.INITIAL, (u1)null, 2, (Object)null);
        this.messageList = v1.i((Object)t.n(), (u1)null, 2, (Object)null);
        this.delayMutableState = v1.i((Object)0L, (u1)null, 2, (Object)null);
        final A b = W0.b((z0)null, 1, (Object)null);
        this.connectDeviceJob = b;
        final ExecutorService singleThreadExecutor = Executors.newSingleThreadExecutor();
        v.i((Object)singleThreadExecutor, "newSingleThreadExecutor(...)");
        this.connectDeviceScope = N.a(((P8.a)q0.c(singleThreadExecutor)).plus((P8.g)b));
        this.connectionCallback = (DeviceConnectionCallback)new FirmwareTestViewModel$connectionCallback.FirmwareTestViewModel$connectionCallback$1(this);
    }
    
    public static final /* synthetic */ DeviceConnectionCallback access$getConnectionCallback$p(final FirmwareTestViewModel firmwareTestViewModel) {
        return firmwareTestViewModel.connectionCallback;
    }
    
    public static final /* synthetic */ d access$getDeviceFwVersionChannel$p(final FirmwareTestViewModel firmwareTestViewModel) {
        return firmwareTestViewModel.deviceFwVersionChannel;
    }
    
    public static final /* synthetic */ String access$getMacToConnect$p(final FirmwareTestViewModel firmwareTestViewModel) {
        return firmwareTestViewModel.macToConnect;
    }
    
    public static final /* synthetic */ x access$get_firmwareFlow$p(final FirmwareTestViewModel firmwareTestViewModel) {
        return firmwareTestViewModel._firmwareFlow;
    }
    
    public static final /* synthetic */ void access$setDeviceConnection$p(final FirmwareTestViewModel firmwareTestViewModel, final DeviceConnection deviceConnection) {
        firmwareTestViewModel.deviceConnection = deviceConnection;
    }
    
    private final void closeFirmwareManager() {
        final FirmwareConnectionUpdater firmwareUpdateManager = this.firmwareUpdateManager;
        if (firmwareUpdateManager != null) {
            firmwareUpdateManager.cancel();
        }
        this.firmwareUpdateManager = null;
    }
    
    private final z0 collectFirmwareFlow() {
        return i.d(f0.a((e0)this), (P8.g)null, (i9.O)null, (p)new FirmwareTestViewModel$collectFirmwareFlow.FirmwareTestViewModel$collectFirmwareFlow$1(this, (P8.d)null), 3, (Object)null);
    }
    
    private final void connectDevice(final String macToConnect) {
        this.disconnectDevice();
        Log.d(FirmwareTestViewModel.TAG, "connect device");
        this.macToConnect = macToConnect;
        this.deviceFwVersionChannel = g.b(0, (a)null, (l)null, 6, (Object)null);
        this.updateConnection();
    }
    
    private final void disconnectDevice() {
        this.getLog("disconnectDevice");
        Log.d(FirmwareTestViewModel.TAG, "disconnectDevice");
        final d deviceFwVersionChannel = this.deviceFwVersionChannel;
        this.macToConnect = null;
        final DeviceConnection deviceConnection = this.deviceConnection;
        if (deviceConnection != null) {
            deviceConnection.removeConnectionCallback(this.connectionCallback);
            this.deviceConnection = null;
        }
        this.deviceFwVersionChannel = null;
        if (deviceFwVersionChannel != null) {
            try {
                u$a.a((u)deviceFwVersionChannel, (Throwable)null, 1, (Object)null);
            }
            catch (final Exception ex) {
                Log.e(FirmwareTestViewModel.TAG, "failed to close channel", (Throwable)ex);
            }
        }
        this.deviceFwVersionChannel = null;
    }
    
    private final boolean evenOrOdd(final boolean b, int n) {
        final boolean b2 = false;
        n %= 2;
        if (b) {
            final boolean b3 = b2;
            if (n != 0) {
                return b3;
            }
        }
        else {
            final boolean b3 = b2;
            if (n == 0) {
                return b3;
            }
        }
        return true;
    }
    
    private final void getLog(final String s) {
        final ArrayList value = new ArrayList();
        ((List)value).addAll((Collection)this.messageList.getValue());
        ((List)value).add((Object)s);
        this.messageList.setValue((Object)value);
    }
    
    private final z0 startDeviceConnectionTimeout() {
        return i.d(f0.a((e0)this), (P8.g)c0.c(), (i9.O)null, (p)new FirmwareTestViewModel$a(this, (P8.d)null), 2, (Object)null);
    }
    
    private final z0 startFirmwareTests(final String s) {
        return i.d(f0.a((e0)this), (P8.g)c0.a(), (i9.O)null, (p)new p(this, s, null) {
            final FirmwareTestViewModel A;
            final String B;
            Object y;
            int z;
            
            public final P8.d create(final Object o, final P8.d d) {
                return (P8.d)new p(this.A, this.B, d) {
                    final FirmwareTestViewModel A;
                    final String B;
                    Object y;
                    int z;
                };
            }
            
            public final Object invoke(final M m, final P8.d d) {
                return ((FirmwareTestViewModel$b)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(final Object o) {
                final Object f = b.f();
                final int z = this.z;
                final Object o2 = null;
                Label_0192: {
                    FirmwareTestConfig y;
                    if (z != 0) {
                        if (z != 1) {
                            if (z == 2) {
                                K8.x.b(o);
                                break Label_0192;
                            }
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        else {
                            final FirmwareTestConfig firmwareTestConfig = (FirmwareTestConfig)this.y;
                            K8.x.b(o);
                            y = firmwareTestConfig;
                        }
                    }
                    else {
                        K8.x.b(o);
                        this.A.getTestingState().setValue((Object)TestingState.ACTIVE);
                        y = (FirmwareTestConfig)this.A.getFirmwareConfig().getValue();
                        if (y == null) {
                            return K8.M.a;
                        }
                        this.A.getDelayMutableState().setValue((Object)kotlin.coroutines.jvm.internal.b.f(y.getPlannedStart()));
                        final long plannedStart = y.getPlannedStart();
                        this.y = y;
                        this.z = 1;
                        if (X.b(plannedStart, (P8.d)this) == f) {
                            return f;
                        }
                    }
                    final FirmwareTestViewModel a = this.A;
                    final String b = this.B;
                    this.y = null;
                    this.z = 2;
                    if (a.startTest(y, b, (P8.d)this) == f) {
                        return f;
                    }
                }
                this.A.closeFirmwareManager();
                this.A.getTestingState().setValue((Object)TestingState.COMPLETED);
                final t0 firmwareConfig = this.A.getFirmwareConfig();
                final FirmwareTestConfig firmwareTestConfig2 = (FirmwareTestConfig)this.A.getFirmwareConfig().getValue();
                Object copy$default = o2;
                if (firmwareTestConfig2 != null) {
                    copy$default = FirmwareTestConfig.copy$default(firmwareTestConfig2, (Uri)null, (Uri)null, 0L, 0, (Integer)null, 27, (Object)null);
                }
                firmwareConfig.setValue(copy$default);
                this.A.getMessageList().setValue((Object)t.n());
                return K8.M.a;
            }
        }, 2, (Object)null);
    }
    
    private final Object startTest(FirmwareTestConfig firmwareTestConfig, final String s, final P8.d d) {
        String s2 = "endOfCycle";
        String s3 = "addNewTestItem";
        String s4 = "cancel timeout";
        String s5 = "online timeout error";
        Object o = null;
        Label_0080: {
            if (d instanceof FirmwareTestViewModel$c) {
                final kotlin.coroutines.jvm.internal.d d2 = (FirmwareTestViewModel$c)d;
                final int b0 = d2.b0;
                if ((b0 & Integer.MIN_VALUE) != 0x0) {
                    d2.b0 = b0 + Integer.MIN_VALUE;
                    o = d2;
                    break Label_0080;
                }
            }
            o = new kotlin.coroutines.jvm.internal.d(this, d) {
                Object A;
                Object B;
                Object C;
                Object H;
                Object L;
                Object M;
                int Q;
                int W;
                int X;
                boolean Y;
                Object Z;
                final FirmwareTestViewModel a0;
                int b0;
                Object y;
                Object z;
                
                public final Object invokeSuspend(final Object z) {
                    this.Z = z;
                    this.b0 |= Integer.MIN_VALUE;
                    return this.a0.startTest(null, null, (P8.d)this);
                }
            };
        }
        final Object z = ((FirmwareTestViewModel$c)o).Z;
        Object f = b.f();
        final int b2 = ((FirmwareTestViewModel$c)o).b0;
        String s6 = "delayEnded";
    Label_2008_Outer:
        while (true) {
            FirmwareTestConfig firmwareTestConfig2 = null;
            int n3 = 0;
            FirmwareTestViewModel firmwareTestViewModel2 = null;
            String s15 = null;
            String s24 = null;
            String s25 = null;
            String s29 = null;
            Object o19 = null;
            Object o20 = null;
            P8.d d5 = null;
            int n11 = 0;
            Integer n12 = null;
            String s30 = null;
            Label_3154: {
                int w2 = 0;
                String s11 = null;
                String s12 = null;
                String s13 = null;
                int x2 = 0;
                int q = 0;
                Integer h = null;
                ObservableDevice c2 = null;
                String a = null;
                FirmwareTestConfig z3 = null;
                String s17 = null;
                Object o9 = null;
                Object o10 = null;
                DeviceFirmware deviceFirmware5 = null;
                Object o21 = null;
                Label_2805: {
                    Object o11 = null;
                    Object o12 = null;
                    Object o13 = null;
                    Label_2786: {
                        Label_2619: {
                            while (true) {
                                ObservableDevice observableDevice = null;
                                Object b3 = null;
                                String s9 = null;
                                FirmwareTestConfig firmwareTestConfig3 = null;
                                String s20 = null;
                                Object o14 = null;
                                Label_2273: {
                                    int n = 0;
                                    z0 z2 = null;
                                    String s14 = null;
                                    Object o7 = null;
                                    Object o8 = null;
                                    Integer n6 = null;
                                    Label_1915: {
                                        boolean y = false;
                                        int w = 0;
                                        ObservableDevice c = null;
                                        String s7 = null;
                                        Object b5 = null;
                                        byte[] array = null;
                                        Integer h3 = null;
                                        kotlin.coroutines.jvm.internal.d d3 = null;
                                        DeviceFirmware deviceFirmware2 = null;
                                        Label_1416: {
                                            int x = 0;
                                            Object o2 = null;
                                            byte[] firmwareLocalFile = null;
                                            Integer n2 = null;
                                            Object o3 = null;
                                            String s8 = null;
                                            Object o4 = null;
                                            Object o5 = null;
                                            FirmwareTestViewModel y2 = null;
                                            Object o6 = null;
                                            Label_1301: {
                                                Object b4;
                                                int w3;
                                                Object o15;
                                                ObservableDevice c3;
                                                Integer h2;
                                                if (b2 != 0) {
                                                    if (b2 == 1) {
                                                        y = ((FirmwareTestViewModel$c)o).Y;
                                                        x = ((FirmwareTestViewModel$c)o).X;
                                                        w = ((FirmwareTestViewModel$c)o).W;
                                                        n = ((FirmwareTestViewModel$c)o).Q;
                                                        o2 = ((FirmwareTestViewModel$c)o).M;
                                                        firmwareLocalFile = (byte[])((FirmwareTestViewModel$c)o).L;
                                                        n2 = (Integer)((FirmwareTestViewModel$c)o).H;
                                                        c = (ObservableDevice)((FirmwareTestViewModel$c)o).C;
                                                        o3 = ((FirmwareTestViewModel$c)o).B;
                                                        s7 = (String)((FirmwareTestViewModel$c)o).A;
                                                        firmwareTestConfig = (FirmwareTestConfig)((FirmwareTestViewModel$c)o).z;
                                                        final FirmwareTestViewModel firmwareTestViewModel = (FirmwareTestViewModel)((FirmwareTestViewModel$c)o).y;
                                                        K8.x.b(z);
                                                        s3 = "addNewTestItem";
                                                        s8 = "cancel timeout";
                                                        s5 = "online timeout error";
                                                        s6 = "delayEnded";
                                                        o4 = z;
                                                        s2 = "endOfCycle";
                                                        o5 = o;
                                                        y2 = firmwareTestViewModel;
                                                        firmwareTestConfig2 = firmwareTestConfig;
                                                        o6 = f;
                                                        break Label_1301;
                                                    }
                                                    if (b2 == 2) {
                                                        n3 = ((FirmwareTestViewModel$c)o).X;
                                                        w2 = ((FirmwareTestViewModel$c)o).W;
                                                        n = ((FirmwareTestViewModel$c)o).Q;
                                                        z2 = (z0)((FirmwareTestViewModel$c)o).L;
                                                        final Integer n4 = (Integer)((FirmwareTestViewModel$c)o).H;
                                                        observableDevice = (ObservableDevice)((FirmwareTestViewModel$c)o).C;
                                                        b3 = ((FirmwareTestViewModel$c)o).B;
                                                        s9 = (String)((FirmwareTestViewModel$c)o).A;
                                                        firmwareTestConfig3 = (FirmwareTestConfig)((FirmwareTestViewModel$c)o).z;
                                                        firmwareTestViewModel2 = (FirmwareTestViewModel)((FirmwareTestViewModel$c)o).y;
                                                        K8.x.b(z);
                                                        final String s10 = "endOfCycle";
                                                        s11 = "addNewTestItem";
                                                        s12 = "cancel timeout";
                                                        s13 = "online timeout error";
                                                        s14 = "delayEnded";
                                                        o7 = f;
                                                        final Integer n5 = n4;
                                                        o8 = z;
                                                        n6 = n5;
                                                        s15 = s10;
                                                        break Label_1915;
                                                    }
                                                    if (b2 == 3) {
                                                        x2 = ((FirmwareTestViewModel$c)o).X;
                                                        w2 = ((FirmwareTestViewModel$c)o).W;
                                                        q = ((FirmwareTestViewModel$c)o).Q;
                                                        h = (Integer)((FirmwareTestViewModel$c)o).H;
                                                        c2 = (ObservableDevice)((FirmwareTestViewModel$c)o).C;
                                                        final List list = (List)((FirmwareTestViewModel$c)o).B;
                                                        a = (String)((FirmwareTestViewModel$c)o).A;
                                                        z3 = (FirmwareTestConfig)((FirmwareTestViewModel$c)o).z;
                                                        firmwareTestViewModel2 = (FirmwareTestViewModel)((FirmwareTestViewModel$c)o).y;
                                                        K8.x.b(z);
                                                        final String s16 = "endOfCycle";
                                                        s11 = "addNewTestItem";
                                                        s12 = "cancel timeout";
                                                        s13 = "online timeout error";
                                                        s17 = "delayEnded";
                                                        o9 = list;
                                                        o10 = f;
                                                        s15 = s16;
                                                        break Label_2619;
                                                    }
                                                    if (b2 == 4) {
                                                        x2 = ((FirmwareTestViewModel$c)o).X;
                                                        w2 = ((FirmwareTestViewModel$c)o).W;
                                                        q = ((FirmwareTestViewModel$c)o).Q;
                                                        o11 = ((FirmwareTestViewModel$c)o).L;
                                                        h = (Integer)((FirmwareTestViewModel$c)o).H;
                                                        c2 = (ObservableDevice)((FirmwareTestViewModel$c)o).C;
                                                        final List list2 = (List)((FirmwareTestViewModel$c)o).B;
                                                        a = (String)((FirmwareTestViewModel$c)o).A;
                                                        z3 = (FirmwareTestConfig)((FirmwareTestViewModel$c)o).z;
                                                        firmwareTestViewModel2 = (FirmwareTestViewModel)((FirmwareTestViewModel$c)o).y;
                                                        K8.x.b(z);
                                                        final String s18 = "endOfCycle";
                                                        s11 = "addNewTestItem";
                                                        s12 = "cancel timeout";
                                                        s13 = "online timeout error";
                                                        s17 = "delayEnded";
                                                        o12 = f;
                                                        o13 = z;
                                                        o9 = list2;
                                                        s15 = s18;
                                                        break Label_2786;
                                                    }
                                                    if (b2 == 5) {
                                                        n3 = ((FirmwareTestViewModel$c)o).X;
                                                        w2 = ((FirmwareTestViewModel$c)o).W;
                                                        n = ((FirmwareTestViewModel$c)o).Q;
                                                        final Integer n7 = (Integer)((FirmwareTestViewModel$c)o).H;
                                                        observableDevice = (ObservableDevice)((FirmwareTestViewModel$c)o).C;
                                                        b3 = ((FirmwareTestViewModel$c)o).B;
                                                        s9 = (String)((FirmwareTestViewModel$c)o).A;
                                                        firmwareTestConfig3 = (FirmwareTestConfig)((FirmwareTestViewModel$c)o).z;
                                                        firmwareTestViewModel2 = (FirmwareTestViewModel)((FirmwareTestViewModel$c)o).y;
                                                        K8.x.b(z);
                                                        final String s19 = "endOfCycle";
                                                        s11 = "addNewTestItem";
                                                        s12 = "cancel timeout";
                                                        s13 = "online timeout error";
                                                        s20 = "delayEnded";
                                                        o14 = f;
                                                        n6 = n7;
                                                        s15 = s19;
                                                        break Label_2273;
                                                    }
                                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                                }
                                                else {
                                                    K8.x.b(z);
                                                    b4 = new ArrayList();
                                                    final Device testingDevice = this.testingDevice;
                                                    if (testingDevice == null) {
                                                        return K8.M.a;
                                                    }
                                                    final ObservableDevice testingObsDevice = this.testingObsDevice;
                                                    if (testingObsDevice == null) {
                                                        return K8.M.a;
                                                    }
                                                    final DeviceParams params = testingDevice.getParams();
                                                    List firmwareSlots;
                                                    if (params != null) {
                                                        firmwareSlots = params.getFirmwareSlots();
                                                    }
                                                    else {
                                                        firmwareSlots = null;
                                                    }
                                                    Integer e = null;
                                                    Label_0951: {
                                                        Label_0948: {
                                                            if (firmwareSlots != null) {
                                                                final Iterator iterator = firmwareSlots.iterator();
                                                                int n8 = 0;
                                                                while (true) {
                                                                    while (iterator.hasNext()) {
                                                                        final FirmwareSlot firmwareSlot = (FirmwareSlot)iterator.next();
                                                                        FirmwareType type;
                                                                        if (firmwareSlot != null) {
                                                                            type = firmwareSlot.getType();
                                                                        }
                                                                        else {
                                                                            type = null;
                                                                        }
                                                                        if (type == FirmwareType.wifi) {
                                                                            if (n8 == -1) {
                                                                                break Label_0948;
                                                                            }
                                                                            e = kotlin.coroutines.jvm.internal.b.e(n8);
                                                                            break Label_0951;
                                                                        }
                                                                        else {
                                                                            ++n8;
                                                                        }
                                                                    }
                                                                    n8 = -1;
                                                                    continue Label_2008_Outer;
                                                                }
                                                            }
                                                        }
                                                        e = null;
                                                    }
                                                    final Integer count = firmwareTestConfig.getCount();
                                                    v.g((Object)count);
                                                    x = count;
                                                    if (1 > x) {
                                                        return K8.M.a;
                                                    }
                                                    n = 0;
                                                    w3 = 1;
                                                    s7 = s;
                                                    o15 = o;
                                                    firmwareTestConfig2 = firmwareTestConfig;
                                                    c3 = testingObsDevice;
                                                    h2 = e;
                                                    y2 = this;
                                                }
                                                y = y2.evenOrOdd(n != 0, w3);
                                                Uri uri;
                                                if (y) {
                                                    if ((uri = firmwareTestConfig2.getFirstFileUri()) == null) {
                                                        return K8.M.a;
                                                    }
                                                }
                                                else if ((uri = firmwareTestConfig2.getSecondFileUri()) == null) {
                                                    return K8.M.a;
                                                }
                                                final String s21 = s4;
                                                firmwareLocalFile = FirmwareViewModelKt.parseFirmwareLocalFile(uri, (Context)y2.appContext);
                                                if (firmwareLocalFile == null) {
                                                    return K8.M.a;
                                                }
                                                y2.connectDevice(s7);
                                                b5 = i.b(f0.a((e0)y2), (P8.g)null, (i9.O)null, (p)new p(y2, null) {
                                                    int y;
                                                    final FirmwareTestViewModel z;
                                                    
                                                    public final P8.d create(final Object o, final P8.d d) {
                                                        return (P8.d)new p(this.z, d) {
                                                            int y;
                                                            final FirmwareTestViewModel z;
                                                        };
                                                    }
                                                    
                                                    public final Object invoke(final M m, final P8.d d) {
                                                        return ((FirmwareTestViewModel$e)this.create(m, d)).invokeSuspend(K8.M.a);
                                                    }
                                                    
                                                    public final Object invokeSuspend(final Object o) {
                                                        b.f();
                                                        if (this.y == 0) {
                                                            K8.x.b(o);
                                                            return this.z.startDeviceConnectionTimeout();
                                                        }
                                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                                    }
                                                }, 3, (Object)null);
                                                y2.getLog("waiting to receive old fw");
                                                Log.d(FirmwareTestViewModel.TAG, "waiting to receive old fw");
                                                final d deviceFwVersionChannel = y2.deviceFwVersionChannel;
                                                if (deviceFwVersionChannel == null) {
                                                    final List list3 = (List)b4;
                                                    final Object o16 = o15;
                                                    final DeviceFirmware deviceFirmware = null;
                                                    array = firmwareLocalFile;
                                                    s13 = s5;
                                                    s14 = s6;
                                                    s12 = s21;
                                                    c = c3;
                                                    h3 = h2;
                                                    w = w3;
                                                    n3 = x;
                                                    d3 = (FirmwareTestViewModel$c)o16;
                                                    deviceFirmware2 = deviceFirmware;
                                                    b3 = list3;
                                                    firmwareTestViewModel2 = y2;
                                                    break Label_1416;
                                                }
                                                ((FirmwareTestViewModel$c)o15).y = y2;
                                                ((FirmwareTestViewModel$c)o15).z = firmwareTestConfig2;
                                                ((FirmwareTestViewModel$c)o15).A = s7;
                                                ((FirmwareTestViewModel$c)o15).B = b4;
                                                ((FirmwareTestViewModel$c)o15).C = c3;
                                                ((FirmwareTestViewModel$c)o15).H = h2;
                                                ((FirmwareTestViewModel$c)o15).L = firmwareLocalFile;
                                                ((FirmwareTestViewModel$c)o15).M = b5;
                                                ((FirmwareTestViewModel$c)o15).Q = n;
                                                ((FirmwareTestViewModel$c)o15).W = w3;
                                                ((FirmwareTestViewModel$c)o15).X = x;
                                                ((FirmwareTestViewModel$c)o15).Y = y;
                                                ((FirmwareTestViewModel$c)o15).b0 = 1;
                                                final Object g = ((k9.t)deviceFwVersionChannel).g((P8.d)o15);
                                                o2 = b5;
                                                o4 = g;
                                                o3 = b4;
                                                o6 = f;
                                                o5 = o15;
                                                w = w3;
                                                n2 = h2;
                                                c = c3;
                                                s8 = s21;
                                                if (g == f) {
                                                    return f;
                                                }
                                            }
                                            final DeviceFirmware deviceFirmware3 = (DeviceFirmware)o4;
                                            final byte[] array2 = firmwareLocalFile;
                                            b3 = o3;
                                            d3 = (FirmwareTestViewModel$c)o5;
                                            firmwareTestViewModel2 = y2;
                                            b5 = o2;
                                            deviceFirmware2 = deviceFirmware3;
                                            f = o6;
                                            n3 = x;
                                            h3 = n2;
                                            s12 = s8;
                                            s14 = s6;
                                            s13 = s5;
                                            array = array2;
                                        }
                                        final StringBuilder sb = new StringBuilder();
                                        sb.append("received old fw=");
                                        sb.append((Object)deviceFirmware2);
                                        firmwareTestViewModel2.getLog(sb.toString());
                                        final String tag = FirmwareTestViewModel.TAG;
                                        final StringBuilder sb2 = new StringBuilder();
                                        sb2.append("received old fw=");
                                        sb2.append((Object)deviceFirmware2);
                                        Log.d(tag, sb2.toString());
                                        z0$a.b((z0)b5, (CancellationException)null, 1, (Object)null);
                                        firmwareTestViewModel2.delayMutableState.setValue((Object)kotlin.coroutines.jvm.internal.b.f(0L));
                                        firmwareTestViewModel2.disconnectDevice();
                                        final long currentTimeMillis = System.currentTimeMillis();
                                        Uri uri2;
                                        if (y) {
                                            uri2 = firmwareTestConfig2.getFirstFileUri();
                                        }
                                        else {
                                            uri2 = firmwareTestConfig2.getSecondFileUri();
                                        }
                                        firmwareTestViewModel2.currentTestItem.setValue((Object)new FirmwareTestItem(currentTimeMillis, (FirmwareTestItem$FirmwareTestResult)null, 0L, 0L, (Integer)null, uri2, deviceFirmware2, (DeviceFirmware)null, 158, (m)null));
                                        final z0 collectFirmwareFlow = firmwareTestViewModel2.collectFirmwareFlow();
                                        Byte b6;
                                        if (h3 != null) {
                                            b6 = kotlin.coroutines.jvm.internal.b.b((byte)(int)h3);
                                        }
                                        else {
                                            b6 = null;
                                        }
                                        firmwareTestViewModel2.firmwareUpdateManager = new FirmwareConnectionUpdater(c, array, b6, (l)new l(firmwareTestViewModel2) {
                                            final FirmwareTestViewModel H;
                                            
                                            public final void a(final FirmwareState value) {
                                                v.j((Object)value, "it");
                                                FirmwareTestViewModel.access$get_firmwareFlow$p(this.H).setValue((Object)value);
                                            }
                                        }, (l)null, 16, (m)null);
                                        final boolean b7 = n != 0;
                                        final StringBuilder sb3 = new StringBuilder();
                                        sb3.append("firmware file even = ");
                                        sb3.append(b7);
                                        firmwareTestViewModel2.getLog(sb3.toString());
                                        final boolean b8 = n != 0;
                                        final StringBuilder sb4 = new StringBuilder();
                                        sb4.append("firmware file even = ");
                                        sb4.append(b8);
                                        Log.d(tag, sb4.toString());
                                        firmwareTestViewModel2.getLog("receive fw code");
                                        Log.d(tag, "receive fw code");
                                        final d fwChannel = firmwareTestViewModel2.fwChannel;
                                        d3.y = firmwareTestViewModel2;
                                        d3.z = firmwareTestConfig2;
                                        d3.A = s7;
                                        d3.B = b3;
                                        d3.C = c;
                                        d3.H = h3;
                                        d3.L = collectFirmwareFlow;
                                        d3.M = null;
                                        d3.Q = n;
                                        d3.W = w;
                                        d3.X = n3;
                                        d3.b0 = 2;
                                        final Object g2 = ((k9.t)fwChannel).g((P8.d)d3);
                                        final DeviceFirmware deviceFirmware4 = (DeviceFirmware)f;
                                        if (g2 == deviceFirmware4) {
                                            return deviceFirmware4;
                                        }
                                        final ObservableDevice observableDevice2 = c;
                                        final String s22 = s7;
                                        final FirmwareTestConfig firmwareTestConfig4 = firmwareTestConfig2;
                                        o8 = g2;
                                        s11 = s3;
                                        s15 = s2;
                                        s9 = s22;
                                        n6 = h3;
                                        w2 = w;
                                        observableDevice = observableDevice2;
                                        o7 = deviceFirmware4;
                                        o = d3;
                                        firmwareTestConfig3 = firmwareTestConfig4;
                                        z2 = collectFirmwareFlow;
                                    }
                                    final int intValue = ((Number)o8).intValue();
                                    z0$a.b(z2, (CancellationException)null, 1, (Object)null);
                                    firmwareTestViewModel2.getLog("fw code received");
                                    final String tag2 = FirmwareTestViewModel.TAG;
                                    Log.d(tag2, "fw code received");
                                    firmwareTestViewModel2.closeFirmwareManager();
                                    Log.d(tag2, "coroutineResume");
                                    FirmwareTestConfig firmwareTestConfig5;
                                    Object o17;
                                    ObservableDevice observableDevice3;
                                    String s26;
                                    String s27;
                                    if (intValue != 0) {
                                        if (intValue != 1) {
                                            firmwareTestConfig5 = firmwareTestConfig3;
                                            o17 = o7;
                                            final String s23 = s9;
                                            s24 = s12;
                                            observableDevice3 = observableDevice;
                                            s25 = s13;
                                            s26 = s14;
                                            s27 = s23;
                                        }
                                        else {
                                            firmwareTestViewModel2.getLog("change file order");
                                            Log.d(tag2, "change file order");
                                            if (n == 0) {
                                                n = 1;
                                            }
                                            else {
                                                n = 0;
                                            }
                                            final long n9 = Math.max(1, firmwareTestConfig3.getInterval()) * 60000L;
                                            firmwareTestViewModel2.delayMutableState.setValue((Object)kotlin.coroutines.jvm.internal.b.f(n9));
                                            final StringBuilder sb5 = new StringBuilder();
                                            sb5.append("delayStarted duration=");
                                            sb5.append(n9);
                                            firmwareTestViewModel2.getLog(sb5.toString());
                                            final StringBuilder sb6 = new StringBuilder();
                                            sb6.append("delayStarted duration=");
                                            sb6.append(n9);
                                            Log.d(tag2, sb6.toString());
                                            ((FirmwareTestViewModel$c)o).y = firmwareTestViewModel2;
                                            ((FirmwareTestViewModel$c)o).z = firmwareTestConfig3;
                                            ((FirmwareTestViewModel$c)o).A = s9;
                                            ((FirmwareTestViewModel$c)o).B = b3;
                                            ((FirmwareTestViewModel$c)o).C = observableDevice;
                                            ((FirmwareTestViewModel$c)o).H = n6;
                                            ((FirmwareTestViewModel$c)o).L = null;
                                            ((FirmwareTestViewModel$c)o).Q = n;
                                            ((FirmwareTestViewModel$c)o).W = w2;
                                            ((FirmwareTestViewModel$c)o).X = n3;
                                            ((FirmwareTestViewModel$c)o).b0 = 5;
                                            final Object b9 = X.b(n9, (P8.d)o);
                                            final Object o18 = o7;
                                            if (b9 == o18) {
                                                return o18;
                                            }
                                            s20 = s14;
                                            o14 = o18;
                                            break Label_2273;
                                        }
                                    }
                                    else {
                                        final int max = Math.max(1, firmwareTestConfig3.getInterval());
                                        final int x3 = n3;
                                        final long n10 = max * 60000L;
                                        firmwareTestViewModel2.delayMutableState.setValue((Object)kotlin.coroutines.jvm.internal.b.f(n10));
                                        final StringBuilder sb7 = new StringBuilder();
                                        sb7.append("delayStarted duration=");
                                        sb7.append(n10);
                                        sb7.append(" ms");
                                        firmwareTestViewModel2.getLog(sb7.toString());
                                        final StringBuilder sb8 = new StringBuilder();
                                        sb8.append("delayStarted duration=");
                                        sb8.append(n10);
                                        sb8.append(" ms");
                                        Log.d(tag2, sb8.toString());
                                        ((FirmwareTestViewModel$c)o).y = firmwareTestViewModel2;
                                        ((FirmwareTestViewModel$c)o).z = firmwareTestConfig3;
                                        ((FirmwareTestViewModel$c)o).A = s9;
                                        ((FirmwareTestViewModel$c)o).B = b3;
                                        ((FirmwareTestViewModel$c)o).C = observableDevice;
                                        ((FirmwareTestViewModel$c)o).H = n6;
                                        ((FirmwareTestViewModel$c)o).L = null;
                                        ((FirmwareTestViewModel$c)o).Q = n;
                                        ((FirmwareTestViewModel$c)o).W = w2;
                                        ((FirmwareTestViewModel$c)o).X = x3;
                                        ((FirmwareTestViewModel$c)o).b0 = 3;
                                        if (X.b(n10, (P8.d)o) == o7) {
                                            return o7;
                                        }
                                        final String s28 = s9;
                                        final FirmwareTestConfig firmwareTestConfig6 = firmwareTestConfig3;
                                        h = n6;
                                        o9 = b3;
                                        s17 = s14;
                                        z3 = firmwareTestConfig6;
                                        c2 = observableDevice;
                                        q = n;
                                        x2 = x3;
                                        o10 = o7;
                                        a = s28;
                                        break Label_2619;
                                    }
                                    final P8.d d4 = (P8.d)o;
                                    firmwareTestConfig2 = firmwareTestConfig5;
                                    s29 = s11;
                                    o19 = o17;
                                    String s7 = s27;
                                    o20 = b3;
                                    d5 = d4;
                                    n11 = w2;
                                    n12 = n6;
                                    ObservableDevice c3 = observableDevice3;
                                    s30 = s26;
                                    break Label_3154;
                                }
                                firmwareTestViewModel2.getLog(s20);
                                Log.d(FirmwareTestViewModel.TAG, s20);
                                final FirmwareTestItem firmwareTestItem = (FirmwareTestItem)firmwareTestViewModel2.currentTestItem.getValue();
                                if (firmwareTestItem != null) {
                                    kotlin.coroutines.jvm.internal.b.a(((List)b3).add((Object)FirmwareTestItem.copy$default(firmwareTestItem, 0L, FirmwareTestItem$FirmwareTestResult.FAILED, 0L, 0L, (Integer)null, (Uri)null, (DeviceFirmware)null, (DeviceFirmware)null, 253, (Object)null)));
                                }
                                final String s31 = s20;
                                FirmwareTestConfig firmwareTestConfig5 = firmwareTestConfig3;
                                Object o17 = o14;
                                String s27 = s9;
                                s24 = s12;
                                ObservableDevice observableDevice3 = observableDevice;
                                String s26 = s31;
                                s25 = s13;
                                continue;
                            }
                        }
                        firmwareTestViewModel2.getLog(s17);
                        final String tag3 = FirmwareTestViewModel.TAG;
                        Log.d(tag3, s17);
                        firmwareTestViewModel2.connectDevice(a);
                        final U b10 = i.b(f0.a((e0)firmwareTestViewModel2), (P8.g)null, (i9.O)null, (p)new p(firmwareTestViewModel2, null) {
                            int y;
                            final FirmwareTestViewModel z;
                            
                            public final P8.d create(final Object o, final P8.d d) {
                                return (P8.d)new p(this.z, d) {
                                    int y;
                                    final FirmwareTestViewModel z;
                                };
                            }
                            
                            public final Object invoke(final M m, final P8.d d) {
                                return ((FirmwareTestViewModel$f)this.create(m, d)).invokeSuspend(K8.M.a);
                            }
                            
                            public final Object invokeSuspend(final Object o) {
                                b.f();
                                if (this.y == 0) {
                                    K8.x.b(o);
                                    return this.z.startDeviceConnectionTimeout();
                                }
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        }, 3, (Object)null);
                        firmwareTestViewModel2.getLog("waiting to receive fw");
                        Log.d(tag3, "waiting to receive fw");
                        final d deviceFwVersionChannel2 = firmwareTestViewModel2.deviceFwVersionChannel;
                        if (deviceFwVersionChannel2 == null) {
                            deviceFirmware5 = null;
                            o21 = b10;
                            break Label_2805;
                        }
                        ((FirmwareTestViewModel$c)o).y = firmwareTestViewModel2;
                        ((FirmwareTestViewModel$c)o).z = z3;
                        ((FirmwareTestViewModel$c)o).A = a;
                        ((FirmwareTestViewModel$c)o).B = o9;
                        ((FirmwareTestViewModel$c)o).C = c2;
                        ((FirmwareTestViewModel$c)o).H = h;
                        ((FirmwareTestViewModel$c)o).L = b10;
                        ((FirmwareTestViewModel$c)o).Q = q;
                        ((FirmwareTestViewModel$c)o).W = w2;
                        ((FirmwareTestViewModel$c)o).X = x2;
                        ((FirmwareTestViewModel$c)o).b0 = 4;
                        final Object g3 = ((k9.t)deviceFwVersionChannel2).g((P8.d)o);
                        o12 = o10;
                        o13 = g3;
                        o11 = b10;
                        if (g3 == o10) {
                            return o10;
                        }
                    }
                    final DeviceFirmware deviceFirmware6 = (DeviceFirmware)o13;
                    o21 = o11;
                    deviceFirmware5 = deviceFirmware6;
                    o10 = o12;
                }
                n11 = w2;
                final StringBuilder sb9 = new StringBuilder();
                sb9.append("received fw=");
                sb9.append((Object)deviceFirmware5);
                firmwareTestViewModel2.getLog(sb9.toString());
                final String tag4 = FirmwareTestViewModel.TAG;
                final StringBuilder sb10 = new StringBuilder();
                sb10.append("received fw=");
                sb10.append((Object)deviceFirmware5);
                Log.d(tag4, sb10.toString());
                firmwareTestViewModel2.disconnectDevice();
                if (deviceFirmware5 == null) {
                    final FirmwareTestItem firmwareTestItem2 = (FirmwareTestItem)firmwareTestViewModel2.currentTestItem.getValue();
                    if (firmwareTestItem2 != null) {
                        kotlin.coroutines.jvm.internal.b.a(((List)o9).add((Object)FirmwareTestItem.copy$default(firmwareTestItem2, 0L, FirmwareTestItem$FirmwareTestResult.ONLINE_TIMEOUT, 0L, 0L, (Integer)null, (Uri)null, (DeviceFirmware)null, (DeviceFirmware)null, 253, (Object)null)));
                    }
                    firmwareTestViewModel2.getLog(s13);
                    Log.d(tag4, s13);
                    firmwareTestViewModel2.firmwareCaseItems.setValue(o9);
                    return K8.M.a;
                }
                final String s32 = s12;
                firmwareTestViewModel2.getLog(s32);
                Log.d(tag4, s32);
                final String s33 = s17;
                z0$a.b((z0)o21, (CancellationException)null, 1, (Object)null);
                firmwareTestViewModel2.delayMutableState.setValue((Object)kotlin.coroutines.jvm.internal.b.f(0L));
                final FirmwareTestItem firmwareTestItem3 = (FirmwareTestItem)firmwareTestViewModel2.currentTestItem.getValue();
                if (firmwareTestItem3 != null) {
                    ((List)o9).add((Object)FirmwareTestItem.copy$default(firmwareTestItem3, 0L, (FirmwareTestItem$FirmwareTestResult)null, 0L, System.currentTimeMillis(), (Integer)null, (Uri)null, (DeviceFirmware)null, deviceFirmware5, 119, (Object)null));
                    firmwareTestViewModel2.getLog(s11);
                    Log.d(tag4, s11);
                    final K8.M a2 = K8.M.a;
                }
                final String s34 = s11;
                final int n13 = x2;
                final FirmwareTestConfig firmwareTestConfig7 = z3;
                ObservableDevice c3 = c2;
                String s7 = a;
                final List list4 = (List)o9;
                s25 = s13;
                s30 = s33;
                n12 = h;
                int n = q;
                n3 = n13;
                s24 = s32;
                d5 = (P8.d)o;
                o20 = list4;
                o19 = o10;
                s29 = s34;
                firmwareTestConfig2 = firmwareTestConfig7;
            }
            firmwareTestViewModel2.firmwareCaseItems.setValue((Object)t.X0((Collection)o20));
            final Integer count2 = firmwareTestConfig2.getCount();
            if (count2 != null && n11 == count2) {
                firmwareTestViewModel2.getLog(s15);
                Log.d(FirmwareTestViewModel.TAG, s15);
            }
            else {
                firmwareTestViewModel2.messageList.setValue((Object)t.n());
                if (n11 != n3) {
                    ++n11;
                    final Object o22 = o19;
                    s2 = s15;
                    final String s35 = s24;
                    s6 = s30;
                    final FirmwareTestViewModel y2 = firmwareTestViewModel2;
                    s3 = s29;
                    s4 = s35;
                    s5 = s25;
                    final Object b4 = o20;
                    f = o22;
                    final Object o15 = d5;
                    final int x = n3;
                    final int w3 = n11;
                    final Integer h2 = n12;
                    continue;
                }
            }
            break;
        }
        return K8.M.a;
    }
    
    private final z0 updateConnection() {
        return i.d(this.connectDeviceScope, (P8.g)null, (i9.O)null, (p)new p(this, null) {
            int y;
            final FirmwareTestViewModel z;
            
            public final P8.d create(final Object o, final P8.d d) {
                return (P8.d)new p(this.z, d) {
                    int y;
                    final FirmwareTestViewModel z;
                };
            }
            
            public final Object invoke(final M m, final P8.d d) {
                return ((FirmwareTestViewModel$g)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(final Object o) {
                b.f();
                if (this.y != 0) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                K8.x.b(o);
                final FirmwareTestViewModel.FirmwareTestViewModel$Companion companion = FirmwareTestViewModel.Companion;
                final String tag = companion.getTAG();
                final String access$getMacToConnect$p = FirmwareTestViewModel.access$getMacToConnect$p(this.z);
                final StringBuilder sb = new StringBuilder();
                sb.append("updateConnection macToConnect=");
                sb.append(access$getMacToConnect$p);
                Log.d(tag, sb.toString());
                final d access$getDeviceFwVersionChannel$p = FirmwareTestViewModel.access$getDeviceFwVersionChannel$p(this.z);
                if (access$getDeviceFwVersionChannel$p == null) {
                    return K8.M.a;
                }
                final String access$getMacToConnect$p2 = FirmwareTestViewModel.access$getMacToConnect$p(this.z);
                if (access$getMacToConnect$p2 == null) {
                    return K8.M.a;
                }
                final UserDeviceItem userDeviceItem = this.z.getDeviceManager().getUserDeviceItem(access$getMacToConnect$p2);
                if (userDeviceItem == null) {
                    return K8.M.a;
                }
                final DeviceConnection deviceConnection = this.z.getDeviceConnection();
                if (deviceConnection != null && deviceConnection.getConnectionState() != DeviceConnectionState.CLOSED) {
                    final DeviceFirmware deviceFirmware = deviceConnection.getDeviceFirmware();
                    if (deviceFirmware != null) {
                        final String tag2 = companion.getTAG();
                        final StringBuilder sb2 = new StringBuilder();
                        sb2.append("updateConnection - already created - fw=");
                        sb2.append((Object)deviceFirmware);
                        Log.d(tag2, sb2.toString());
                        try {
                            ((u)access$getDeviceFwVersionChannel$p).i((Object)deviceFirmware);
                        }
                        catch (final Exception ex) {
                            Log.e(FirmwareTestViewModel.Companion.getTAG(), "failed to send fw", (Throwable)ex);
                        }
                    }
                }
                else {
                    Log.d(companion.getTAG(), "updateConnection - create new");
                    final DeviceConnection connection$default = DeviceManager.getConnection$default(this.z.getDeviceManager(), userDeviceItem.getUserDevice().getMac(), userDeviceItem.getUserDevice().getDeviceToken(), FirmwareTestViewModel.access$getConnectionCallback$p(this.z), kotlin.coroutines.jvm.internal.b.a(true), (Boolean)null, false, false, t.q((Object[])new Class[] { UdpTransport.INSTANCE.getClass(), BleTransport.INSTANCE.getClass() }), kotlin.coroutines.jvm.internal.b.a(true), (Boolean)null, 624, (Object)null);
                    FirmwareTestViewModel.access$setDeviceConnection$p(this.z, connection$default);
                    DeviceFirmware deviceFirmware2;
                    if (connection$default != null) {
                        deviceFirmware2 = connection$default.getDeviceFirmware();
                    }
                    else {
                        deviceFirmware2 = null;
                    }
                    final String tag3 = companion.getTAG();
                    final StringBuilder sb3 = new StringBuilder();
                    sb3.append("updateConnection - create - fw=");
                    sb3.append((Object)deviceFirmware2);
                    Log.d(tag3, sb3.toString());
                    if (deviceFirmware2 != null) {
                        try {
                            ((u)access$getDeviceFwVersionChannel$p).i((Object)deviceFirmware2);
                        }
                        catch (final Exception ex2) {
                            Log.e(FirmwareTestViewModel.Companion.getTAG(), "failed to send fw", (Throwable)ex2);
                        }
                    }
                }
                return K8.M.a;
            }
        }, 3, (Object)null);
    }
    
    public void connect() {
    }
    
    public void disconnect() {
        this.closeFirmwareManager();
        this.disconnectDevice();
    }
    
    public final ApiService getApiService() {
        return this.apiService;
    }
    
    public final t0 getCurrentTestItem() {
        return this.currentTestItem;
    }
    
    public final t0 getDelayMutableState() {
        return this.delayMutableState;
    }
    
    public final DeviceConnection getDeviceConnection() {
        return this.deviceConnection;
    }
    
    public final DeviceManager getDeviceManager() {
        return this.deviceManager;
    }
    
    public final t0 getFirmwareCaseItems() {
        return this.firmwareCaseItems;
    }
    
    public final t0 getFirmwareConfig() {
        return this.firmwareConfig;
    }
    
    public final l9.M getFirmwareFlow() {
        return this.firmwareFlow;
    }
    
    public final J getFirstFileUri() {
        return this.firstFileUri;
    }
    
    public final void getLogFile(final Uri uri) {
        v.j((Object)uri, "uri");
        final Locale english = Locale.ENGLISH;
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("M/d:HH:mm:ss", english);
        final SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("mm:ss", english);
        final OutputStream openOutputStream = ((Context)this.appContext).getContentResolver().openOutputStream(uri);
        v.h((Object)openOutputStream, "null cannot be cast to non-null type java.io.FileOutputStream");
        final FileOutputStream fileOutputStream = (FileOutputStream)openOutputStream;
        Label_0824: {
            List list = null;
            Charset utf_8 = null;
            String title = null;
            Label_0209: {
                try {
                    list = (List)this.firmwareCaseItems.getValue();
                    if (list.isEmpty()) {
                        return;
                    }
                    final Date date = new Date();
                    final StringBuilder sb = new StringBuilder();
                    sb.append("\n\nFirmware testing  from ");
                    sb.append((Object)date);
                    sb.append("\n\n");
                    final String string = sb.toString();
                    utf_8 = StandardCharsets.UTF_8;
                    v.i((Object)utf_8, "UTF_8");
                    final byte[] bytes = string.getBytes(utf_8);
                    v.i((Object)bytes, "getBytes(...)");
                    fileOutputStream.write(bytes);
                    final String testingMac = this.testingMac;
                    if (testingMac != null) {
                        final UserDeviceItem userDeviceItem = this.deviceManager.getUserDeviceItem(testingMac);
                        if (userDeviceItem != null) {
                            final UserDevice userDevice = userDeviceItem.getUserDevice();
                            if (userDevice != null) {
                                title = userDevice.getTitle();
                                break Label_0209;
                            }
                        }
                    }
                }
                catch (final Exception ex) {
                    break Label_0824;
                }
                title = null;
            }
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("\n\nTest cases for ");
            sb2.append(title);
            sb2.append(" \n\n");
            final String string2 = sb2.toString();
            v.i((Object)utf_8, "UTF_8");
            final byte[] bytes2 = string2.getBytes(utf_8);
            v.i((Object)bytes2, "getBytes(...)");
            fileOutputStream.write(bytes2);
            for (final FirmwareTestItem firmwareTestItem : (Iterable)list) {
                final String format = ((DateFormat)simpleDateFormat).format(new Date(firmwareTestItem.getStartTime()));
                final FirmwareTestItem$FirmwareTestResult testResult = firmwareTestItem.getTestResult();
                String name;
                if (testResult != null) {
                    name = ((Enum)testResult).name();
                }
                else {
                    name = null;
                }
                final Integer percentageCompleted = firmwareTestItem.getPercentageCompleted();
                final StringBuilder sb3 = new StringBuilder();
                sb3.append("update start ");
                sb3.append(format);
                sb3.append(" ");
                sb3.append(name);
                sb3.append(" ");
                sb3.append((Object)percentageCompleted);
                sb3.append("% ");
                final String string3 = sb3.toString();
                final Charset utf_9 = StandardCharsets.UTF_8;
                v.i((Object)utf_9, "UTF_8");
                final byte[] bytes3 = string3.getBytes(utf_9);
                v.i((Object)bytes3, "getBytes(...)");
                fileOutputStream.write(bytes3);
                final DeviceFirmware oldFirmware = firmwareTestItem.getOldFirmware();
                final DeviceFirmware newFirmware = firmwareTestItem.getNewFirmware();
                final StringBuilder sb4 = new StringBuilder();
                sb4.append("old ");
                sb4.append((Object)oldFirmware);
                sb4.append(" new ");
                sb4.append((Object)newFirmware);
                sb4.append(" \n");
                final String string4 = sb4.toString();
                v.i((Object)utf_9, "UTF_8");
                final byte[] bytes4 = string4.getBytes(utf_9);
                v.i((Object)bytes4, "getBytes(...)");
                fileOutputStream.write(bytes4);
                final String format2 = ((DateFormat)simpleDateFormat2).format(new Date(firmwareTestItem.getEndTime() - firmwareTestItem.getStartTime()));
                final String format3 = ((DateFormat)simpleDateFormat2).format(new Date(firmwareTestItem.getOnlineTime() - firmwareTestItem.getEndTime()));
                final StringBuilder sb5 = new StringBuilder();
                sb5.append("updateTime ");
                sb5.append(format2);
                sb5.append(" came online after ");
                sb5.append(format3);
                final String string5 = sb5.toString();
                v.i((Object)utf_9, "UTF_8");
                final byte[] bytes5 = string5.getBytes(utf_9);
                v.i((Object)bytes5, "getBytes(...)");
                fileOutputStream.write(bytes5);
                final Uri targetFirmware = firmwareTestItem.getTargetFirmware();
                if (targetFirmware != null) {
                    final String fileName = FileUtils.INSTANCE.getFileName((Context)this.appContext, targetFirmware);
                    final StringBuilder sb6 = new StringBuilder();
                    sb6.append("target firmware ");
                    sb6.append(fileName);
                    sb6.append(" \n");
                    final String string6 = sb6.toString();
                    v.i((Object)utf_9, "UTF_8");
                    final byte[] bytes6 = string6.getBytes(utf_9);
                    v.i((Object)bytes6, "getBytes(...)");
                    fileOutputStream.write(bytes6);
                }
            }
            ((OutputStream)fileOutputStream).flush();
            fileOutputStream.close();
            return;
        }
        final Exception ex;
        Log.e(FirmwareTestViewModel.TAG, "failed to read firmware file from storage", (Throwable)ex);
    }
    
    public final t0 getMessageList() {
        return this.messageList;
    }
    
    public final J getSecondFileUri() {
        return this.secondFileUri;
    }
    
    public final Device getTestingDevice() {
        return this.testingDevice;
    }
    
    public final String getTestingMac() {
        return this.testingMac;
    }
    
    public final ObservableDevice getTestingObsDevice() {
        return this.testingObsDevice;
    }
    
    public final t0 getTestingState() {
        return this.testingState;
    }
    
    public final Uri getUri() {
        return this.uri;
    }
    
    public final void pickedFile(final FirmwareTestViewModel.FirmwareTestViewModel$FileName firmwareTestViewModel$FileName) {
        v.j((Object)firmwareTestViewModel$FileName, "file");
        final int n = FirmwareTestViewModel.FirmwareTestViewModel$WhenMappings.$EnumSwitchMapping$0[((Enum)firmwareTestViewModel$FileName).ordinal()];
        if (n != 1) {
            if (n == 2) {
                this.secondFileUri.setValue((Object)this.uri);
                final t0 firmwareConfig = this.firmwareConfig;
                final FirmwareTestConfig firmwareTestConfig = (FirmwareTestConfig)firmwareConfig.getValue();
                if (firmwareTestConfig != null) {
                    final FirmwareTestConfig copy$default = FirmwareTestConfig.copy$default(firmwareTestConfig, (Uri)null, this.uri, 0L, 0, (Integer)null, 29, (Object)null);
                    if (copy$default != null) {
                        firmwareConfig.setValue((Object)copy$default);
                    }
                }
            }
        }
        else {
            this.firstFileUri.setValue((Object)this.uri);
            final t0 firmwareConfig2 = this.firmwareConfig;
            final FirmwareTestConfig firmwareTestConfig2 = (FirmwareTestConfig)firmwareConfig2.getValue();
            if (firmwareTestConfig2 != null) {
                final FirmwareTestConfig copy$default2 = FirmwareTestConfig.copy$default(firmwareTestConfig2, this.uri, (Uri)null, 0L, 0, (Integer)null, 30, (Object)null);
                if (copy$default2 != null) {
                    firmwareConfig2.setValue((Object)copy$default2);
                }
            }
        }
    }
    
    public final void setCurrentTestItem(final t0 currentTestItem) {
        v.j((Object)currentTestItem, "<set-?>");
        this.currentTestItem = currentTestItem;
    }
    
    public final void setDelayMutableState(final t0 delayMutableState) {
        v.j((Object)delayMutableState, "<set-?>");
        this.delayMutableState = delayMutableState;
    }
    
    public final void setFirmwareConfig(final t0 firmwareConfig) {
        v.j((Object)firmwareConfig, "<set-?>");
        this.firmwareConfig = firmwareConfig;
    }
    
    public final void setFirstFileUri(final J firstFileUri) {
        v.j((Object)firstFileUri, "<set-?>");
        this.firstFileUri = firstFileUri;
    }
    
    public final void setSecondFileUri(final J secondFileUri) {
        v.j((Object)secondFileUri, "<set-?>");
        this.secondFileUri = secondFileUri;
    }
    
    public final void setTestingDevice(final Device testingDevice) {
        this.testingDevice = testingDevice;
    }
    
    public final void setTestingMac(final String testingMac) {
        this.testingMac = testingMac;
    }
    
    public final void setTestingObsDevice(final ObservableDevice testingObsDevice) {
        this.testingObsDevice = testingObsDevice;
    }
    
    public final void setUri(final Uri uri) {
        this.uri = uri;
    }
    
    public final void startTesting(final String s) {
        v.j((Object)s, "mac");
        this.testingJob = this.startFirmwareTests(s);
        this.firmwareCaseItems.setValue((Object)t.n());
    }
    
    public final void stopTesting() {
        final z0 testingJob = this.testingJob;
        final Integer n = null;
        if (testingJob != null) {
            z0$a.b(testingJob, (CancellationException)null, 1, (Object)null);
        }
        this.testingJob = null;
        final FirmwareTestConfig firmwareTestConfig = (FirmwareTestConfig)this.firmwareConfig.getValue();
        final int n2 = 0;
        int intValue = 0;
        Label_0071: {
            if (firmwareTestConfig != null) {
                final Integer count = firmwareTestConfig.getCount();
                if (count != null) {
                    intValue = count;
                    break Label_0071;
                }
            }
            intValue = 0;
        }
        if (intValue > ((List)this.firmwareCaseItems.getValue()).size()) {
            final FirmwareTestConfig firmwareTestConfig2 = (FirmwareTestConfig)this.firmwareConfig.getValue();
            Integer value = n;
            if (firmwareTestConfig2 != null) {
                final Integer count2 = firmwareTestConfig2.getCount();
                value = n;
                if (count2 != null) {
                    value = count2 - ((List)this.firmwareCaseItems.getValue()).size();
                }
            }
            final ArrayList value2 = new ArrayList();
            ((List)value2).addAll((Collection)this.firmwareCaseItems.getValue());
            if (value != null) {
                final long currentTimeMillis = System.currentTimeMillis();
                for (int intValue2 = value, i = n2; i < intValue2; ++i) {
                    ((List)value2).add((Object)new FirmwareTestItem(currentTimeMillis, FirmwareTestItem$FirmwareTestResult.CANCELLED, currentTimeMillis, 0L, (Integer)null, (Uri)null, (DeviceFirmware)null, (DeviceFirmware)null, 248, (m)null));
                }
            }
            this.firmwareCaseItems.setValue((Object)value2);
        }
        this.testingState.setValue((Object)TestingState.INITIAL);
        this.messageList.setValue((Object)t.n());
    }
}
