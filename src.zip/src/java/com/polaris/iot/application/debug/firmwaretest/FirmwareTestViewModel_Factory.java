package com.polaris.iot.application.debug.firmwaretest;

import android.app.Application;
import com.syncleoiot.core.api.ApiService;
import com.syncleoiot.core.api.DeviceManager;
import I8.a;
import A8.b;

public final class FirmwareTestViewModel_Factory implements b
{
    private final a apiServiceProvider;
    private final a appContextProvider;
    private final a deviceManagerProvider;
    
    public FirmwareTestViewModel_Factory(final a deviceManagerProvider, final a apiServiceProvider, final a appContextProvider) {
        this.deviceManagerProvider = deviceManagerProvider;
        this.apiServiceProvider = apiServiceProvider;
        this.appContextProvider = appContextProvider;
    }
    
    public static FirmwareTestViewModel_Factory create(final a a, final a a2, final a a3) {
        return new FirmwareTestViewModel_Factory(a, a2, a3);
    }
    
    public static FirmwareTestViewModel newInstance(final DeviceManager deviceManager, final ApiService apiService, final Application application) {
        return new FirmwareTestViewModel(deviceManager, apiService, application);
    }
    
    public FirmwareTestViewModel get() {
        return newInstance((DeviceManager)this.deviceManagerProvider.get(), (ApiService)this.apiServiceProvider.get(), (Application)this.appContextProvider.get());
    }
}
