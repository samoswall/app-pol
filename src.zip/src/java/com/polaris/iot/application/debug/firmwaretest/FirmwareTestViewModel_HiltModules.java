package com.polaris.iot.application.debug.firmwaretest;

import androidx.lifecycle.e0;

public final class FirmwareTestViewModel_HiltModules
{
    private FirmwareTestViewModel_HiltModules() {
    }
    
    public abstract static class BindsModule
    {
        private BindsModule() {
        }
        
        public abstract e0 binds(final FirmwareTestViewModel p0);
    }
    
    public static final class KeyModule
    {
        private KeyModule() {
        }
        
        public static boolean provide() {
            return true;
        }
    }
}
