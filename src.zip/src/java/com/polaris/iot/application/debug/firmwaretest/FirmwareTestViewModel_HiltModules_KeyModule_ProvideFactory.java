package com.polaris.iot.application.debug.firmwaretest;

import A8.b;

public final class FirmwareTestViewModel_HiltModules_KeyModule_ProvideFactory implements b
{
    public static FirmwareTestViewModel_HiltModules_KeyModule_ProvideFactory create() {
        return a.a;
    }
    
    public static boolean provide() {
        return FirmwareTestViewModel_HiltModules.KeyModule.provide();
    }
    
    public Boolean get() {
        return provide();
    }
    
    private abstract static final class a
    {
        private static final FirmwareTestViewModel_HiltModules_KeyModule_ProvideFactory a;
        
        static {
            a = new FirmwareTestViewModel_HiltModules_KeyModule_ProvideFactory();
        }
    }
}
