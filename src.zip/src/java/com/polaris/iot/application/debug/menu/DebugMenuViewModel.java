package com.polaris.iot.application.debug.menu;

import i9.O;
import P8.g;
import i9.i;
import K8.x;
import Q8.b;
import i9.M;
import P8.d;
import kotlin.coroutines.jvm.internal.l;
import X8.p;
import androidx.lifecycle.f0;
import i9.z0;
import L8.t;
import kotlin.jvm.internal.v;
import java.util.List;
import com.syncleoiot.core.data.dataStore.AppDataStore;
import com.syncleoiot.core.data.dataStore.entities.PrimitiveDataStoreEntity;
import androidx.lifecycle.e0;

public final class DebugMenuViewModel extends e0
{
    public static final int $stable = 8;
    private final boolean accessLevelMenuEnabled;
    private final PrimitiveDataStoreEntity<Boolean> accessLevelOptions;
    private final boolean accessMockMenuEnabled;
    private final boolean autoConnectMenuEnabled;
    private final PrimitiveDataStoreEntity<Boolean> autoConnectOption;
    private final PrimitiveDataStoreEntity<Boolean> betaFirmware;
    private final AppDataStore dataStore;
    private final PrimitiveDataStoreEntity<Boolean> debugEnableCustomizedTransportOption;
    private final PrimitiveDataStoreEntity<Boolean> deviceHiddenVendor;
    private final boolean deviceTestingMenuEnabled;
    private final PrimitiveDataStoreEntity<Boolean> deviceTestingOption;
    private final PrimitiveDataStoreEntity<Boolean> enableDebugOption;
    private final boolean hiddenDeviceMenuEnabled;
    private final PrimitiveDataStoreEntity<Boolean> hiddenDeviceOptions;
    private final boolean hiddenVendorMenuEnabled;
    private final boolean logsMenuEnabled;
    private final PrimitiveDataStoreEntity<Boolean> mockMenuOption;
    private final PrimitiveDataStoreEntity<Boolean> saveDemoDevices;
    private final boolean transportMenuEnabled;
    private final List<PrimitiveDataStoreEntity<Boolean>> transportOptions;
    
    public DebugMenuViewModel(final AppDataStore dataStore) {
        v.j((Object)dataStore, "dataStore");
        this.dataStore = dataStore;
        this.enableDebugOption = (PrimitiveDataStoreEntity<Boolean>)dataStore.getKeyDebugEnable();
        this.betaFirmware = (PrimitiveDataStoreEntity<Boolean>)dataStore.getKeyDebugEnableBetaFirmware();
        this.accessLevelOptions = (PrimitiveDataStoreEntity<Boolean>)dataStore.getKeyDebugIgnoreAccessLevel();
        this.mockMenuOption = (PrimitiveDataStoreEntity<Boolean>)dataStore.getKeyDebugMockState();
        this.autoConnectOption = (PrimitiveDataStoreEntity<Boolean>)dataStore.getKeyDebugAutoConnect();
        this.hiddenDeviceOptions = (PrimitiveDataStoreEntity<Boolean>)dataStore.getKeyShowHiddenDevices();
        this.deviceHiddenVendor = (PrimitiveDataStoreEntity<Boolean>)dataStore.getKeyShowHiddenVendors();
        this.deviceTestingOption = (PrimitiveDataStoreEntity<Boolean>)dataStore.getKeyDebugDeviceTesting();
        this.saveDemoDevices = (PrimitiveDataStoreEntity<Boolean>)dataStore.getKeyDebugSaveDemoDevices();
        this.debugEnableCustomizedTransportOption = (PrimitiveDataStoreEntity<Boolean>)dataStore.getKeyDebugEnableCustomizedTransport();
        this.transportOptions = (List<PrimitiveDataStoreEntity<Boolean>>)t.q((Object[])new PrimitiveDataStoreEntity[] { dataStore.getKeyDebugEnableMqtt(), dataStore.getKeyDebugEnableBle(), dataStore.getKeyDebugEnableEvo(), dataStore.getKeyDebugEnableUdp(), dataStore.getKeyDebugEnableDemo(), dataStore.getKeyDebugEnableIpv4(), dataStore.getKeyDebugEnableIpv6() });
        this.deviceTestingMenuEnabled = (boolean)dataStore.getMenuDeviceTesting().getValue();
        this.accessMockMenuEnabled = (boolean)dataStore.getMenuMock().getValue();
        this.hiddenVendorMenuEnabled = (boolean)dataStore.getMenuHiddenVendor().getValue();
        this.hiddenDeviceMenuEnabled = (boolean)dataStore.getMenuHiddenDevices().getValue();
        this.autoConnectMenuEnabled = (boolean)dataStore.getMenuAutoConnect().getValue();
        this.logsMenuEnabled = (boolean)dataStore.getMenuDebugLogs().getValue();
        this.accessLevelMenuEnabled = (boolean)dataStore.getMenuAccessLevel().getValue();
        this.transportMenuEnabled = (boolean)dataStore.getMenuTransport().getValue();
    }
    
    public static final /* synthetic */ AppDataStore access$getDataStore$p(final DebugMenuViewModel debugMenuViewModel) {
        return debugMenuViewModel.dataStore;
    }
    
    public final z0 disableAllOptions() {
        return i.d(f0.a((e0)this), (g)null, (O)null, (p)new p(this, null) {
            int y;
            final DebugMenuViewModel z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.z, d) {
                    int y;
                    final DebugMenuViewModel z;
                };
            }
            
            public final Object invoke(final M m, final d d) {
                return ((DebugMenuViewModel$a)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(final Object o) {
                final Object f = b.f();
                final int y = this.y;
                if (y != 0) {
                    if (y != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    x.b(o);
                }
                else {
                    x.b(o);
                    final AppDataStore access$getDataStore$p = DebugMenuViewModel.access$getDataStore$p(this.z);
                    this.y = 1;
                    if (access$getDataStore$p.switchAllDebugOptions(false, (d)this) == f) {
                        return f;
                    }
                }
                return K8.M.a;
            }
        }, 3, (Object)null);
    }
    
    public final boolean getAccessLevelMenuEnabled() {
        return this.accessLevelMenuEnabled;
    }
    
    public final PrimitiveDataStoreEntity<Boolean> getAccessLevelOptions() {
        return this.accessLevelOptions;
    }
    
    public final boolean getAccessMockMenuEnabled() {
        return this.accessMockMenuEnabled;
    }
    
    public final boolean getAutoConnectMenuEnabled() {
        return this.autoConnectMenuEnabled;
    }
    
    public final PrimitiveDataStoreEntity<Boolean> getAutoConnectOption() {
        return this.autoConnectOption;
    }
    
    public final PrimitiveDataStoreEntity<Boolean> getBetaFirmware() {
        return this.betaFirmware;
    }
    
    public final PrimitiveDataStoreEntity<Boolean> getDebugEnableCustomizedTransportOption() {
        return this.debugEnableCustomizedTransportOption;
    }
    
    public final PrimitiveDataStoreEntity<Boolean> getDeviceHiddenVendor() {
        return this.deviceHiddenVendor;
    }
    
    public final boolean getDeviceTestingMenuEnabled() {
        return this.deviceTestingMenuEnabled;
    }
    
    public final PrimitiveDataStoreEntity<Boolean> getDeviceTestingOption() {
        return this.deviceTestingOption;
    }
    
    public final PrimitiveDataStoreEntity<Boolean> getEnableDebugOption() {
        return this.enableDebugOption;
    }
    
    public final boolean getHiddenDeviceMenuEnabled() {
        return this.hiddenDeviceMenuEnabled;
    }
    
    public final PrimitiveDataStoreEntity<Boolean> getHiddenDeviceOptions() {
        return this.hiddenDeviceOptions;
    }
    
    public final boolean getHiddenVendorMenuEnabled() {
        return this.hiddenVendorMenuEnabled;
    }
    
    public final boolean getLogsMenuEnabled() {
        return this.logsMenuEnabled;
    }
    
    public final PrimitiveDataStoreEntity<Boolean> getMockMenuOption() {
        return this.mockMenuOption;
    }
    
    public final PrimitiveDataStoreEntity<Boolean> getSaveDemoDevices() {
        return this.saveDemoDevices;
    }
    
    public final boolean getTransportMenuEnabled() {
        return this.transportMenuEnabled;
    }
    
    public final List<PrimitiveDataStoreEntity<Boolean>> getTransportOptions() {
        return this.transportOptions;
    }
}
