package com.polaris.iot.application.debug.menu;

import com.syncleoiot.core.data.dataStore.AppDataStore;
import I8.a;
import A8.b;

public final class DebugMenuViewModel_Factory implements b
{
    private final a dataStoreProvider;
    
    public DebugMenuViewModel_Factory(final a dataStoreProvider) {
        this.dataStoreProvider = dataStoreProvider;
    }
    
    public static DebugMenuViewModel_Factory create(final a a) {
        return new DebugMenuViewModel_Factory(a);
    }
    
    public static DebugMenuViewModel newInstance(final AppDataStore appDataStore) {
        return new DebugMenuViewModel(appDataStore);
    }
    
    public DebugMenuViewModel get() {
        return newInstance((AppDataStore)this.dataStoreProvider.get());
    }
}
