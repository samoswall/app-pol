package com.polaris.iot.application.debug.menu;

import androidx.lifecycle.e0;

public final class DebugMenuViewModel_HiltModules
{
    private DebugMenuViewModel_HiltModules() {
    }
    
    public abstract static class BindsModule
    {
        private BindsModule() {
        }
        
        public abstract e0 binds(final DebugMenuViewModel p0);
    }
    
    public static final class KeyModule
    {
        private KeyModule() {
        }
        
        public static boolean provide() {
            return true;
        }
    }
}
