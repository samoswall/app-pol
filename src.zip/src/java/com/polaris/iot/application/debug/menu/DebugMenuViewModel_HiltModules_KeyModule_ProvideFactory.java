package com.polaris.iot.application.debug.menu;

import A8.b;

public final class DebugMenuViewModel_HiltModules_KeyModule_ProvideFactory implements b
{
    public static DebugMenuViewModel_HiltModules_KeyModule_ProvideFactory create() {
        return a.a;
    }
    
    public static boolean provide() {
        return DebugMenuViewModel_HiltModules.KeyModule.provide();
    }
    
    public Boolean get() {
        return provide();
    }
    
    private abstract static final class a
    {
        private static final DebugMenuViewModel_HiltModules_KeyModule_ProvideFactory a;
        
        static {
            a = new DebugMenuViewModel_HiltModules_KeyModule_ProvideFactory();
        }
    }
}
