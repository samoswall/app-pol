package com.polaris.iot.application.device.acl;

import l9.w;
import com.syncleoiot.core.data.db.entity.UserDevice$AccessLevel;
import java.util.List;
import com.syncleoiot.core.api.commands.CmdAccessControl;
import kotlin.coroutines.jvm.internal.l;
import X8.p;
import i9.z0;
import android.database.Cursor;
import android.content.ContentResolver;
import com.syncleoiot.core.data.model.ContactsUser;
import android.provider.ContactsContract$CommonDataKinds$Phone;
import android.provider.ContactsContract$Contacts;
import java.util.ArrayList;
import com.syncleoiot.core.domain.device.acl.AccessControlObject;
import K8.s;
import com.syncleoiot.core.domain.core.objects.Either$Right;
import com.syncleoiot.core.domain.core.failures.CommonFailure;
import com.syncleoiot.core.domain.core.objects.Either$Left;
import com.syncleoiot.core.domain.core.objects.Either;
import Q8.b;
import androidx.core.content.a;
import P8.d;
import l9.H$a;
import l9.H;
import androidx.lifecycle.f0;
import i9.c0;
import java.util.Collection;
import l9.g;
import L8.t;
import l9.i;
import l9.O;
import kotlin.jvm.internal.v;
import com.syncleoiot.core.domain.profile.ProfileRepository;
import X8.r;
import android.content.Context;
import l9.M;
import com.syncleoiot.core.domain.device.acl.AccessControlRepository;
import l9.x;
import androidx.lifecycle.e0;

public final class AccessControlViewModel extends e0
{
    public static final int $stable = 8;
    private final x _aclState;
    private final x _isLoading;
    private final AccessControlRepository accessControlRepository;
    private final M aclState;
    private final M aclUsers;
    private final Context appContext;
    private final x contactsList;
    private boolean isInitialized;
    private final M isLoading;
    private String mac;
    private final M profile;
    public r sendCommands;
    
    public AccessControlViewModel(final Context appContext, final ProfileRepository profileRepository, final AccessControlRepository accessControlRepository) {
        v.j((Object)appContext, "appContext");
        v.j((Object)profileRepository, "profileRepository");
        v.j((Object)accessControlRepository, "accessControlRepository");
        this.appContext = appContext;
        this.accessControlRepository = accessControlRepository;
        this.mac = "";
        final x a = O.a((Object)null);
        this._aclState = a;
        this.aclState = (M)a;
        final x a2 = O.a((Object)Boolean.FALSE);
        this._isLoading = a2;
        this.isLoading = i.b(a2);
        final x a3 = O.a((Object)t.n());
        this.contactsList = a3;
        final M result = profileRepository.getUserProfileState().getResult();
        this.profile = result;
        this.aclUsers = i.K(i.A((g)new AccessControlViewModel$special$$inlined$map.AccessControlViewModel$special$$inlined$map$1(i.l((g)new AccessControlViewModel$special$$inlined$combine.AccessControlViewModel$special$$inlined$combine$1((g[])((Collection)t.U0((Iterable)t.q((Object[])new M[] { (M)a3, (M)a, result }))).toArray((Object[])new g[0])))), (P8.g)c0.b()), f0.a((e0)this), H$a.b(H.a, 0L, 0L, 3, (Object)null), (Object)t.n());
    }
    
    public static final /* synthetic */ AccessControlRepository access$getAccessControlRepository$p(final AccessControlViewModel accessControlViewModel) {
        return accessControlViewModel.accessControlRepository;
    }
    
    public static final /* synthetic */ String access$getMac$p(final AccessControlViewModel accessControlViewModel) {
        return accessControlViewModel.mac;
    }
    
    public static final /* synthetic */ x access$get_aclState$p(final AccessControlViewModel accessControlViewModel) {
        return accessControlViewModel._aclState;
    }
    
    public static final /* synthetic */ x access$get_isLoading$p(final AccessControlViewModel accessControlViewModel) {
        return accessControlViewModel._isLoading;
    }
    
    private final boolean getHasContactsPermission() {
        return a.checkSelfPermission(this.appContext, "android.permission.READ_CONTACTS") == 0;
    }
    
    private final Object loadAclState(final d d) {
        kotlin.coroutines.jvm.internal.d d2 = null;
        Label_0045: {
            if (d instanceof AccessControlViewModel$b) {
                d2 = (AccessControlViewModel$b)d;
                final int c = d2.C;
                if ((c & Integer.MIN_VALUE) != 0x0) {
                    d2.C = c + Integer.MIN_VALUE;
                    break Label_0045;
                }
            }
            d2 = new kotlin.coroutines.jvm.internal.d(this, d) {
                Object A;
                final AccessControlViewModel B;
                int C;
                Object y;
                Object z;
                
                public final Object invokeSuspend(final Object a) {
                    this.A = a;
                    this.C |= Integer.MIN_VALUE;
                    return this.B.loadAclState((d)this);
                }
            };
        }
        Object o = d2.A;
        final Object f = b.f();
        final int c2 = d2.C;
        AccessControlViewModel accessControlViewModel = null;
        Either z = null;
        Label_0312: {
            while (true) {
                Label_0211: {
                    if (c2 != 0) {
                        if (c2 == 1) {
                            accessControlViewModel = (AccessControlViewModel)d2.y;
                            K8.x.b(o);
                            break Label_0211;
                        }
                        if (c2 != 2) {
                            if (c2 == 3) {
                                final Either either = (Either)d2.z;
                                accessControlViewModel = (AccessControlViewModel)d2.y;
                                K8.x.b(o);
                                z = either;
                                break Label_0312;
                            }
                            if (c2 == 4) {
                                K8.x.b(o);
                                return K8.M.a;
                            }
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        else {
                            accessControlViewModel = (AccessControlViewModel)d2.y;
                            K8.x.b(o);
                        }
                    }
                    else {
                        K8.x.b(o);
                        final x isLoading = this._isLoading;
                        final Boolean a = kotlin.coroutines.jvm.internal.b.a(true);
                        d2.y = this;
                        d2.C = 1;
                        accessControlViewModel = this;
                        if (((w)isLoading).emit((Object)a, (d)d2) == f) {
                            return f;
                        }
                        break Label_0211;
                    }
                    z = (Either)o;
                    final x isLoading2 = accessControlViewModel._isLoading;
                    final Boolean a2 = kotlin.coroutines.jvm.internal.b.a(false);
                    d2.y = accessControlViewModel;
                    d2.z = z;
                    d2.C = 3;
                    if (((w)isLoading2).emit((Object)a2, (d)d2) == f) {
                        return f;
                    }
                    break Label_0312;
                }
                final AccessControlRepository accessControlRepository = accessControlViewModel.accessControlRepository;
                final String mac = accessControlViewModel.mac;
                d2.y = accessControlViewModel;
                d2.C = 2;
                if ((o = accessControlRepository.getUserAccessItems(mac, (d)d2)) == f) {
                    return f;
                }
                continue;
            }
        }
        if (z instanceof Either$Left) {
            final CommonFailure commonFailure = (CommonFailure)((Either$Left)z).getValue();
        }
        else {
            if (!(z instanceof Either$Right)) {
                throw new s();
            }
            final AccessControlObject accessControlObject = (AccessControlObject)((Either$Right)z).getValue();
            final x aclState = accessControlViewModel._aclState;
            d2.y = null;
            d2.z = null;
            d2.C = 4;
            if (((w)aclState).emit((Object)accessControlObject, (d)d2) == f) {
                return f;
            }
        }
        return K8.M.a;
    }
    
    private final Object loadContacts(final d d) {
        if (!this.getHasContactsPermission()) {
            return K8.M.a;
        }
        final ArrayList list = new ArrayList();
        final ContentResolver contentResolver = this.appContext.getContentResolver();
        v.i((Object)contentResolver, "getContentResolver(...)");
        final Cursor query = contentResolver.query(ContactsContract$Contacts.CONTENT_URI, (String[])null, (String)null, (String[])null, (String)null);
        if (query == null) {
            return K8.M.a;
        }
        if (query.getCount() > 0) {
            while (query.moveToNext()) {
                final int columnIndex = query.getColumnIndex("_id");
                if (columnIndex != -1) {
                    if (query.getType(columnIndex) != 3) {
                        continue;
                    }
                    String string;
                    if (query.isNull(columnIndex)) {
                        string = null;
                    }
                    else {
                        string = query.getString(columnIndex);
                    }
                    if (string == null) {
                        continue;
                    }
                    final int columnIndex2 = query.getColumnIndex("display_name");
                    if (columnIndex2 == -1) {
                        continue;
                    }
                    if (query.getType(columnIndex2) != 3) {
                        continue;
                    }
                    String string2;
                    if (query.isNull(columnIndex2)) {
                        string2 = null;
                    }
                    else {
                        string2 = query.getString(columnIndex2);
                    }
                    if (string2 == null) {
                        continue;
                    }
                    final int columnIndex3 = query.getColumnIndex("has_phone_number");
                    if (columnIndex3 == -1) {
                        continue;
                    }
                    if (query.getType(columnIndex3) != 1) {
                        continue;
                    }
                    Integer e;
                    if (query.isNull(columnIndex3)) {
                        e = null;
                    }
                    else {
                        e = kotlin.coroutines.jvm.internal.b.e(query.getInt(columnIndex3));
                    }
                    if (e == null || e <= 0) {
                        continue;
                    }
                    final Cursor query2 = contentResolver.query(ContactsContract$CommonDataKinds$Phone.CONTENT_URI, (String[])null, "contact_id = ?", new String[] { string }, (String)null);
                    if (query2 == null) {
                        continue;
                    }
                    while (query2.moveToNext()) {
                        final int columnIndex4 = query2.getColumnIndex("data1");
                        if (columnIndex4 != -1) {
                            if (query2.getType(columnIndex4) != 3) {
                                continue;
                            }
                            String string3;
                            if (query2.isNull(columnIndex4)) {
                                string3 = null;
                            }
                            else {
                                string3 = query2.getString(columnIndex4);
                            }
                            if (string3 == null) {
                                continue;
                            }
                            ((List)list).add((Object)new ContactsUser(string3, string2));
                        }
                    }
                    query2.close();
                }
            }
        }
        query.close();
        final Object emit = ((w)this.contactsList).emit((Object)list, d);
        if (emit == b.f()) {
            return emit;
        }
        return K8.M.a;
    }
    
    public final z0 changeAccessControlState() {
        return i9.i.d(f0.a((e0)this), (P8.g)c0.b(), (i9.O)null, (p)new p(this, null) {
            int A;
            final AccessControlViewModel B;
            int y;
            Object z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.B, d) {
                    int A;
                    final AccessControlViewModel B;
                    int y;
                    Object z;
                };
            }
            
            public final Object invoke(final i9.M m, final d d) {
                return ((AccessControlViewModel$a)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(Object changeAccessControlState) {
                final Object f = b.f();
                final int a = this.A;
                final boolean b = false;
                int y = 0;
                AccessControlViewModel accessControlViewModel2 = null;
                Label_0383: {
                    Object z = null;
                    Label_0305: {
                        Label_0252: {
                            if (a != 0) {
                                if (a != 1) {
                                    if (a == 2) {
                                        y = this.y;
                                        K8.x.b(changeAccessControlState);
                                        break Label_0252;
                                    }
                                    if (a == 3) {
                                        y = this.y;
                                        final Either either = (Either)this.z;
                                        K8.x.b(changeAccessControlState);
                                        z = either;
                                        break Label_0305;
                                    }
                                    if (a == 4) {
                                        y = this.y;
                                        final AccessControlViewModel accessControlViewModel = (AccessControlViewModel)this.z;
                                        K8.x.b(changeAccessControlState);
                                        accessControlViewModel2 = accessControlViewModel;
                                        break Label_0383;
                                    }
                                    if (a == 5) {
                                        K8.x.b(changeAccessControlState);
                                        return K8.M.a;
                                    }
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                else {
                                    K8.x.b(changeAccessControlState);
                                }
                            }
                            else {
                                K8.x.b(changeAccessControlState);
                                final x access$get_isLoading$p = AccessControlViewModel.access$get_isLoading$p(this.B);
                                final Boolean a2 = kotlin.coroutines.jvm.internal.b.a(true);
                                this.A = 1;
                                if (((w)access$get_isLoading$p).emit((Object)a2, (d)this) == f) {
                                    return f;
                                }
                            }
                            final AccessControlObject accessControlObject = (AccessControlObject)AccessControlViewModel.access$get_aclState$p(this.B).getValue();
                            y = (((accessControlObject != null && accessControlObject.getEnabled()) ^ true) ? 1 : 0);
                            final AccessControlRepository access$getAccessControlRepository$p = AccessControlViewModel.access$getAccessControlRepository$p(this.B);
                            final String access$getMac$p = AccessControlViewModel.access$getMac$p(this.B);
                            this.y = y;
                            this.A = 2;
                            if ((changeAccessControlState = access$getAccessControlRepository$p.changeAccessControlState((boolean)(y != 0), access$getMac$p, (d)this)) == f) {
                                return f;
                            }
                        }
                        z = changeAccessControlState;
                        final x access$get_isLoading$p2 = AccessControlViewModel.access$get_isLoading$p(this.B);
                        final Boolean a3 = kotlin.coroutines.jvm.internal.b.a(false);
                        this.z = z;
                        this.y = y;
                        this.A = 3;
                        if (((w)access$get_isLoading$p2).emit((Object)a3, (d)this) == f) {
                            return f;
                        }
                    }
                    final AccessControlViewModel b2 = this.B;
                    if (z instanceof Either$Left) {
                        final CommonFailure commonFailure = (CommonFailure)((Either$Left)z).getValue();
                        return K8.M.a;
                    }
                    if (!(z instanceof Either$Right)) {
                        throw new s();
                    }
                    final K8.M m = (K8.M)((Either$Right)z).getValue();
                    this.z = b2;
                    this.y = y;
                    this.A = 4;
                    if (b2.loadAclState((d)this) == f) {
                        return f;
                    }
                    accessControlViewModel2 = b2;
                }
                final r sendCommands = accessControlViewModel2.getSendCommands();
                boolean b3 = b;
                if (y != 0) {
                    b3 = true;
                }
                final List e = t.e((Object)new CmdAccessControl(b3));
                final X8.a h = (X8.a)AccessControlViewModel$a$a.H;
                final Boolean a4 = kotlin.coroutines.jvm.internal.b.a(true);
                this.z = null;
                this.A = 5;
                if (sendCommands.invoke((Object)e, (Object)h, (Object)a4, (Object)this) == f) {
                    return f;
                }
                return K8.M.a;
            }
        }, 2, (Object)null);
    }
    
    public final M getAclState() {
        return this.aclState;
    }
    
    public final M getAclUsers() {
        return this.aclUsers;
    }
    
    public final M getProfile() {
        return this.profile;
    }
    
    public final r getSendCommands() {
        final r sendCommands = this.sendCommands;
        if (sendCommands != null) {
            return sendCommands;
        }
        v.A("sendCommands");
        return null;
    }
    
    public final void init(final String mac, final r sendCommands) {
        v.j((Object)mac, "mac");
        v.j((Object)sendCommands, "sendCommands");
        if (this.isInitialized) {
            return;
        }
        this.isInitialized = true;
        this.setSendCommands(sendCommands);
        this.mac = mac;
        this.refresh();
    }
    
    public final M isLoading() {
        return this.isLoading;
    }
    
    public final z0 modifyUserAccessLevel(final String s, final UserDevice$AccessLevel userDevice$AccessLevel) {
        v.j((Object)s, "userId");
        v.j((Object)userDevice$AccessLevel, "level");
        return i9.i.d(f0.a((e0)this), (P8.g)c0.b(), (i9.O)null, (p)new p(this, userDevice$AccessLevel, s, null) {
            final AccessControlViewModel A;
            final UserDevice$AccessLevel B;
            final String C;
            Object y;
            int z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.A, this.B, this.C, d) {
                    final AccessControlViewModel A;
                    final UserDevice$AccessLevel B;
                    final String C;
                    Object y;
                    int z;
                };
            }
            
            public final Object invoke(final i9.M m, final d d) {
                return ((AccessControlViewModel$c)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(Object modifyUserAccessLevel) {
                final Object f = b.f();
                final int z = this.z;
                Object y = null;
                Label_0226: {
                    Label_0180: {
                        if (z != 0) {
                            if (z != 1) {
                                if (z == 2) {
                                    K8.x.b(modifyUserAccessLevel);
                                    break Label_0180;
                                }
                                if (z == 3) {
                                    final Either either = (Either)this.y;
                                    K8.x.b(modifyUserAccessLevel);
                                    y = either;
                                    break Label_0226;
                                }
                                if (z == 4) {
                                    K8.x.b(modifyUserAccessLevel);
                                    return K8.M.a;
                                }
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            else {
                                K8.x.b(modifyUserAccessLevel);
                            }
                        }
                        else {
                            K8.x.b(modifyUserAccessLevel);
                            final x access$get_isLoading$p = AccessControlViewModel.access$get_isLoading$p(this.A);
                            final Boolean a = kotlin.coroutines.jvm.internal.b.a(true);
                            this.z = 1;
                            if (((w)access$get_isLoading$p).emit((Object)a, (d)this) == f) {
                                return f;
                            }
                        }
                        final AccessControlRepository access$getAccessControlRepository$p = AccessControlViewModel.access$getAccessControlRepository$p(this.A);
                        final String name = ((Enum)this.B).name();
                        final String c = this.C;
                        final String access$getMac$p = AccessControlViewModel.access$getMac$p(this.A);
                        this.z = 2;
                        if ((modifyUserAccessLevel = access$getAccessControlRepository$p.modifyUserAccessLevel(name, c, access$getMac$p, (d)this)) == f) {
                            return f;
                        }
                    }
                    y = modifyUserAccessLevel;
                    final x access$get_isLoading$p2 = AccessControlViewModel.access$get_isLoading$p(this.A);
                    final Boolean a2 = kotlin.coroutines.jvm.internal.b.a(false);
                    this.y = y;
                    this.z = 3;
                    if (((w)access$get_isLoading$p2).emit((Object)a2, (d)this) == f) {
                        return f;
                    }
                }
                final AccessControlViewModel a3 = this.A;
                if (y instanceof Either$Left) {
                    final CommonFailure commonFailure = (CommonFailure)((Either$Left)y).getValue();
                }
                else {
                    if (!(y instanceof Either$Right)) {
                        throw new s();
                    }
                    final K8.M m = (K8.M)((Either$Right)y).getValue();
                    this.y = null;
                    this.z = 4;
                    if (a3.loadAclState((d)this) == f) {
                        return f;
                    }
                }
                return K8.M.a;
            }
        }, 2, (Object)null);
    }
    
    public final z0 refresh() {
        return i9.i.d(f0.a((e0)this), (P8.g)c0.b(), (i9.O)null, (p)new p(this, null) {
            int y;
            final AccessControlViewModel z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.z, d) {
                    int y;
                    final AccessControlViewModel z;
                };
            }
            
            public final Object invoke(final i9.M m, final d d) {
                return ((AccessControlViewModel$d)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(final Object o) {
                final Object f = b.f();
                final int y = this.y;
                if (y != 0) {
                    if (y != 1) {
                        if (y == 2) {
                            K8.x.b(o);
                            return K8.M.a;
                        }
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    else {
                        K8.x.b(o);
                    }
                }
                else {
                    K8.x.b(o);
                    final AccessControlViewModel z = this.z;
                    this.y = 1;
                    if (z.loadAclState((d)this) == f) {
                        return f;
                    }
                }
                final AccessControlViewModel z2 = this.z;
                this.y = 2;
                if (z2.loadContacts((d)this) == f) {
                    return f;
                }
                return K8.M.a;
            }
        }, 2, (Object)null);
    }
    
    public final void setSendCommands(final r sendCommands) {
        v.j((Object)sendCommands, "<set-?>");
        this.sendCommands = sendCommands;
    }
}
