package com.polaris.iot.application.device.acl;

import java.util.Iterator;
import com.syncleoiot.core.data.model.UserProfile;
import kotlin.jvm.internal.v;
import com.syncleoiot.core.data.model.ContactsUser;
import java.util.List;
import com.syncleoiot.core.data.model.UserAccessItem;

public final class AccessControlViewModelKt
{
    public static final String displayName(final UserAccessItem userAccessItem, final List<ContactsUser> list) {
        v.j((Object)userAccessItem, "<this>");
        final UserProfile profile = userAccessItem.getProfile();
        final CharSequence charSequence = null;
        if (profile == null) {
            return null;
        }
        Object name = charSequence;
        Label_0103: {
            if (list != null) {
                final String phone = profile.getPhone();
                name = charSequence;
                if (phone != null) {
                    while (true) {
                        for (final Object next : (Iterable)list) {
                            if (v.e((Object)((ContactsUser)next).getPhoneNumber(), (Object)phone)) {
                                final ContactsUser contactsUser = (ContactsUser)next;
                                name = charSequence;
                                if (contactsUser != null) {
                                    name = contactsUser.getName();
                                }
                                break Label_0103;
                            }
                        }
                        Object next = null;
                        continue;
                    }
                }
            }
        }
        if (name != null) {
            final Object o = name;
            if (((CharSequence)name).length() != 0) {
                return (String)o;
            }
        }
        final String nickname = profile.getNickname();
        Object o;
        if (nickname != null && ((CharSequence)nickname).length() != 0) {
            o = String.valueOf((Object)profile.getNickname());
        }
        else {
            final String firstName = profile.getFirstName();
            if (firstName != null) {
                if (((CharSequence)firstName).length() != 0) {
                    final String lastName = profile.getLastName();
                    if (lastName != null) {
                        if (((CharSequence)lastName).length() != 0) {
                            final String firstName2 = profile.getFirstName();
                            final String lastName2 = profile.getLastName();
                            final StringBuilder sb = new StringBuilder();
                            sb.append(firstName2);
                            sb.append(" ");
                            sb.append(lastName2);
                            o = sb.toString();
                            return (String)o;
                        }
                    }
                }
            }
            final String firstName3 = profile.getFirstName();
            if (firstName3 != null && ((CharSequence)firstName3).length() != 0) {
                o = profile.getFirstName();
            }
            else {
                final String emailIdentity = profile.getEmailIdentity();
                if (emailIdentity != null && ((CharSequence)emailIdentity).length() != 0) {
                    o = profile.getEmailIdentity();
                }
                else {
                    o = profile.getPhone();
                }
            }
        }
        return (String)o;
    }
    
    public static final String getDisplayName(final UserProfile userProfile) {
        v.j((Object)userProfile, "<this>");
        final String nickname = userProfile.getNickname();
        String s;
        if (nickname != null && ((CharSequence)nickname).length() != 0) {
            s = String.valueOf((Object)userProfile.getNickname());
        }
        else {
            final String firstName = userProfile.getFirstName();
            if (firstName != null) {
                if (((CharSequence)firstName).length() != 0) {
                    final String lastName = userProfile.getLastName();
                    if (lastName != null) {
                        if (((CharSequence)lastName).length() != 0) {
                            final String firstName2 = userProfile.getFirstName();
                            final String lastName2 = userProfile.getLastName();
                            final StringBuilder sb = new StringBuilder();
                            sb.append(firstName2);
                            sb.append(" ");
                            sb.append(lastName2);
                            s = sb.toString();
                            return s;
                        }
                    }
                }
            }
            final String firstName3 = userProfile.getFirstName();
            if (firstName3 != null && ((CharSequence)firstName3).length() != 0) {
                s = userProfile.getFirstName();
            }
            else {
                final String emailIdentity = userProfile.getEmailIdentity();
                if (emailIdentity != null && ((CharSequence)emailIdentity).length() != 0) {
                    s = userProfile.getEmailIdentity();
                }
                else {
                    s = userProfile.getPhone();
                }
            }
        }
        return s;
    }
}
