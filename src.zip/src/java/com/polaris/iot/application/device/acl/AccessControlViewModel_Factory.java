package com.polaris.iot.application.device.acl;

import com.syncleoiot.core.domain.device.acl.AccessControlRepository;
import com.syncleoiot.core.domain.profile.ProfileRepository;
import android.content.Context;
import I8.a;
import A8.b;

public final class AccessControlViewModel_Factory implements b
{
    private final a accessControlRepositoryProvider;
    private final a appContextProvider;
    private final a profileRepositoryProvider;
    
    public AccessControlViewModel_Factory(final a appContextProvider, final a profileRepositoryProvider, final a accessControlRepositoryProvider) {
        this.appContextProvider = appContextProvider;
        this.profileRepositoryProvider = profileRepositoryProvider;
        this.accessControlRepositoryProvider = accessControlRepositoryProvider;
    }
    
    public static AccessControlViewModel_Factory create(final a a, final a a2, final a a3) {
        return new AccessControlViewModel_Factory(a, a2, a3);
    }
    
    public static AccessControlViewModel newInstance(final Context context, final ProfileRepository profileRepository, final AccessControlRepository accessControlRepository) {
        return new AccessControlViewModel(context, profileRepository, accessControlRepository);
    }
    
    public AccessControlViewModel get() {
        return newInstance((Context)this.appContextProvider.get(), (ProfileRepository)this.profileRepositoryProvider.get(), (AccessControlRepository)this.accessControlRepositoryProvider.get());
    }
}
