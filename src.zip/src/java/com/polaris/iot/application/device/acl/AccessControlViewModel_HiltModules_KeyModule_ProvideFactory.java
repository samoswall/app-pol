package com.polaris.iot.application.device.acl;

import A8.b;

public final class AccessControlViewModel_HiltModules_KeyModule_ProvideFactory implements b
{
    public static AccessControlViewModel_HiltModules_KeyModule_ProvideFactory create() {
        return a.a;
    }
    
    public static boolean provide() {
        return AccessControlViewModel_HiltModules.KeyModule.provide();
    }
    
    public Boolean get() {
        return provide();
    }
    
    private abstract static final class a
    {
        private static final AccessControlViewModel_HiltModules_KeyModule_ProvideFactory a;
        
        static {
            a = new AccessControlViewModel_HiltModules_KeyModule_ProvideFactory();
        }
    }
}
