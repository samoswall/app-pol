package com.polaris.iot.application.device.acl;

import kotlin.jvm.internal.v;
import com.syncleoiot.core.data.db.entity.UserDevice$AccessLevel;

public final class UserAclItem
{
    public static final int $stable = 8;
    private final String displayName;
    private UserDevice$AccessLevel level;
    private final String userId;
    
    public UserAclItem(final String userId, final String displayName, final UserDevice$AccessLevel level) {
        v.j((Object)userId, "userId");
        v.j((Object)level, "level");
        this.userId = userId;
        this.displayName = displayName;
        this.level = level;
    }
    
    public final String component1() {
        return this.userId;
    }
    
    public final String component2() {
        return this.displayName;
    }
    
    public final UserDevice$AccessLevel component3() {
        return this.level;
    }
    
    public final UserAclItem copy(final String s, final String s2, final UserDevice$AccessLevel userDevice$AccessLevel) {
        v.j((Object)s, "userId");
        v.j((Object)userDevice$AccessLevel, "level");
        return new UserAclItem(s, s2, userDevice$AccessLevel);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof UserAclItem)) {
            return false;
        }
        final UserAclItem userAclItem = (UserAclItem)o;
        return v.e((Object)this.userId, (Object)userAclItem.userId) && v.e((Object)this.displayName, (Object)userAclItem.displayName) && this.level == userAclItem.level;
    }
    
    public final String getDisplayName() {
        return this.displayName;
    }
    
    public final UserDevice$AccessLevel getLevel() {
        return this.level;
    }
    
    public final String getUserId() {
        return this.userId;
    }
    
    @Override
    public int hashCode() {
        final int hashCode = this.userId.hashCode();
        final String displayName = this.displayName;
        int hashCode2;
        if (displayName == null) {
            hashCode2 = 0;
        }
        else {
            hashCode2 = displayName.hashCode();
        }
        return (hashCode * 31 + hashCode2) * 31 + this.level.hashCode();
    }
    
    public final void setLevel(final UserDevice$AccessLevel level) {
        v.j((Object)level, "<set-?>");
        this.level = level;
    }
    
    @Override
    public String toString() {
        final String userId = this.userId;
        final String displayName = this.displayName;
        final UserDevice$AccessLevel level = this.level;
        final StringBuilder sb = new StringBuilder();
        sb.append("UserAclItem(userId=");
        sb.append(userId);
        sb.append(", displayName=");
        sb.append(displayName);
        sb.append(", level=");
        sb.append((Object)level);
        sb.append(")");
        return sb.toString();
    }
}
