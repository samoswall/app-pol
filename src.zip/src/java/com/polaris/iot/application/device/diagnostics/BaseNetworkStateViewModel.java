package com.polaris.iot.application.device.diagnostics;

import l9.w;
import java.util.Iterator;
import Q8.b;
import P8.d;
import kotlin.coroutines.jvm.internal.l;
import X8.p;
import java.util.Map;
import androidx.lifecycle.E;
import K8.t;
import K8.s;
import java.util.List;
import kotlin.jvm.internal.v;
import java.util.ArrayList;
import com.syncleoiot.transport.mqtt.connection.MqttProviderConnectionState;
import l9.g;
import l9.H$a;
import l9.H;
import androidx.lifecycle.f0;
import com.syncleoiot.transport.core.connectivity.ConnectivityTracker;
import l9.i;
import L8.P;
import l9.O;
import androidx.lifecycle.J;
import com.syncleoiot.transport.mqtt.discovery.MqttProviderState;
import l9.M;
import l9.x;
import androidx.lifecycle.e0;

public abstract class BaseNetworkStateViewModel extends e0
{
    public static final int $stable = 8;
    private final x _currentLinkType;
    private final x _layoutType;
    private final x _mapLink;
    private final M currentLinkType;
    private final M mapLink;
    private MqttProviderState mqttProviderStateActual;
    private final J mqttProviderStateLive;
    private M phoneNetworkState;
    
    public BaseNetworkStateViewModel() {
        this._layoutType = O.a((Object)LayoutType.MultiRouter.INSTANCE);
        final x a = O.a((Object)P.j());
        this._mapLink = a;
        final x a2 = O.a((Object)null);
        this._currentLinkType = a2;
        this.mapLink = i.b(a);
        this.currentLinkType = i.b(a2);
        this.phoneNetworkState = i.K((g)ConnectivityTracker.INSTANCE.getConnectivityInfo(), f0.a((e0)this), H$a.b(H.a, 0L, 0L, 3, (Object)null), (Object)null);
        this.mqttProviderStateActual = new MqttProviderState(MqttProviderConnectionState.Disconnected, 0L);
        this.mqttProviderStateLive = new J();
    }
    
    public static final /* synthetic */ x access$get_mapLink$p(final BaseNetworkStateViewModel baseNetworkStateViewModel) {
        return baseNetworkStateViewModel._mapLink;
    }
    
    private final LinkParams getNetworkIssue(final LinkType linkType) {
        final ArrayList list = new ArrayList();
        LinkParams linkParams;
        if (v.e((Object)linkType, (Object)LinkType.PhoneRouter.INSTANCE)) {
            linkParams = this.phoneRouterParams((List<NetworkIssue>)list);
        }
        else if (v.e((Object)linkType, (Object)LinkType.PhoneDevice.INSTANCE)) {
            linkParams = this.phoneDeviceParams((List<NetworkIssue>)list);
        }
        else if (v.e((Object)linkType, (Object)LinkType.DeviceRouter.INSTANCE)) {
            linkParams = this.deviceRouterParams((List<NetworkIssue>)list);
        }
        else if (v.e((Object)linkType, (Object)LinkType.DeviceRouterCloud.INSTANCE)) {
            linkParams = this.dvRouterCloudParams((List<NetworkIssue>)list);
        }
        else {
            if (!v.e((Object)linkType, (Object)LinkType.PhoneRouterCloud.INSTANCE)) {
                throw new s();
            }
            linkParams = this.phRouterCloudParams((List<NetworkIssue>)list);
        }
        return linkParams;
    }
    
    public LinkParams deviceRouterParams(final List<NetworkIssue> list) {
        v.j((Object)list, "list");
        final StringBuilder sb = new StringBuilder();
        sb.append("An operation is not implemented: ");
        sb.append("Implement in child classes");
        throw new t(sb.toString());
    }
    
    public LinkParams dvRouterCloudParams(final List<NetworkIssue> list) {
        v.j((Object)list, "list");
        final StringBuilder sb = new StringBuilder();
        sb.append("An operation is not implemented: ");
        sb.append("Implement in child classes");
        throw new t(sb.toString());
    }
    
    public final M getCurrentLinkType() {
        return this.currentLinkType;
    }
    
    public final M getLayoutType() {
        return i.b(this.get_layoutType());
    }
    
    public abstract List<LinkType> getLinkList();
    
    public final M getMapLink() {
        return this.mapLink;
    }
    
    public final MqttProviderState getMqttProviderState() {
        return this.mqttProviderStateActual;
    }
    
    public final E getMqttProviderStateLive() {
        return (E)this.mqttProviderStateLive;
    }
    
    public final M getPhoneNetworkState() {
        return this.phoneNetworkState;
    }
    
    protected x get_layoutType() {
        return this._layoutType;
    }
    
    public LinkParams phRouterCloudParams(final List<NetworkIssue> list) {
        v.j((Object)list, "list");
        final StringBuilder sb = new StringBuilder();
        sb.append("An operation is not implemented: ");
        sb.append("Implement in child classes");
        throw new t(sb.toString());
    }
    
    public LinkParams phoneDeviceParams(final List<NetworkIssue> list) {
        v.j((Object)list, "list");
        final StringBuilder sb = new StringBuilder();
        sb.append("An operation is not implemented: ");
        sb.append("Implement in child classes");
        throw new t(sb.toString());
    }
    
    public LinkParams phoneRouterParams(final List<NetworkIssue> list) {
        v.j((Object)list, "list");
        final StringBuilder sb = new StringBuilder();
        sb.append("An operation is not implemented: ");
        sb.append("Implement in child classes");
        throw new t(sb.toString());
    }
    
    public final void showDialog(final LinkType value) {
        this._currentLinkType.setValue((Object)value);
    }
    
    public final void updateLinkState() {
        final Map x = P.x((Map)this.mapLink.getValue());
        for (final LinkType linkType : (Iterable)this.getLinkList()) {
            x.put((Object)linkType, (Object)this.getNetworkIssue(linkType));
        }
        i9.i.d(f0.a((e0)this), (P8.g)null, (i9.O)null, (p)new p(this, x, null) {
            final Map A;
            int y;
            final BaseNetworkStateViewModel z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.z, this.A, d) {
                    final Map A;
                    int y;
                    final BaseNetworkStateViewModel z;
                };
            }
            
            public final Object invoke(final i9.M m, final d d) {
                return ((BaseNetworkStateViewModel$a)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(final Object o) {
                final Object f = b.f();
                final int y = this.y;
                if (y != 0) {
                    if (y != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    K8.x.b(o);
                }
                else {
                    K8.x.b(o);
                    final x access$get_mapLink$p = BaseNetworkStateViewModel.access$get_mapLink$p(this.z);
                    final Map a = this.A;
                    this.y = 1;
                    if (((w)access$get_mapLink$p).emit((Object)a, (d)this) == f) {
                        return f;
                    }
                }
                return K8.M.a;
            }
        }, 3, (Object)null);
    }
    
    public final void updateMqttProviderState(final MqttProviderState mqttProviderStateActual) {
        v.j((Object)mqttProviderStateActual, "state");
        this.mqttProviderStateActual = mqttProviderStateActual;
        this.mqttProviderStateLive.postValue((Object)mqttProviderStateActual);
    }
}
