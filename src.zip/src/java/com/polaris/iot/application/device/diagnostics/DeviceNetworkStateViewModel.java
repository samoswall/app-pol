package com.polaris.iot.application.device.diagnostics;

import l9.x;
import com.syncleoiot.transport.core.utils.ByteExtKt;
import com.syncleoiot.core.data.model.DeviceState;
import com.syncleoiot.transport.core.connection.DeviceConnectionMode;
import com.syncleoiot.transport.core.connectivity.ConnectivityInfo;
import androidx.lifecycle.E;
import com.syncleoiot.transport.mqtt.connection.MqttConnection;
import com.syncleoiot.transport.udp.connection.UdpConnection;
import com.syncleoiot.tools.logwriter.Log;
import com.syncleoiot.transport.mqtt.connection.MqttProviderConnectionState;
import com.syncleoiot.transport.core.connection.DeviceConnectionState;
import com.syncleoiot.core.utils.DeviceUtils;
import kotlin.jvm.internal.v;
import L8.t;
import com.syncleoiot.transport.core.models.MacAddress;
import kotlin.jvm.internal.m;
import java.util.List;
import androidx.lifecycle.J;
import com.syncleoiot.transport.core.models.DeviceNetworkInfo;
import com.syncleoiot.transport.core.connection.DeviceConnection;
import com.syncleoiot.core.data.model.Device;

public final class DeviceNetworkStateViewModel extends BaseNetworkStateViewModel
{
    public static final int $stable;
    public static final Companion Companion;
    private static final String TAG;
    private Device device;
    private DeviceConnection deviceConnection;
    private DeviceNetworkInfo deviceConnectivityState;
    private final J deviceConnectivityStateLive;
    private final List<LinkType> linkList;
    private double udpStability;
    private final J udpStabilityLive;
    
    static {
        String simpleName = null;
        final Companion companion = Companion = new Companion(null);
        $stable = 8;
        final Class<?> enclosingClass = companion.getClass().getEnclosingClass();
        if (enclosingClass != null) {
            simpleName = enclosingClass.getSimpleName();
        }
        String tag;
        if ((tag = simpleName) == null) {
            tag = "TAG";
        }
        TAG = tag;
    }
    
    public DeviceNetworkStateViewModel() {
        this.deviceConnectivityState = new DeviceNetworkInfo((byte)0, MacAddress.Companion.getEmpty(), (String)null, 0, 0.0, 0.0, 0.0);
        this.deviceConnectivityStateLive = new J();
        this.udpStabilityLive = new J();
        this.linkList = (List<LinkType>)t.q((Object[])new LinkType[] { LinkType.PhoneRouter.INSTANCE, LinkType.PhoneDevice.INSTANCE, LinkType.PhoneRouterCloud.INSTANCE, LinkType.DeviceRouter.INSTANCE, LinkType.DeviceRouterCloud.INSTANCE });
    }
    
    @Override
    public LinkParams deviceRouterParams(final List<NetworkIssue> list) {
        v.j((Object)list, "list");
        final boolean evoDevice = DeviceUtils.INSTANCE.isEvoDevice(this.device);
        DeviceConnectionState connectionState = null;
        final DeviceConnectionState deviceConnectionState = null;
        if (evoDevice) {
            final DeviceConnection deviceConnection = this.deviceConnection;
            DeviceConnectionState connectionState2 = deviceConnectionState;
            if (deviceConnection != null) {
                connectionState2 = deviceConnection.getConnectionState();
            }
            if (connectionState2 == DeviceConnectionState.READY) {
                return new LinkParams((List<? extends NetworkIssue>)t.n(), LinkStatus.Active.INSTANCE);
            }
            list.add((Object)NetworkIssue.DeviceOffline.INSTANCE);
            return new LinkParams(list, LinkStatus.Error.INSTANCE);
        }
        else {
            final DeviceConnection deviceConnection2 = this.deviceConnection;
            if (deviceConnection2 != null) {
                connectionState = deviceConnection2.getConnectionState();
            }
            if (connectionState != DeviceConnectionState.READY) {
                if (this.getMqttProviderState().getConnectionState() == MqttProviderConnectionState.Connected) {
                    list.add((Object)NetworkIssue.DeviceWifiError.INSTANCE);
                    return new LinkParams(list, LinkStatus.Error.INSTANCE);
                }
                list.add((Object)NetworkIssue.DeviceRouterLoss.INSTANCE);
                return new LinkParams(list, LinkStatus.Inactive.INSTANCE);
            }
            else {
                if (!this.getDeviceConnectivityState().getHasConfig()) {
                    list.add((Object)NetworkIssue.DeviceNoConfiguration.INSTANCE);
                    return new LinkParams(list, LinkStatus.Warning.INSTANCE);
                }
                if (!this.getDeviceConnectivityState().getHasConnection()) {
                    final String tag = DeviceNetworkStateViewModel.TAG;
                    final boolean hasConnection = this.deviceConnectivityState.getHasConnection();
                    final StringBuilder sb = new StringBuilder();
                    sb.append("DEVICE-ROUTER RED ");
                    sb.append(hasConnection ^ true);
                    Log.d(tag, sb.toString());
                    list.add((Object)NetworkIssue.DeviceOffline.INSTANCE);
                    return new LinkParams(list, LinkStatus.Error.INSTANCE);
                }
                if (this.getDeviceConnectivityState().getGatewayPing() > 40.0 || this.getDeviceConnectivityState().getRssi() < -60 || this.getDeviceConnectivityState().getGatewayLoss() > 10.0) {
                    list.add((Object)NetworkIssue.DeviceRouterLatency.INSTANCE);
                    return new LinkParams(list, LinkStatus.Warning.INSTANCE);
                }
                if (this.deviceConnection instanceof UdpConnection && this.getUdpStability() < 0.7) {
                    list.add((Object)NetworkIssue.DeviceUnstableUDP.INSTANCE);
                    return new LinkParams(list, LinkStatus.Warning.INSTANCE);
                }
                return new LinkParams((List<? extends NetworkIssue>)t.n(), LinkStatus.Active.INSTANCE);
            }
        }
    }
    
    @Override
    public LinkParams dvRouterCloudParams(final List<NetworkIssue> list) {
        v.j((Object)list, "list");
        if (DeviceUtils.INSTANCE.isEvoDevice(this.device)) {
            return new LinkParams((List<? extends NetworkIssue>)t.n(), LinkStatus.Disabled.INSTANCE);
        }
        if (this.getPhoneNetworkState().getValue() != null && this.getDeviceConnectivityState().getHasConnection()) {
            final DeviceConnection deviceConnection = this.deviceConnection;
            DeviceConnectionState connectionState;
            if (deviceConnection != null) {
                connectionState = deviceConnection.getConnectionState();
            }
            else {
                connectionState = null;
            }
            final DeviceConnectionState ready = DeviceConnectionState.READY;
            if (connectionState == ready) {
                if (!this.getDeviceConnectivityState().getHasConfig()) {
                    list.add((Object)NetworkIssue.DeviceNoConfiguration.INSTANCE);
                    return new LinkParams(list, LinkStatus.Inactive.INSTANCE);
                }
                if (!this.getDeviceConnectivityState().getHasCloud()) {
                    list.add((Object)NetworkIssue.DeviceCloudOffline.INSTANCE);
                    return new LinkParams(list, LinkStatus.Error.INSTANCE);
                }
                if (this.getMqttProviderState().getLatency() > 200L) {
                    list.add((Object)NetworkIssue.DeviceCloudLatency.INSTANCE);
                    return new LinkParams(list, LinkStatus.Warning.INSTANCE);
                }
                final DeviceConnection deviceConnection2 = this.deviceConnection;
                if (deviceConnection2 instanceof MqttConnection) {
                    v.h((Object)deviceConnection2, "null cannot be cast to non-null type com.syncleoiot.transport.mqtt.connection.MqttConnection");
                    if (((MqttConnection)deviceConnection2).getConnectionState() == ready) {
                        return new LinkParams((List<? extends NetworkIssue>)t.n(), LinkStatus.Active.INSTANCE);
                    }
                }
                return new LinkParams(list, LinkStatus.Good.INSTANCE);
            }
        }
        list.add((Object)NetworkIssue.DeviceRouterLoss.INSTANCE);
        return new LinkParams(list, LinkStatus.Inactive.INSTANCE);
    }
    
    public final DeviceNetworkInfo getDeviceConnectivityState() {
        return this.deviceConnectivityState;
    }
    
    public final E getDeviceConnectivityStateLive() {
        return (E)this.deviceConnectivityStateLive;
    }
    
    @Override
    public List<LinkType> getLinkList() {
        return this.linkList;
    }
    
    public final double getUdpStability() {
        return this.udpStability;
    }
    
    public final E getUdpStabilityLive() {
        return (E)this.udpStabilityLive;
    }
    
    public final void init(final DeviceConnection deviceConnection, final Device device) {
        v.j((Object)device, "device");
        this.deviceConnection = deviceConnection;
        this.device = device;
    }
    
    @Override
    public LinkParams phRouterCloudParams(final List<NetworkIssue> list) {
        v.j((Object)list, "list");
        if (DeviceUtils.INSTANCE.isEvoDevice(this.device)) {
            return new LinkParams((List<? extends NetworkIssue>)t.n(), LinkStatus.Disabled.INSTANCE);
        }
        Label_0281: {
            if (this.getPhoneNetworkState().getValue() != null) {
                final Object value = this.getPhoneNetworkState().getValue();
                v.g(value);
                if (!((ConnectivityInfo)value).isWifiConnected()) {
                    final Object value2 = this.getPhoneNetworkState().getValue();
                    v.g(value2);
                    if (!((ConnectivityInfo)value2).isCellularConnected()) {
                        break Label_0281;
                    }
                }
                final DeviceConnection deviceConnection = this.deviceConnection;
                if (deviceConnection instanceof UdpConnection) {
                    v.h((Object)deviceConnection, "null cannot be cast to non-null type com.syncleoiot.transport.udp.connection.UdpConnection");
                    if (((UdpConnection)deviceConnection).getMode() == DeviceConnectionMode.Config) {
                        list.add((Object)NetworkIssue.HotspotConnected.INSTANCE);
                        return new LinkParams(list, LinkStatus.Inactive.INSTANCE);
                    }
                }
                if (this.getMqttProviderState().getConnectionState() != MqttProviderConnectionState.Connected) {
                    list.add((Object)NetworkIssue.PhoneCloudOffline.INSTANCE);
                    return new LinkParams(list, LinkStatus.Error.INSTANCE);
                }
                if (this.getMqttProviderState().getLatency() > 200L) {
                    list.add((Object)NetworkIssue.PhoneCloudLatency.INSTANCE);
                    return new LinkParams(list, LinkStatus.Warning.INSTANCE);
                }
                final DeviceConnection deviceConnection2 = this.deviceConnection;
                if (deviceConnection2 instanceof MqttConnection) {
                    v.h((Object)deviceConnection2, "null cannot be cast to non-null type com.syncleoiot.transport.mqtt.connection.MqttConnection");
                    if (((MqttConnection)deviceConnection2).getConnectionState() == DeviceConnectionState.READY) {
                        return new LinkParams((List<? extends NetworkIssue>)t.n(), LinkStatus.Active.INSTANCE);
                    }
                }
                return new LinkParams((List<? extends NetworkIssue>)t.n(), LinkStatus.Good.INSTANCE);
            }
        }
        list.add((Object)NetworkIssue.NoConnection.INSTANCE);
        return new LinkParams(list, LinkStatus.Inactive.INSTANCE);
    }
    
    @Override
    public LinkParams phoneDeviceParams(final List<NetworkIssue> list) {
        v.j((Object)list, "list");
        if (DeviceUtils.INSTANCE.isEvoDevice(this.device)) {
            return new LinkParams((List<? extends NetworkIssue>)t.n(), LinkStatus.Disabled.INSTANCE);
        }
        if (this.getPhoneNetworkState().getValue() == null) {
            list.add((Object)NetworkIssue.NoConnection.INSTANCE);
            return new LinkParams(list, LinkStatus.Error.INSTANCE);
        }
        final DeviceConnection deviceConnection = this.deviceConnection;
        if (deviceConnection instanceof UdpConnection) {
            v.h((Object)deviceConnection, "null cannot be cast to non-null type com.syncleoiot.transport.udp.connection.UdpConnection");
            if (((UdpConnection)deviceConnection).getConnectionState() == DeviceConnectionState.READY) {
                final DeviceConnection deviceConnection2 = this.deviceConnection;
                v.h((Object)deviceConnection2, "null cannot be cast to non-null type com.syncleoiot.transport.udp.connection.UdpConnection");
                if (((UdpConnection)deviceConnection2).getMode() == DeviceConnectionMode.Config) {
                    final Object value = this.getPhoneNetworkState().getValue();
                    v.g(value);
                    if (((ConnectivityInfo)value).getWifiRssi() >= -60) {
                        final Object value2 = this.getPhoneNetworkState().getValue();
                        v.g(value2);
                        if (((ConnectivityInfo)value2).getWifiLatency() <= 40.0f) {
                            if (this.getUdpStability() >= 0.7) {
                                return new LinkParams((List<? extends NetworkIssue>)t.n(), LinkStatus.Active.INSTANCE);
                            }
                        }
                    }
                    list.add((Object)NetworkIssue.HotspotConnected.INSTANCE);
                    return new LinkParams(list, LinkStatus.Warning.INSTANCE);
                }
            }
        }
        list.add((Object)NetworkIssue.HotspotNoConnected.INSTANCE);
        return new LinkParams(list, LinkStatus.Disabled.INSTANCE);
    }
    
    @Override
    public LinkParams phoneRouterParams(final List<NetworkIssue> list) {
        v.j((Object)list, "list");
        Label_0402: {
            if (this.getPhoneNetworkState().getValue() != null) {
                final Object value = this.getPhoneNetworkState().getValue();
                v.g(value);
                if (!((ConnectivityInfo)value).isWifiConnected()) {
                    final Object value2 = this.getPhoneNetworkState().getValue();
                    v.g(value2);
                    if (!((ConnectivityInfo)value2).isCellularConnected()) {
                        break Label_0402;
                    }
                }
                final DeviceConnection deviceConnection = this.deviceConnection;
                if (deviceConnection instanceof UdpConnection) {
                    v.h((Object)deviceConnection, "null cannot be cast to non-null type com.syncleoiot.transport.udp.connection.UdpConnection");
                    if (((UdpConnection)deviceConnection).getMode() == DeviceConnectionMode.Config) {
                        list.add((Object)NetworkIssue.PhoneUDP.INSTANCE);
                        return new LinkParams(list, LinkStatus.Inactive.INSTANCE);
                    }
                }
                final Object value3 = this.getPhoneNetworkState().getValue();
                v.g(value3);
                Label_0223: {
                    if (((ConnectivityInfo)value3).isCellularConnected()) {
                        final Object value4 = this.getPhoneNetworkState().getValue();
                        v.g(value4);
                        if (((ConnectivityInfo)value4).getCellularRssi() >= -60) {
                            final Object value5 = this.getPhoneNetworkState().getValue();
                            v.g(value5);
                            if (((ConnectivityInfo)value5).getCellularLatency() <= 100.0f) {
                                break Label_0223;
                            }
                        }
                        list.add((Object)NetworkIssue.PhoneCellularLatency.INSTANCE);
                        return new LinkParams(list, LinkStatus.Warning.INSTANCE);
                    }
                }
                final Object value6 = this.getPhoneNetworkState().getValue();
                v.g(value6);
                Label_0323: {
                    if (((ConnectivityInfo)value6).isWifiConnected()) {
                        final Object value7 = this.getPhoneNetworkState().getValue();
                        v.g(value7);
                        if (((ConnectivityInfo)value7).getWifiRssi() >= -60) {
                            final Object value8 = this.getPhoneNetworkState().getValue();
                            v.g(value8);
                            if (((ConnectivityInfo)value8).getWifiLatency() <= 40.0f) {
                                break Label_0323;
                            }
                        }
                        list.add((Object)NetworkIssue.PhoneRouterLatency.INSTANCE);
                        return new LinkParams(list, LinkStatus.Warning.INSTANCE);
                    }
                }
                final DeviceConnection deviceConnection2 = this.deviceConnection;
                if (deviceConnection2 instanceof UdpConnection) {
                    v.h((Object)deviceConnection2, "null cannot be cast to non-null type com.syncleoiot.transport.udp.connection.UdpConnection");
                    if (((UdpConnection)deviceConnection2).getConnectionState() == DeviceConnectionState.READY && this.getUdpStability() < 0.7) {
                        list.add((Object)NetworkIssue.PhoneUDP.INSTANCE);
                        return new LinkParams(list, LinkStatus.Warning.INSTANCE);
                    }
                }
                return new LinkParams((List<? extends NetworkIssue>)t.n(), LinkStatus.Active.INSTANCE);
            }
        }
        list.add((Object)NetworkIssue.NoConnection.INSTANCE);
        return new LinkParams(list, LinkStatus.Error.INSTANCE);
    }
    
    public final void setDeviceConnectivityState(final DeviceNetworkInfo deviceConnectivityState) {
        v.j((Object)deviceConnectivityState, "deviceNetworkInfo");
        this.deviceConnectivityState = deviceConnectivityState;
        this.deviceConnectivityStateLive.postValue((Object)deviceConnectivityState);
    }
    
    public final void updateDeviceConnectivityState(final DeviceConnection deviceConnection, final DeviceState deviceState, final Device device) {
        v.j((Object)deviceState, "deviceState");
        if (device == null) {
            return;
        }
        final Object value = deviceState.get((Object)"ConnectionStatus");
        final boolean b = value instanceof DeviceNetworkInfo;
        final Object o = null;
        DeviceNetworkInfo deviceNetworkInfo;
        if (b) {
            deviceNetworkInfo = (DeviceNetworkInfo)value;
        }
        else {
            deviceNetworkInfo = null;
        }
        DeviceNetworkInfo deviceConnectivityState = deviceNetworkInfo;
        if (deviceNetworkInfo == null) {
            final boolean b2 = deviceConnection instanceof MqttConnection;
            final int n = 0;
            byte setBit;
            if (b2 && ((MqttConnection)deviceConnection).getConnectionState() == DeviceConnectionState.READY) {
                setBit = ByteExtKt.setBit(ByteExtKt.setBit(ByteExtKt.setBit(0, 3), 2), 1);
            }
            else {
                setBit = 0;
            }
            final Object value2 = deviceState.get((Object)"LastWifi");
            String s;
            if (value2 instanceof String) {
                s = (String)value2;
            }
            else {
                s = null;
            }
            final Object value3 = deviceState.get((Object)"MqttLatency");
            Integer n2;
            if (value3 instanceof Integer) {
                n2 = (Integer)value3;
            }
            else {
                n2 = null;
            }
            int intValue;
            if (n2 != null) {
                intValue = n2;
            }
            else {
                intValue = 0;
            }
            final double n3 = intValue;
            final Object value4 = deviceState.get((Object)"GatewayLatency");
            Integer n4;
            if (value4 instanceof Integer) {
                n4 = (Integer)value4;
            }
            else {
                n4 = null;
            }
            int intValue2;
            if (n4 != null) {
                intValue2 = n4;
            }
            else {
                intValue2 = 0;
            }
            final double n5 = intValue2;
            final Object value5 = deviceState.get((Object)"GatewayLoss");
            Integer n6;
            if (value5 instanceof Integer) {
                n6 = (Integer)value5;
            }
            else {
                n6 = null;
            }
            int intValue3 = n;
            if (n6 != null) {
                intValue3 = n6;
            }
            deviceConnectivityState = new DeviceNetworkInfo(setBit, MacAddress.Companion.getEmpty(), s, 0, n5, (double)intValue3, n3);
        }
        this.setDeviceConnectivityState(deviceConnectivityState);
        final x get_layoutType = this.get_layoutType();
        LayoutType value6 = null;
        Label_0445: {
            Label_0441: {
                if (!(deviceConnection instanceof UdpConnection)) {
                    final ConnectivityInfo connectivityInfo = (ConnectivityInfo)this.getPhoneNetworkState().getValue();
                    if (connectivityInfo != null && !connectivityInfo.isCellularConnected()) {
                        final ConnectivityInfo connectivityInfo2 = (ConnectivityInfo)this.getPhoneNetworkState().getValue();
                        if (connectivityInfo2 != null && connectivityInfo2.isWifiConnected()) {
                            final ConnectivityInfo connectivityInfo3 = (ConnectivityInfo)this.getPhoneNetworkState().getValue();
                            Object wifiSsid = o;
                            if (connectivityInfo3 != null) {
                                wifiSsid = connectivityInfo3.getWifiSsid();
                            }
                            if (v.e(wifiSsid, (Object)this.getDeviceConnectivityState().getSsid())) {
                                break Label_0441;
                            }
                        }
                    }
                    if (!DeviceUtils.INSTANCE.isEvoDevice(device)) {
                        value6 = LayoutType.MultiRouter.INSTANCE;
                        break Label_0445;
                    }
                }
            }
            value6 = LayoutType.SingleRouter.INSTANCE;
        }
        get_layoutType.setValue((Object)value6);
    }
    
    public final void updateUdpStability(final double udpStability) {
        this.udpStability = udpStability;
        this.udpStabilityLive.postValue((Object)udpStability);
    }
    
    public static final class Companion
    {
        private Companion() {
        }
    }
}
