package com.polaris.iot.application.device.diagnostics;

import A8.b;

public final class DeviceNetworkStateViewModel_Factory implements b
{
    public static DeviceNetworkStateViewModel_Factory create() {
        return a.a;
    }
    
    public static DeviceNetworkStateViewModel newInstance() {
        return new DeviceNetworkStateViewModel();
    }
    
    public DeviceNetworkStateViewModel get() {
        return newInstance();
    }
    
    private abstract static final class a
    {
        private static final DeviceNetworkStateViewModel_Factory a;
        
        static {
            a = new DeviceNetworkStateViewModel_Factory();
        }
    }
}
