package com.polaris.iot.application.device.diagnostics;

import androidx.lifecycle.e0;

public final class DeviceNetworkStateViewModel_HiltModules
{
    private DeviceNetworkStateViewModel_HiltModules() {
    }
    
    public abstract static class BindsModule
    {
        private BindsModule() {
        }
        
        public abstract e0 binds(final DeviceNetworkStateViewModel p0);
    }
    
    public static final class KeyModule
    {
        private KeyModule() {
        }
        
        public static boolean provide() {
            return true;
        }
    }
}
