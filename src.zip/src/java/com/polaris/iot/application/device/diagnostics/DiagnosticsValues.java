package com.polaris.iot.application.device.diagnostics;

public final class DiagnosticsValues
{
    public static final int $stable = 0;
    public static final DiagnosticsValues INSTANCE;
    public static final String errorAuthError = "auth_error";
    public static final String errorNoWifi = "no_wifi";
    public static final int warningCellularPing = 100;
    public static final int warningCellularRssi = -60;
    public static final int warningGwLoss = 10;
    public static final int warningMqttLatency = 200;
    public static final double warningUdpStability = 0.7;
    public static final int warningWifiPing = 40;
    public static final int warningWifiRssi = -60;
    
    static {
        INSTANCE = new DiagnosticsValues();
    }
    
    private DiagnosticsValues() {
    }
}
