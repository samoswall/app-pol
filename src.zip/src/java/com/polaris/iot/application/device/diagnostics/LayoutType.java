package com.polaris.iot.application.device.diagnostics;

import kotlin.jvm.internal.m;

public abstract class LayoutType
{
    public static final int $stable = 0;
    
    private LayoutType() {
    }
    
    public static final class MultiRouter extends LayoutType
    {
        public static final int $stable = 0;
        public static final MultiRouter INSTANCE;
        
        static {
            INSTANCE = new MultiRouter();
        }
        
        private MultiRouter() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof MultiRouter;
        }
        
        @Override
        public int hashCode() {
            return -1152341535;
        }
        
        @Override
        public String toString() {
            return "MultiRouter";
        }
    }
    
    public static final class PhoneOnly extends LayoutType
    {
        public static final int $stable = 0;
        public static final PhoneOnly INSTANCE;
        
        static {
            INSTANCE = new PhoneOnly();
        }
        
        private PhoneOnly() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof PhoneOnly;
        }
        
        @Override
        public int hashCode() {
            return 739786233;
        }
        
        @Override
        public String toString() {
            return "PhoneOnly";
        }
    }
    
    public static final class SingleRouter extends LayoutType
    {
        public static final int $stable = 0;
        public static final SingleRouter INSTANCE;
        
        static {
            INSTANCE = new SingleRouter();
        }
        
        private SingleRouter() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof SingleRouter;
        }
        
        @Override
        public int hashCode() {
            return 909693330;
        }
        
        @Override
        public String toString() {
            return "SingleRouter";
        }
    }
}
