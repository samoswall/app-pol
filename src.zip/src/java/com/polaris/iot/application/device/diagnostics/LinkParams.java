package com.polaris.iot.application.device.diagnostics;

import kotlin.jvm.internal.v;
import java.util.List;

public final class LinkParams
{
    public static final int $stable = 8;
    private final List<NetworkIssue> issues;
    private final LinkStatus status;
    
    public LinkParams(final List<? extends NetworkIssue> issues, final LinkStatus status) {
        v.j((Object)issues, "issues");
        v.j((Object)status, "status");
        this.issues = (List<NetworkIssue>)issues;
        this.status = status;
    }
    
    public final List<NetworkIssue> component1() {
        return this.issues;
    }
    
    public final LinkStatus component2() {
        return this.status;
    }
    
    public final LinkParams copy(final List<? extends NetworkIssue> list, final LinkStatus linkStatus) {
        v.j((Object)list, "issues");
        v.j((Object)linkStatus, "status");
        return new LinkParams(list, linkStatus);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof LinkParams)) {
            return false;
        }
        final LinkParams linkParams = (LinkParams)o;
        return v.e((Object)this.issues, (Object)linkParams.issues) && v.e((Object)this.status, (Object)linkParams.status);
    }
    
    public final List<NetworkIssue> getIssues() {
        return this.issues;
    }
    
    public final LinkStatus getStatus() {
        return this.status;
    }
    
    @Override
    public int hashCode() {
        return this.issues.hashCode() * 31 + this.status.hashCode();
    }
    
    @Override
    public String toString() {
        final List<NetworkIssue> issues = this.issues;
        final LinkStatus status = this.status;
        final StringBuilder sb = new StringBuilder();
        sb.append("LinkParams(issues=");
        sb.append((Object)issues);
        sb.append(", status=");
        sb.append((Object)status);
        sb.append(")");
        return sb.toString();
    }
}
