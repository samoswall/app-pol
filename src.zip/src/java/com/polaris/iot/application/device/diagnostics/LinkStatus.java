package com.polaris.iot.application.device.diagnostics;

import kotlin.jvm.internal.m;

public abstract class LinkStatus
{
    public static final int $stable = 0;
    
    private LinkStatus() {
    }
    
    public static final class Active extends LinkStatus
    {
        public static final int $stable = 0;
        public static final Active INSTANCE;
        
        static {
            INSTANCE = new Active();
        }
        
        private Active() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof Active;
        }
        
        @Override
        public int hashCode() {
            return -1723649121;
        }
        
        @Override
        public String toString() {
            return "Active";
        }
    }
    
    public static final class Disabled extends LinkStatus
    {
        public static final int $stable = 0;
        public static final Disabled INSTANCE;
        
        static {
            INSTANCE = new Disabled();
        }
        
        private Disabled() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof Disabled;
        }
        
        @Override
        public int hashCode() {
            return -937481003;
        }
        
        @Override
        public String toString() {
            return "Disabled";
        }
    }
    
    public static final class Error extends LinkStatus
    {
        public static final int $stable = 0;
        public static final Error INSTANCE;
        
        static {
            INSTANCE = new Error();
        }
        
        private Error() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof Error;
        }
        
        @Override
        public int hashCode() {
            return 1888200271;
        }
        
        @Override
        public String toString() {
            return "Error";
        }
    }
    
    public static final class Good extends LinkStatus
    {
        public static final int $stable = 0;
        public static final Good INSTANCE;
        
        static {
            INSTANCE = new Good();
        }
        
        private Good() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof Good;
        }
        
        @Override
        public int hashCode() {
            return 615155606;
        }
        
        @Override
        public String toString() {
            return "Good";
        }
    }
    
    public static final class Inactive extends LinkStatus
    {
        public static final int $stable = 0;
        public static final Inactive INSTANCE;
        
        static {
            INSTANCE = new Inactive();
        }
        
        private Inactive() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof Inactive;
        }
        
        @Override
        public int hashCode() {
            return -1183756604;
        }
        
        @Override
        public String toString() {
            return "Inactive";
        }
    }
    
    public static final class Warning extends LinkStatus
    {
        public static final int $stable = 0;
        public static final Warning INSTANCE;
        
        static {
            INSTANCE = new Warning();
        }
        
        private Warning() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof Warning;
        }
        
        @Override
        public int hashCode() {
            return 392728099;
        }
        
        @Override
        public String toString() {
            return "Warning";
        }
    }
}
