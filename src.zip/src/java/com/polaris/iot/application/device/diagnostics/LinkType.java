package com.polaris.iot.application.device.diagnostics;

import kotlin.jvm.internal.m;

public abstract class LinkType
{
    public static final int $stable = 0;
    
    private LinkType() {
    }
    
    public static final class DeviceRouter extends LinkType
    {
        public static final int $stable = 0;
        public static final DeviceRouter INSTANCE;
        
        static {
            INSTANCE = new DeviceRouter();
        }
        
        private DeviceRouter() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof DeviceRouter;
        }
        
        @Override
        public int hashCode() {
            return 1532471312;
        }
        
        @Override
        public String toString() {
            return "DeviceRouter";
        }
    }
    
    public static final class DeviceRouterCloud extends LinkType
    {
        public static final int $stable = 0;
        public static final DeviceRouterCloud INSTANCE;
        
        static {
            INSTANCE = new DeviceRouterCloud();
        }
        
        private DeviceRouterCloud() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof DeviceRouterCloud;
        }
        
        @Override
        public int hashCode() {
            return -262025211;
        }
        
        @Override
        public String toString() {
            return "DeviceRouterCloud";
        }
    }
    
    public static final class PhoneDevice extends LinkType
    {
        public static final int $stable = 0;
        public static final PhoneDevice INSTANCE;
        
        static {
            INSTANCE = new PhoneDevice();
        }
        
        private PhoneDevice() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof PhoneDevice;
        }
        
        @Override
        public int hashCode() {
            return -720584589;
        }
        
        @Override
        public String toString() {
            return "PhoneDevice";
        }
    }
    
    public static final class PhoneRouter extends LinkType
    {
        public static final int $stable = 0;
        public static final PhoneRouter INSTANCE;
        
        static {
            INSTANCE = new PhoneRouter();
        }
        
        private PhoneRouter() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof PhoneRouter;
        }
        
        @Override
        public int hashCode() {
            return -310560410;
        }
        
        @Override
        public String toString() {
            return "PhoneRouter";
        }
    }
    
    public static final class PhoneRouterCloud extends LinkType
    {
        public static final int $stable = 0;
        public static final PhoneRouterCloud INSTANCE;
        
        static {
            INSTANCE = new PhoneRouterCloud();
        }
        
        private PhoneRouterCloud() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof PhoneRouterCloud;
        }
        
        @Override
        public int hashCode() {
            return -288381841;
        }
        
        @Override
        public String toString() {
            return "PhoneRouterCloud";
        }
    }
}
