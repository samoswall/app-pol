package com.polaris.iot.application.device.diagnostics;

import kotlin.jvm.internal.m;

public abstract class NetworkIssue
{
    public static final int $stable = 0;
    
    private NetworkIssue() {
    }
    
    public static final class DeviceCloudLatency extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final DeviceCloudLatency INSTANCE;
        
        static {
            INSTANCE = new DeviceCloudLatency();
        }
        
        private DeviceCloudLatency() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof DeviceCloudLatency;
        }
        
        @Override
        public int hashCode() {
            return -923681095;
        }
        
        @Override
        public String toString() {
            return "DeviceCloudLatency";
        }
    }
    
    public static final class DeviceCloudOffline extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final DeviceCloudOffline INSTANCE;
        
        static {
            INSTANCE = new DeviceCloudOffline();
        }
        
        private DeviceCloudOffline() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof DeviceCloudOffline;
        }
        
        @Override
        public int hashCode() {
            return 1869250462;
        }
        
        @Override
        public String toString() {
            return "DeviceCloudOffline";
        }
    }
    
    public static final class DeviceNoConfiguration extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final DeviceNoConfiguration INSTANCE;
        
        static {
            INSTANCE = new DeviceNoConfiguration();
        }
        
        private DeviceNoConfiguration() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof DeviceNoConfiguration;
        }
        
        @Override
        public int hashCode() {
            return -1028887291;
        }
        
        @Override
        public String toString() {
            return "DeviceNoConfiguration";
        }
    }
    
    public static final class DeviceOffline extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final DeviceOffline INSTANCE;
        
        static {
            INSTANCE = new DeviceOffline();
        }
        
        private DeviceOffline() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof DeviceOffline;
        }
        
        @Override
        public int hashCode() {
            return 704320051;
        }
        
        @Override
        public String toString() {
            return "DeviceOffline";
        }
    }
    
    public static final class DeviceRouterLatency extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final DeviceRouterLatency INSTANCE;
        
        static {
            INSTANCE = new DeviceRouterLatency();
        }
        
        private DeviceRouterLatency() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof DeviceRouterLatency;
        }
        
        @Override
        public int hashCode() {
            return 2018296261;
        }
        
        @Override
        public String toString() {
            return "DeviceRouterLatency";
        }
    }
    
    public static final class DeviceRouterLoss extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final DeviceRouterLoss INSTANCE;
        
        static {
            INSTANCE = new DeviceRouterLoss();
        }
        
        private DeviceRouterLoss() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof DeviceRouterLoss;
        }
        
        @Override
        public int hashCode() {
            return 577626044;
        }
        
        @Override
        public String toString() {
            return "DeviceRouterLoss";
        }
    }
    
    public static final class DeviceRouterRssi extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final DeviceRouterRssi INSTANCE;
        
        static {
            INSTANCE = new DeviceRouterRssi();
        }
        
        private DeviceRouterRssi() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof DeviceRouterRssi;
        }
        
        @Override
        public int hashCode() {
            return 577808624;
        }
        
        @Override
        public String toString() {
            return "DeviceRouterRssi";
        }
    }
    
    public static final class DeviceUnstableUDP extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final DeviceUnstableUDP INSTANCE;
        
        static {
            INSTANCE = new DeviceUnstableUDP();
        }
        
        private DeviceUnstableUDP() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof DeviceUnstableUDP;
        }
        
        @Override
        public int hashCode() {
            return -536782755;
        }
        
        @Override
        public String toString() {
            return "DeviceUnstableUDP";
        }
    }
    
    public static final class DeviceWifiError extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final DeviceWifiError INSTANCE;
        
        static {
            INSTANCE = new DeviceWifiError();
        }
        
        private DeviceWifiError() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof DeviceWifiError;
        }
        
        @Override
        public int hashCode() {
            return 1781434435;
        }
        
        @Override
        public String toString() {
            return "DeviceWifiError";
        }
    }
    
    public static final class HotspotConnected extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final HotspotConnected INSTANCE;
        
        static {
            INSTANCE = new HotspotConnected();
        }
        
        private HotspotConnected() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof HotspotConnected;
        }
        
        @Override
        public int hashCode() {
            return 1168048052;
        }
        
        @Override
        public String toString() {
            return "HotspotConnected";
        }
    }
    
    public static final class HotspotNoConnected extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final HotspotNoConnected INSTANCE;
        
        static {
            INSTANCE = new HotspotNoConnected();
        }
        
        private HotspotNoConnected() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof HotspotNoConnected;
        }
        
        @Override
        public int hashCode() {
            return 773684275;
        }
        
        @Override
        public String toString() {
            return "HotspotNoConnected";
        }
    }
    
    public static final class NoConnection extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final NoConnection INSTANCE;
        
        static {
            INSTANCE = new NoConnection();
        }
        
        private NoConnection() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof NoConnection;
        }
        
        @Override
        public int hashCode() {
            return 1301850937;
        }
        
        @Override
        public String toString() {
            return "NoConnection";
        }
    }
    
    public static final class PhoneCellularLatency extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final PhoneCellularLatency INSTANCE;
        
        static {
            INSTANCE = new PhoneCellularLatency();
        }
        
        private PhoneCellularLatency() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof PhoneCellularLatency;
        }
        
        @Override
        public int hashCode() {
            return -282388832;
        }
        
        @Override
        public String toString() {
            return "PhoneCellularLatency";
        }
    }
    
    public static final class PhoneCellularLoss extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final PhoneCellularLoss INSTANCE;
        
        static {
            INSTANCE = new PhoneCellularLoss();
        }
        
        private PhoneCellularLoss() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof PhoneCellularLoss;
        }
        
        @Override
        public int hashCode() {
            return 480522433;
        }
        
        @Override
        public String toString() {
            return "PhoneCellularLoss";
        }
    }
    
    public static final class PhoneCloudLatency extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final PhoneCloudLatency INSTANCE;
        
        static {
            INSTANCE = new PhoneCloudLatency();
        }
        
        private PhoneCloudLatency() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof PhoneCloudLatency;
        }
        
        @Override
        public int hashCode() {
            return -1080724963;
        }
        
        @Override
        public String toString() {
            return "PhoneCloudLatency";
        }
    }
    
    public static final class PhoneCloudOffline extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final PhoneCloudOffline INSTANCE;
        
        static {
            INSTANCE = new PhoneCloudOffline();
        }
        
        private PhoneCloudOffline() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof PhoneCloudOffline;
        }
        
        @Override
        public int hashCode() {
            return 1712206594;
        }
        
        @Override
        public String toString() {
            return "PhoneCloudOffline";
        }
    }
    
    public static final class PhoneRouterLatency extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final PhoneRouterLatency INSTANCE;
        
        static {
            INSTANCE = new PhoneRouterLatency();
        }
        
        private PhoneRouterLatency() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof PhoneRouterLatency;
        }
        
        @Override
        public int hashCode() {
            return 1444903649;
        }
        
        @Override
        public String toString() {
            return "PhoneRouterLatency";
        }
    }
    
    public static final class PhoneRouterLoss extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final PhoneRouterLoss INSTANCE;
        
        static {
            INSTANCE = new PhoneRouterLoss();
        }
        
        private PhoneRouterLoss() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof PhoneRouterLoss;
        }
        
        @Override
        public int hashCode() {
            return -1804657632;
        }
        
        @Override
        public String toString() {
            return "PhoneRouterLoss";
        }
    }
    
    public static final class PhoneUDP extends NetworkIssue
    {
        public static final int $stable = 0;
        public static final PhoneUDP INSTANCE;
        
        static {
            INSTANCE = new PhoneUDP();
        }
        
        private PhoneUDP() {
            super(null);
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || o instanceof PhoneUDP;
        }
        
        @Override
        public int hashCode() {
            return 1999607853;
        }
        
        @Override
        public String toString() {
            return "PhoneUDP";
        }
    }
}
