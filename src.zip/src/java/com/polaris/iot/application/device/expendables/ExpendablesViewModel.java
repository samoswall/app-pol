package com.polaris.iot.application.device.expendables;

import com.syncleoiot.core.api.commands.CmdExpendables;
import i9.z0;
import X8.r;
import l9.H$a;
import l9.H;
import androidx.lifecycle.f0;
import i9.c0;
import java.util.Collection;
import kotlin.jvm.internal.w;
import X8.p;
import l9.g;
import l9.i;
import K8.u;
import Q8.b;
import com.syncleoiot.core.data.model.UserDeviceItem;
import P8.d;
import kotlin.coroutines.jvm.internal.l;
import X8.q;
import java.util.Iterator;
import com.syncleoiot.core.data.model.DeviceParams;
import kotlin.jvm.internal.m;
import com.syncleoiot.core.utils.LocaleUtils;
import java.util.Map;
import java.util.ArrayList;
import com.syncleoiot.core.data.model.ExpendableItem;
import com.syncleoiot.core.data.model.DeviceState;
import com.syncleoiot.core.data.model.Device;
import l9.O;
import L8.t;
import kotlin.jvm.internal.v;
import java.util.List;
import l9.M;
import com.syncleoiot.core.api.DeviceManager;
import l9.x;
import androidx.lifecycle.e0;

public final class ExpendablesViewModel extends e0
{
    public static final int $stable = 8;
    private final x _showDialog;
    private final DeviceManager deviceManager;
    private M deviceStateFlow;
    private M expendablesList;
    private final x loadingState;
    private String mac;
    private final List<String> observedDeviceStateKeys;
    private final M showDialog;
    private M userDeviceItem;
    
    public ExpendablesViewModel(final DeviceManager deviceManager) {
        v.j((Object)deviceManager, "deviceManager");
        this.deviceManager = deviceManager;
        this.observedDeviceStateKeys = (List<String>)t.e((Object)"Expendables");
        this.mac = "";
        final x a = O.a((Object)null);
        this._showDialog = a;
        this.showDialog = (M)a;
        this.deviceStateFlow = (M)O.a((Object)null);
        this.userDeviceItem = (M)O.a((Object)null);
        this.expendablesList = (M)O.a((Object)null);
        this.loadingState = O.a((Object)Boolean.TRUE);
    }
    
    public static final /* synthetic */ DeviceManager access$getDeviceManager$p(final ExpendablesViewModel expendablesViewModel) {
        return expendablesViewModel.deviceManager;
    }
    
    public static final /* synthetic */ void access$setDeviceStateFlow$p(final ExpendablesViewModel expendablesViewModel, final M deviceStateFlow) {
        expendablesViewModel.deviceStateFlow = deviceStateFlow;
    }
    
    private final List<ExpendableItem> getExpendableItems(final Device device, final DeviceState deviceState) {
        final ArrayList list = new ArrayList();
        final Object value = deviceState.get((Object)"Expendables");
        List list2;
        if (value != null && value instanceof List) {
            list2 = (List)value;
        }
        else {
            list2 = null;
        }
        final DeviceParams params = device.getParams();
        List n = null;
        Label_0088: {
            if (params != null) {
                final Object value2 = params.get((Object)"expendable_max");
                if (value2 != null) {
                    List list3;
                    if (value2 instanceof List) {
                        list3 = (List)value2;
                    }
                    else {
                        list3 = null;
                    }
                    n = list3;
                    if (list3 != null) {
                        break Label_0088;
                    }
                }
            }
            n = t.n();
        }
        final Iterator iterator = n.iterator();
        int n2 = 0;
        while (iterator.hasNext()) {
            final short shortValue = ((Number)iterator.next()).shortValue();
            final Map messages = device.getMessages();
            Map map = null;
            Label_0182: {
                if (messages != null) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append("expendable.");
                    sb.append(n2);
                    map = (Map)messages.get((Object)sb.toString());
                    if (map != null) {
                        break Label_0182;
                    }
                }
                map = null;
            }
            String string;
            if ((string = (String)LocaleUtils.INSTANCE.getLocalized(map)) == null) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("Expendable.");
                sb2.append(n2);
                string = sb2.toString();
            }
            final DeviceParams params2 = device.getParams();
            Map map2 = null;
            Label_0275: {
                if (params2 != null) {
                    final Object value3 = params2.get((Object)"icons");
                    if (value3 != null && value3 instanceof Map) {
                        map2 = (Map)value3;
                        break Label_0275;
                    }
                }
                map2 = null;
            }
            String s;
            if (map2 != null) {
                final StringBuilder sb3 = new StringBuilder();
                sb3.append("expendable.");
                sb3.append(n2);
                s = (String)map2.get((Object)sb3.toString());
            }
            else {
                s = null;
            }
            int intValue;
            if (list2 != null) {
                intValue = ((Number)list2.get(n2)).intValue();
            }
            else {
                intValue = 0;
            }
            ((List)list).add((Object)new ExpendableItem(n2, string, shortValue, s, Integer.valueOf(intValue), (String)null, 32, (m)null));
            ++n2;
        }
        return (List<ExpendableItem>)list;
    }
    
    private final void initExpandableItems() {
        this.expendablesList = i.K(i.A((g)new ExpendablesViewModel$initExpandableItems$$inlined$map.ExpendablesViewModel$initExpandableItems$$inlined$map$1(i.o(i.y((g)this.deviceStateFlow, (g)this.userDeviceItem, (q)new q(null) {
            Object A;
            int y;
            Object z;
            
            public final Object f(final DeviceState z, final UserDeviceItem a, final d d) {
                final q q = (q)new q(d) {
                    Object A;
                    int y;
                    Object z;
                };
                q.z = z;
                q.A = a;
                return q.invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(final Object o) {
                b.f();
                if (this.y == 0) {
                    K8.x.b(o);
                    return new u((Object)this.z, (Object)this.A);
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }), (p)new p(this) {
            final ExpendablesViewModel H;
            
            public final Boolean a(final u u, final u u2) {
                v.j((Object)u, "old");
                v.j((Object)u2, "new");
                final DeviceState deviceState = (DeviceState)u.c();
                final UserDeviceItem userDeviceItem = (UserDeviceItem)u.d();
                final DeviceState deviceState2 = (DeviceState)u2.c();
                final UserDeviceItem userDeviceItem2 = (UserDeviceItem)u2.d();
                DeviceState deviceState3 = deviceState;
                if (deviceState == null) {
                    deviceState3 = new DeviceState();
                }
                final Collection collection = (Collection)this.H.getObservedDeviceStateKeys();
                DeviceState deviceState4;
                if ((deviceState4 = deviceState2) == null) {
                    deviceState4 = new DeviceState();
                }
                return DeviceState.keyValuesEquals$default(deviceState3, collection, deviceState4, false, false, 12, (Object)null) || !v.e((Object)userDeviceItem, (Object)userDeviceItem2);
            }
        }), this), (P8.g)c0.b()), f0.a((e0)this), H$a.b(H.a, 0L, 0L, 3, (Object)null), (Object)t.n());
        this.loadingState.setValue((Object)Boolean.FALSE);
    }
    
    public final void closeDialogs() {
        this._showDialog.setValue((Object)null);
    }
    
    public final M getExpendablesList() {
        return this.expendablesList;
    }
    
    public final x getLoadingState() {
        return this.loadingState;
    }
    
    public final List<String> getObservedDeviceStateKeys() {
        return this.observedDeviceStateKeys;
    }
    
    public final M getShowDialog() {
        return this.showDialog;
    }
    
    public final M getUserDeviceItem() {
        return this.userDeviceItem;
    }
    
    public final z0 handleReset(final ExpendableItem expendableItem, final Device device, final r r) {
        v.j((Object)expendableItem, "item");
        v.j((Object)device, "device");
        v.j((Object)r, "sendCommand");
        return i9.i.d(f0.a((e0)this), (P8.g)c0.b(), (i9.O)null, (p)new p(device, expendableItem, r, null) {
            final ExpendableItem A;
            final r B;
            int y;
            final Device z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.z, this.A, this.B, d) {
                    final ExpendableItem A;
                    final r B;
                    int y;
                    final Device z;
                };
            }
            
            public final Object invoke(final i9.M m, final d d) {
                return ((ExpendablesViewModel$a)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(final Object o) {
                final Object f = b.f();
                final int y = this.y;
                if (y != 0) {
                    if (y != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    K8.x.b(o);
                }
                else {
                    K8.x.b(o);
                    final List e = t.e((Object)CmdExpendables.Companion.resetValue(this.z, this.A.getIndex()));
                    final r b = this.B;
                    final Boolean a = kotlin.coroutines.jvm.internal.b.a(true);
                    this.y = 1;
                    if (b.invoke((Object)e, (Object)null, (Object)a, (Object)this) == f) {
                        return f;
                    }
                }
                return K8.M.a;
            }
        }, 2, (Object)null);
    }
    
    public final void init(final String mac) {
        v.j((Object)mac, "mac");
        this.mac = mac;
        i9.i.d(f0.a((e0)this), (P8.g)null, (i9.O)null, (p)new p(this, mac, null) {
            private Object A;
            final ExpendablesViewModel B;
            final String C;
            Object y;
            int z;
            
            public final d create(final Object a, final d d) {
                final p p2 = (p)new p(this.B, this.C, d) {
                    private Object A;
                    final ExpendablesViewModel B;
                    final String C;
                    Object y;
                    int z;
                };
                p2.A = a;
                return (d)p2;
            }
            
            public final Object invoke(final i9.M m, final d d) {
                return ((ExpendablesViewModel$b)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(Object j) {
                final Object f = b.f();
                final int z = this.z;
                ExpendablesViewModel expendablesViewModel = null;
                Object i = null;
                Label_0208: {
                    ExpendablesViewModel b;
                    i9.M a;
                    if (z != 0) {
                        if (z != 1) {
                            if (z == 2) {
                                expendablesViewModel = (ExpendablesViewModel)this.A;
                                K8.x.b(j);
                                i = j;
                                break Label_0208;
                            }
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        else {
                            b = (ExpendablesViewModel)this.y;
                            a = (i9.M)this.A;
                            K8.x.b(j);
                        }
                    }
                    else {
                        K8.x.b(j);
                        a = (i9.M)this.A;
                        b = this.B;
                        final g a2 = androidx.lifecycle.l.a(ExpendablesViewModel.access$getDeviceManager$p(b).getUserDeviceItemLive(this.C));
                        this.A = a;
                        this.y = b;
                        this.z = 1;
                        j = l9.i.J(a2, a, (d)this);
                        if (j == f) {
                            return f;
                        }
                    }
                    b.setUserDeviceItem((M)j);
                    final ExpendablesViewModel b2 = this.B;
                    final g a3 = androidx.lifecycle.l.a(ExpendablesViewModel.access$getDeviceManager$p(b2).getDeviceStateLive(this.C));
                    this.A = b2;
                    this.y = null;
                    this.z = 2;
                    i = l9.i.J(a3, a, (d)this);
                    if (i == f) {
                        return f;
                    }
                    expendablesViewModel = b2;
                }
                ExpendablesViewModel.access$setDeviceStateFlow$p(expendablesViewModel, (M)i);
                this.B.initExpandableItems();
                return K8.M.a;
            }
        }, 3, (Object)null);
    }
    
    public final void setExpendablesList(final M expendablesList) {
        v.j((Object)expendablesList, "<set-?>");
        this.expendablesList = expendablesList;
    }
    
    public final void setUserDeviceItem(final M userDeviceItem) {
        v.j((Object)userDeviceItem, "<set-?>");
        this.userDeviceItem = userDeviceItem;
    }
    
    public final void showDialog(final ExpendableItem expendableItem, final Device device) {
        v.j((Object)expendableItem, "item");
        v.j((Object)device, "device");
        this._showDialog.setValue((Object)new u((Object)expendableItem, (Object)device));
    }
}
