package com.polaris.iot.application.device.expendables;

public final class ExpendablesViewModelKt
{
}
