package com.polaris.iot.application.device.expendables;

import com.syncleoiot.core.api.DeviceManager;
import I8.a;
import A8.b;

public final class ExpendablesViewModel_Factory implements b
{
    private final a deviceManagerProvider;
    
    public ExpendablesViewModel_Factory(final a deviceManagerProvider) {
        this.deviceManagerProvider = deviceManagerProvider;
    }
    
    public static ExpendablesViewModel_Factory create(final a a) {
        return new ExpendablesViewModel_Factory(a);
    }
    
    public static ExpendablesViewModel newInstance(final DeviceManager deviceManager) {
        return new ExpendablesViewModel(deviceManager);
    }
    
    public ExpendablesViewModel get() {
        return newInstance((DeviceManager)this.deviceManagerProvider.get());
    }
}
