package com.polaris.iot.application.device.expendables;

import androidx.lifecycle.e0;

public final class ExpendablesViewModel_HiltModules
{
    private ExpendablesViewModel_HiltModules() {
    }
    
    public abstract static class BindsModule
    {
        private BindsModule() {
        }
        
        public abstract e0 binds(final ExpendablesViewModel p0);
    }
    
    public static final class KeyModule
    {
        private KeyModule() {
        }
        
        public static boolean provide() {
            return true;
        }
    }
}
