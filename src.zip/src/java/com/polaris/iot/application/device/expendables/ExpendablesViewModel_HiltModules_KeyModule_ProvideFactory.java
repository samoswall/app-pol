package com.polaris.iot.application.device.expendables;

import A8.b;

public final class ExpendablesViewModel_HiltModules_KeyModule_ProvideFactory implements b
{
    public static ExpendablesViewModel_HiltModules_KeyModule_ProvideFactory create() {
        return a.a;
    }
    
    public static boolean provide() {
        return ExpendablesViewModel_HiltModules.KeyModule.provide();
    }
    
    public Boolean get() {
        return provide();
    }
    
    private abstract static final class a
    {
        private static final ExpendablesViewModel_HiltModules_KeyModule_ProvideFactory a;
        
        static {
            a = new ExpendablesViewModel_HiltModules_KeyModule_ProvideFactory();
        }
    }
}
