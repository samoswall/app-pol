package com.polaris.iot.application.device.featurechart;

import androidx.lifecycle.E;
import java.text.DateFormat;
import R8.b;
import R8.a;
import java.util.Iterator;
import com.syncleoiot.core.data.DeviceFeature;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;
import okhttp3.Callback;
import com.syncleoiot.tools.logwriter.Log;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;
import K8.s;
import com.syncleoiot.core.domain.device.DataType;
import java.util.Calendar;
import L8.P;
import kotlin.jvm.internal.v;
import java.util.concurrent.TimeUnit;
import kotlin.jvm.internal.m;
import androidx.lifecycle.J;
import com.syncleoiot.core.api.ApiService;
import androidx.lifecycle.e0;

public final class FeatureChartViewModel extends e0
{
    public static final int $stable;
    public static final Companion Companion;
    private static final long DAY_INTERVAL;
    private static final long MOUTH_INTERVAL;
    private static final String TAG;
    private static final long WEEK_INTERVAL;
    private static final long YEAR_INTERVAL;
    private final ApiService apiService;
    private final J chartsData;
    private final J loadingState;
    private final J selectedDataTypes;
    private String token;
    
    static {
        String simpleName = null;
        final Companion companion = Companion = new Companion(null);
        $stable = 8;
        DAY_INTERVAL = TimeUnit.HOURS.toMillis(1L);
        final TimeUnit days = TimeUnit.DAYS;
        WEEK_INTERVAL = days.toMillis(1L);
        MOUTH_INTERVAL = days.toMillis(1L);
        YEAR_INTERVAL = days.toMillis(7L);
        final Class<?> enclosingClass = companion.getClass().getEnclosingClass();
        if (enclosingClass != null) {
            simpleName = enclosingClass.getSimpleName();
        }
        String tag;
        if ((tag = simpleName) == null) {
            tag = "TAG";
        }
        TAG = tag;
    }
    
    public FeatureChartViewModel(final ApiService apiService) {
        v.j((Object)apiService, "apiService");
        this.apiService = apiService;
        this.chartsData = new J((Object)P.j());
        this.selectedDataTypes = new J((Object)P.j());
        this.loadingState = new J((Object)LoadingState.IDLE);
        this.token = "";
    }
    
    private final long getCurrentTimeRounded() {
        final Calendar instance = Calendar.getInstance();
        final int n = instance.get(12) % 15;
        int n2;
        if (n < 8) {
            n2 = -n;
        }
        else {
            n2 = 15 - n;
        }
        instance.add(12, n2);
        instance.set(14, 0);
        instance.set(13, 0);
        return instance.getTimeInMillis();
    }
    
    public final ApiService getApiService() {
        return this.apiService;
    }
    
    public final J getChartsData() {
        return this.chartsData;
    }
    
    public final J getLoadingState() {
        return this.loadingState;
    }
    
    public final J getSelectedDataTypes() {
        return this.selectedDataTypes;
    }
    
    public final String getToken() {
        return this.token;
    }
    
    public final void init(final String token) {
        v.j((Object)token, "deviceToken");
        this.token = token;
    }
    
    public final void loadChartData(final String s, final DataType dataType) {
        v.j((Object)s, "feature");
        v.j((Object)dataType, "period");
        final int n = WhenMappings.$EnumSwitchMapping$0[((Enum)dataType).ordinal()];
        long n2;
        long n3;
        if (n != 1) {
            if (n != 2) {
                if (n != 3) {
                    if (n != 4) {
                        throw new s();
                    }
                    n2 = FeatureChartViewModel.YEAR_INTERVAL;
                    n3 = TimeUnit.DAYS.toMillis(365L);
                }
                else {
                    n2 = FeatureChartViewModel.MOUTH_INTERVAL;
                    n3 = TimeUnit.DAYS.toMillis(30L);
                }
            }
            else {
                n2 = FeatureChartViewModel.WEEK_INTERVAL;
                n3 = TimeUnit.DAYS.toMillis(7L);
            }
        }
        else {
            n2 = FeatureChartViewModel.DAY_INTERVAL;
            n3 = TimeUnit.HOURS.toMillis(24L);
        }
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd:HH:mm", Locale.getDefault());
        final long currentTimeRounded = this.getCurrentTimeRounded();
        final long n4 = currentTimeRounded - n3;
        final String tag = FeatureChartViewModel.TAG;
        final String format = ((DateFormat)simpleDateFormat).format(new Date(n4));
        final String format2 = ((DateFormat)simpleDateFormat).format(new Date(currentTimeRounded));
        final String format3 = ((DateFormat)simpleDateFormat).format(new Date(System.currentTimeMillis()));
        final StringBuilder sb = new StringBuilder();
        sb.append("startTime = ");
        sb.append(format);
        sb.append(", currentTimeRounded = ");
        sb.append(format2);
        sb.append(", currentTime ");
        sb.append(format3);
        Log.e(tag, sb.toString());
        this.loadingState.setValue((Object)LoadingState.LOADING);
        this.apiService.getFeatureChartData(n4, currentTimeRounded, n2 / 1000, s, this.token, (Callback)new FeatureChartViewModel$loadChartData.FeatureChartViewModel$loadChartData$1(this, s));
    }
    
    public final void setDataType(final String s, final DataType dataType) {
        v.j((Object)s, "featureString");
        v.j((Object)dataType, "dataType");
        final Map map = (Map)((E)this.selectedDataTypes).getValue();
        Object x;
        if (map == null || (x = P.x(map)) == null) {
            x = new LinkedHashMap();
        }
        this.loadChartData(s, dataType);
        ((Map)x).put((Object)s, (Object)dataType);
        this.selectedDataTypes.postValue(x);
    }
    
    public final void setToken(final String token) {
        v.j((Object)token, "<set-?>");
        this.token = token;
    }
    
    public final void updateAllCharts(final List<? extends DeviceFeature> list) {
        v.j((Object)list, "featuresList");
        for (final DeviceFeature deviceFeature : (Iterable)list) {
            final Map map = (Map)((E)this.selectedDataTypes).getValue();
            DataType day;
            if (map == null || (day = (DataType)map.get((Object)((Enum)deviceFeature).name())) == null) {
                day = DataType.DAY;
            }
            this.loadChartData(((Enum)deviceFeature).name(), day);
        }
    }
    
    public static final class Companion
    {
        private Companion() {
        }
    }
    
    public enum LoadingState
    {
        private static final a $ENTRIES;
        private static final LoadingState[] $VALUES;
        
        IDLE, 
        LOADING;
        
        private static final /* synthetic */ LoadingState[] $values() {
            return new LoadingState[] { LoadingState.LOADING, LoadingState.IDLE };
        }
        
        static {
            $ENTRIES = b.a((Enum[])($VALUES = $values()));
        }
        
        public static a getEntries() {
            return LoadingState.$ENTRIES;
        }
    }
}
