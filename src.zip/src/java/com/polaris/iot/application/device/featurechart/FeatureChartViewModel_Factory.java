package com.polaris.iot.application.device.featurechart;

import com.syncleoiot.core.api.ApiService;
import I8.a;
import A8.b;

public final class FeatureChartViewModel_Factory implements b
{
    private final a apiServiceProvider;
    
    public FeatureChartViewModel_Factory(final a apiServiceProvider) {
        this.apiServiceProvider = apiServiceProvider;
    }
    
    public static FeatureChartViewModel_Factory create(final a a) {
        return new FeatureChartViewModel_Factory(a);
    }
    
    public static FeatureChartViewModel newInstance(final ApiService apiService) {
        return new FeatureChartViewModel(apiService);
    }
    
    public FeatureChartViewModel get() {
        return newInstance((ApiService)this.apiServiceProvider.get());
    }
}
