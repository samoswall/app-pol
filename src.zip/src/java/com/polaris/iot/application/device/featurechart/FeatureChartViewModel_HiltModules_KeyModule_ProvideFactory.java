package com.polaris.iot.application.device.featurechart;

import A8.b;

public final class FeatureChartViewModel_HiltModules_KeyModule_ProvideFactory implements b
{
    public static FeatureChartViewModel_HiltModules_KeyModule_ProvideFactory create() {
        return a.a;
    }
    
    public static boolean provide() {
        return FeatureChartViewModel_HiltModules.KeyModule.provide();
    }
    
    public Boolean get() {
        return provide();
    }
    
    private abstract static final class a
    {
        private static final FeatureChartViewModel_HiltModules_KeyModule_ProvideFactory a;
        
        static {
            a = new FeatureChartViewModel_HiltModules_KeyModule_ProvideFactory();
        }
    }
}
