package com.polaris.iot.application.device.history;

import l9.w;
import h9.a;
import h9.c;
import com.syncleoiot.core.domain.core.network.Status;
import com.syncleoiot.core.domain.core.network.NetworkState;
import java.util.Iterator;
import com.syncleoiot.core.data.model.DeviceHistory;
import com.syncleoiot.core.data.model.HistoryItem;
import com.syncleoiot.core.domain.device.history.HistoryRepositoryKt;
import K8.u;
import com.syncleoiot.core.data.model.DeviceParams;
import com.syncleoiot.core.data.model.Device;
import L8.P;
import l9.H$a;
import l9.H;
import P8.g;
import i9.i;
import Q8.b;
import P8.d;
import kotlin.coroutines.jvm.internal.l;
import X8.p;
import i9.c0;
import androidx.lifecycle.f0;
import java.util.concurrent.CancellationException;
import i9.z0$a;
import l9.O;
import L8.t;
import kotlin.jvm.internal.v;
import com.syncleoiot.core.data.model.UserDeviceItem;
import l9.x;
import i9.z0;
import java.util.Map;
import java.util.List;
import com.syncleoiot.core.domain.device.history.HistoryRepository;
import l9.M;
import com.syncleoiot.core.api.DeviceManager;
import com.syncleoiot.core.api.ApiService;
import androidx.lifecycle.e0;

public final class HistoryViewModel extends e0
{
    public static final int $stable = 8;
    private final ApiService apiService;
    private final DeviceManager deviceManager;
    private String graph;
    public M historyItems;
    private final HistoryRepository historyRepository;
    private List<? extends Map<String, String>> historyRules;
    public M loading;
    private z0 loadingJob;
    private final x scrollUp;
    private UserDeviceItem userDeviceItem;
    
    public HistoryViewModel(final ApiService apiService, final HistoryRepository historyRepository, final DeviceManager deviceManager) {
        v.j((Object)apiService, "apiService");
        v.j((Object)historyRepository, "historyRepository");
        v.j((Object)deviceManager, "deviceManager");
        this.apiService = apiService;
        this.historyRepository = historyRepository;
        this.deviceManager = deviceManager;
        this.historyRules = (List<? extends Map<String, String>>)t.n();
        this.scrollUp = O.a((Object)0L);
    }
    
    public static final /* synthetic */ HistoryRepository access$getHistoryRepository$p(final HistoryViewModel historyViewModel) {
        return historyViewModel.historyRepository;
    }
    
    public final void cancelLoading() {
        final z0 loadingJob = this.loadingJob;
        if (loadingJob != null && loadingJob.isActive()) {
            z0$a.b(loadingJob, (CancellationException)null, 1, (Object)null);
        }
        this.loadingJob = null;
    }
    
    public final void deleteHistoryItem(final long n) {
        if (this.userDeviceItem == null) {
            return;
        }
        this.loadingJob = i.d(f0.a((e0)this), (g)c0.b(), (i9.O)null, (p)new p(this, n, null) {
            final long A;
            int y;
            final HistoryViewModel z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.z, this.A, d) {
                    final long A;
                    int y;
                    final HistoryViewModel z;
                };
            }
            
            public final Object invoke(final i9.M m, final d d) {
                return ((HistoryViewModel$a)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(final Object o) {
                final Object f = b.f();
                final int y = this.y;
                if (y != 0) {
                    if (y != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    K8.x.b(o);
                }
                else {
                    K8.x.b(o);
                    final HistoryRepository access$getHistoryRepository$p = HistoryViewModel.access$getHistoryRepository$p(this.z);
                    final long a = this.A;
                    this.y = 1;
                    if (access$getHistoryRepository$p.deleteHistory(a, (d)this) == f) {
                        return f;
                    }
                }
                return K8.M.a;
            }
        }, 2, (Object)null);
    }
    
    public final ApiService getApiService() {
        return this.apiService;
    }
    
    public final String getGraph() {
        return this.graph;
    }
    
    public final M getHistoryItems() {
        final M historyItems = this.historyItems;
        if (historyItems != null) {
            return historyItems;
        }
        v.A("historyItems");
        return null;
    }
    
    public final List<Map<String, String>> getHistoryRules() {
        return (List<Map<String, String>>)this.historyRules;
    }
    
    public final M getLoading() {
        final M loading = this.loading;
        if (loading != null) {
            return loading;
        }
        v.A("loading");
        return null;
    }
    
    public final x getScrollUp() {
        return this.scrollUp;
    }
    
    public final UserDeviceItem getUserDeviceItem() {
        return this.userDeviceItem;
    }
    
    public final void init(String graph) {
        v.j((Object)graph, "mac");
        final UserDeviceItem userDeviceItem = this.deviceManager.getUserDeviceItem(graph);
        if (!v.e((Object)this.userDeviceItem, (Object)userDeviceItem)) {
            if (userDeviceItem != null) {
                this.historyRepository.init(userDeviceItem);
                this.userDeviceItem = userDeviceItem;
                final l9.g n = l9.i.n(l9.i.l(l9.i.A(this.historyRepository.getLoadingState(), (g)c0.b())));
                final i9.M a = f0.a((e0)this);
                final H$a a2 = H.a;
                final H b = H$a.b(a2, 0L, 0L, 3, (Object)null);
                final String s = null;
                this.setLoading(l9.i.K(n, a, b, (Object)null));
                this.setHistoryItems(l9.i.K(l9.i.n(l9.i.l(l9.i.A(this.historyRepository.watchHistoryChanges(), (g)c0.b()))), f0.a((e0)this), H$a.b(a2, 0L, 0L, 3, (Object)null), (Object)null));
                final Device device = userDeviceItem.getDevice();
                DeviceParams params;
                if (device != null) {
                    params = device.getParams();
                }
                else {
                    params = null;
                }
                Map j = null;
                Label_0214: {
                    if (params != null) {
                        final Object value = params.get((Object)"history");
                        if (value != null) {
                            Map map;
                            if (value instanceof Map) {
                                map = (Map)value;
                            }
                            else {
                                map = null;
                            }
                            j = map;
                            if (map != null) {
                                break Label_0214;
                            }
                        }
                    }
                    j = P.j();
                }
                final Object value2 = j.get((Object)"values");
                List historyRules;
                if (value2 != null && value2 instanceof List) {
                    historyRules = (List)value2;
                }
                else {
                    historyRules = null;
                }
                this.historyRules = (List<? extends Map<String, String>>)historyRules;
                final Object value3 = j.get((Object)"graph");
                graph = s;
                if (value3 != null) {
                    Map map2;
                    if (value3 instanceof Map) {
                        map2 = (Map)value3;
                    }
                    else {
                        map2 = null;
                    }
                    graph = s;
                    if (map2 != null) {
                        graph = (String)map2.get((Object)"value");
                    }
                }
                this.graph = graph;
            }
        }
    }
    
    public final void loadHistory(final Long n) {
        this.loadingJob = i.d(f0.a((e0)this), (g)c0.b(), (i9.O)null, (p)new p(this, n, null) {
            final HistoryViewModel A;
            final Long B;
            long y;
            int z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.A, this.B, d) {
                    final HistoryViewModel A;
                    final Long B;
                    long y;
                    int z;
                };
            }
            
            public final Object invoke(final i9.M m, final d d) {
                return ((HistoryViewModel$b)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(Object o) {
                final Object f = b.f();
                final int z = this.z;
                final long n = 0L;
                final Object o2 = null;
                long y = 0L;
                if (z != 0) {
                    if (z != 1) {
                        if (z == 2) {
                            K8.x.b(o);
                            return K8.M.a;
                        }
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    else {
                        y = this.y;
                        K8.x.b(o);
                    }
                }
                else {
                    K8.x.b(o);
                    final u u = (u)this.A.getHistoryItems().getValue();
                    Label_0233: {
                        if (u != null) {
                            final DeviceHistory history = HistoryRepositoryKt.getHistory(u);
                            if (history != null) {
                                final List data = history.getData();
                                if (data != null) {
                                    final Iterator iterator = ((Iterable)data).iterator();
                                    if (!iterator.hasNext()) {
                                        o = null;
                                    }
                                    else {
                                        o = iterator.next();
                                        if (iterator.hasNext()) {
                                            long timestamp = ((HistoryItem)o).getTimestamp();
                                            Object o3 = o;
                                            do {
                                                final Object next = iterator.next();
                                                final long timestamp2 = ((HistoryItem)next).getTimestamp();
                                                o = o3;
                                                long n2 = timestamp;
                                                if (timestamp < timestamp2) {
                                                    o = next;
                                                    n2 = timestamp2;
                                                }
                                                o3 = o;
                                                timestamp = n2;
                                            } while (iterator.hasNext());
                                        }
                                    }
                                    final HistoryItem historyItem = (HistoryItem)o;
                                    if (historyItem != null) {
                                        y = historyItem.getTimestamp();
                                        break Label_0233;
                                    }
                                }
                            }
                        }
                        y = 0L;
                    }
                    final HistoryRepository access$getHistoryRepository$p = HistoryViewModel.access$getHistoryRepository$p(this.A);
                    final Long b = this.B;
                    this.y = y;
                    this.z = 1;
                    if (access$getHistoryRepository$p.loadHistory(b, (d)this) == f) {
                        return f;
                    }
                }
                final u u2 = (u)this.A.getHistoryItems().getValue();
                long timestamp3 = n;
                if (u2 != null) {
                    final DeviceHistory history2 = HistoryRepositoryKt.getHistory(u2);
                    timestamp3 = n;
                    if (history2 != null) {
                        final List data2 = history2.getData();
                        timestamp3 = n;
                        if (data2 != null) {
                            final Iterator iterator2 = ((Iterable)data2).iterator();
                            if (!iterator2.hasNext()) {
                                o = o2;
                            }
                            else {
                                o = iterator2.next();
                                if (iterator2.hasNext()) {
                                    long timestamp4 = ((HistoryItem)o).getTimestamp();
                                    Object o4 = o;
                                    do {
                                        final Object next2 = iterator2.next();
                                        final long timestamp5 = ((HistoryItem)next2).getTimestamp();
                                        o = o4;
                                        long n3 = timestamp4;
                                        if (timestamp4 < timestamp5) {
                                            o = next2;
                                            n3 = timestamp5;
                                        }
                                        o4 = o;
                                        timestamp4 = n3;
                                    } while (iterator2.hasNext());
                                }
                            }
                            final HistoryItem historyItem2 = (HistoryItem)o;
                            timestamp3 = n;
                            if (historyItem2 != null) {
                                timestamp3 = historyItem2.getTimestamp();
                            }
                        }
                    }
                }
                if (timestamp3 > y) {
                    final x scrollUp = this.A.getScrollUp();
                    final Long f2 = kotlin.coroutines.jvm.internal.b.f(timestamp3);
                    this.z = 2;
                    if (((w)scrollUp).emit((Object)f2, (d)this) == f) {
                        return f;
                    }
                }
                return K8.M.a;
            }
        }, 2, (Object)null);
    }
    
    public final void loadMoreHistory() {
        final z0 loadingJob = this.loadingJob;
        if (loadingJob != null && !loadingJob.isCompleted()) {
            return;
        }
        this.loadingJob = i.d(f0.a((e0)this), (g)c0.b(), (i9.O)null, (p)new p(this, null) {
            int y;
            final HistoryViewModel z;
            
            public final d create(final Object o, final d d) {
                return (d)new p(this.z, d) {
                    int y;
                    final HistoryViewModel z;
                };
            }
            
            public final Object invoke(final i9.M m, final d d) {
                return ((HistoryViewModel$c)this.create(m, d)).invokeSuspend(K8.M.a);
            }
            
            public final Object invokeSuspend(final Object o) {
                final Object f = b.f();
                final int y = this.y;
                if (y != 0) {
                    if (y != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    K8.x.b(o);
                }
                else {
                    K8.x.b(o);
                    final HistoryRepository access$getHistoryRepository$p = HistoryViewModel.access$getHistoryRepository$p(this.z);
                    this.y = 1;
                    if (access$getHistoryRepository$p.loadNextPage((d)this) == f) {
                        return f;
                    }
                }
                return K8.M.a;
            }
        }, 2, (Object)null);
    }
    
    public final void refreshIfErrorOrEmpty(final Long n) {
        final z0 loadingJob = this.loadingJob;
        if (loadingJob != null && !loadingJob.isCompleted()) {
            return;
        }
        final Object value = this.getLoading().getValue();
        final Long n2 = null;
        if (value != null) {
            final NetworkState networkState = (NetworkState)this.getLoading().getValue();
            Status status;
            if (networkState != null) {
                status = networkState.getStatus();
            }
            else {
                status = null;
            }
            if (status != Status.FAILED) {
                return;
            }
        }
        Long value2 = n2;
        if (n != null) {
            value2 = System.currentTimeMillis() - a.q(c.t(((Number)n).longValue(), h9.d.HOURS));
        }
        this.loadHistory(value2);
    }
    
    public final void setGraph(final String graph) {
        this.graph = graph;
    }
    
    public final void setHistoryItems(final M historyItems) {
        v.j((Object)historyItems, "<set-?>");
        this.historyItems = historyItems;
    }
    
    public final void setHistoryRules(final List<? extends Map<String, String>> historyRules) {
        this.historyRules = historyRules;
    }
    
    public final void setLoading(final M loading) {
        v.j((Object)loading, "<set-?>");
        this.loading = loading;
    }
}
